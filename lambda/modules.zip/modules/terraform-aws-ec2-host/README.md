# Anthem AWS Dedicated Host Service

This module will creates a Dedicated Host.

## Pre-requisite

- Conditional resource creation is enabled with "create_ec2_host" variable, setting this variable to "true" will create the resource and setting this to "false" will skip the resource creation.
- Availability zone ,instance type ,host recovery and auto placement parameters are mandatory.
- Once the dedicated host is created it can be destroyed after a timeperiod of 24 hours. 

## Mandatory Tags Note:
*	As per redesigned new mandatory tags, mandatory tags along with any additional tags have to be added through template configuration within the modules as below
*	Have a reference of mandatory tags module within the template configuration as shown in example script below.
```bash
# Mandatory Tag Workspace Variables
variable "apm-id" {}
variable "application-name" {}
variable "app-support-dl" {}
variable "app-servicenow-group" {}
variable "business-division" {}
variable "company" {}
variable "compliance" {}
variable "costcenter" {}
variable "environment" {}
variable "PatchGroup" {}
variable "PatchWindow" {}
variable "ATLAS_WORKSPACE_NAME" {}

# Mandatory Tags Module 
module "mandatory_tags" {
  source               = "cps-terraform.anthem.com/<ORG_NAME>/terraform-aws-mandatory-tags-v2/aws"
  tags                 = {}
  apm-id               = var.apm-id
  application-name     = var.application-name
  app-support-dl       = var.app-support-dl
  app-servicenow-group = var.app-servicenow-group
  business-division    = var.business-division
  compliance           = var.compliance
  company              = var.company
  costcenter           = var.costcenter
  environment          = var.environment
  PatchGroup           = var.PatchGroup
  PatchWindow          = var.PatchWindow
  workspace            = var.ATLAS_WORKSPACE_NAME
}
```
*	Mandatory tags module should be referred in tags attribute as below:
tags = module.mandatory_tags.tags
*	Any additional tags can be merged to tags attribute as below:
tags = merge(module.mandatory_tags.tags, {"sample" = "abc"})

## Usage
To run this example you need to execute:

```bash
#Example script
module "terraform-aws-ec2-host" {
  source  = "cps-terraform.anthem.com/<ORGANIZATION NAME>/terraform-aws-ec2-host/aws"
 
  tags = merge(module.mandatory_tags.tags)

  /******** Parameter required for resource creation ****/

  instance_type     = ""
  availability_zone = ""
  host_recovery     = ""
  auto_placement    = ""

}

#Initialize Terraform
terraform init

#Terraform Dry-Run
terraform plan

#Create the resources
terraform apply

#Destroy the resources saved in the tfstate
terraform destroy
```

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| auto\_placement | (Optional) "Default : "on" ". Indicates whether the host accepts any untargeted instance launches that match its instance type configuration, or if it only accepts Host tenancy instance launches that specify its unique host ID. Valid values: on, off. Default: on. | `string` | `"on"` | no |
| availability\_zone | (Required) The Availability Zone in which you want to create the Capacity Reservation. | `string` | n/a | yes |
| create\_ec2\_host | (Optional) "Default : true". Need to create a new capacity reservation Ec2 instance True or False | `bool` | `true` | no |
| host\_recovery | (Optional) "Default : "off" ". Indicates whether to enable or disable host recovery for the Dedicated Host. Valid values: on, off. Default: off. | `string` | `"off"` | no |
| instance\_type | (Optional) "Default : "t2.medium" ". The Instance type that Needs to be created for capacity reservation. | `string` | `"t2.medium"` | no |
| tags | (Required) A mapping of tags to assign to all resources. | `map(string)` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| arn | The ARN of the Dedicated Host. |
| id | The ID of the allocated Dedicated Host. |
| owner\_id | The ID of the AWS account that owns the Dedicated Host. |
| tags\_all | Tags attatched to the Ec2 Host |

## Testing

1. Created a Dedicated Host service. 
2. Able to see the snapshot of the volume in AWS console.

