## Anthem ECR Terraform Module

This module creates an ECR Repository using Terraform

## HIPAA eligibility status

1. Amazon Elastic Container Registry (ECR)


## Security Guardrail reference

[AWS Security Pattern](https://confluence.anthem.com/download/attachments/299009562/Anthem%20AWS%20Security%20Patterns%20-%20ECR%20-%20v1.docx?api=v2)

## Pre-Requisite

- Name of the repository is mandatory.
- At-rest encryption is implemented and enforced in the code.
- scan on push is set to true by default. Can override if need.
- image_tag_mutability is set to mutable.
- Conditional resource creation is enabled with "create_ecr_repository" variable, setting this variable to "true" will create the resource and setting this to "false" will skip the resource creation.

## Mandatory Tags Note:
*	As per redesigned new mandatory tags, mandatory tags along with any additional tags have to be added through template configuration within the modules as below
*	Have a reference of mandatory tags module within the template configuration as shown in example script below.
```bash
# Mandatory Tag Workspace Variables
variable "apm-id" {}
variable "application-name" {}
variable "app-support-dl" {}
variable "app-servicenow-group" {}
variable "business-division" {}
variable "company" {}
variable "compliance" {}
variable "costcenter" {}
variable "environment" {}
variable "PatchGroup" {}
variable "PatchWindow" {}
variable "ATLAS_WORKSPACE_NAME" {}

# Mandatory Tags Module 
module "mandatory_tags" {
  source               = "cps-terraform.anthem.com/<ORG_NAME>/terraform-aws-mandatory-tags-v2/aws"
  tags                 = {}
  apm-id               = var.apm-id
  application-name     = var.application-name
  app-support-dl       = var.app-support-dl
  app-servicenow-group = var.app-servicenow-group
  business-division    = var.business-division
  compliance           = var.compliance
  company              = var.company
  costcenter           = var.costcenter
  environment          = var.environment
  PatchGroup           = var.PatchGroup
  PatchWindow          = var.PatchWindow
  workspace            = var.ATLAS_WORKSPACE_NAME
}
```
*	Mandatory tags module should be referred in tags attribute as below:
tags = module.mandatory_tags.tags
*	Any additional tags can be merged to tags attribute as below:
tags = merge(module.mandatory_tags.tags, {"sample" = "abc"})


## Usage
To run this example you need to execute:

```bash

# Example Script

module "ecrexample" {

source = "cps-terraform.anthem.com/<ORGANIZATION NAME>/terraform-aws-ecr/aws"

tags = merge(module.mandatory_tags.tags)

ecr_repo_name        = ["test1","test2"]
role_name          = "slvr-scapp1-devrole"
}

#Initialize Terraform
terraform init

#Terraform Dry-Run
terraform plan

#Create the resources
terraform apply

#Destroy the resources saved in the tfstate
terraform destroy
```

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| create\_ecr\_repository | (Optional) "Default : true". A Boolean that indicates whether to create an ecr repository or not. Default is set to true | `bool` | `true` | no |
| ecr\_repo\_name | (Required) Name of the repository. | `set(string)` | n/a | yes |
| image\_tag\_mutability | (Optional) "Default : "MUTABLE" ". The tag mutability setting for the repository. Must be one of: MUTABLE or IMMUTABLE. Defaults to MUTABLE. | `string` | `"MUTABLE"` | no |
| kms\_key | (Required) The ARN of the customer managed CMK for ECR. | `string` | n/a | yes |
| lifecyclepolicy | (Optional) "Default : null". The policy document. This is a JSON formatted string. | `string` | `null` | no |
| role\_name | (Required) Role name of the account | `string` | n/a | yes |
| scan\_on\_push | (Optional) "Default : true". Indicates whether images are scanned after being pushed to the repository (true) or not scanned (false). | `bool` | `true` | no |
| tags | (Required) A mapping of tags to assign to all resources. | `map(string)` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| arn | n/a |
| ecr\_policy\_registry\_id | The registry ID where the repository was created. |
| ecr\_policy\_repository | The name of the repository. |
| ecr\_registry\_id | The registry ID where the repository was created. |
| ecr\_repopolicy\_registry\_id | The registry ID where the repository was created. |
| ecr\_repopolicy\_repository | The name of the repository. |
| ecr\_repository\_url | The URL of the repository (in the form aws\_account\_id.dkr.ecr.region.amazonaws.com/repositoryName) |
| name | n/a |

## Testing 

- Able to see the repository registration and url in console.
- The repository and registration policies were created succesfully.
- Able to create multiple repositories at once.

