#############################
# Anthem AWS S3 Object Push Module 

This module is used to push objects to S3 bucket

## HIPAA eligibility status
   1.Amazon Simple Storage Service (Amazon S3) [including S3 Transfer Acceleration] is eligible.

## Security Guardrail reference
[security pattern](https://confluence.anthem.com/pages/viewpageattachments.action?pageId=299009562&sortBy=date&startIndex=100&preview=/299009562/331420436/Anthem%20AWS%20Security%20Patterns%20-%20S3%20-%20Final-v1.4.docx)


## Pre-Requisites

* A valid KMS key ID for encryption at rest.
* At-rest encryption is implemented and enforced in the code. Valid Customer Managed Key (CMK) is required.
* Before creating this module,we need to have s3 bucket created.
* Tags should not be greater than 10 while creating object.
* To create a folder need to pass the value (key= ["<folder name>/"])
* To push the object into already exists folder neeed to pass the value (key= ["<folder name>/file name"]).
* To upload a file need to pass the value "NAME OF THE FILE".
* Source_file_name and source_hash parameters does not required to create folder.
* Conditional resource creation is enabled with "create_s3_object" variable, setting this variable to "true"  will create the resource and setting this to "false" will skip the resource creation.
* source_file_name and source_hash conflicts with content paramaters

## NOTE

* s3 bucket object has a limitation of adding only 10 tags. so required mandatory tags are included in the module.

## Usage

To run this example you need to execute:

```bash
1)
module "terraform_aws_s3_bucket_object" {
  source = "cps-terraform.anthem.com/<ORGANIZATION NAME>/terraform-aws-s3-bucket-object/aws"

  application-name      = ""
  company               = ""
  compliance            = ""
  costcenter            = ""
  business-division     = ""

  bucket           = ""
  key              = ["<FILE NAME>"]
  kms_key_id       = ""
  source_file_name = ""
  source_hash     = filemd5("<FILE NAME>")
}

2)
module "terraform_aws_s3_bucket_object1" {
  source = "cps-terraform.anthem.com/<ORGANIZATION NAME>/terraform-aws-s3-bucket-object/aws"

  application-name      = ""
  company               = ""
  compliance            = ""
  costcenter            = ""
  business-division     = ""

  bucket           = ""
  key              = ["test.utf8"]
  kms_key_id       = module.antm_silver_account_s3_kms.kms_arn["s3"]
  content = "./test.utf8"
  content_type = filemd5("test.utf8")
  
}

#Initialize Terraform
terraform init

#Terraform Dry-Run
terraform plan

#Create the resources
terraform apply

#Destroy the resources saved in the tfstate
terraform destroy
```

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| application-name | Based upon application nomenclature in server naming convention policy.Use up to six (6) characters to name your application. | `string` | n/a | yes |
| bucket | The name of the bucket to put the file in. | `string` | n/a | yes |
| business-division | business division | `string` | n/a | yes |
| company | Company that owns resource | `string` | n/a | yes |
| compliance | PHI, PCI, PII, SOX, None | `string` | n/a | yes |
| content | (Optional, conflicts with source and content\_base64) Literal string value to use as the object content, which will be uploaded as UTF-8-encoded text. | `string` | `null` | no |
| content\_base64 | (Optional, conflicts with source and content) Base64-encoded data that will be decoded and uploaded as raw bytes for the object content. This allows safely uploading non-UTF8 binary data, but is recommended only for small content such as the result of the gzipbase64 function with small text strings. For larger objects, use source to stream the content from a disk file. | `string` | `null` | no |
| content\_disposition | Presentational information for the object. | `string` | `null` | no |
| content\_encoding | Content encodings that have been applied to the object and thus what decoding mechanisms must be applied to obtain the media-type referenced by the Content-Type header field. Read http://www.w3.org/Protocols/rfc2616/rfc2616-sec14.html#sec14.11 for further information. | `string` | `null` | no |
| content\_language | Language the content is in e.g., en-US or en-GB. | `string` | `null` | no |
| content\_type | Standard MIME type describing the format of the object data, e.g., application/octet-stream. All Valid MIME Types are valid for this input. | `string` | `null` | no |
| costcenter | The project cost center. | `number` | n/a | yes |
| create\_s3\_object | A boolean which validates whether to create an S3 bucket object or not | `bool` | `true` | no |
| key | The name of the object once it is in the bucket. | `list(any)` | n/a | yes |
| kms\_key\_id | Specifies the AWS KMS Key ARN to use for object encryption. This value is a fully qualified ARN of the KMS Key. If using aws\_kms\_key, use the exported arn attribute: kms\_key\_id | `string` | n/a | yes |
| source\_file\_name | (Required unless content or content\_base64 is set) The path to a file that will be read and uploaded as raw bytes for the object content. | `string` | `""` | no |
| source\_hash | Triggers updates of the object | `string` | `""` | no |

## Outputs

| Name | Description |
|------|-------------|
| id | the key of the resource supplied above |
| tags\_all | the key of the resource supplied above |
| version\_id | A unique version ID value for the object, if bucket versioning is enabled. |


## Testing

* Able to create module successfully.
* Able to see objects pushed under specified s3 bucket.Tested with diffreent formats of file like zip,csv and py.
* Able to create multiple folders at once.
* Able to update the object when the value changes.
