# Anthem AWS API Gateway Model Module

This module Provides a Model for a REST API Gateway.

## HIPAA eligibility status

1. Amazon API Gateway is eligible

## Security Guardrail reference

https://confluence.anthem.com/pages/viewpageattachments.action?pageId=299009562&sortBy=date&startIndex=60&preview=/299009562/370573552/Anthem%20AWS%20Security%20Patterns%20-%20API%20Gateway.docx

## Pre-Requisites

1. Rest API should be created.
2. Name of the model is required.
3. Content type of the model.
4. Schema of the model.

## Important Note

## Usage
To run this example you need to execute:

```bash

module "api-model" {
  source = "cps-terraform.anthem.com/<ORG>/terraform-aws-api-gateway-model/aws"

  name         = "FirstModel"
  rest_api_id  = module.rest_api.id
  description  = "Model for the api gateway"
  content_type = "application/json"
  schema       = "{}"

}

#Initialize Terraform
terraform init

#Terraform Dry-Run
terraform plan

#Create the resources
terraform apply

#Destroy the resources saved in the tfstate
terraform destroy
```

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| content\_type | (Required) The content type of the model | `string` | n/a | yes |
| description | (Optional) The description of the model | `string` | `""` | no |
| name | (Required) The name of the model | `string` | n/a | yes |
| rest\_api\_id | (Required) The ID of the associated Rest API | `string` | n/a | yes |
| schema | (Required) The schema of the model in a JSON form | `string` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| id | The ID of the model |

## Testing

1. Able to create the model with the pre-requisites.
