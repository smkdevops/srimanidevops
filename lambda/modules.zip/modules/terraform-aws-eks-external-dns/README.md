## Terraform module to create IAM policy and role for external-dns configuration in EKS Cluster
    This module will help to create required IAM policy and role for external-dns configuration.

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| application | Based upon application naming convention policy.Use up to six (6) characters to name your application. | `string` | n/a | yes |
| application\_dl | Application DL | `string` | n/a | yes |
| barometer-it-num | The barometer it number | `string` | n/a | yes |
| company | Company that owns resource | `string` | n/a | yes |
| compliance | PHI, PCI, PII, SOX, None | `string` | n/a | yes |
| costcenter | The project cost center | `string` | n/a | yes |
| description | Default is "". Description of the IAM policy. | `string` | `""` | no |
| environment | DBx,SIT,PERF,PRODX,UAT,UTILx | `string` | n/a | yes |
| it-department | The name of IT department | `string` | n/a | yes |
| layer | WEBx, MWx, DBx, UTILx | `string` | n/a | yes |
| policy_name | Default is "". The name of the policy. | `string` | `""` | no |
| owner-department | The name of department owner | `string` | n/a | yes |
| resource-type | Type of resource. | `string` | n/a | yes |
| tags | A mapping of tags to assign to the bucket. | `map(string)` | `{}` | no |
|role_name | ExternalDns role name. | `string` | "externaldns-update-role" | no
|cluster_account_id | AWS account ID in which the cluster created. | `string` | "null" | yes
|cluster_identity_oidc_issuer | OpenID Connect provider URL| `string` | "null" | yes
|namespace | namespace to create serviceaccount used by external-dns | `string` | "null" | yes
|service_account_name | name of serviceaccount for external-dns | `string` | "external-dns" | no


## sample Usage:
1. Include below module
```bash
module "terraform-aws-eks-external-dns" {
    source  = "cps-terraform.anthem.com/ACSCD/terraform-aws-eks-external-dns/aws"
    version           = "0.0.1"
    application      = ""
    application_dl   = ""
    barometer-it-num = ""
    company          = ""
    compliance       = ""
    costcenter       = ""
    environment      = ""
    it-department    = ""
    layer            = ""
    owner-department = ""
    cluster_account_id           = "" # Provide aws account ID of EKS cluster created
    cluster_identity_oidc_issuer = "" # OpenID Connect provider URL, get it from after cluster provisioned 
    namespace                    = "" # namespace to create service account for externaldns
    service_account_name         = "" # service account name for external dns

}
terraform init
terraform plan
terraform apply
```
2. After the policy and role got created follow the steps mentioned - https://kubernetes-sigs.github.io/aws-load-balancer-controller/v2.4/guide/integrations/external_dns/  to deploy external dns.