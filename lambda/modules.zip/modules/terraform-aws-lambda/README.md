## Anthem AWS Lambda Module

This module will create a Lambda Function with mandatory tags and necessary IAM Roles.

## HIPPA eligibility status

1. AWS Lambda is eligible.

## Security Guardrail reference
[AWS Security Pattern](https://confluence.anthem.com/pages/viewpageattachments.action?pageId=299009562&sortBy=date&startIndex=80&preview=/299009562/331420438/Anthem%20AWS%20Security%20Patterns%20-Lambda-Final-v1.docx)

## Pre-Requisites

1. The module is to create a lambda function with the source code located at s3 or loc
2. If the source code location is s3 then s3 bucket should be exist where lamda function deployment package should be copied. Lambda function will read the object from the s3 bucket.
3. If the source code location is local then the lambda function deployment package should be copied to the same location of the client build script.
4. If the source code location is ecr then ecr image should be exist where lamda function deployment package should be copied. Lambda function will read the image from ecr.
5. The required role with required policy should be created using IAM module and use that role arn for lambda function creation.
6. Security group should be created with required rules seprately and use that for creating lambda function in VPC.
7. Subnet ID need to be provided if the Lambda function need to be created in VPC. If the subnet ID is not provided then the lambda function will created outside of VPC.
8. At-rest encryption is implemented and enforced in the code.Valid KMS Key is required.
9. The KMS key should be valid and exist in the account. KMS validation has been enforced in the code.
10. Conditional resource creation is enabled with "create_aws_lambda_function" variable, setting this variable to "true" will create the resource and setting this to "false" will skip the resource creation
11. Lambda environment configuration parameters need to be pass as a key value pair like below.
   lambda_environment = {
    variables = {
      "test" = "test"
      "test1" = "test1"
    }

## Log Group Note:
- Updated the module to manage lambda log group within the module.
- This creates a log group with the suffix as lambda function name, i.e., "/aws/lambda/${var.function_name}".
- retention_in_days: Users have to input log group retention period, i.e., as per the requirement in the template. If not specified, the value has been defaulted to 90 days.
- lambda_logs_kms_key_id:  KMS key for encryption of log group should be created and added in the template.
- If the lambda is destroyed, log group gets destroyed along with it.  Set skip_destroy parameter to  true if you do not wish the log group (and any logs it may contain) to be deleted at destroy time, and instead just remove the log group from the Terraform state.
- If there is an error stating that the log group with the same name already exists, then check if there is any lambda function available with that name in the console and if there is no function available, delete the log group manually and re-run the code.

## Mandatory Tags Note:
*	As per redesigned new mandatory tags, mandatory tags along with any additional tags have to be added through template configuration within the modules as below
*	Have a reference of mandatory tags module within the template configuration as shown in example script below.

```bash
# Mandatory Tag Workspace Variables
variable "apm-id" {}
variable "application-name" {}
variable "app-support-dl" {}
variable "app-servicenow-group" {}
variable "business-division" {}
variable "company" {}
variable "compliance" {}
variable "costcenter" {}
variable "environment" {}
variable "PatchGroup" {}
variable "PatchWindow" {}
variable "ATLAS_WORKSPACE_NAME" {}

# Mandatory Tags Module 
module "mandatory_tags" {
  source               = "cps-terraform.anthem.com/<ORG_NAME>/terraform-aws-mandatory-tags-v2/aws"
  tags                 = {}
  apm-id               = var.apm-id
  application-name     = var.application-name
  app-support-dl       = var.app-support-dl
  app-servicenow-group = var.app-servicenow-group
  business-division    = var.business-division
  compliance           = var.compliance
  company              = var.company
  costcenter           = var.costcenter
  environment          = var.environment
  PatchGroup           = var.PatchGroup
  PatchWindow          = var.PatchWindow
  workspace            = var.ATLAS_WORKSPACE_NAME
}
```
*	Mandatory tags module should be referred in tags attribute as below:
tags = module.mandatory_tags.tags
*	Any additional tags can be merged to tags attribute as below:
tags = merge(module.mandatory_tags.tags, {"sample" = "abc"})

## Usage
```bash
#Example script 1
module "lambda" {
  source  = "cps-terraform.anthem.com/<ORGANIZATION NAME>/terraform-aws-lambda/aws"
  
  tags    = module.mandatory_tags.tags
  
  create_aws_lambda_function = true
  function_name        = ""
  handler              = ""
  runtime              = ""
  kms_key_arn          = "" #module.kms_lambda.kms_arn["lambda"]
  description          = ""
  role                 = "" #module.iam-role.iamrole_arn
  
  ephemeral_storage = [{
     size = 512
   }]
  lambda_environment = {
    variables = {
      "test" = "test"
      "test1" = "test1"
    }
  }

  #Log Group Required Parameter  
  lambda_logs_kms_key_id = "" #module.kms_lambda_logs.kms_arn["logs"]

  #Log Group Optional Parameters
  skip_destroy = false
  retention_in_days = 90
}

#Example Script 2
module "lambda" {
  source               = "cps-terraform.anthem.com/<ORGANIZATION NAME>/terraform-aws-lambda/aws"

  tags                 = module.mandatory_tags.tags
  
  function_name        = ""
  source_code_location = "ecr"
  handler              = null 
  timeout              = ""
  kms_key_arn          = "" #module.kms_lambda.kms_arn["lambda"]
  description          = ""
  role                 = "" #module.iam-role.iamrole_arn
  image_uri = ""
  package_type = "Image"
   ephemeral_storage = [{
     size = 512
   }]

  #Log Group Required Parameter  
  lambda_logs_kms_key_id = "" #module.kms_lambda_logs.kms_arn["logs"]

  #Log Group Optional Parameters
  skip_destroy = false
  retention_in_days = 90
}

# To create a Lambda KMS Key
module "kms_lambda" {
  source  = "cps-terraform.anthem.com/<ORGANIZATION NAME>/terraform-aws-kms-service/aws"

  tags                    = module.mandatory_tags.tags

  service_name            = ["lambda"]
  description             = "KMS Key for Lambda"
  kms_alias_name          = "${module.mandatory_tags.tags["application-name"]}-${module.mandatory_tags.tags["environment"]}"
}

# To create a Lambda Logs KMS Key
module "kms_lambda_logs" {
  source = "cps-terraform.anthem.com/<ORGANIZATION NAME>/terraform-aws-kms-service/aws"  

  tags           = module.mandatory_tags.tags
  
  service_name   = ["logs"]
  description    = "KMS key for Lambda Log Group"  
  kms_alias_name = "${module.mandatory_tags.tags["application-name"]}-${module.mandatory_tags.tags["environment"]}"
}

# To create IAM role
module "iam-role" {
  source = "cps-terraform.anthem.com/<ORGANIZATION NAME>/terraform-aws-iam-role/aws"

  tags  = module.mandatory_tags.tags
  
  iam_role_name             = ""
  role_description          = ""
  assume_role_service_names = ["lambda.amazonaws.com"]
  inline_policy = [{
    name   = "test-inlinepolicy"
    policy = "./policy.json"
  }]
}


#Initialize Terraform
terraform init

#Terraform Dry-Run
terraform plan

#Create the resources
terraform apply

#Destroy the resources saved in the tfstate
terraform destroy
```

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| architectures | (Optional) "Default : ["x86\_64"] ". Instruction set architecture for your Lambda function. Valid values are ["x86\_64"] and ["arm64"].  Removing this attribute, function's architecture stay the same. | `any` | <pre>[<br>  "x86_64"<br>]</pre> | no |
| code\_signing\_config\_arn | (Optional) "Default : null". To enable code signing for this function, specify the ARN of a code-signing configuration. A code-signing configuration includes a set of signing profiles, which define the trusted publishers for this function. | `string` | `null` | no |
| create\_aws\_lambda\_function | (Optional) "Default : true". Controls if Lambda shoulbd be created | `bool` | `true` | no |
| dead\_letter\_target\_arn | (Optional) "Default : "" ". The ARN of an SNS topic or SQS queue to notify when an invocation fails. If this option is used, the function's IAM role must be granted suitable access to write to the target object, which means allowing either the sns:Publish or sqs:SendMessage action on this ARN, depending on which service is targeted. | `string` | `""` | no |
| description | (Optional) "Default : " " ". Description of what your Lambda Function does. | `string` | `""` | no |
| ephemeral\_storage | (Optional) "Default : []". The size of the Lambda function Ephemeral storage(/tmp) represented in MB. The minimum supported ephemeral\_storage value defaults to 512MB and the maximum supported value is 10240MB. | `any` | `[]` | no |
| file\_system\_config\_arn | (Optional) "Default : " " ". The Amazon Resource Name (ARN) of the Amazon EFS Access Point that provides access to the file system. | `string` | `""` | no |
| filename | (Optional) Default : "" ". Required when "source\_code\_location" is "local" and need to provide valid value for the attribute .The path to the function's deployment package within the local filesystem. If defined, The s3\_-prefixed options cannot be used. | `string` | `""` | no |
| function\_name | (Required) A unique name for your Lambda Function. | `string` | n/a | yes |
| handler | (Required) The function entrypoint in your code. | `string` | n/a | yes |
| image\_config | (Optional) "Default : []". Configuration block. | `any` | `[]` | no |
| image\_uri | (Optional) "Default : null". ECR image URI containing the function's deployment package. Conflicts with filename, s3\_bucket, s3\_key, and s3\_object\_version. | `any` | `null` | no |
| kms\_key\_arn | (Required) Amazon Resource Name (ARN) of customer managed CMK should be used for encryption. | `string` | n/a | yes |
| lambda\_environment | (Optional) "Default : {}". The Lambda environment's configuration settings. | `map` | `{}` | no |
| lambda\_logs\_kms\_key\_id | (Optional) "Default : 90". The ARN of the KMS Key to use when encrypting log data. Please note, after the AWS KMS CMK is disassociated from the log group, AWS CloudWatch Logs stops encrypting newly ingested data for the log group. All previously ingested data remains encrypted, and AWS CloudWatch Logs requires permissions for the CMK whenever the encrypted data is requested. | `string` | n/a | yes |
| layers | (Optional) "Default : []". List of Lambda Layer Version ARNs (maximum of 5) to attach to your Lambda Function. | `list` | `[]` | no |
| local\_mount\_path | (Optional) "Default : " " ". The path where the function can access the file system, starting with /mnt/. | `string` | `""` | no |
| memory\_size | (Optional) "Default : "128" ". Amount of memory in MB your Lambda Function can use at runtime. Defaults to 128. | `string` | `"128"` | no |
| package\_type | (Optional) "Default : null". Lambda deployment package type. Valid values are Zip and Image. | `string` | `null` | no |
| publish | (Optional) "Default : false". Whether to publish creation/change as new Lambda Function Version. Defaults to false. | `string` | `"false"` | no |
| reserved\_concurrent\_executions | (Optional) "Default : "-1" ". The amount of reserved concurrent executions for this lambda function. A value of 0 disables lambda from being triggered and -1 removes any concurrency limitations. Defaults to Unreserved Concurrency Limits -1. | `string` | `"-1"` | no |
| retention\_in\_days | (Optional) "Default : 90". Specifies the number of days you want to retain log events in the specified log group. Possible values are: 1, 3, 5, 7, 14, 30, 60, 90, 120, 150, 180, 365, 400, 545, 731, 1096, 1827, 2192, 2557, 2922, 3288, 3653, and 0. If you select 0, the events in the log group are always retained and never expire. | `number` | `90` | no |
| role | (Required) IAM role attached to the Lambda Function. This governs both who / what can invoke your Lambda Function, as well as what resources our Lambda Function has access to. | `string` | n/a | yes |
| runtime | (Optional) "Default : "nodejs12.x" " . Valid runtimes: nodejs10.x \| nodejs12.x \| java8 \| java11 \| python2.7 \| python3.6 \| python3.7 \| python3.8 \| dotnetcore2.1 \| dotnetcore3.1 \| go1.x \| ruby2.5 \| ruby2.7 \| provided | `string` | `"nodejs12.x"` | no |
| s3\_bucket | (Optional) "Default : "" ". The S3 bucket location containing the function's deployment package. | `string` | `""` | no |
| s3\_key | (Optional) "Default : "" ". The S3 key of an object containing the function's deployment package. | `string` | `""` | no |
| s3\_object\_version | (Optional) "Default : "" ". The object version containing the function's deployment package. | `string` | `""` | no |
| security\_group\_ids | (Optional) "Default : []". A list of security group IDs associated with the Lambda function. | `list` | `[]` | no |
| skip\_destroy | (Optional) "Default : false". Set to true if you do not wish the log group (and any logs it may contain) to be deleted at destroy time, and instead just remove the log group from the Terraform state. | `bool` | `false` | no |
| source\_code\_location | (Optional) "Default : "s3" ". The location of source code. It can be either s3 or local or ecr. | `string` | `"s3"` | no |
| subnet\_ids | (Optional) "Default : []". A list of subnet IDs associated with the Lambda function. | `list` | `[]` | no |
| tags | (Required) A mapping of tags to assign to the resource | `map(string)` | n/a | yes |
| timeout | (Optional) "Default : "15" ". The amount of time your Lambda Function has to run in seconds. Max: 900 (15 min) | `string` | `"15"` | no |
| tracing\_config\_mode | (Optional) "Default : "" ". Can be either PassThrough or Active. If PassThrough, Lambda will only trace the request from an upstream service if it contains a tracing header with sampled=1. If Active, Lambda will respect any tracing header it receives from an upstream service. If no tracing header is received, Lambda will call X-Ray for a tracing decision. | `string` | `""` | no |

## Outputs

| Name | Description |
|------|-------------|
| function\_arn | The Amazon Resource Name (ARN) identifying your Lambda Function. |
| invoke\_arn | The ARN to be used for invoking Lambda Function from API Gateway - to be used in aws\_api\_gateway\_integration's uri |
| kms\_key\_arn | The ARN for the KMS encryption key. |
| last\_modified | The date this resource was last modified. |
| log\_group\_arn | The Amazon Resource Name (ARN) specifying the lambda log group. |
| qualified\_arn | The Amazon Resource Name (ARN) identifying your Lambda Function Version. |
| source\_code\_hash | Base64-encoded representation of raw SHA-256 sum of the zip file, provided either via filename or s3\_\* parameters. |
| source\_code\_size | The size in bytes of the function .zip file. |
| version | Latest published version of your Lambda Function. |

## Testing

1. Created lambda function along  with log group with the sample Hello world code.
2. Logged in to console and verified the function is created.
3. Created test event and tested the function. Function is executing as expected.
4. Tried to create the lambda fuction with the invalid key and it is failing in plan stage.
