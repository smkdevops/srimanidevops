## Terraform module to deploy Istio Ingress in EKS Cluster

 This module will help to deploy Istio into existing Kubernetes cluster.

 
## Pre-Requisites

1. Should have EKS cluster up and running.
2. Istio controlplane(istiod) configured in istio-system namespace
2. Get qualified DNS of application.
3. Include Kuberenetes provider for your EKS cluster as shown below:

```bash
data "aws_eks_cluster" "cluster" {
  name = module.eks_cluster.cluster_id
}

data "aws_eks_cluster_auth" "cluster" {
  name = module.eks_cluster.cluster_id
}

provider "kubernetes" {
  #  load_config_file       = false
  host                   = data.aws_eks_cluster.cluster.endpoint
  cluster_ca_certificate = base64decode(data.aws_eks_cluster.cluster.certificate_authority.0.data)
  token                  = data.aws_eks_cluster_auth.cluster.token
}
```
## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| gateway_namespace | Name of namespace for gateway-ingress| String | - | yes |
| domain_name | Provide fully qualified DNS of application | String | - | yes |
|istio_charts_url    | Helm repository URL|string|https://istio-release.storage.googleapis.com/charts|yes|
| gateway_chartname       |Helm chart name||String|gateway|yes|
|chart_version| Helm chart Version | String| 1.14.0 |yes|

## Usage

Include below module code to deploy Istio into EKS cluster:
1. Configure Ingress gateway for application. Use this module to create ingress gateway for each application (specific to application). It also configure IAM policy for ExternalDns.

```bash
module "terraform_aws_istio_ingress" {
  source  = "cps-terraform.anthem.com/ACSCD/terraform-aws-eks-istio-test/aws"
  version = "0.0.1" # Module Version
  gateway_namespace = "" # Specific to application Example: istio-ingress-{appname}
  domain_name = "" # DNS name of the application.
  istio_charts_url = ""
  gateway_chartname = ""
  chart_version     = ""
}

terraform init
terraform plan # Evaluate the resources creation
terraform apply --auto-approve

```
## Validation

Run below command to verify the installation. Make sure all resources got deployed successfully without any error.

```bash
kubectl get all -n istio-ingress-{appname}

```
