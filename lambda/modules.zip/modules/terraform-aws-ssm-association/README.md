# Anthem AWS SSM Association

This module creates SSM Association service

## HIPPA eligibility status

1. AWS Systems Manager service is eligible.

## Security Guardrail reference

https://confluence.anthem.com/pages/viewpageattachments.action?pageId=299009562&preview=/299009562/516937786/Anthem%20AWS%20Security%20Patterns%20-%20Systems%20Manager.docx

## Pre-requisite

* ssm document name is mandatory
* Conditional resource creation is enabled with "create_aws_ssm_association" variable, setting this variable to "true" will create the resource   and setting this to "false" will skip the resource creation.
* targets can be provided in below format if required.

       targets = [{
                    ssm_association_targets_key = "keyname"
                    ssm_association_targets_values= ["keyvalues"]
       }]
* output_location can be provided in below format if required.

       output_location = [{
                    s3_bucket_name = "s3bucketname"
                    s3_key_prefix= "s3flodername"
       }]

## Usage

To run this example you need to execute:

```bash
#Example script
module "ssmassociation" {
  source  = "cps-terraform.anthem.com/<ORGANIZATION NAME>/terraform-aws-ssm-association/aws"
  
  /******** Parameter required for resource creation ****/

  ssm_document_name           = ""
  parameters                  = {}
  association_name            = ""

  /******** Optional Parameters *******/

  apply_only_at_cron_interval      = ""
  document_version                 = ""  
  schedule_expression              = ""
  compliance_severity              = ""
  max_concurrency                  = ""
  max_errors                       = ""
  automation_target_parameter_name = ""
  targets = [{
                    ssm_association_targets_key = ""
                    ssm_association_targets_values= [""]
       }]
  
  output_location = [{
    s3_bucket_name = ""
    s3_key_prefix  = ""
  }]
}

#Initialize Terraform
terraform init

#Terraform Dry-Run
terraform plan

#Create the resources
terraform apply

#Destroy the resources saved in the tfstate
terraform destroy
```

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| apply\_only\_at\_cron\_interval | Default : false .By default, when you create a new or update associations, the system runs it immediately and then according to the schedule you specified. Enable this option if you do not want an association to run immediately after you create or update it. This parameter is not supported for rate expressions. Default: false. | `bool` | `false` | no |
| association\_name | The descriptive name for the association. | `string` | n/a | yes |
| automation\_target\_parameter\_name | Default : "" .Specify the target for the association. This target is required for associations that use an Automation document and 
target resources by using rate controls. | `string` | `""` | no |
| compliance\_severity | Default : "LOW" .The compliance severity for the association. Can be one of the following: UNSPECIFIED, LOW, MEDIUM, HIGH or CRITICAL | `string` | `"LOW"` | no |
| create\_aws\_ssm\_association | The name of the SSM document to apply. | `bool` | `true` | no |
| document\_version | Default : "" .The document version you want to associate with the target(s). Can be a specific version or the default version. | `string` | `""` | no |
| max\_concurrency | Default : 10 .The maximum number of targets allowed to run the association at the same time. You can specify a number, for example 10, or a percentage of the target set, for example 10%. | `number` | `10` | no |
| max\_errors | Default : 10 .The number of errors that are allowed before the system stops sending requests to run the association on additional targets. You can specify 
a number, for example 10, or a percentage of the target set, for example 10%. | `number` | `10` | no |
| output\_location | Default : [] .An output location block. | `list` | `[]` | no |
| parameters | A block of arbitrary string parameters to pass to the SSM document. | `map` | n/a | yes |
| schedule\_expression | Default : "" .A cron expression when the association will be applied to the target(s). | `string` | `""` | no |
| ssm\_document\_name | The name of the SSM document to apply. | `string` | n/a | yes |
| targets | Default : [] .A block containing the targets of the SSM association. Targets are documented below. AWS currently supports a maximum of 5 targets. | `list` | `[]` | no |

## Outputs

| Name | Description |
|------|-------------|
| association\_id | The ID of the SSM association. |
| instance\_id | The instance id that the SSM document was applied to. |
| name | The name of the SSM document to apply. |

## Testing

* Created one EC2 instance.
* Created SSM Association with AWS SSM Document "AWS-TerminateEC2Instance" name.
* Added schedule corn expression to SSM Association. 
* Added parameters to SSM parameters to provide Assume role and instance id to terminate 
* The EC2 instance got terminated
* Able to see the terminated EC2 instance and success status in SSM Association.