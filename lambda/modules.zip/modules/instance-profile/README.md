# Anthem IAM instance profile Module

This module creates IAM instance profile to act as a container for an IAM role that you can use to pass role information to an EC2 instance when the instance starts.

## Pre-requesits
1. To Skip create IAM Instance profile need pass the variable aws_create_iam_instance_profile as false and by default it's true and will create IAM Instance profile.


## HIPAA eligibility status

IAM is not storing or proccessing any PHI data. IAM is used to provide the control to other services which stores or process PHI information so IAM is not relavent to be evaluated as per HIPAA guidelines. 


## Security Guardrail reference

https://confluence.anthem.com/pages/viewpageattachments.action?pageId=299009562&sortBy=date&startIndex=0&preview=/299009562/516559035/Anthem%20AWS%20Security%20Patterns%20-%20Identity%20and%20Access%20Management.docx

## Pre-Requisite

1. An existing role is required.

## Mandatory Tags Note:
*	As per redesigned new mandatory tags, mandatory tags along with any additional tags have to be added through template configuration within the modules as below
*	Have a reference of mandatory tags module within the template configuration as shown in example script below.

```bash

# Mandatory Tag Workspace Variables
variable "apm-id" {}
variable "application-name" {}
variable "app-support-dl" {}
variable "app-servicenow-group" {}
variable "business-division" {}
variable "company" {}
variable "compliance" {}
variable "costcenter" {}
variable "environment" {}
variable "PatchGroup" {}
variable "PatchWindow" {}
variable "ATLAS_WORKSPACE_NAME" {}

# Mandatory Tags Module 
module "mandatory_tags" {
  source               = "cps-terraform.anthem.com/<ORG_NAME>/terraform-aws-mandatory-tags-v2/aws"
  tags                 = {}
  apm-id               = var.apm-id
  application-name     = var.application-name
  app-support-dl       = var.app-support-dl
  app-servicenow-group = var.app-servicenow-group
  business-division    = var.business-division
  compliance           = var.compliance
  company              = var.company
  costcenter           = var.costcenter
  environment          = var.environment
  PatchGroup           = var.PatchGroup
  PatchWindow          = var.PatchWindow
  workspace            = var.ATLAS_WORKSPACE_NAME
}
```
*	Mandatory tags module should be referred in tags attribute as below:
tags = module.mandatory_tags.tags
*	Any additional tags can be merged to tags attribute as below:
tags = merge(module.mandatory_tags.tags, {"sample" = "abc"})

## Usage
To run this example you need to execute:

```bash
#Example Script

module "instance-profile" {

source = "cps-terraform.anthem.com/<ORG_NAME>/terraform-aws-iam-instance-profile/aws"

instance_profile_name = ""
role_name             = ""
tags                  = module.mandatory_tags.tags
}

#Initialize Terraform
terraform init

#Terraform Dry-Run
terraform plan

#Create the resources
terraform apply

#Destroy the resources saved in the tfstate
terraform destroy
```

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| aws\_create\_iam\_instance\_profile | (Optional) "Default : true" it should take care of creation of IAM instance profile or skip the creation of IAM instance profile | `bool` | `true` | no |
| instance\_profile\_name | (Required) The instance profile name. | `string` | n/a | yes |
| role\_name | (Required) The role name to include in the profile. | `string` | n/a | yes |
| tags | (Required) A mapping of tags to assign to the resource. | `map` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| arn | The ARN assigned by AWS to the instance profile. |
| create\_date | The creation timestamp of the instance profile. |
| id | The instance profile's ID. |
| name | The instance profile's name. |
| path | The path of the instance profile in IAM. |
| role | The role assigned to the instance profile. |
| unique\_id | The unique ID assigned by AWS. |


## Testing

1. Created instance profile.
2. Launched ec2 instance with this instance profile successfully.