## Terraform module to deploy ArgoCD in EKS Cluster

Argo CD is a declarative, GitOps continuous delivery tool for Kubernetes. 

## Pre-Requisites

1. Should have EKS cluster up and running.
2. Include Kuberenetes provier for your EKS cluster as shown below:

```bash
data "aws_eks_cluster" "cluster" {
  name = module.eks_cluster.cluster_id
}

data "aws_eks_cluster_auth" "cluster" {
  name = module.eks_cluster.cluster_id
}

provider "kubernetes" {
  #  load_config_file       = false
  host                   = data.aws_eks_cluster.cluster.endpoint
  cluster_ca_certificate = base64decode(data.aws_eks_cluster.cluster.certificate_authority.0.data)
  token                  = data.aws_eks_cluster_auth.cluster.token
}

provider "helm" { 
  kubernetes {
    host                   = data.aws_eks_cluster.cluster.endpoint
    cluster_ca_certificate = base64decode(data.aws_eks_cluster.cluster.certificate_authority.0.data)
    token                  = data.aws_eks_cluster_auth.cluster.token
  }
}
```

## Usage

Include below module code to deploy ArgoCD into EKS cluster:

```bash

module "terraform_aws_argocd" {
  depends_on = [ module.eks_cluster, module.eks-managed-node-group ]
  source  = "cps-terraform.anthem.com/<ORG NAME>/terraform-aws-eks-argocd/aws"
  
}

#Initialize Terraform
terraform init

#Terraform Dry-Run
terraform plan

#Create the resources
terraform apply

#Destroy the resources saved in the tfstate
terraform destroy
```

## Verify Installation


1. Create EKS Cluster.
2. Deploy ArgoCD using reference module code provided above in earlier section.
3. Run below commands to verify resources deployed without any errors:
```bash
kubectl get ns

NAME               STATUS   AGE
argocd             Active   17h
```
- Verify the resources deployed in argocd namespace.

```bash

kubectl get all -n argocd

NAME                                                         READY   STATUS    RESTARTS   AGE
pod/argo-cd-argocd-application-controller-55dc978cfc-487m4   1/1     Running   0          17h
pod/argo-cd-argocd-dex-server-bf6794c66-42rnb                1/1     Running   0          17h
pod/argo-cd-argocd-redis-7c7cfd9849-qv6gc                    1/1     Running   0          17h
pod/argo-cd-argocd-repo-server-d9b8d766d-nb86f               1/1     Running   0          17h
pod/argo-cd-argocd-server-6d9747b49b-nsthw                   1/1     Running   0          17h

NAME                                            TYPE        CLUSTER-IP       EXTERNAL-IP   PORT(S)             AGE
service/argo-cd-argocd-application-controller   ClusterIP   172.20.244.197   <none>        8082/TCP            17h
service/argo-cd-argocd-dex-server               ClusterIP   172.20.132.74    <none>        5556/TCP,5557/TCP   17h
service/argo-cd-argocd-redis                    ClusterIP   172.20.98.59     <none>        6379/TCP            17h
service/argo-cd-argocd-repo-server              ClusterIP   172.20.33.241    <none>        8081/TCP            17h
service/argo-cd-argocd-server                   ClusterIP   172.20.43.109    <none>        80/TCP,443/TCP      17h

NAME                                                    READY   UP-TO-DATE   AVAILABLE   AGE
deployment.apps/argo-cd-argocd-application-controller   1/1     1            1           17h
deployment.apps/argo-cd-argocd-dex-server               1/1     1            1           17h
deployment.apps/argo-cd-argocd-redis                    1/1     1            1           17h
deployment.apps/argo-cd-argocd-repo-server              1/1     1            1           17h
deployment.apps/argo-cd-argocd-server                   1/1     1            1           17h

NAME                                                               DESIRED   CURRENT   READY   AGE
replicaset.apps/argo-cd-argocd-application-controller-55dc978cfc   1         1         1       17h
replicaset.apps/argo-cd-argocd-dex-server-bf6794c66                1         1         1       17h
replicaset.apps/argo-cd-argocd-redis-7c7cfd9849                    1         1         1       17h
replicaset.apps/argo-cd-argocd-repo-server-d9b8d766d               1         1         1       17h
replicaset.apps/argo-cd-argocd-server-6d9747b49b                   1         1         1       17h

```

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| argocd\_name | Release name | `string` | argo-cd | no |
| argocd\_chart |Chart name to be installed | `string` | argo-cd | no |
| argocd\_repository | Repository URL where to locate the requested chart | `string` | https://argoproj.github.io/argo-helm | no |
| argocd\_namespace | The namespace to install the release into | `string` | argocd | no |
| argocd\_helm\_version | Specify the exact chart version to install. If this is not specified, the latest version is installed | `string` | null | no |
| argocd\_timeout | Time in seconds to wait for any individual kubernetes operation | `number` | 500 | no |
| argocd\_values | List of values in raw yaml to pass to helm. Values will be merged, in order, as Helm does with multiple -f options | `list(string)` | [] | no |
| argocd\_set | Value block with custom values to be merged with the values yaml | `any` | [] | no |
| redis\_image\_repository | Image Repository for Redis | `string` | quay.apps.lz-np2.ent-ocp4-useast1.aws.internal.das/eks/argocd | no |
| haproxy\_image\_repository | Image Repository for HA Proxy | `string` | quay.apps.lz-np2.ent-ocp4-useast1.aws.internal.das/eks/argocd | no |
| redis\_image\_tag | Image Tag for Redis | `string` | redis-7.0.7-alpine | no |
| haproxy\_image\_tag | Image Tag for HA Proxy | `string` | haproxy-2.6.4 | no |
| enable\_ha | Enable HA for Redis | `bool` | false | no |