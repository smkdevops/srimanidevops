# Anthem DMS Event Subscription

This creates event subscription for various event of DMS replication Instance and task of AWS DMS (Database Migration Services)

## HIPAA eligibility status

1. AWS DMS (Database MIgration Service) is eligible.

## Security Guardrail reference

[AWS Security Pattern](https://confluence.anthem.com/download/attachments/299009562/Anthem%20AWS%20Security%20Patterns%20-%20Database%20Migration%20Service.docx?api=v2)

# Release Notes:
## New Version - 0.0.3
1. With Mandatory Tags Redesign that happened early part of this year, we had to refactor all our templates to include central Mandatory Tag Module and remove variable references from the code.
2. All the new templates has been pushed in and you should be able to see the changes. Below are the highlights. 

### Adoption of the New Version - 0.0.3

1.	There is a new file tags.tf that is now included and integral part of our code base.
2.	We now have only Application Specific Tags in DMS modules of each templates. The entire code is now bit sleek. 
3.	Each module refers to mandatory tags module.

## Prerequisite
1. IAM Role name "dms-vpc-role" with action "sts:AssumeRole" , identifiers "dms.amazonaws.com" and type "Service".
2. Event category like "creation" , "failure" are required.
3. source type like replication instance or task are required.
4. SNS topic is required for notification.

## Usage

To run this example you need to execute:

```bash
#Initialize Terraform
terraform init

#Terraform Dry-Run
terraform plan

#Create the resources
terraform apply

#Destroy the resources saved in the tfstate
terraform destroy
```

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| application | Based upon application nomenclature in server naming convention policy.Use up to six (6) characters to name your application. | `string` | n/a | yes |
| application\_dl | Application DL | `string` | n/a | yes |
| barometer-it-num | Define barometer-it-num | `string` | n/a | yes |
| company | Based upon company that owns resource-ANTM–Anthem | `string` | n/a | yes |
| compliance | PHI, PCI, PII, SOX, None | `string` | n/a | yes |
| costcenter | Define costcenter for the mandatory tags | `string` | n/a | yes |
| delivery\_policy | Default : "" .The path of JSON file of SNS Delivery Policy. If policy is not provided AWS add default policy as given in pre-requisite section of readme.md. One can refere  AWS Documentation[https://docs.aws.amazon.com/sns/latest/dg/DeliveryPolicies.html]. | `string` | `""` | no |
| environment | DBx,SIT,PERF,PRODX,UAT,UTILx | `string` | n/a | yes |
| event\_categories | List of event categories to listen for, see DescribeEventCategories for a canonical list. | `list(string)` | `[]` | no |
| event\_subscription\_enabled | Whether the event subscription should be enabled. Default is true | `bool` | `true` | no |
| event\_subscription\_name | Name of event subscription. | `string` | n/a | yes |
| identifiers | List of identifiers for principals. When type is Service, these are AWS Service roles e.g. lambda.amazonaws.com. | `list(string)` | <pre>[<br>  "sns.amazonaws.com"<br>]</pre> | no |
| it-department | Define it-department | `string` | n/a | yes |
| layer | WEBx, MWx, DBx, UTILx | `string` | n/a | yes |
| owner-department | Define Owner-department | `string` | n/a | yes |
| policy\_id | Default : "" .The name of the policy related with the SNS Topic.If we need to give specific policy\_id then it will take that as policy\_id, otherwise it will take sns\_name along with suffix \_policy as input. | `string` | `""` | no |
| resource-type | Based upon the type of resource. | `string` | n/a | yes |
| sns\_name | The friendly name for the SNS topic. | `string` | n/a | yes |
| sns\_topic\_policy\_json | The fully-formed AWS policy as JSON | `string` | `""` | no |
| source\_ids | Ids of sources to listen to. | `list(any)` | n/a | yes |
| source\_type | Type of source for events. Valid values: replication-instance or replication-task. Default: all events | `string` | `""` | no |
| stat\_id | Default : "snsSTSPolicy-ID" . Statement ID | `string` | `"snsSTSPolicy-ID"` | no |
| subscribers | Required configuration for subscibres to SNS topic. | <pre>map(object({<br>    protocol = string<br>    # The protocol to use. The possible values for this are: sqs, sms, lambda, application. (http or https are partially supported, see below) (email is an option but is unsupported, see below).<br>    endpoint = string<br>    # The endpoint to send data to, the contents will vary with the protocol. (see below for more information)<br>    endpoint_auto_confirms = bool<br>    # Boolean indicating whether the end point is capable of auto confirming subscription e.g., PagerDuty (default is false)<br>    #raw_message_delivery = bool<br>    # Boolean indicating whether or not to enable raw message delivery (the original message is directly passed, not wrapped in JSON with the original message in the message property) (default is false)<br>  }))</pre> | `{}` | no |
| tags | Additional tags (\_e.g.\_ { BusinessUnit : ABC }) | `map(string)` | `{}` | no |

## Outputs

| Name | Description |
|------|-------------|
| event\_subscription\_arn | Amazon Resource Name (ARN) of the DMS Event Subscription |


## Unit Testing
1. created event subscription for events (creation, failure etc) for Replication Instance and Replication task.