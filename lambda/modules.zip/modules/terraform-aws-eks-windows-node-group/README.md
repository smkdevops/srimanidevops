## Anthem EKS Windows Node Group Module

This module will create a EKS self-managed windows node group.

## HIPPA eligibility status

1. AWS EKS is eligible.

## Security Guardrail reference

https://confluence.anthem.com/pages/viewpageattachments.action?pageId=299009562&sortBy=date&startIndex=0&preview=/299009562/407571792/Anthem%20AWS%20Security%20Patterns%20-%20AWS-EKS-BUNDLE.docx

## Pre-Requisite

1. This module is to create the self managed windows node group using autoscaling group and launch template.
2. Before creating/attaching the windows node group to the cluster, cluster with linux node group(that has all dependent kubernetes resources) has to be created.
3. Rquired IAM role is created with instance profile in the module.
4. Policies AmazonEKSWorkerNodePolicy, AmazonEKS_CNI_Policy, AmazonEC2ContainerRegistryReadOnly, and AmazonSSMFullAccess are attached.
5.  Security group is created with required ingress and egress rules by default. You can add the additional rules or create additional security group using Security group module.
6. Egress all port and protocol for CIDR 0.0.0.0/0 is allowed by default.
7. Ingress port 443 and protocol HTTPS is allowed from the cluster security group and the node security group by default.
10. Ingress Port TCP 1025 to 65535 are allowed from CIDR 30.0.0.0/8 and 10.0.0.0./8 by default.
11. Enables windows support on the cluster by attaching additional policy to EKS Cluster Role, i.e., AmazonEKSVPCResourceController and creating vpc-resource-controller-configmap.
18. If users want to pass kubelet extra arguments on runtime, they can pass using  kubelet_extra_args parameter.
Ex: kubelet_extra_args = "--register-with-taints='os=windows:NoSchedule'"
If it is not needed, no need to pass this parameter.

## Mandatory Tags Note:
*	As per redesigned new mandatory tags, mandatory tags along with any additional tags have to be added through template configuration within the modules as below
*	Have a reference of mandatory tags module within the template configuration as shown in example script below.
```bash
# Mandatory Tag Workspace Variables
variable "apm-id" {}
variable "application-name" {}
variable "app-support-dl" {}
variable "app-servicenow-group" {}
variable "business-division" {}
variable "company" {}
variable "compliance" {}
variable "costcenter" {}
variable "environment" {}
variable "PatchGroup" {}
variable "PatchWindow" {}
variable "ATLAS_WORKSPACE_NAME" {}

# Mandatory Tags Module 
module "mandatory_tags" {
  source               = "cps-terraform.anthem.com/<ORG_NAME>/terraform-aws-mandatory-tags-v2/aws"
  tags                 = {}
  apm-id               = var.apm-id
  application-name     = var.application-name
  app-support-dl       = var.app-support-dl
  app-servicenow-group = var.app-servicenow-group
  business-division    = var.business-division
  compliance           = var.compliance
  company              = var.company
  costcenter           = var.costcenter
  environment          = var.environment
  PatchGroup           = var.PatchGroup
  PatchWindow          = var.PatchWindow
  workspace            = var.ATLAS_WORKSPACE_NAME
}
```
*	Mandatory tags module should be referred in tags attribute as below:
tags = module.mandatory_tags.tags
*	Any additional tags can be merged to tags attribute as below:
tags = merge(module.mandatory_tags.tags, {"sample" = "abc"})


## Usage

To run this example you need to execute:

**Example script to create Windows node group**
```bash
module "eks_windows_node_group" {
source = "cps-terraform.anthem.com/<ORGANIZATION NAME>/terraform-aws-eks-windows-node-group/aws"

tags                = module.mandatory_tags.tags
#Parameters
cluster_name        = module.eks_cluster.cluster_id
cluster_role        = module.eks_cluster.cluster_role_name
image_id            = "ami-<ID>"
instance_type       = "t3.large"
node_group_name     = "Test-Windows-Node-Group"
node_group_role     = "Test-Windows-NodeGroup-Role"
kubelet_extra_args  = "--register-with-taints='os=windows:NoSchedule'"

providers = {
    kubernetes = kubernetes.cluster-windows
  }
}
```

**Example script for EKS Cluster with Linux Node Group, which has to be created before adding Windows node group.**
```bash
module "eks_cluster" {

  source           = "cps-terraform.anthem.com/CORP/terraform-aws-eks-cluster/aws"  
  #Parameters
  cluster_name     = "TEST-CLUSTER"
  master_user      = "plat-scapp1-devrole"
  tags             = module.mandatory_tags.tags
  additional_roles = [
    {
      rolearn  = "arn:aws:iam::<ACCOUNT NUMBER>:role/Test-Windows-NodeGroup-Role"
      username = "system:node:{{EC2PrivateDNSName}}"
      groups = [
        "system:bootstrappers",
        "system:nodes",
        "eks:kube-proxy-windows"
      ]
    }
  ]

  providers = {
    kubernetes = kubernetes.cluster-windows
  }

}

module "eks-managed-linux-node-group" {
  source = "cps-terraform.anthem.com/CORP/terraform-aws-eks-managed-node-group/aws"
  #Parameters
  tags               = module.mandatory_tags.tags
  cluster_name       = module.eks_cluster.cluster_id
  node_group_name    = "test-linux-node-group"
  image_id           = "ami-<ID>"
  instance_type      = "t3.large"
  desired_size       = 2
  max_size           = 2
  min_size           = 1
  user_data_file     = "user_data.sh"
  kubelet_extra_args = "--kubelet_extra_args --node-labels=mykey=myvalue,nodegroup=NodeGroup1"
     taint = [{
         key         = "statefulset-no-schedule"
         value       = "true"
         effect      = "NO_SCHEDULE"
     }]

   update_config      = [{
        max_unavailable_percentage = 50
         max_unavailable = 1
   }]
  capacity_type      = "SPOT"
  instance_types     = ["t3.medium", "t3.large"]


  providers = {
    kubernetes       = kubernetes.cluster-windows
  }

}
```

**Example kubernetes.tf script, to include within the test build script.**
```bash
  terraform {
    required_providers {
      kubernetes = {
        source = "hashicorp/kubernetes"
      }
    }
  }

  data "aws_eks_cluster" "cluster" {
    name = module.eks_cluster.cluster_id
  }

  data "aws_eks_cluster_auth" "cluster" {
    name = module.eks_cluster.cluster_id
  }

  provider "kubernetes" {  
    host                   = data.aws_eks_cluster.cluster.endpoint
    cluster_ca_certificate = base64decode(data.aws_eks_cluster.cluster.certificate_authority.0.data)
    token                  = data.aws_eks_cluster_auth.cluster.token
    alias                  = "cluster-windows"
  }

#Initialize Terraform
terraform init

#Terraform Dry-Run
terraform plan

#Create the resources
terraform apply

#Destroy the resources saved in the tfstate
terraform destroy
```

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| block\_device\_mappings | Default is []. Specify volumes to attach to the instance besides the volumes specified by the AMI | <pre>list(object({<br>    device_name = string<br>    ebs = object({<br>      delete_on_termination = bool<br>      iops                  = number<br>      kms_key_id            = string<br>      snapshot_id           = string<br>      volume_size           = number<br>      volume_type           = string<br>    })<br>  }))</pre> | `[]` | no |
| cluster\_name | Name of the EKS cluster. | `string` | n/a | yes |
| cluster\_role | Cluster role name | `string` | n/a | yes |
| desired\_capacity | Default is 2. Desired number of worker nodes | `string` | `"2"` | no |
| image\_id | The EKS Optimized Windows AMI (Amazon Machine Image) that identifies the instance | `string` | n/a | yes |
| instance\_refresh | If this block is configured, start an Instance Refresh when this Auto Scaling Group is updated. | <pre>object({<br>    strategy = string<br>    preferences = object({<br>      instance_warmup        = number<br>      min_healthy_percentage = number<br>    })<br>    triggers = list(string)<br>  })</pre> | `null` | no |
| instance\_type | Default is t3.medium. Instance type | `string` | `"t3.medium"` | no |
| kubelet\_extra\_args | Extra arguments to pass to kubelet, like "--register-with-taints=dedicated=ci-cd:NoSchedule --node-labels=purpose=ci-worker" | `string` | `""` | no |
| max\_capacity | Default is 4. Maximum number of worker nodes | `string` | `"4"` | no |
| min\_capacity | Default is 2. Mininum number of worker nodes | `string` | `"2"` | no |
| node\_group\_name | Name of the EKS Managed Node Group. | `string` | n/a | yes |
| node\_group\_role | Node group role name | `string` | `""` | no |
| tags | A mapping of tags to assign to all resources | `map(string)` | n/a | no |
| vpc\_id | VPC id for security group creation | `string` | `""` | no |

## Outputs

| Name | Description |
|------|-------------|
| asg\_arn | The ARN for this AutoScaling Group. |
| asg\_availability\_zones | The availability zones of the autoscale group. |
| asg\_default\_cooldown | Time between a scaling activity and the succeeding scaling activity. |
| asg\_desired\_capacity | The number of Amazon EC2 instances that should be running in the group. |
| asg\_health\_check\_grace\_period | Time after instance comes into service before checking health. |
| asg\_health\_check\_type | EC2 or ELB. Controls how health checking is done. |
| asg\_id | The autoscaling group id. |
| asg\_launch\_configuration | The launch configuration of the autoscale group. |
| asg\_max\_size | The maximum size of the autoscale group. |
| asg\_min\_size | The minimum size of the autoscale group. |
| asg\_name | The name of the autoscale group. |
| asg\_vpc\_zone\_identifier | The VPC zone identifier. |
| lt\_arn | Amazon Resource Name (ARN) of the launch template. |
| lt\_id | The ID of the launch template. |
| lt\_latest\_version | The latest version of the launch template. |
| sg\_arn | The ARN of the security group. |
| sg\_description | The description of the security group. |
| sg\_egress | The egress rules. |
| sg\_id | The ID of the security group. |
| sg\_ingress | The ingress rules. |
| sg\_name | The name of the security group. |
| sg\_owner\_id | The owner ID. |
| sg\_vpc\_id | The VPC ID. |

## Testing

1. Created Cluster with linux node group and attached windows node group.
2. Could see that the nodes are in running state using kubectl command.
3. Could see that Launch template is created in console.
4. Could see that the ASG is created and the instances are in running state in console.
5. Windows support is enabled.
6. Deployed sample application and it is working as expected.