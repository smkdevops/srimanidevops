## Twistlock Defender (EKS)

Twistlock Defender ([part of Prisma Cloud](https://www.paloaltonetworks.com/blog/2019/11/cloud-prisma-cloud-compute-edition/)) is a supporting component to securing the enterprise's container-based fleet, including

- data collection on runtime container usage in Kubernetes, ECS, EC2 instances, container-driven Lambda functions, etc.
- enforcing enterprise security policies in container runtime environments
- detecting vulnerabilities in containers' execution environments

This Terraform module supports a standard method of deploying Twistlock Defender, according to the [Kubernetes operator pattern](https://kubernetes.io/docs/concepts/extend-kubernetes/operator/).


## Security Guardrail reference

N/A

## Pre-Requisites

1. Should have EKS cluster up and running.
2. Should have a `kubernetes` and `helm` terraform provider configured to point at that EKS cluster (example below)
3. Your terraform workspace must have the `tf-module-caas-cluster` policy applied to it in HashiCorp Vault.

```terraform
data "aws_eks_cluster" "cluster" {
  name = module.eks_cluster.cluster_id
}

data "aws_eks_cluster_auth" "cluster" {
  name = module.eks_cluster.cluster_id
}

provider "helm" {
  kubernetes {
    host                   = data.aws_eks_cluster.cluster.endpoint
    cluster_ca_certificate = base64decode(data.aws_eks_cluster.cluster.certificate_authority.0.data)
    token                  = data.aws_eks_cluster_auth.cluster.token
  }
}

provider "kubernetes" {
  host                   = data.aws_eks_cluster.cluster.endpoint
  cluster_ca_certificate = base64decode(data.aws_eks_cluster.cluster.certificate_authority.0.data)
  token                  = data.aws_eks_cluster_auth.cluster.token
}
```

## Inputs

| Name | Description | Type | Default | Required |
|:-----|:------------|:----:|:-------:|:--------:|
| namespace | Kubernetes namespace in which the Twistlock Defender operator will be installed | `string` | twistlock | no |
| cluster\_name | Unique name for your Kubernetes cluster, as visible in the Prisma Cloud console | `string` | - | yes |
| namespace\_labels | A mapping of Namespace labels (Mandatory tags/labels will be added automatically) | `map(string)` | {} | no |

## Usage

```terraform
module "terraform_aws_twistlock_defender" {
  depends_on = [module.dig-eks-managed-node-group]
  source     = "cps-terraform.anthem.com/<ORG NAME>/terraform-aws-eks-twistlock-defender/aws"

  cluster_name = module.eks_cluster.cluster_id

  # Twistlock Defender secrets:
  secret_service_parameter = data.vault_generic_secret.twistlock-defender.data["service-parameter"]
  secret_defender_cert     = data.vault_generic_secret.twistlock-defender.data["defender-client-cert.pem"]
  secret_defender_key      = data.vault_generic_secret.twistlock-defender.data["defender-client-key.pem"]
  secret_admission_cert    = data.vault_generic_secret.twistlock-defender.data["admission-cert.pem"]
  secret_admission_key     = data.vault_generic_secret.twistlock-defender.data["admission-key.pem"]

  # Mandatory tagging info:
  namespace_labels = {
    apm-id               = var.apm-id
    application-name     = replace(var.application-name, " ", "-")
    app-support-dl       = replace(var.app-support-dl, "@", "--")
    app-servicenow-group = replace(var.app-servicenow-group, " ", "-")
    business-division    = replace(var.business-division, " ", "-")
    compliance           = var.compliance
    environment          = var.environment
    company              = var.company
    costcenter           = var.costcenter
    PatchGroup           = var.patchgroup
    PatchWindow          = var.patchwindow
    workspace            = var.workspace    
  }
} 

data "vault_generic_secret" "twistlock-defender" {
  path = "shared-caas/kube-operators/twistlock-agent"
}
```

```bash
# Initialize Terraform
$ terraform init

# Terraform Dry-Run
$ terraform plan -out=./tfplan

# Create the resources
$ terraform apply ./tfplan

# Destroy the resources saved in the tfstate
$ terraform destroy
```

## Verify Installation

1. Run below commands to verify Twistlock defender resouces deployed without any errors:
```bash
kubectl get ns

NAME               STATUS   AGE
...
twistlock          Active   127m
...
```
- Verify resouces deployed on namespace twistlock are successful without any errors:

```bash
$ kubectl get all -n twistlock

NAME                              READY   STATUS    RESTARTS   AGE
pod/twistlock-defender-ds-2qvsf   1/1     Running   0          22h
pod/twistlock-defender-ds-975d6   1/1     Running   0          24h
pod/twistlock-defender-ds-fmkjn   1/1     Running   0          22h
pod/twistlock-defender-ds-gz7xq   1/1     Running   0          24h
pod/twistlock-defender-ds-znvg8   1/1     Running   0          24h

NAME               TYPE        CLUSTER-IP       EXTERNAL-IP   PORT(S)   AGE
service/defender   ClusterIP   172.20.163.235   <none>        443/TCP   24h

NAME                                   DESIRED   CURRENT   READY   UP-TO-DATE   AVAILABLE   NODE SELECTOR   AGE
daemonset.apps/twistlock-defender-ds   5         5         5       5            5           <none>          24h
```

- Check the logs for twistlock defender pods for any error:

```bash

$ kubectl logs pod/twistlock-defender-ds-2qvsf -n twistlock

```

## Redeploying

Sometimes when Terraform is paired with other tools like Helm, it does a bad job at detecting configuration drift. If there's ever any concern of that happening, this module has a failsafe to force Helm to upgrade the release by using [`terraform apply -replace`](https://www.terraform.io/cli/commands/taint#recommended-alternative).

```bash
$ terraform apply -replace='module.twistlock-defender.random_uuid.sentinel'
```
