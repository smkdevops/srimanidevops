# Anthem AWS APIGateway Method Settings Module

Manages API Gateway Stage Method Settings. For example, CloudWatch logging and metrics.

## HIPAA eligibility status

1. Amazon API Gateway is eligible

## Security Guardrail reference

https://confluence.anthem.com/pages/viewpageattachments.action?pageId=299009562&sortBy=date&startIndex=60&preview=/299009562/370573552/Anthem%20AWS%20Security%20Patterns%20-%20API%20Gateway.docx

## Pre-Requisites

1. Rest API should be created
2. Stage should be available
3. Method Path is required.
4. API gateway account should be created.

## Important Note

## Usage
To run this example you need to execute:

```bash

module "method-settings" {
    source = "cps-terraform.anthem.com/CORP/terraform-aws-api-gateway-method-settings/aws"
    depends_on = [module.rest_api, module.api_stage, module.api_method, module.api_gateway_account]

    rest_api_id   = module.rest_api.id
    stage_name    = "TEST-STAGE"
    method_path   = "*/*"
    metrics_enabled = true
    logging_level   = "INFO"
    data_trace_enabled = true 

}

#Initialize Terraform
terraform init

#Terraform Dry-Run
terraform plan

#Create the resources
terraform apply

#Destroy the resources saved in the tfstate
terraform destroy
```

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| cache\_ttl\_in\_seconds | (Optional) Specifies the time to live (TTL), in seconds, for cached responses | `string` | `"300"` | no |
| caching\_enabled | (Optional) Specifies whether responses should be cached and returned for requests | `bool` | `true` | no |
| data\_trace\_enabled | (Optional) Specifies whether data trace logging is enabled for this method | `bool` | `true` | no |
| logging\_level | (Optional) Specifies the logging level for this method | `string` | `"ERROR"` | no |
| method\_path | (Required) Method path defined as {resource\_path}/{http\_method} for an individual method override, or \*/\* for overriding all methods in the stage | `string` | n/a | yes |
| metrics\_enabled | (Optional) Specifies whether Amazon CloudWatch metrics are enabled for this method | `bool` | `true` | no |
| rest\_api\_id | (Required) The ID of the REST API | `string` | n/a | yes |
| settings | (Required) The endpoint\_configuration specifies the type of the endpoint | `any` | `[]` | no |
| stage\_name | (Required) The name of the stage | `string` | n/a | yes |
| throttling\_burst\_limit | (Optional) Specifies the throttling burst limit. | `string` | `"500"` | no |
| throttling\_rate\_limit | (Optional) Specifies the throttling rate limit. | `string` | `"10000.0"` | no |
| unauthorized\_cache\_control\_header\_strategy | (Optional) Specifies how to handle unauthorized requests for cache invalidation. | `string` | `"FAIL_WITH_403"` | no |

## Outputs

No output.

## Testing

1. Able to create the method settings.