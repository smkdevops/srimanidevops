# Anthem IAM Policy creation Module

This module creates a new policy.


## HIPAA eligibility status

IAM is not storing or proccessing any PHI data. IAM is used to provide the control to other services which stores or process PHI information so IAM is not relavent to be evaluated as per HIPAA guidelines. 


## Security Guardrail reference

https://confluence.anthem.com/pages/viewpageattachments.action?pageId=299009562&sortBy=date&startIndex=0&preview=/299009562/516559035/Anthem%20AWS%20Security%20Patterns%20-%20Identity%20and%20Access%20Management.docx

## Pre-Requisite

1. Policy document must be in json format. Please refer [Validating policy](https://docs.aws.amazon.com/IAM/latest/UserGuide/access_policies_policy-validator.html) 
3. Policy will be created with this module and for attachment to a existing role, use policy attachment module.
4. It is mandatory to have the Permission Boundary attached to the role while attaching a policy.
5. Policy can not be created if the mention role for the attachment is not having the permission boundary attached.
6. Refer https://confluence.anthem.com/display/AWS/Permissions+Boundary+in+IAM for more details on permission boundary allowed actions.
7. Json Policy can be passed in different approaches like using json file, data block and inline policy as shown below.
8. Added tags in iam policy. 

### Examples: 
1. policy = file("./policy.json")
2. policy = <<-EOF
    {
    "Version": "2012-10-17",
    "Statement": [
      {
        "Action": [
          "ec2:Describe*"
        ],
        "Effect": "Allow",
        "Resource": "*"
      }
    ]
    }
    EOF
3. policy = data.aws_iam_policy_document.example.json

   data "aws_iam_policy_document" "example" {
  statement {
    sid = "1"

    actions = [
      "ec2:Describe*"
    ]

    resources = [
      "*",
    ]
  }
  
}

## Usage
To run this example you need to execute:

```bash
#Example script
module "iam-policy" {

  source = "cps-terraform.anthem.com/<ORGANIZATION NAME>/terraform-aws-iam-policy/aws"

  application      = ""
  application_dl   = ""
  barometer-it-num = ""
  company          = ""
  compliance       = ""
  costcenter       = ""
  environment      = ""
  it-department    = ""
  layer            = ""
  owner-department = ""
  resource-type    = ""

  name          = "test-policy"
  description   = "Testing the policy creation"
  policy        = file("./policy.json")  
}

#Initialize Terraform
terraform init

#Terraform Dry-Run
terraform plan

#Create the resources
terraform apply

#Destroy the resources saved in the tfstate
terraform destroy
```

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| application | Based upon application nomenclature in server naming convention policy.Use up to six (6) characters to name your application. | `string` | n/a | yes |
| application\_dl | Application DL | `string` | n/a | yes |
| barometer-it-num | The barometer it number | `string` | n/a | yes |
| company | Company that owns resource | `string` | n/a | yes |
| compliance | PHI, PCI, PII, SOX, None | `string` | n/a | yes |
| costcenter | The project cost center | `string` | n/a | yes |
| description | Default is "". Description of the IAM policy. | `string` | `""` | no |
| environment | DBx,SIT,PERF,PRODX,UAT,UTILx | `string` | n/a | yes |
| it-department | The name of IT department | `string` | n/a | yes |
| layer | WEBx, MWx, DBx, UTILx | `string` | n/a | yes |
| name | Default is "". The name of the policy. | `string` | `""` | no |
| owner-department | The name of department owner | `string` | n/a | yes |
| policy | The policy document. This is a JSON formatted string. For more information about building AWS IAM policy documents with Terraform, see the AWS IAM Policy Document Guide. | `string` | n/a | yes |
| resource-type | Type of resource. | `string` | n/a | yes |
| tags | A mapping of tags to assign to the bucket. | `map(string)` | `{}` | no |

## Outputs

| Name | Description |
|------|-------------|
| arn | The ARN assigned by AWS to this policy. |
| description | The description of the policy. |
| id | The policy's ID. |
| name | The name of the policy. |
| path | The path of the policy in IAM. |
| policy | The policy document. |


## Testing

1. Created a policy and attached to existing role using policy attachment module.
2. Able to see that the policy is getting attached successfully to the role.
3. Tested and created a policy with different approaches as mentioned in pre-requisites.