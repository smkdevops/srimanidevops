# Anthem AWS EventBridge Target
This module will create an EventBridge Target.

A target processes events. Targets can include Amazon EC2 instances, Lambda functions, Kinesis streams, Amazon ECS tasks, Step Functions state machines, Amazon SNS topics, Amazon SQS queues, and built-in targets. A target receives events in JSON format. 

### Limitations

* Conditional resource creation is enabled with "create_cloudwatch_event_target" variable, setting this variable to "true" will create the resource and setting this to "false" will skip the resource creation.
* The targets you associate with a rule must be in the same Region as the rule.

### Permissions

In order to make API calls against the resources that you own, EventBridge needs appropriate permissions. 
* For AWS Lambda and Amazon SNS resources, EventBridge relies on resource-based policies.
* For EC2 instances, Kinesis Data Streams, and AWS Step Functions state machines, EventBridge relies on IAM roles that you specify in the `role_arn` argument. API Gateway REST endpoints with configured IAM authorization can be invoked via IAM roles, but the role is optional if no Authorization is configured.

## Targets
**NOTE:** The current EventBridge targets were being tested. Other targets are in the process of being tested. If you use an unlisted target and find an error, please raise an incident in ServiceNow and assign it to Anthem Cloud Reimagined Support.

### Lambda
In order to make API calls against the AWS Lambda service, Lambda Function needs appropriate permissions. Use the module `terrafor-aws-lambda-permission` to set the attribute `action` with the value `lambda:InvokeFunction` and add as `principal`the EventBridge service `events.amazonaws.com`. Also, create the execution role using the module `terraform-aws-iam-role` & `terraform-aws-iam-policy`, set the `policiy_arn`  attribute with the AWS Managed policy `AWSLambdaBasicExecutionRole`

## Usage
To run this example you need to execute:

```bash
#Example script

module "EventBridge_target" {
  source = "cps-terraform.anthem.com/<ORGANIZATION NAME>/terraform-aws-eventbridge-target/aws"

/******** Parameter required for resource creation ******/

  event_rule_name = ""
  target_id       = ""
  target_arn      = ""

/******** Optional Parameters *******/

  event_bus_name  = ""
  role_arn        = ""
  input           = ""
  input_path      = ""
  batch_target        = ""
  ecs_target          = ""
  kinesis_target      = ""
  sqs_target          = ""
  run_command_targets = ""
}

#Initialize Terraform
terraform init

#Terraform Dry-Run
terraform plan

#Create the resources
terraform apply

#Destroy the resources saved in the tfstate
terraform destroy
```

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| batch\_target | Parameters used when you are using the rule to invoke an Amazon Batch Job. Documented below. | `any` | `null` | no |
| create\_cloudwatch\_event\_target | Need to create a cloudwatch event target True or False | `bool` | `true` | no |
| ecs\_target | Parameters used when you are using the rule to invoke Amazon ECS Task. | `any` | `null` | no |
| event\_bus\_name | The event bus to associate with this rule. If you omit this the default event bus is used. | `string` | `"default"` | no |  
| event\_rule\_name | The name of the rule you want to add targets to. Take the reference from the event rule module: E.g. module.terraform-aws-event-rule.id | `string` | n/a | yes |
| input | Valid JSON text passed to the target. Conflicts with input\_path and input\_transformer. | `any` | `null` | no |
| input\_path | The value of the JSONPath that is used for extracting part of the matched event when passing it to the target. Conflicts with input and input\_transformer. | `any` | `null` | no |
| input\_transformer | Parameters used when you are providing a custom input to a target based on certain event data. Conflicts with input and input\_path. | `any` | `null` | no |
| kinesis\_target | Parameters used when you are using the rule to invoke an Amazon Kinesis Stream. Documented below. | `map(string)` | `null` | 
no |
| role\_arn | The Amazon Resource Name (ARN) of the IAM role to be used for this target when the rule is triggered. Required if ecs\_target is used. | `string` | `null` | no |
| run\_command\_targets | Parameters used when you are using the rule to invoke Amazon EC2 Run Command. Documented below. A maximum of 5 are allowed. | `list(map(string))` | `null` | no |
| sqs\_target | Parameters used when you are using the rule to invoke an Amazon SQS Queue. Documented below. | `map(string)` | `null` | no |     
| target\_arn | The Amazon Resource Name (ARN) associated of the target. | `string` | n/a | yes |
| target\_id | The unique target assignment ID. | `string` | n/a | yes |

## Outputs

No output.

## Testing

1. created eventbridge target with terraform successfuly.
2. Able to see that in console.