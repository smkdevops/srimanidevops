# Anthem AWS Api Gateway - Gateway Response 

This module create AWS Api Gateway - Gateway Response resource.

## HIPAA eligibility status

* N/A

## Security Guardrail reference

[security Guardrails Link](https://confluence.anthem.com/display/AWS/Accenture+Files?preview=%2F299009562%2F370573552%2FAnthem+AWS+Security+Patterns+-+API+Gateway.docx)

## Pre-requisite

- Dependent resources will be needed if any.

## Usage

To run this example you need to execute:
```bash
module "aws_api_gateway_gateway_response_response_4xx" {
  source  = "cps-terraform.anthem.com/CORP/terraform-aws-api-gateway-gateway-response/aws"
  version = "0.0.0"
  
  rest_api_id   = module.rest_api.id
  response_type = "DEFAULT_4XX"
  response_templates = {
    "application/json" = "{'message':$context.error.messageString}"
  }
  response_parameters = {
    "gatewayresponse.header.Access-Control-Allow-Origin" = "'https://d2w4ambey9py4l.cloudfront.net'", # replace with hostname of frontend (CloudFront)
  }
}

#Initialize Terraform
terraform init

#Terraform Dry-Run
terraform plan

#Create the resources
terraform apply

#Destroy the resources saved in the tfstate
terraform destroy
```

## Resources

| Name | Type |
|------|------|
| [aws_api_gateway_gateway_response.this](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/api_gateway_gateway_response) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| aws\_api\_gateway\_gateway\_response | (Optional) Controls if Api-gateway gateway response should be created. Default: true | `bool` | `true` | no |
| response\_parameters | (Optional) A map specifying the parameters (paths, query strings and headers) of the Gateway Response. | `map(string)` | `null` | no |
| response\_templates | (Optional) A map specifying the templates used to transform the response body. | `map(string)` | `null` | no |
| response\_type | (Required) The response type of the associated GatewayResponse. | `string` | n/a | yes |
| rest\_api\_id | (Required) The string identifier of the associated REST API. | `string` | n/a | yes |
| status\_code | (Optional) The HTTP status code of the Gateway Response. | `string` | `null` | no |

## Outputs

| Name | Description |
|------|-------------|
| id | returns a string |
| this | n/a |
