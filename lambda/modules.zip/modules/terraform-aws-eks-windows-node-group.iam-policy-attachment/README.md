# Anthem IAM Policy Attachment Module

This modules attaches a IAM policy to existing role(s).


## HIPAA eligibility status

IAM is not storing or proccessing any PHI data. IAM is used to provide the control to other services which stores or process PHI information so IAM is not relavent to be evaluated as per HIPAA guidelines. 


## Security Guardrail reference

https://confluence.anthem.com/pages/viewpageattachments.action?pageId=299009562&sortBy=date&startIndex=0&preview=/299009562/516559035/Anthem%20AWS%20Security%20Patterns%20-%20Identity%20and%20Access%20Management.docx

## Pre-Requisite

1. The role that the policy is being attached to should be a role that is created with IAM Role Module and should have permissions boundary 'antm-IAMPermissionsBoundaryForExecutionRole' attached to it.
3. Policy cannot be attached if the mentioned role for the attachment does not have the permission boundary attached.
4. Refer https://confluence.anthem.com/display/AWS/Permissions+Boundary+in+IAM for more details on permission boundary allowed actions.
5. Policy can be attached to a single role(only).

## Notes
1. WARNING:
The aws_iam_policy_attachment resource creates exclusive attachments of IAM policies. Across the entire AWS account, all of the users/roles/groups to which a single policy is attached must be declared by a single aws_iam_policy_attachment resource. This means that even any users/roles/groups that have the attached policy via any other mechanism (including other Terraform resources) will have that attached policy revoked by this resource. Consider aws_iam_role_policy_attachment, aws_iam_user_policy_attachment, or aws_iam_group_policy_attachment instead. These resources do not enforce exclusive attachment of an IAM policy.

2. The usage of this resource conflicts with the aws_iam_group_policy_attachment, aws_iam_role_policy_attachment, and aws_iam_user_policy_attachment resources and will permanently show a difference if both are defined.

3. For a given role, this resource is incompatible with using the aws_iam_role resource managed_policy_arns argument. When using that argument and this resource, both will attempt to manage the role's managed policy attachments and Terraform will show a permanent difference.

```bash
#Example script
module "iam-policy-attachment" {

  source = "cps-terraform.anthem.com/<ORGANIZATION NAME>/terraform-aws-iam-policy-attachment/aws"
  version = "0.0.4"

  name        = "test-policy-attachment"
  role_name   = module.iam-role.iamrole_name
  policy_arn  = module.iam-policy.arn
}

#Initialize Terraform
terraform init

#Terraform Dry-Run
terraform plan

#Create the resources
terraform apply

#Destroy the resources saved in the tfstate
terraform destroy
```

## Providers

| Name | Version |
|------|---------|
| aws | n/a |
| null | n/a |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| create\_iam\_policy\_attachment | default:true; to create iam policy attachment | `bool` | `true` | no |
| name | The name of the attachment. This cannot be an empty string. | `string` | n/a | yes |
| policy\_arn | The ARN of the policy you want to attach. E.g. arn:aws:iam::aws:policy/AmazonSSMManagedInstanceCore. | `string` | n/a | yes |
| role\_name | The role the policy should be applied to for policy attachment. | `string` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| id | The policy's ID. |
| name | The name of the policy. |

## Testing

1. Created a policy and attached to a existing role using policy attachment module.
2. Able to see that the policy is getting attached successfully to the role.

