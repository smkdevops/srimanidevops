# Anthem DMS Migration Task

This creates  database replication task from source to target database of AWS DMS (Database Migration Services)

## HIPAA eligibility status

1. AWS DMS (Database MIgration Service) is eligible.

## Security Guardrail reference

[AWS Security Pattern](https://confluence.elevancehealth.com/download/attachments/299009562/Anthem%20AWS%20Security%20Patterns%20-%20Database%20Migration%20Service.docx?api=v2)

# Release Notes:
## New Version - 0.0.4
1. Added the parameter <start_replication_task>

### Adoption of the New Version - 0.0.4
1. If you want to start replication task immediately after launching kindly make <start_replication_task> = <true> otherwise by deafult it is <false>.

## old Version - 0.0.3
1. With Mandatory Tags Redesign that happened early part of this year, we had to refactor all our templates to include central Mandatory Tag Module and remove variable references from the code.
2. All the new templates has been pushed in and you should be able to see the changes. Below are the highlights. 

### Adoption of the old Version - 0.0.3

1.	There is a new file tags.tf that is now included and integral part of our code base.
2.	We now have only Application Specific Tags in DMS modules of each templates. The entire code is now bit sleek. 
3.	Each module refers to mandatory tags module.

## Prerequisite
1. IAM Role name "dms-vpc-role" with action "sts:AssumeRole" , identifiers "dms.amazonaws.com" and type "Service".
2. Migration Type is required.
3. source and target endpoint arn are required.
4. table mapping and replication task setting are required.
5. CDC start time is required in [Unix timestamp integer format](https://www.unixtimestamp.com/), if migration type is "cdc" or "full-load-and-cdc". 

## Usage

To run this example you need to execute:

```bash
#Initialize Terraform
terraform init

#Terraform Dry-Run
terraform plan

#Create the resources
terraform apply

#Destroy the resources saved in the tfstate
terraform destroy
```

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|:----:|:-----:|:-----:|
| cdc\_start\_time | The Unix timestamp integer for the start of the Change Data Capture \(CDC\) operation. | string | n/a | yes |
| migration\_type | The migration type. Can be one of full-load \| cdc \| full-load-and-cdc. | string | n/a | yes |
| replication\_instance\_arn | The Amazon Resource Name \(ARN\) of the replication instance. | string | n/a | yes |
| replication\_task\_id | The replication task identifier.    > Must contain from 1 to 255 alphanumeric characters or hyphens.   > First character must be a letter.    > Cannot end with a hyphen.  > Cannot contain two consecutive hyphens. | string | n/a | yes |
| replication\_task\_settings\_path | Path to JSON string that contains the task settings. For a complete list of task settings, see \[Task Settings for AWS Database Migration Service Tasks.\]\(http://docs.aws.amazon.com/dms/latest/userguide/CHAP\_Tasks.CustomizingTasks.TaskSettings.html\) | string | n/a | yes |
| source\_endpoint\_arn | The Amazon Resource Name \(ARN\) string that uniquely identifies the source endpoint. | string | n/a | yes |
| table\_mappings\_path | Path to JSON string that contains the table mappings. For information on table mapping see \[Using Table Mapping with an AWS Database Migration Service Task to Select and Filter Data\]\(http://docs.aws.amazon.com/dms/latest/userguide/CHAP\_Tasks.CustomizingTasks.TableMapping.html\) | string | n/a | yes |
| tags | A map of tags to assign to the resource. | map | n/a | yes |
| target\_endpoint\_arn | The Amazon Resource Name \(ARN\) string that uniquely identifies the target endpoint. | string | n/a | yes |
| application | Based upon application nomenclature in server naming convention policy.Use up to six \(6\) characters to name your application. | string | n/a | yes |
| application\_dl | Application DL | string | n/a | yes |
| barometer-it-num | The barometer it number. | string | n/a | yes |
| company | Company that owns resource | string | n/a | yes |
| compliance | PHI, PCI, PII, SOX, None | string | n/a | yes |
| costcenter | The project cost center. | string | n/a | yes |
| environment | DBx,SIT,PERF,PRODX,UAT,UTILx | string | n/a | yes |
| it-department | The name of IT department | string | n/a | yes |
| layer | WEBx, MWx, DBx, UTILx | string | n/a | yes |
| owner-department | The name of department owner. | string | n/a | yes |
| resource-type | Type of resource. | string | n/a | yes |


## Outputs

| Name | Description |
|------|-------------|
| replication\_task\_arn | The Amazon Resource Name \(ARN\) for the replication task. |

## Unit Testing
1. created replication task using using table mapping json file and replication task setting json file.