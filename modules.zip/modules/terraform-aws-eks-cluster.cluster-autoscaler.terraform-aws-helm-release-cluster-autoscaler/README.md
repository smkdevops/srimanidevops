## Anthem HELM Release Module

This module will create a HELM Release.

A Release is an instance of a chart running in a Kubernetes cluster.

A Chart is a Helm package. It contains all of the resource definitions necessary to run an application, tool, or service inside of a Kubernetes cluster.

helm_release describes the desired status of a chart in a kubernetes cluster.

## HIPPA eligibility status

1. HELM is eligible.

## Security Guardrail reference

N/A

## Pre-Requisites

1. Should have EKS cluster up and running to install helm chart.
2. User need to pass the namespace parameter to deploy the Helm chart into particular namespace.  If the user does not pass this, chart will be deployed into default namespace.
3. The helm provider should have a kubernetes block for cluster connection. Example:
```bash
provider "helm" { 
 kubernetes {  
  host                   = data.aws_eks_cluster.cluster.endpoint
  cluster_ca_certificate = base64decode(data.aws_eks_cluster.cluster.certificate_authority.0.data)
  token                  = data.aws_eks_cluster_auth.cluster.token
}
}
```

## Usage

To run this example you need to execute:

```bash
#Example script
module "helm_release" {
  source = "cps-terraform-dev.anthem.com/<ORGANIZATION NAME>/terraform-aws-helm-release/aws"
  version = "0.0.1"
  
  #Required Parameters
  name       = "aws-ebs-csi-driver"  
  chart      = "aws-ebs-csi-driver"
  
  #Optional Parameters
  repository = "https://kubernetes-sigs.github.io/aws-ebs-csi-driver"
  helm_version    = "6.0.1"
  namespace  = "kube-system"
  set = [{
    name  = "image.repository"
    value = "602401143452.dkr.ecr.us-east-2.amazonaws.com/eks/aws-ebs-csi-driver"
  },  
  {
    name  = "enableVolumeResizing"
    value = "true"
  },
  {
    name  = "enableVolumeSnapshot"
    value = "true"
  },
  {
    name  = "serviceAccount.controller.create"
    value = "true"
  },
  {
    name  = "serviceAccount.controller.name"
    value = "ebs-csi-controller-sa"
  }
  ]
  values = [
    "${file("ebs-csi.yaml")}"
  ]
  set_sensitive = [{
    name  = ""
    value = ""
  }]  
}


#Initialize Terraform
terraform init

#Terraform Dry-Run
terraform plan

#Create the resources
terraform apply

#Destroy the resources saved in the tfstate
terraform destroy
```


## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| atomic | If set, installation process purges chart on fail. The wait flag will be set automatically if atomic is used. Defaults to false. | `bool` | `false` | no |
| chart | Chart name to be installed. The chart name can be local path, a URL to a chart, or the name of the chart if repository is specified. It is also possible to use the <repository>/<chart> format here if you are running Terraform on a system that the repository has been added to with helm repo add but this is not recommended. | `string` | n/a | yes |
| cleanup\_on\_fail | Allow deletion of new resources created in this upgrade when upgrade fails. Defaults to false. | `bool` | `false` | no |
| create\_namespace | Create the namespace if it does not yet exist. Defaults to false. | `bool` | `false` | no |
| dependency\_update | Runs helm dependency update before installing the chart. Defaults to false. | `bool` | `false` | no |
| description | Set release description attribute (visible in the history). | `string` | `null` | no |
| devel | Use chart development versions, too. Equivalent to version '>0.0.0-0'. If version is set, this is ignored. | `string` | `null` | no |
| disable\_openapi\_validation | If set, the installation process will not validate rendered templates against the Kubernetes OpenAPI Schema. Defaults to false. | `bool` | `false` | no |
| disable\_webhooks | Prevent hooks from running. Defaults to false. | `bool` | `false` | no |
| force\_update | Force resource update through delete/recreate if needed. Defaults to false. | `bool` | `false` | no |
| helm\_version | Specify the exact chart version to install. If this is not specified, the latest version is installed. | `string` | `null` | no |
| keyring | Location of public keys used for verification. Used only if verify is true. Defaults to /.gnupg/pubring.gpg in the location set by home. | `string` | `null` | no |
| lint | Run the helm chart linter during the plan. Defaults to false. | `bool` | `false` | no |
| max\_history | Maximum number of release versions stored per release. Defaults to 0 (no limit). | `number` | `0` | no |
| name | Release name. | `string` | n/a | yes |
| namespace | The namespace to install the release into. Defaults to default. | `string` | `null` | no |
| postrender | Configure a command to run after helm renders the manifest which can alter the manifest contents. binary\_path = relative or full path to command binary. | `any` | `[]` | no |
| recreate\_pods | Perform pods restart during upgrade/rollback. Defaults to false. | `bool` | `false` | no |
| render\_subchart\_notes | If set, render subchart notes along with the parent. Defaults to true. | `bool` | `true` | no |
| replace | Re-use the given name, even if that name is already used. This is unsafe in production. Defaults to false. | `bool` | `false` | no |
| repository | Repository URL where to locate the requested chart. | `string` | `null` | no |
| repository\_ca\_file | The repositories CA file. | `string` | `null` | no |
| repository\_cert\_file | The repositories cert file. | `string` | `null` | no |
| repository\_key\_file | The repositories cert key file. | `string` | `null` | no |
| repository\_password | Password for HTTP basic authentication against the repository. | `string` | `null` | no |
| repository\_username | Username for HTTP basic authentication against the repository. | `string` | `null` | no |
| reset\_values | When upgrading, reset the values to the ones built into the chart. Defaults to false. | `bool` | `false` | no |
| reuse\_values | When upgrading, reuse the last release's values and merge in any overrides. If 'reset\_values' is specified, this is ignored. Defaults to false. | `bool` | `false` | no |
| set | Value block with custom values to be merged with the values yaml. | `any` | `[]` | no |
| set\_sensitive | Value block with custom sensitive values to be merged with the values yaml that won't be exposed in the plan's diff. | `any` | `[]` | no |
| skip\_crds | If set, no CRDs will be installed. By default, CRDs are installed if not already present. Defaults to false. | `bool` | `false` | no |
| timeout | Time in seconds to wait for any individual kubernetes operation (like Jobs for hooks). Defaults to 300 seconds. | `number` | `300` | no |
| values | List of values in raw yaml to pass to helm. Values will be merged, in order, as Helm does with multiple -f options. | `list(string)` | `[]` | no |
| verify | Verify the package before installing it. Helm uses a provenance file to verify the integrity of the chart; this must be hosted alongside the chart. For more information see the Helm Documentation. Defaults to false. | `bool` | `false` | no |
| wait | Will wait until all resources are in a ready state before marking the release as successful. It will wait for as long as timeout. Defaults to true. | `bool` | `true` | no |
| wait\_for\_jobs | If wait is enabled, will wait until all Jobs have been completed before marking the release as successful. It will wait for as long as timeout. Defaults to false. | `bool` | `false` | no |

## Outputs

| Name | Description |
|------|-------------|
| manifest | The rendered manifest of the release as JSON. Enable the manifest experiment to use this feature. |
| metadata | Block status of the deployed release. |

## Testing

1. Created HELM Release using example script.
2. Cloud see the chart deployed in EKS cluster.
