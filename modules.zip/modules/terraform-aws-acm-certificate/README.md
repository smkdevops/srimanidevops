# Anthem AWS ACM Import Module

This module Import the Private cerificate into AWS ACM.

## Prerequisite

* decrypted privatekey, certificatebody and certificate chain pem files are  mandatory.

## Mandatory Tags Note:
*	As per redesigned new mandatory tags, mandatory tags along with any additional tags have to be added through template configuration within the modules as below
*	Have a reference of mandatory tags module within the template configuration as shown in example script below.
```bash
# Mandatory Tag Workspace Variables
  variable "apm-id" {}
  variable "application-name" {}
  variable "app-support-dl" {}
  variable "app-servicenow-group" {}
  variable "business-division" {}
  variable "company" {}
  variable "compliance" {}
  variable "costcenter" {}
  variable "environment" {}
  variable "PatchGroup" {}
  variable "PatchWindow" {}
  variable "ATLAS_WORKSPACE_NAME" {}

# Mandatory Tags Module 
module "mandatory_tags" {
  source               = "cps-terraform.anthem.com/<ORG_NAME>/terraform-aws-mandatory-tags-v2/aws"
  tags                 = {}
  apm-id               = var.apm-id
  application-name     = var.application-name
  app-support-dl       = var.app-support-dl
  app-servicenow-group = var.app-servicenow-group
  business-division    = var.business-division
  compliance           = var.compliance
  company              = var.company
  costcenter           = var.costcenter
  environment          = var.environment
  PatchGroup           = var.PatchGroup
  PatchWindow          = var.PatchWindow
  workspace            = var.ATLAS_WORKSPACE_NAME
}
```
*	Mandatory tags module should be referred in tags attribute as below:
  tags = module.mandatory_tags.tags
*	Any additional tags can be merged to tags attribute as below:
  tags = merge(module.mandatory_tags.tags, {"sample" = "abc"})


```bash
## Usage

module "acm" {
  source = "cps-terraform.anthem.com/<ORGANIZATION>/terraform-aws-acm-import/aws"
 
 ### Mandatory Tags
 tags = module.mandatory_tags.tags
 
 # Required Parameters
  private_key        = "<filename>"
  certificate_body   = "<filename>"
  certificate_chain  = "<filename>"  
}

To run this example you need to execute:

```bash
#Initialize Terraform
terraform init

#Terraform Dry-Run
terraform plan

#Create the resources
terraform apply

#Destroy the resources saved in the tfstate
terraform destroy
```
## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| certificate\_body | (Required) Path of certificate body. | `string` | n/a | yes |
| certificate\_chain | (Required) Path of certificate chain. | `string` | n/a | yes |
| create\_certificate | (Optional) Set to true or false to decide Whether to create ACM certificate. | `bool` | `true` | no |
| private\_key | (Required) Path of private key. | `string` | n/a | yes |
| tags | (Required) Map of tags assigned to the resource, including those inherited from the provider default\_tags | `map(string)` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| id | The ID of the Certificate. |

###  Testing
1. Imported Venafi certificate into ACM.
2. Could see the certificate is created and is accessible.