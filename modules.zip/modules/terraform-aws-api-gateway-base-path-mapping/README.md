# Anthem AWS API Gateway Base Path Mapping

This module connects a custom domain name registered via "terraform-aws-api-domain-name" with a deployed API so that its methods can be called via the custom domain name. 

## Pre-requisite
* Domain Name "domain_name" argument is mandatory
* API ID "api_id" argument is mandatory
* Ensure "terraform-aws-api-domain-name" and "rest_api" is created before creating this module .
* To have the Custom Domain Name and Rest API module ensure following modules are available: "S3 Bucket Creation", "IAM Role and Policy", "KMS", "API Resource", "API Method", "API Integration", "API Deployment"
* Above modules helps you to create S3 integration and this is used for demonstration purpose. 
* Client Certifucation module is must for API Stage
* Mandatory Tags are mandatory for all the resources mentioned above but not for mapping as mapping is done for these modules.

## Note
* Ensure to have "regional_certificate_arn" in case Type is selected as REGIONAL for Custom Domain Module [Refer Custom Domain Module Readme for more information]

## Usage
To run this module you need to execute template for quick demo:

```bash
module "mandatory_tags" {
  source               = "cps-terraform-dev.anthem.com/CORP/terraform-aws-mandatory-tags-v2/aws"
  version              = "0.0.0"
  tags                 = {}
  apm-id               = "APM1007444"
  application-name     = "airflow"
  app-support-dl       = "servicecatalog"
  app-servicenow-group = "servicecatalog"
  business-division    = "cloudops"
  compliance           = "None"
  company              = "Elevance"
  costcenter           = "6590215400"
  environment          = "dev"
  PatchGroup           = "none"
  PatchWindow          = "none"
  workspace            = "scapp"
}
################## KMS KEY #######################
module "kms_lambda" {
  source = "cps-terraform-dev.anthem.com/CORP/terraform-aws-kms-service/aws"
  version = "0.4.2"

  tags = module.mandatory_tags.tags
  description  = "KMS key for Lambda"
  service_name = ["lambda","s3", "sqs","logs"]
  kms_alias_name = "test-kms-base-path"
}

##################API Client Certificate########################

module "client-certificate" {
    source = "cps-terraform-dev.anthem.com/CORP/terraform-aws-api-gateway-client-certificate/aws"

    #Mandatory tags
    tags = module.mandatory_tags.tags
  
    description = "Test client certificate"
}

##################S3 Creation########################

variable "create_s3_bucket" {
  default = true
}

module "terraform_aws_s3" {
  source = "cps-terraform-dev.anthem.com/CORP/terraform-aws-s3/aws"
  
  /********* Tags **********/
   tags = module.mandatory_tags.tags

  create_s3_bucket = var.create_s3_bucket
  /***** Parameters Required for S3 Primary Creation *****/

  aws_kms_key_arn    = var.create_s3_bucket == false ? "" : module.kms_lambda.kms_arn["s3"]
  bucket             = "s3bucketforbasepathmappingtf"
  create_aws_s3_lifecycle_configuration = true
  noncurrent_version_transition = [
    {
      "noncurrent_days" : 30,
      "storage_class" : "STANDARD_IA"
    }
  ]
  force_destroy = true
  role          = module.iam_role_s3.iamrole_arn
 
  transition = [
    {
      "days" : 30,
      "storage_class" : "STANDARD_IA"
    }
  ]
}

###############  REST API  ############################

module "rest_api" {
  source = "cps-terraform-dev.anthem.com/CORP/terraform-aws-api-gateway-rest-api/aws"

 tags = module.mandatory_tags.tags
 
  api_name = "REST-API-BASE-PATH-TEST"
  endpoint_configuration = [{
    types         = ["REGIONAL"]
  }]
  api_description              = "Testing REST API for BASE Path Mapping"
  api_binary_media_types       = ["UTF-8-encoded"]
  api_minimum_compression_size = "-1"
}

module "api_policy" {
  source = "cps-terraform-dev.anthem.com/CORP/terraform-aws-api-gateway-restapi-policy/aws"

  rest_api_id = module.rest_api.id
  policy      = <<EOF
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Principal": {
        "AWS": "*"
      },
      "Action": "execute-api:Invoke",
      "Resource": "${module.rest_api.execution_arn}",
      "Condition": {
        "IpAddress": {
          "aws:SourceIp": "10.188.212.0/22"
        }
      }
    }
  ]

}
EOF
}

################################### S3 INTEGRATION #######################################################

######################  API Resource S3 ##############################

module "api_resource_s3" {
  source = "cps-terraform-dev.anthem.com/CORP/terraform-aws-api-gateway-resource/aws"

  rest_api_id = module.rest_api.id
  parent_id   = module.rest_api.root_resource_id
  path_part   = "login"
}

######################### API Method S3 ##################################

module "api_method_s3" {
  source = "cps-terraform-dev.anthem.com/CORP/terraform-aws-api-gateway-method/aws"

  rest_api_id          = module.rest_api.id
  resource_id          = module.api_resource_s3.id
  http_method          = "GET"
  authorization        = "AWS_IAM"
  authorizer_id        = null
  authorization_scopes = []
}

##################### API Integration S3 ###################################

module "api_integration_s3" {
  source     = "cps-terraform-dev.anthem.com/CORP/terraform-aws-api-gateway-integration/aws"
  depends_on = [module.terraform_aws_s3, module.api_method_s3]

  #Parameters
  rest_api_id             = module.rest_api.id
  resource_id             = module.api_resource_s3.id
  http_method             = module.api_method_s3.http_method
  integration_http_method = "GET"
  integration_type        = "AWS"
  uri                     = "arn:aws:apigateway:us-east-2:s3:path/2015-03-31/module.terraform_aws_s3.arn"
  connection_type                = null
  credentials                    = module.iam_role_s3.iamrole_arn
}

########################  API Deployment  ###########################
module "api_deployment_s3" {
  source     = "cps-terraform-dev.anthem.com/CORP/terraform-aws-api-gateway-deployment/aws"
  depends_on = [module.api_method_s3, module.api_integration_s3, module.rest_api]
  rest_api_id            = module.rest_api.id
  deployment_description = "S3 Test deployment"
  triggers               = {}
}

#####################  API Stage  ################################
module "api_stage_s3" {
  source = "cps-terraform-dev.anthem.com/CORP/terraform-aws-api-gateway-stage/aws"
  depends_on = [module.api_deployment_s3]

  tags = module.mandatory_tags.tags
  scheme = "external"
  rest_api_id           = module.rest_api.id
  stage_name            = "S3-STAGE"
  deployment_id         = module.api_deployment_s3.id
  stage_description     = "Test stage"
  cache_cluster_enabled = true
  cache_cluster_size    = "1.6"
  xray_tracing_enabled  = true
  client_certificate_id = module.client-certificate.id
  documentation_version = ""
  stage_variables       = {}
}


#################### S3 Role ########################################

module "iam_role_s3" {
  source = "cps-terraform-dev.anthem.com/CORP/terraform-aws-iam-role/aws"
  
  tags = module.mandatory_tags.tags
  assume_role_service_names = ["apigateway.amazonaws.com","lambda.amazonaws.com","s3.amazonaws.com","sqs.amazonaws.com"]
  iam_role_name             = "apigatewayrole"
  role_description          = "test role for S3 and apigateway"
}
module "iam-policy-s3" {
  source = "cps-terraform-dev.anthem.com/CORP/terraform-aws-iam-role-policy/aws"
  iam_role_policy_name = "apigatewayrolepolicy"
  role                 = module.iam_role_s3.iamrole_name
  role_policy          = "./policy.json"
}
#################### Custom Domain Name ########################################
module "custom_domain" {
  source  = "cps-terraform-dev.anthem.com/CORP/terraform-aws-api-domain-name/aws"
  depends_on = [module.api_stage_s3]

  tags = module.mandatory_tags.tags
  domain_name = "test.slvr-corp-sharedserv.awsdns.internal.das"
  regional_certificate_arn = "arn:aws:acm:us-east-2:544086441256:certificate/171c3b41-147d-4a96-87be-81eaafd4dd4a"
    types = ["REGIONAL"]
}

######################## API Gateway Base Path Mapping ########################################
module "terraform-aws-api-gateway-base-path-mapping" {
  source  = "cps-terraform-dev.anthem.com/CORP/terraform-aws-api-gateway-base-path-mapping/aws"
  version = "0.0.2"
  depends_on = [module.api_stage_s3, module.custom_domain, module.rest_api]

    domain_name = module.custom_domain.domain_name_id 
    api_id = module.rest_api.id 
    stage_name = "S3-STAGE"
    # base_path = "/"
}
```

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_domain_name"></a> [domain\_name](#input\_domain\_name) | (Required) Already-registered domain name to connect the API to. | `string` | n/a | yes |
| <a name="api_id"></a> [api\_id](#input\_api\_id) | Required) ID of the API to connect. | `string` | n/a | yes |
| <a name="stage_name"></a> [stage\_name](#input\_stage_\_name) | (Optional) Name of a specific deployment stage to expose at the given path. If omitted, callers may select any stage by including its name as a path element after the base path. | `string` | `null` | no |
| <a name="input_dag_s3_path"></a> [dag\_s3\_path](#input\_dag\_s3\_path) | (Optional) Path segment that must be prepended to the path when accessing the API via this mapping. If omitted, the API is exposed at the root of the given domain. | `string` | `"dags"` | no |

## Unit Testing 
* Submit the above usage for successful Custom Domain Mapping
* Terraform takes 5-6 minutes to create the sample usage and similarly if used for other services like Lambda or VPC Link.
* Creates REST API with API Policy, API S3 Integration, API Stage, API Custom Domain and Finally maps the Custom Domain with API, Domain and Stage.