## Anthem ami from instance Module

This module will create a ami from an already got provisioned instance.

## Pre-Requisite

* Need to have an already provisioned instance in AWS.

## Mandatory Tags Note:
*	As per redesigned new mandatory tags, mandatory tags along with any additional tags have to be added through template configuration within the modules as below
*	Have a reference of mandatory tags module within the template configuration as shown in example script below.
```bash
# Mandatory Tag Workspace Variables
  variable "apm-id" {}
  variable "application-name" {}
  variable "app-support-dl" {}
  variable "app-servicenow-group" {}
  variable "business-division" {}
  variable "company" {}
  variable "compliance" {}
  variable "costcenter" {}
  variable "environment" {}
  variable "PatchGroup" {}
  variable "PatchWindow" {}
  variable "ATLAS_WORKSPACE_NAME" {}

# Mandatory Tags Module 
module "mandatory_tags" {
  source               = "cps-terraform.anthem.com/<ORG_NAME>/terraform-aws-mandatory-tags/aws"
  tags                 = {}
  apm-id               = var.apm-id
  application-name     = var.application-name
  app-support-dl       = var.app-support-dl
  app-servicenow-group = var.app-servicenow-group
  business-division    = var.business-division
  compliance           = var.compliance
  company              = var.company
  costcenter           = var.costcenter
  environment          = var.environment
  PatchGroup           = var.PatchGroup
  PatchWindow          = var.PatchWindow
  workspace            = var.ATLAS_WORKSPACE_NAME
}
```
*	Mandatory tags module should be referred in tags attribute as below:
  tags = module.mandatory_tags.tags
*	Any additional tags can be merged to tags attribute as below:
  tags = merge(module.mandatory_tags.tags, {"sample" = "abc"})

``` bash
### usage

module "ami-from-instance" {
  source  = "cps-terraform.anthem.com/<ORGANIZATION>/terraform-aws-ami-from-instance/aws"
  
  #Mandatory tags
  tags = module.mandatory_tags.tags

  instance_ami_name       = "<name of the ami>"
  source_instance_id      = "i-0bda2c75f28d6e886"
}

To run this example you need to execute:

``` bash
#Initialize Terraform
terraform init

#Terraform Dry-Run
terraform plan

#Create the resources
terraform apply

#Destroy the resources saved in the tfstate
terraform destroy
```

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| instance\_ami\_name | (Required) Region-unique name for the AMI. | `string` | n/a | yes |
| snapshot\_without\_reboot | (Optional) Boolean that overrides the behavior of stopping the instance before snapshotting. This is risky since it may cause a snapshot of an inconsistent filesystem state, but can be used to avoid downtime if the user otherwise guarantees that no filesystem writes will be underway at the time of snapshot. | `bool` | n/a | yes |
| source\_instance\_id | (Required) ID of the instance to use as the basis of the AMI. | `string` | n/a | yes |
| tags | (Required) Map of tags assigned to the resource, including those inherited from the provider default\_tags | `map(string)` | `{}` | yes |

## Outputs

| Name | Description |
|------|-------------|
| arn | n/a |
| id | n/a |


### Testing
1. Able to take snapshot of the instacne and stored in the ami section in AWS.