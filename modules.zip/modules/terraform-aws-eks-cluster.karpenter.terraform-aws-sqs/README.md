# AWS SQS Terraform module

Terraform module which creates SQS resources on AWS.

## HIPAA eligibility status

1. Amazon Simple Queue Service (SQS) is eligible

## Security Guardrail reference

[Security Guardrail Link](https://confluence.anthem.com/pages/viewpageattachments.action?pageId=299009562&sortBy=date&startIndex=80&preview=/299009562/351708257/Anthem%20AWS%20Security%20Patterns_SNS-SQS_v1.docx)

## Pre-Requisite

* This module is to to create the SQS standard and FIFO queue.
* At-rest encryption is implemented and enforced in the code.Valid KMS Key is required.
* policy is optional variable. If user wants to add policy, then policy should be provided in below format either file format or jsonencode format.
```bash
  policy = file("./policy.json") 
  ```
  or
  ```bash
   policy = jsonencode({
      Version = "2012-10-17"
      Statement = [
        {
          Action   = ["ec2:Describe*"]
          Effect   = "Allow"
          Resource = "*"
        }
      ]
   })
```
## Important Note :

* If your configuring notification to SQS/SNS then have below configuration to be added(either cross account access statements or any other statements) to the KMS Key policy, please reach-out to Encryption Team on this DL - dl-cloudencryption@anthem.com.

```bash
statement {
    sid    = "s3 sqs notify"
    effect = "Allow"
    principals {
      type        = "Service"
      identifiers = ["s3.amazonaws.com"]
    }
    actions = [
      "kms:GenerateDataKey",
      "kms:Decrypt"
    ]
    resources = ["*"]   
  }
```
* Note: Notify Encryption Team of any upcoming production key policy updates ahead of time. If it is after hours and if there is an issue, an incident would need to be created and TOC engaged.
KMS Key Policy Modification Process Ref: AWS Key Policy Modification Process
Sample Request Ref: RITM13640527 (https://elevancehealth.service-now.com/ess?id=ant_sc_cat_item&sys_id=900779701ba79450bf6132231b4bcb18)
* Please Reference below link for more information 
https://confluence.elevancehealth.com/pages/viewpage.action?spaceKey=ENTCLOUD&title=AWS+Key+Policy+Modification+Process

## Mandatory Tags Note:
*	As per redesigned new mandatory tags, mandatory tags along with any additional tags have to be added through template configuration within the modules as below
*	Have a reference of mandatory tags module within the template configuration as shown in example script below.
```bash
# Mandatory Tag Workspace Variables
variable "apm-id" {}
variable "application-name" {}
variable "app-support-dl" {}
variable "app-servicenow-group" {}
variable "business-division" {}
variable "company" {}
variable "compliance" {}
variable "costcenter" {}
variable "environment" {}
variable "PatchGroup" {}
variable "PatchWindow" {}
variable "ATLAS_WORKSPACE_NAME" {}

# Mandatory Tags Module 
module "mandatory_tags" {
  source               = "cps-terraform.anthem.com/<ORG_NAME>/terraform-aws-mandatory-tags-v2/aws"
  tags                 = {}
  apm-id               = var.apm-id
  application-name     = var.application-name
  app-support-dl       = var.app-support-dl
  app-servicenow-group = var.app-servicenow-group
  business-division    = var.business-division
  compliance           = var.compliance
  company              = var.company
  costcenter           = var.costcenter
  environment          = var.environment
  PatchGroup           = var.PatchGroup
  PatchWindow          = var.PatchWindow
  workspace            = var.ATLAS_WORKSPACE_NAME
}
```
*	Mandatory tags module should be referred in tags attribute as below:
tags = module.mandatory_tags.tags
*	Any additional tags can be merged to tags attribute as below:
tags = merge(module.mandatory_tags.tags, {"sample" = "abc"})


## Usage
To run this example you need to execute:

```bash
module "terraform-aws-sqs" {
  source  = "cps-terraform.anthem.com/<ORG_NAME>/terraform-aws-sqs/aws"
  
  sqs_queue_name                    = ""
  kms_master_key_id                 = module.kms-key.kms_arn["sqs"]
  
  tags = merge(module.mandatory_tags.tags)
  #policy = file("./policy.json")

}

module "kms-key" {
  source  = "cps-terraform.anthem.com/<ORG_NAME>/terraform-aws-kms-service/aws"

  kms_alias_name = "" #"${module.mandatory_tags.tags["application-name"]}-${module.mandatory_tags.tags["environment"]}-test"
  tags = merge(module.mandatory_tags.tags)

  description = "KMS Key for sqs"
  service_name = ["sqs"]
 
}
#Initialize Terraform
terraform init

#Terraform Dry-Run
terraform plan

#Create the resources
terraform apply

#Destroy the resources saved in the tfstate
terraform destroy
```

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| content\_based\_deduplication | (Optional) "Default : false". Enables content-based deduplication for FIFO queues. For more information,refer link https://docs.aws.amazon.com/AWSSimpleQueueService/latest/SQSDeveloperGuide/FIFO-queues.html#FIFO-queues-exactly-once-processing | `bool` | `false` | no |
| delay\_seconds | (Optional) "Default : 0". The time in seconds that the delivery of all messages in the queue will be delayed. An integer from 0 to 900 (15 minutes). | `number` | `0` | no |
| fifo\_queue | (Optional) "Default : false". Boolean designating a FIFO queue | `bool` | `false` | no |
| kms\_data\_key\_reuse\_period\_seconds | (Optional) "Default : 300". The length of time, in seconds, for which Amazon SQS can reuse a data key to encrypt or decrypt messages before calling AWS KMS again. An integer representing seconds, between 60 seconds (1 minute) and 86,400 seconds (24 hours) | `number` | `300` | no |
| kms\_master\_key\_id | (Required) The ID of an customer managed CMK for Amazon SQS.For more information,refere link https://docs.aws.amazon.com/AWSSimpleQueueService/latest/SQSDeveloperGuide/sqs-server-side-encryption.html#sqs-sse-key-terms | `string` | n/a | yes |
| max\_message\_size | (Optional) "Default : 262144". The limit of how many bytes a message can contain before Amazon SQS rejects it. An integer from 1024 bytes (1 KiB) up to 262144 bytes (256 KiB). | `number` | `262144` | no |
| message\_retention\_seconds | (Optional) "Default : 345600". The number of seconds Amazon SQS retains a message. Integer representing seconds, from 60 (1 minute) to 1209600 (14 days). | `number` | `345600` | no |
| policy | (Optional) "Default : "" ". The JSON policy for the SQS queue. For more information about building AWS IAM policy documents with Terraform, refer link https://learn.hashicorp.com/tutorials/terraform/aws-iam-policy | `string` | `""` | no |
| receive\_wait\_time\_seconds | (Optional) "Default : 0". The time for which a ReceiveMessage call will wait for a message to arrive (long polling) before returning. An integer from 0 to 20 (seconds). The default for this attribute is 0, meaning that the call will return immediately. | `number` | `0` | no |
| redrive\_policy | (Optional) "Default : "" ". The JSON policy to set up the Dead Letter Queue, refer link https://docs.aws.amazon.com/AWSSimpleQueueService/latest/SQSDeveloperGuide/sqs-dead-letter-queues.html . Note: when specifying maxReceiveCount, you must specify it as an integer (5), and not a string ("5") | `string` | `""` | no |
| sqs\_queue\_name | (Required) This is the human-readable name of the queue. | `string` | n/a | yes |
| tags | (Required) A mapping of tags to assign to all resources. | `map(string)` | n/a | yes |
| visibility\_timeout\_seconds | (Optional) "Default : 30". The visibility timeout for the queue. An integer from 0 to 43200 (12 hours). For more information about visibility timeout, refer the link https://docs.aws.amazon.com/AWSSimpleQueueService/latest/SQSDeveloperGuide/sqs-visibility-timeout.html | `number` | `30` | no |

## Outputs

| Name | Description |
|------|-------------|
| sqs\_queue\_arn | The ARN of the SQS queue |
| sqs\_queue\_id | The URL for the created Amazon SQS queue |

## Testing

1. Created SQS standard queue with encryption and verified in console.
2. Logged in to console and tried to push the message to the queue and could see the message has been push to queue successfully.
