# Anthem AWS ALB Module

AWS Application Load Balancer (ALB) service distributes incoming application traffic across multiple targets.
This module can provision the ALB, target group and the ALB listener.

## HIPPA eligibility status

* Application Load Balancing is eligible

## Security Guardrail reference

[security Guardrails Link](https://confluence.anthem.com/pages/viewpageattachments.action?pageId=299009562&sortBy=date&startIndex=80&preview=/299009562/357901581/Anthem%20AWS%20Security%20Patterns%20-%20ALB%20v1.0.docx)

## Pre-Requisite

1. In-Transit encryption (https://) is implemented and enforced in the code. The non ssl (http:// and port 80) is not allowed.
2. A Certificate ARN is required for use through ACM (AWS Certificate Manager).
3. If this is an external facing load balancer an Internet Gateway is required on the VPC (Virtual Public Cloud) being deployed on.
4. Load Balancer must be deployed on a public subnet for internet facing traffic. Private subnet for internal traffic.
5. SSL Policy is required for listener. See example "ELBSecurityPolicy-2016-08".
6. Port 443 and Protocol HTTPS attribute values are hardcoded for listener, target group and health check.
7. Application should be configured with SSL on port 443 to configure with ALB.
8. Accesslogs is enabled.
9. enable_http2 attribute values are hardcoded as true.
10. enable_deletion_protection is set to false by default. But it can be set to true while execution if required. 
10. Target type can be instance, ip or lambda.
11. Variabilized additional tag "scheme" in the module and added "internal" as default value.
12. If user wants to provide Protocol_version variable then they can pass otherwise it will take by default.Default value is "HTTP1"

## Mandatory Tags Note:
*	As per redesigned new mandatory tags, mandatory tags along with any additional tags have to be added through template configuration within the modules as below
*	Have a reference of mandatory tags module within the template configuration as shown in example script below.
```bash
# Mandatory Tag Workspace Variables
variable "apm-id" {}
variable "application-name" {}
variable "app-support-dl" {}
variable "app-servicenow-group" {}
variable "business-division" {}
variable "company" {}
variable "compliance" {}
variable "costcenter" {}
variable "environment" {}
variable "PatchGroup" {}
variable "PatchWindow" {}
variable "ATLAS_WORKSPACE_NAME" {}

# Mandatory Tags Module 
module "mandatory_tags" {
  source               = "cps-terraform.anthem.com/<ORG_NAME>/terraform-aws-mandatory-tags-v2/aws"
  tags                 = {}
  apm-id               = var.apm-id
  application-name     = var.application-name
  app-support-dl       = var.app-support-dl
  app-servicenow-group = var.app-servicenow-group
  business-division    = var.business-division
  compliance           = var.compliance
  company              = var.company
  costcenter           = var.costcenter
  environment          = var.environment
  PatchGroup           = var.PatchGroup
  PatchWindow          = var.PatchWindow
  workspace            = var.ATLAS_WORKSPACE_NAME
}
```
*	Mandatory tags module should be referred in tags attribute as below:
  tags = module.mandatory_tags.tags
*	Any additional tags can be merged to tags attribute as below:
  tags = merge(module.mandatory_tags.tags, {"sample" = "abc"})

## Usage
To run this example you need to execute:

```bash

module "alb" {
  source  = "cps-terraform.anthem.com/<ORG_NAME>/terraform-aws-alb/aws"
  
  /******** Mandatory tags *****************************/
  tags = module.mandatory_tags.tags
  
/******** Parameter required for resource creation ****/
  load_balancer_name = ""
  subnet_ids = ["subnet-XXXX", "subnet-XXXX"]
  security_group_ids = ["sg-XXXXX"]
  type = "forward"
  certificate_arn = ""
  vpc_id             = "vpc-XXXX"
  protocol_version   = "GRPC"
  #scheme = "internal" # "external"
}

#Initialize Terraform
terraform init

#Terraform Dry-Run
terraform plan

#Create the resources
terraform apply

#Destroy the resources saved in the tfstate
terraform destroy
```

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| access\_logs\_prefix | (Optional) "Default : null". The S3 bucket prefix. Logs are stored in the root if not configured. | `string` | `null` | no |
| certificate\_arn | (Required) ARN of the default SSL server certificate. Exactly one certificate is required if the protocol is HTTPS. | `string` | n/a | yes |
| cookie\_duration | (Optional) "Default : 86400". The time period, in seconds, during which requests from a client should be routed to the same target. After this time period expires, the load balancer-generated cookie is considered stale. The range is 1 second to 1 week (604800 seconds). The default value is 1 day (86400 seconds). | `string` | `"86400"` | no |
| create\_alb | (Optional) "Default : true". A boolean that indicates whether to create ALB or not. Default is true | `bool` | `true` | no |      
| create\_alb\_listener | (Optional) "Default : true". A boolean that indicates whether to create ALB Listener or not. Default is true | `bool` | 
`true` | no |
| create\_alb\_target\_group | (Optional) "Default : true". A boolean that indicates whether to create ALB Target Group  or not. Default is true | `bool` | `true` | no |
| deregistration\_delay | (Optional) "Default : 300". The amount time for Elastic Load Balancing to wait before changing the state of a deregistering target from draining to unused. Range: 0-3600 seconds. Default:300 seconds. | `string` | `"300"` | no |
| enable\_deletion\_protection | (Optional) "Default : false". If true, deletion of the load balancer will be disabled via the AWS API. This will 
prevent Terraform from deleting the load balancer. Default: false. | `bool` | `false` | no |
| health\_check\_healthy\_threshold | (Optional) "Default : 3". The number of consecutive health checks successes required before considering an unhealthy target healthy. Default: 3. | `string` | `"3"` | no |
| health\_check\_interval | (Optional) "Default : 30". The approximate amount of time, in seconds, between health checks of an individual target. 
Minimum value 5 seconds, Maximum value 300 seconds. For lambda target groups, it needs to be greater as the timeout of the underlying lambda. Default: 30 seconds. | `string` | `"30"` | no |
| health\_check\_matcher | (Optional) "Default : 200-399". The HTTP codes to use when checking for a successful response from a target. You can specify multiple values (for example, 200,202) or a range of values (for example, 200-299). Default: 200-399. | `string` | `"200-399"` | no |       
| health\_check\_path | (Optional) "Default : /". The destination for the health check request. Applies to Application Load Balancers only (HTTP/HTTPS), not Network Load Balancers (TCP). Default: / | `string` | `"/"` | no |
| health\_check\_timeout | (Optional) "Default : 10". The amount of time, in seconds, during which no response means a failed health check. The range is 2 to 120 seconds. Default: 10 | `string` | `"10"` | no |
| health\_check\_unhealthy\_threshold | (Optional) "Default : 3". The number of consecutive health check failures required before considering the 
target unhealthy . Default: 3. | `string` | `"3"` | no |
| idle\_timeout | (Optional) "Default : 60". The time in seconds that the connection is allowed to be idle. Default: 60. | `string` | `"60"` | no |
| internal | (Optional) "Default : true". A boolean flag to determine whether the ALB should be internal. Values: true or false. Default: true. | 
`bool` | `true` | no |
| ip\_address\_type | (Optional) "Default : ipv4". The type of IP addresses used by the subnets for your load balancer. Valid values: ipv4 and dualstack. Default: ipv4. | `string` | `"ipv4"` | no |
| lambda\_multi\_value\_headers\_enabled | (Optional) "Default : false". Boolean whether the request and response headers exchanged between the load balancer and the Lambda function include arrays of values or strings. Only applies when target\_type is lambda. Default: false. | `bool` | `false` | no |
| load\_balancer\_arn | (Optional) "Default : null". Required if create alb is false. The ARN of the aplication LB that you wish to pass to the Listener | `string` | `null` | no |
| load\_balancer\_name | (Required) The name of the aplication LB. This name must be unique within your AWS account, can have a maximum of 32 characters, must contain only alphanumeric characters or hyphens, and must not begin or end with a hyphen. | `string` | n/a | yes |
| load\_balancing\_algorithm\_type | (Optional) "Default : round\_robin". Determines how the load balancer selects targets when routing requests. 
Values: round\_robin or least\_outstanding\_requests. Default: round\_robin. | `string` | `"round_robin"` | no |
| protocol\_version | (Optional) Default : "HTTP1". Only applicable when protocol is HTTP or HTTPS. The protocol version. Specify GRPC to send requests to targets using gRPC. Specify HTTP2 to send requests to targets using HTTP/2. The default is HTTP1, which sends requests to targets using HTTP/1.1. | `string` | `"HTTP1"` | no |
| scheme | (Optional) "Default : internal". Tag Scheme should be either external or internal. | `string` | `"internal"` | no |
| security\_group\_ids | (Required) A list of security group IDs to assign to the LB. E.g.["subnet-xxxxxxxxxxxxxxxxx", "subnet-yyyyyyyyyyyyyyyyy"] | `list(any)` | n/a | yes |
| ssl\_policy | (Optional) "Default : ELBSecurityPolicy-2016-08". The name of the SSL Policy for the listener. Valid values: See Security Policies section on https://docs.aws.amazon.com/elasticloadbalancing/latest/application/create-https-listener.html. Default: ELBSecurityPolicy-2016-08 | `string` | `"ELBSecurityPolicy-2016-08"` | no |
| stickiness\_enable | (Optional) "Default : true". Boolean to enable/disable stickiness. Default is true | `bool` | `true` | no |
| subnet\_ids | (Required) A list of subnet IDs to attach to the LB. Must be at least two subnets in different AZ. E.g.["sg-xxxxxxxxxxxxxxxxx", "sg-yyyyyyyyyyyyyyyyy"] | `list(any)` | n/a | yes |
| tags | (Required) Map of tags assigned to the resource, including those inherited from the provider default\_tags | `map(string)` | n/a | yes | 
| target\_group\_arn | (Optional) "Default : null". Required if create\_alb\_target\_group is false. Arn of the target group arn | `string` | `null` | no |
| target\_group\_name | (Optional) "Default : null". The unique name of the target group. | `string` | `null` | no |
| target\_type | (Optional) "Default : instance". The type of target that you must specify when registering targets with this target group. The possible values are instance (targets are specified by instance ID) or ip (targets are specified by IP address) or lambda (targets are specified by 
lambda arn). The default is instance. Note that you can't specify targets for a target group using both instance IDs and IP addresses. If the target type is ip, specify IP addresses from the subnets of the virtual private cloud (VPC) for the target group, the RFC 1918 range (10.0.0.0/8, 172.16.0.0/12, and 192.168.0.0/16), and the RFC 6598 range (100.64.0.0/10). You can't specify publicly routable IP addresses. | `string` | `"instance"` | no |
| type | (Required) The type of routing action. Valid values: forward, redirect, fixed-response, authenticate-cognito and authenticate-oidc. | `string` | n/a | yes |
| vpc\_id | (Required) Identifier of the VPC in which to create the target group. Required when target\_type is instance, ip or alb. Does not apply when target\_type is lambda. | `string` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| alb\_arn | The ARN of the ALB |
| alb\_arn\_suffix | The ARN suffix of the ALB |
| alb\_dns\_name | DNS name of ALB |
| alb\_name | The ARN suffix of the ALB |
| alb\_zone\_id | The ID of the zone which ALB is provisioned |
| default\_target\_group\_arn | The default target group ARN |
| http\_listener\_arn | The ARN of the HTTP listener |

## Testing

1) ALB has been created with SSL certificate and enabled access log.
2) Target group is created.
3) ALB Listener is created with the one forward rule  on port 443 and protocol HTTPS.
4) Use the same ALB target group for creating ECS cluster. ECS EC2 cluster is getting created without any error.
5) Created EC2 instance with apache application and installed root certificate on port 443.
6) Attached the same EC2 instance to target group and tested accessing the application using ALB internal DNS name using https protocol and port 443.
7) Created the target group with the protocol_version GRPC and able to see it in the console.

**Note:** The certificate generated with the domain name starting with "*" is not working. The certificate created with fully qualified name is working fine.