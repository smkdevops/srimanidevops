# Anthem AWS API Gateway Authorizer Module

This module provides an API Gateway Authorizer.

## HIPAA eligibility status

1. Amazon API Gateway is eligible

## Security Guardrail reference

https://confluence.anthem.com/pages/viewpageattachments.action?pageId=299009562&sortBy=date&startIndex=60&preview=/299009562/370573552/Anthem%20AWS%20Security%20Patterns%20-%20API%20Gateway.docx 

## Pre-Requisites

1. REST API should be created.
2. Authorizer name is required.
3. Lambda function should be created.


## Important Note

## Usage
To run this example you need to execute:

```bash

module "api-authorizer" {
  source = "cps-terraform.anthem.com/<ORG>/terraform-aws-api-gateway-authorizer-test/aws"

  depends_on = [module.lambda_authorizer]

  name                             = "API-gateway-authorizer"
  rest_api_id                      = module.rest_api.id
  authorizer_uri                   = module.lambda_authorizer.invoke_arn
  identity_source                  = "method.request.header.authorizationToken"
  type                             = "TOKEN"
  authorizer_result_ttl_in_seconds = "300"
  identity_validation_expression   = "[^\n]+"
  provider_arns = []

}

#Initialize Terraform
terraform init

#Terraform Dry-Run
terraform plan

#Create the resources
terraform apply

#Destroy the resources saved in the tfstate
terraform destroy
```

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| authorizer\_credentials | (Optional) The credentials required for the authorizer. To specify an IAM Role for API Gateway to assume, use the IAM Role ARN. | `string` | `null` | no |
| authorizer\_result\_ttl\_in\_seconds | (Optional) The TTL of cached authorizer results in seconds. Defaults to 300. | `string` | `"300"` | no |
| authorizer\_uri | (Optional, required for type TOKEN/REQUEST) The authorizer's Uniform Resource Identifier (URI). This must be a well-formed Lambda function URI in the form of arn:aws:apigateway:{region}:lambda:path/{service\_api}, e.g. arn:aws:apigateway:us-west-2:lambda:path/2015-03-31/functions/arn:aws:lambda:us-west-2:012345678912:function:my-function/invocations. | `string` | n/a | yes |
| identity\_source | (Optional) The source of the identity in an incoming request. Defaults to method.request.header.Authorization. For REQUEST type, this may be a comma-separated list of values, including headers, query string parameters and stage variables - e.g. "method.request.header.SomeHeaderName,method.request.querystring.SomeQueryStringName". | `string` | `null` | no |
| identity\_validation\_expression | (Optional) A validation expression for the incoming identity. For TOKEN type, this value should be a regular expression. The incoming token from the client is matched against this expression, and will proceed if the token matches. If the token doesn't match, the client receives a 401 Unauthorized response. | `string` | `null` | no |
| name | (Required) The name of the authorizer. | `string` | `null` | no |
| provider\_arns | (Optional, required for type COGNITO\_USER\_POOLS) A list of the Amazon Cognito user pool ARNs. Each element is of this format: arn:aws:cognito-idp:{region}:{account\_id}:userpool/{user\_pool\_id}. | `list(any)` | `[]` | no |
| rest\_api\_id | (Required) REST API identifier | `string` | n/a | yes |
| type | (Optional) The type of the authorizer. Possible values are TOKEN for a Lambda function using a single authorization token submitted in a custom header, REQUEST for a Lambda function using incoming request parameters, or COGNITO\_USER\_POOLS for using an Amazon Cognito user pool. Defaults to TOKEN. | `string` | `null` | no |

## Outputs

| Name | Description |
|------|-------------|
| id | The Authorizer identifier |

## Testing

1. Able to create the authorizer.