def call(def repo, def serviceName) {
    def cmd = "curl -s -X GET   https://bitbucket.org/api/2.0/repositories/ftd1platform/${repo}/pullrequests   -H 'Authorization: Basic amVua2luc2NpLXVzZXI6dVA4bURMTEhlVFdwR0RFdWE0OFM='   -H 'Cache-Control: no-cache'   -H 'Postman-Token: 0ac9736a-e0ad-4c6d-92ab-f50535037bd6' | jq '.values[].id'"
    def openPRs = sh(returnStdout: true, script: cmd)
    openPRs = openPRs.replace("\n", ",")
    PRlist = openPRs.split(',')
    for (def PR : PRlist) {
        PR = PR.trim()
        cmd = "curl -s -X GET   https://bitbucket.org/api/2.0/repositories/ftd1platform/${repo}/pullrequests/${PR}   -H 'Authorization: Basic amVua2luc2NpLXVzZXI6dVA4bURMTEhlVFdwR0RFdWE0OFM=' | jq '.title'"
        if (sh(returnStdout: true, script: cmd).contains("changes from master")) {
            cmd = "curl -s -X POST  -H 'Authorization: Basic amVua2luc2NpLXVzZXI6dVA4bURMTEhlVFdwR0RFdWE0OFM='  https://bitbucket.org/api/2.0/repositories/ftd1platform/${repo}/pullrequests/${PR}/approve"
            sh(returnStdout: true, script: cmd)
            cmd = "curl -s -X POST  -H 'Authorization: Basic amVua2luc2NpLXVzZXI6dVA4bURMTEhlVFdwR0RFdWE0OFM='  https://bitbucket.org/api/2.0/repositories/ftd1platform/${repo}/pullrequests/${PR}/merge"
            mergeStatus = sh(returnStdout: true, script: cmd)
            if (mergeStatus.contains("You can't merge until you resolve all merge conflicts")){
                echo " Couldn't Complete the merge"
                currentBuild.result = "SUCCESS"
                mailStep = "pullRequest"
                mailSubject = "$serviceName - ${PR}- MERGE CONFLICTS!!! PLEASE REVIEW & RESOLVE "
                EmailNotifications(serviceName, mailStep, mailSubject)
                prMessage = "$serviceName - ${PR}- MERGE CONFLICTS!!! PLEASE REVIEW & RESOLVE"
                // updateJira(jiraKey, prMessage)


            }
            else if(mergeStatus.contains("error"))
            {


                echo " Couldn't Complete the merge"
                currentBuild.result = "SUCCESS"
                mailStep = "pullRequest"
                mailSubject = "$serviceName - ${PR}- MERGE Aborted !!! PLEASE Make sure ftdtools has WRITE access to dev branches "
                EmailNotifications(serviceName, mailStep, mailSubject)
                prMessage = "$serviceName - ${PR}-  MERGE Aborted !!! PLEASE Make sure ftdtools has WRITE access to dev branches"
                // updateJira(jiraKey, prMessage)




            }
            else{
                echo " MERGE COMPLETED !!!"
                currentBuild.result = "SUCCESS"
                mailStep = "pullRequest"
                mailSubject = "$serviceName - ${PR}- MERGE COMPLETED !! PLEASE REVIEW "
                EmailNotifications(serviceName, mailStep, mailSubject)
                prMessage = "$serviceName - ${PR}- MERGE COMPLETED!!! PLEASE REVIEW "

            }
        }
    }
}