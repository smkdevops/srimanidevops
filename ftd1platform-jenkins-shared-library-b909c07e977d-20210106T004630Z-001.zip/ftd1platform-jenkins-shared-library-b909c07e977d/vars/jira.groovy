
// package com.ftd.workflow
def update(def jiraKey, def envString) {
    def logs=new logs()
    def props = readProperties file: "job-configuration.properties"
    def jiraApproverList = props['jiraApproverList']
    def commentJAList = props['commentJAList']
    logs.infoMessage( " $envString ")
    
    if(envString.contains(":")){
    try{envString.split(':')[1].contains("test") ? jiraApproverList = "rkande" : ""
         envString.split(':')[1].contains("test") ? commentJAList = "[~rkande]" : ""
       logs.infoMessage("JIRA Appover list & commentList- $jiraApproverList $commentJAList")
        }
    catch (e)
    {
        logs.infoMessage("$e")
    }
    }


    if (envString.contains("MergeUpdate")) {
        jiraAddComment comment: "{panel:bgColor=#97FF94}{code} ${envString} {code} {panel}", idOrKey: "$jiraKey", site: 'jira'
    } else if (envString.contains("Approval")) {


        jiraAddComment comment: "{panel:bgColor=#97FF94}{code}Approval Needed from ENG Leaders - ${commentJAList} {code} {panel}", idOrKey: "$jiraKey", site: 'jira'

    } else if (envString.contains("Pull-request")) {
        jiraAddComment comment: "{panel:bgColor=#97FF94}{code} ${envString} {code} {panel}", idOrKey: "$jiraKey", site: 'jira'
    } else if (envString.contains("EDIT")) {

//        def props = readProperties file: "job-configuration.properties"
//        def jiraApproverList = props['jiraApproverList']
        def Issue = [fields: [
//                project    : [id: "$projectID"],
//                summary    : "${serviceName} - ${crSummary}",
//                description: 'New JIRA Created from Jenkins.',
//                issuetype  : [id: "$issueTypeID"],
//                components : [[id: "$componentID", name: 'CHNG']],
//                duedate    : dateFormat.format(date),
//                labels     : ["$REGION"],
//                customfield_10036 : [value: "$impact"],
//                customfield_10037: [value: "$changeType"],
//                customfield_10110: "$rollback",
//                reporter: [name: "$reporter"],
customfield_10035: [[name: "$jiraApproverList"]],


        ]]

//        response = jiraNewIssue issue: testIssue, site: 'jira'
        response = jiraEditIssue idOrKey: "$jiraKey", issue: Issue, site: 'jira'
        echo response.successful.toString()

    } 
    
    
    else {
        jiraAddComment comment: "{panel:bgColor=#97FF94}{code}Code was deployed to ${envString} {code} {panel}", idOrKey: "$jiraKey", site: 'jira'
    }

}

//def checkApprovalStatus(def jiraKey) {
//
//    echo "PLACE HOLDER"
//
//}


def transition(def jiraKey, def transition) {
def logs=new logs()
    def transitionInput =
            [
                    transition: [
                            id: "$transition"
                    ]
            ]

    jiraTransitionIssue idOrKey: "$jiraKey", input: transitionInput, site: 'jira'


}
def getIssueStatus(def jiraKey) {
def logs=new logs()
    cmd = "curl -X GET   https://ftdcorp.atlassian.net/rest/agile/1.0/issue/${jiraKey}  -H 'Accept: application/json'   -H 'Authorization: Basic cmthbmRlQGZ0ZGkuY29tOmRtYjVlcjRNUGZaNzBOaFBSbHRHQUYxRA=='   -H 'Content-Type: application/json'   -H 'Postman-Token: a6f45267-75e9-4a11-9ace-0dd2a2394c4c'   -H 'cache-control: no-cache' | jq '.fields.status.name'"

    status = sh(returnStdout: true, script: cmd).trim()
    status = status.replaceAll("\"", "")
    // logs.infoMessage("BEFORE")
    logs.infoMessage("${status}")
    // logs.infoMessage("AFTER")
    return status

}
def createIssue()
{

    echo "Place Holder"
}

def usersInGroup(def groupName)
{

groupName = groupName.contains("CHNG ") ? "CHNG%20Approvers" : groupName
cmd = "curl -X GET   'https://ftdcorp.atlassian.net/rest/api/2/group/member?groupname=${groupName}&expand=users'   -H 'Accept: application/json'   -H 'Authorization: Basic cmthbmRlQGZ0ZGkuY29tOmRtYjVlcjRNUGZaNzBOaFBSbHRHQUYxRA=='   -H 'Cache-Control: no-cache'  | jq '.values[].emailAddress'| sed 's/\"//g' | awk 'NR > 1 { printf(\",\") } {printf \"%s\",\$0}'"
usersArray = sh(returnStdout: true, script: cmd)
return usersArray

}

def addLabel(def jiraKey, def label)
{
        def Issue = [fields: [
//                project    : [id: "$projectID"],
//                summary    : "${serviceName} - ${crSummary}",
//                description: 'New JIRA Created from Jenkins.',
//                issuetype  : [id: "$issueTypeID"],
//                components : [[id: "$componentID", name: 'CHNG']],
//                duedate    : dateFormat.format(date),
               labels     : ["$label"],
//                customfield_10036 : [value: "$impact"],
//                customfield_10037: [value: "$changeType"],
//                customfield_10110: "$rollback",
//                reporter: [name: "$reporter"],
// customfield_10035: [[name: "$jiraApproverList"]],


        ]]

//        response = jiraNewIssue issue: testIssue, site: 'jira'
        response = jiraEditIssue idOrKey: "$jiraKey", issue: Issue, site: 'jira'
        echo response.successful.toString()

}
def updateDesc(def jiraKey, def description)
{
        def Issue = [fields: [
//                project    : [id: "$projectID"],
//                summary    : "${serviceName} - ${crSummary}",
               description: "${description}",
//                issuetype  : [id: "$issueTypeID"],
//                components : [[id: "$componentID", name: 'CHNG']],
//                duedate    : dateFormat.format(date),
            //    labels     : ["$label"],
//                customfield_10036 : [value: "$impact"],
//                customfield_10037: [value: "$changeType"],
//                customfield_10110: "$rollback",
//                reporter: [name: "$reporter"],
// customfield_10035: [[name: "$jiraApproverList"]],


        ]]

//        response = jiraNewIssue issue: testIssue, site: 'jira'
        response = jiraEditIssue idOrKey: "$jiraKey", issue: Issue, site: 'jira'
        echo response.successful.toString()

}

def updateStartTime(def jiraKey, def value)
{
        def Issue = [fields: [
//                project    : [id: "$projectID"],
//                summary    : "${serviceName} - ${crSummary}",
            //    description: "${description}",
//                issuetype  : [id: "$issueTypeID"],
//                components : [[id: "$componentID", name: 'CHNG']],
//                duedate    : dateFormat.format(date),
            //    labels     : ["$label"],
//                customfield_10036 : [value: "$impact"],
//                customfield_10037: [value: "$changeType"],
//                customfield_10110: "$rollback",
//                reporter: [name: "$reporter"],
// customfield_10035: [[name: "$jiraApproverList"]],
customfield_10040: "${value}"


        ]]

//        response = jiraNewIssue issue: testIssue, site: 'jira'
        response = jiraEditIssue idOrKey: "$jiraKey", issue: Issue, site: 'jira'
        echo response.successful.toString()

}