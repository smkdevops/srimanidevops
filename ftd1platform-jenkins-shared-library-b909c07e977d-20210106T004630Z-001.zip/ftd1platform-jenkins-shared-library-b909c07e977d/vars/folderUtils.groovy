/*
 * this file will create jenkins jobs folders
 * it takes folder path as a parameter
 */

def call(String folderPath)
{
	try
	{
		wrap([$class: 'AnsiColorBuildWrapper']) 
		{
			println "\u001B[32m[INFO] creating jenkins folder at $folderPath"
			def tokens = folderPath.tokenize("/")
			def folders
			def startIndex = 0
			for(String token : tokens)
			{
				def slashIndex = folderPath.indexOf('/',startIndex)
				if( slashIndex == -1 ) 
				{
					folders = folderPath 
				}
				else 
				{
					folders = folderPath[0..slashIndex - 1]
					startIndex = slashIndex + 1
				}	
				jobDsl scriptText: """folder('${folders}')"""
			}	
		}
	}
	catch(err) 
	{
		wrap([$class: 'AnsiColorBuildWrapper']) 
		{
			print "\u001B[31m[ERROR]: Failed creating jenkins folder at $folderPath"
			currentBuild.result = "FAILED"
			throw err
		}
	}
}

