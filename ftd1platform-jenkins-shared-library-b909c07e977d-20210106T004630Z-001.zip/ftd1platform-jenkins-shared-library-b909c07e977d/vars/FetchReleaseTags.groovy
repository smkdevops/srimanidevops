def call(script)
{
	try
        {
		stage('Fetch Release Tags')
		{
	                wrap([$class: 'AnsiColorBuildWrapper']) {
        	                println "\u001B[32m[INFO] Fetching Release Tags to deploy to UAT"
				def jobObj = new com.ftd.workflow.JobManager(script)
				def branchName = jobObj.getBranchName()
				//def serviceName = jobObj.getServiceName()
				serviceName = "api-gateway-service"

				def jobConfiguration = libraryResource 'com/ftd/workflow/job-configuration.properties'
                        	writeFile file: 'job-configuration.properties', text: jobConfiguration

				def props = readProperties file: "job-configuration.properties"
        	                def project = props['project']

			
				sh("gcloud container images list-tags gcr.io/${project}/${serviceName} --filter='tags:rel-$branchName' > relTags")
				def relTags = sh(returnStdout: true, script : '''cat relTags | awk '{print $2}' | tail -n +2''').trim()

				//if( relTags == "empty")
                                //{
                                //        println "\u001B[41m[ERROR]: There are no release tags approved from this branch."
                                //        println "\u001B[41m[ERROR]: Please manually approve the builds from Jenkins Job to deploy to Production environments."
	                        //        return
	                        //}
				//def tagsList = relTags.split("\\r?\\n")
				return relTags
			}
		}
	}
	catch (err) {
                wrap([$class: 'AnsiColorBuildWrapper']) {
                        println "\u001B[31m[ERROR]: Caused by error at Fetching Release Tags to deploy to UAT"
                        currentBuild.result = "FAILED"
                        throw err
                }
        }
}
