
def call(def serviceSubstr,def branchName,def serviceName ,def imageTag , def timeOut){
    def ns
    def nameSpace
    def count
    def kubTag
    def readyfalse

//    def jobObj = new com.ftd.workflow.JobManager(script)
//    def serviceName = jobObj.getServiceName()
//    def pipelineName = jobObj.getPipelineName()
    def pipelineName = "${env.JOB_NAME}"
        def executeShell=new executeShell()

    stage('Deployment Status')
            {

                if(!pipelineName.contains("-job"))
                {
                    try {
                        timeout(time: timeOut, unit: 'MINUTES')
                                {



                                    while (true) {


                                        if ( branchName.contains("prod") )
                                        {
                                            nameSpace = "prod"
                                            ns=branchName
//                                        sleep 20
                                        }
                                        else if (branchName.contains("stag") )
                                        {
                                            nameSpace = "stag"
                                            ns=branchName
                                        }
                                        else
                                        {
                                            nameSpace = branchName
                                            ns=branchName
                                        }
                                        saveSN = serviceName.replaceAll("pci-","").trim()
                                        //save service name for greppign tagname below
                                        // saveSN = (serviceName.contains("pci-") ? serviceName.replaceAll("pci-","").trim() : serviceName )
                                        // cmd = "kubectl get pods --selector=app=${serviceSubstr},ns=${ns} -n ${nameSpace}  -o json | jq -r '.items[].status.containerStatuses[] | { \"image\": .image}' | grep ${saveSN} | cut -d':' -f3 | sed 's/\"//' | sort -u | wc -l"
                                        // count = sh(returnStdout: true, script: cmd)
                                        // count = count.replaceAll("[\n\r]", "").toInteger()
                                        rolloutCmd = "kubectl rollout status deployment/${serviceName}-${ns} -n ${nameSpace}"
                                        status=executeShell.exec(rolloutCmd).toString()
                                        cmd = "kubectl get pods --selector=app=${serviceSubstr},ns=${ns} -n ${nameSpace}  -o json | jq -r '.items[].status.containerStatuses[]? | { \"image\": .image}' | grep ${saveSN} | cut -d':' -f3 | sed 's/\"//' | sort -u "
                                        kubTag = sh(returnStdout: true, script: cmd)
                                        kubTag = kubTag.replaceAll("[\n\r]", "")
                                        cmd = "kubectl get pods --selector=app=${serviceSubstr},ns=${ns} -n ${nameSpace}  -o json | jq -r '.items[].status.containerStatuses[]? | { \"ready\": .ready}'  | grep  'false' | sort -u | wc -l"
                                        readyfalse = sh(returnStdout: true, script: cmd)
                                        readyfalse = readyfalse.replaceAll("[\n\r]", "").toInteger()
                                        println("CURRENT Tag : ${kubTag} | New Tag : ${imageTag} | PODs Unready: ${readyfalse} | uniquePodsTags: ${count}")





                                        // if (count == 1 && kubTag.contains(imageTag) && readyfalse == 0) {
                                            if(status.contains("successfully rolled out")){
//                                        println("!!!  $count --> $kubTag --> $imageTag")
                                            break
                                        }
//                                    else
//                                    {
//
//                                        println("!!! DOESNT QUALIFY")
//                                    }

                                        sleep 30
                                    }

                                    return count
                                }

                    }
                    catch (err)
                    {
                        println( "Error: $err" )

                        currentBuild.result = "UNSTABLE"
                        if ( branchName.matches("dev") || branchName.matches("qa") )
                        {
                            println("!!!!!! Please check the deployment logs - PODS are not stable/restarting continuously")
                        }
                        else if ( branchName.contains("prod") || branchName.contains("stag") )
                        {
                            // manualApproval("!!!!!! Please check the deployment logs - PODS are not stable/restarting continuously")
                            println("!!!!!! Please check the deployment logs - PODS are not stable/restarting continuously")

                        }

                    }

                }

            }



}