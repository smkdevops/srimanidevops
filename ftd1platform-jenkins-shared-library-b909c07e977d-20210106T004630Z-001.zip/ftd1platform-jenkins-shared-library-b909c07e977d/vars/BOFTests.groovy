/*
 * This files will run functional tests for respective services
 */

def call(script)
{
	try
	{
                // create Job Manager object and fetch pipeline jobs details to be used in conditions
                def jobObj = new com.ftd.workflow.JobManager(script)
                def pipeline = jobObj.getPipelineName()
		def serviceName = jobObj.getServiceName()

                //Skipping the functional tests stage for release deploy only jobs
                if( ! pipeline.contains("deploy"))
		{
			if( ! serviceName.equals("common-service"))
                	{
				wrap([$class: 'AnsiColorBuildWrapper']) {
                                	println "\u001B[32m[INFO] Functional Tests Stage. Not yet implemented"
				}
			}
		}
		currentBuild.result = "SUCCESS"
	}
        catch (err) {
                wrap([$class: 'AnsiColorBuildWrapper']) {
                        println "\u001B[31mERROR]: caused by error at Functional Tests Stage"
                        currentBuild.result = "FAILED"
                        EmailNotifications(this)
                        throw err
                }
	}
}
