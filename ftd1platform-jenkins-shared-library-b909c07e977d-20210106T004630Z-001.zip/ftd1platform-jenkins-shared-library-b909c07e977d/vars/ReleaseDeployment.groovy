/*
 * This file will handle release deployments to UAT, STRESS and PROD
 * It will also do some validations before deploying to PROD
 */

def call(script)
{
	try
        {
                def jobObj = new com.ftd.workflow.JobManager(script)
                def serviceName = jobObj.getServiceName()
		def pipelineName = jobObj.getPipelineName()

		def jobConfiguration = libraryResource 'com/ftd/workflow/job-configuration.properties'
		writeFile file: 'job-configuration.properties', text: jobConfiguration

                def props = readProperties file: "job-configuration.properties"
                def project = props['project']
		def k8sGitUrl = props['k8sGitUrl']
                def k8sGitBranch = props['k8sGitProd']
		def k8sTargetDir = props['k8sTargetDir']

		def buildTag = "${params.DOCKER_TAG}"
		def environment = "${params.ENVIRONMENT}"
		def crId = "${params.CR_ID}"
		def nonProdImage
		def releaseTag
		def logs=new logs()

		if( buildTag == "" )
		{
			error("Tags cannot be null value!!!! Please enter appropriate build tag to be deployed to $environment")
		}
		else if( ! buildTag.startsWith("uat"))
		{
			println("Please enter uat deployed docker tags. Dev deployed tags will not be deployed to production environments")
		}
		
		environment = environment.toLowerCase()
		//def updateTag = "${buildTag}"

		prodImage = "gcr.io/${project}/${serviceName}:${buildTag}"
                //releaseTag = "gcr.io/${project}/$serviceName:${updateTag}"
		
		if( environment.matches("uat|stress|stg1|stg2|stg3"))
		{
			this.checkParams(project, serviceName, environment, "$buildTag")
			if(serviceName.matches("pci-web-api-gateway-service"))
			{
		prodImage = "gcr.io/${project}/web-api-gateway-service:${buildTag}"

			}

	sh("gcloud docker -- pull ${prodImage}")

	def deployProject = props["${environment}DeployProject"]
	def cluster = props["${environment}Cluster"]
	def zone = props["${environment}Zone"]
	def nameSpace = props["${environment}NameSpace"]

	if(serviceName.matches("pci-web-api-gateway-service") || serviceName.matches("payment-gateway-service") || serviceName.matches("pci-token-service") || serviceName.matches("payment-vault-service") || serviceName.matches("payment-provider-integration-service") || serviceName.contains("fol"))
	
       {
       deployProject = props["pci${environment}DeployProject"]
       cluster = props["pci${environment}Cluster"]
       zone = props["pci${environment}Zone"]
       nameSpace = props["pci${environment}NameSpace"]

       }

	sh("gcloud config set project ${deployProject}")
        sh("gcloud container clusters get-credentials ${cluster} --zone ${zone} --project ${deployProject}")
	
    logs.infoMessage("****** ${deployProject}  ${cluster}  ${zone} ${nameSpace} ****")
			
		
                        //sh("docker tag ${nonProdImage} ${releaseTag}")
                        //sh("gcloud docker -- push ${releaseTag}")
			// DeploymentHandler(serviceName, props["${environment}Cluster"], props["${environment}Zone"], props["${environment}DeployProject"], props["${environment}NameSpace"], buildTag, k8sGitBranch, k8sTargetDir)
		DeploymentHandler(serviceName, cluster, zone, deployProject, nameSpace, buildTag, k8sGitBranch, k8sTargetDir)
		}
		else if( environment.matches("prod1|prod2|prod3|prod4|prod"))
		{
			this.prodDeploy(project, serviceName, environment, buildTag, k8sGitBranch, k8sTargetDir, props)
		}
		else
		{
			currentBuild.result = "FAILED"
			error("Environment Doesnt Match")
		}
	}
	catch (err) {
	        wrap([$class: 'AnsiColorBuildWrapper']) {
		        println "\u001B[31m[ERROR]: Caued by error at Release Deployment Stage"
		        currentBuild.result = "FAILED"
		        throw err
	        }
	}
}

def prodDeploy(def project, def serviceName, def environment, def updateTag, def k8sGitBranch, def k8sTargetDir, def props)
{
	
	this.checkParams(project, serviceName, environment, "$updateTag")
	
	def deployProject = props["${environment}DeployProject"]
	def cluster = props["${environment}Cluster"]
	def zone = props["${environment}Zone"]
	def nameSpace = props["${environment}NameSpace"]
        def logs=new logs()
        if(serviceName.matches("pci-web-api-gateway-service") || serviceName.matches("payment-gateway-service") || serviceName.matches("pci-token-service") || serviceName.matches("payment-vault-service") || serviceName.matches("payment-provider-integration-service") || serviceName.contains("fol"))
	
       {
       deployProject = props["pci${environment}DeployProject"]
       cluster = props["pci${environment}Cluster"]
       zone = props["pci${environment}Zone"]
       nameSpace = props["pci${environment}NameSpace"]

       }

	sh("gcloud config set project ${deployProject}")
        sh("gcloud container clusters get-credentials ${cluster} --zone ${zone} --project ${deployProject}")
	
    logs.infoMessage("****** ${deployProject}  ${cluster}  ${zone} ${nameSpace} ****")


	//added logic to handle front-end-service deployments
	/*if( serviceName.equals("front-end-service"))
        {
	        serviceName = "front-end-ftd-service front-end-proflowers-service"
	}*/

	for( def service : serviceName.split())
	{
		//switch traffic before deployment
		if(!(serviceName =~ "job")){

if( environment.matches("prod1"))
			this.switchTraffic(service, "Prod2", props)
		else if( environment.matches("prod2"))
			this.switchTraffic(service, "Prod1", props)
		else if( environment.matches("prod3"))
			this.switchTraffic(service, "Prod4", props)
		else if( environment.matches("prod4"))
			this.switchTraffic(service, "Prod3", props)

		}
		
		

		DeploymentHandler(service, cluster, zone, deployProject, nameSpace, updateTag, k8sGitBranch, k8sTargetDir)
	}
}

def checkParams(def project, def serviceName, def environment, def buildTag)
{
	if(serviceName.matches("pci-web-api-gateway-service"))
	{

			tagStatus = sh(returnStdout: true, script: "gcloud container images list-tags gcr.io/${project}/web-api-gateway-service --filter='tags:$buildTag'")

	}
	else{
			tagStatus = sh(returnStdout: true, script: "gcloud container images list-tags gcr.io/${project}/${serviceName} --filter='tags:$buildTag'")

	}
	
	if((tagStatus == "" ) && (environment == "prod"))
	        {	
		        currentBuild.result = "FAILED"
			error("Please deploy $buildTag to previous environment first and then deploy to Production")
		}
		else if( tagStatus == "" )
		{
			currentBuild.result = "FAILED"
			error("Tag missing in GCR. Please check the tag $buildTag and re-deploy with correct tag.")
		}
}

def switchTraffic(def serviceName, def nameSpace, def props)
{
        def targetDir = props['k8sTargetDir']

        stage("Switch Traffic to $nameSpace")
        {
                dir("$targetDir/$serviceName")
                {
		                //retryContinueOrAbort{
					sh(". ../scripts/setup.sh && 'switchTrafficTo${nameSpace}' $serviceName")
				//}
		}
	}
}
