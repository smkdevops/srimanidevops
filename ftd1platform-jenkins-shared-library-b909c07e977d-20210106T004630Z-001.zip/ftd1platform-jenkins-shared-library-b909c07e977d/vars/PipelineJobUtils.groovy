/*
 * This file is used to create pipeline jobs for deploy to STG, UAT, STRESS and PROD
 */

def call(def jobDir, def jobType, def branch, def jobName, def gitUrl, def jenkinsFile)
{
	try {
		if( jobType.equals("deploy"))
			this.deploy(jobDir, branch, jobName, gitUrl, jenkinsFile)
		else if(jobType.equals("prodDeploy"))
			this.prodDeploy(jobDir, branch, jobName, gitUrl, jenkinsFile)
		else if(jobType.equals("ukDeploy"))
			this.ukDeploy(jobDir, branch, jobName, gitUrl, jenkinsFile)
		else if(jobType.equals("prFromMaster"))
			this.prFromMaster(jobDir, branch, jobName, gitUrl, jenkinsFile)
		else if(jobType.equals("scheduler"))
		   this.scheduler(jobDir, branch, jobName, gitUrl, jenkinsFile)

	}
	catch (err) {
		wrap([$class: 'AnsiColorBuildWrapper']) {
			println "\u001B[31m[ERROR]: Failed to create pipeline job " + jobName + " at " + jobDir
			currentBuild.result = "FAILED"
			throw err
		}
	}
}

def scheduler(def jobDir, def branch, def jobName, def gitUrl, def jenkinsFile)
{
	wrap([$class: 'AnsiColorBuildWrapper']) {
		println "\u001B[32m[INFO] Creating pipeline job " + jobName + " at " + jobDir
		jobDsl scriptText: """pipelineJob("${jobDir}/${jobName}"){


			 definition {
                                 cpsScm {
                                         scm {
                                                 git {
                                                         remote {
                                                                 url('${gitUrl}')
                                                                 branches('${branch}')
                                                                 scriptPath('${jenkinsFile}')
							}
						}
					}
				}
			}
		}"""
	}
}


def deploy(def jobDir, def branch, def jobName, def gitUrl, def jenkinsFile)
{
	wrap([$class: 'AnsiColorBuildWrapper']) {
		println "\u001B[32m[INFO] Creating pipeline job " + jobName + " at " + jobDir
		jobDsl scriptText: """pipelineJob("${jobDir}/${jobName}"){
			parameters {
				stringParam('DOCKER_TAG', '', 'Please enter the docker build tag you want to deploy example :- qa1-<build_number>.<timestamp>')
				choiceParam('ENVIRONMENT', ["STG1", "STG2", "PROD1", "PROD2", "PROD3", "PROD4"], 'Please select the environment you would like to deploy the tag')
				stringParam('CR_ID', '', 'Please enter CR ID for reverting / manually deploying to  production')
			}

			 definition {
                                 cpsScm {
                                         scm {
                                                 git {
                                                         remote {
                                                                 url('${gitUrl}')
                                                                 branches('${branch}')
                                                                 scriptPath('${jenkinsFile}')
							}
						}
					}
				}
			}
		}"""
	}
}


def prodDeploy(def jobDir, def branch, def jobName, def gitUrl, def jenkinsFile)
{
        wrap([$class: 'AnsiColorBuildWrapper']) {
                println "\u001B[32m[INFO] Creating prod deploy pipeline job " + jobName + " at " + jobDir
                jobDsl scriptText: """pipelineJob("${jobDir}/${jobName}"){
                        parameters {
                                stringParam('DOCKER_TAG', '', 'Please enter the docker build tag you want to deploy example :- qa1-<build_number>.<timestamp>')
                                choiceParam('ENVIRONMENT', ["STG"], 'Please select the environment you would like to deploy the tag')
				choiceParam('REGION', ["Active-Active","REGION1", "REGION2"], 'Please select the region you would like to deploy the tag') 
                                stringParam('CR_TITLE', '', 'REQUIRED FIELD - Please enter change  title for this deployment. This will be used for CHANGE JIRA title')
								textParam('CR_DESCRIPTION', '', 'REQUIRED FIELD - Please enter additional information about this release. This will be added to the description of the change ticket ')
								

                        }

			definition {
				cpsScm {
					scm {
						git {
							remote {
								url('${gitUrl}')
								branches('${branch}')
								scriptPath('${jenkinsFile}')
							}
						}
					}
				}
			}
		}"""
	}
}



def ukDeploy(def jobDir, def branch, def jobName, def gitUrl, def jenkinsFile)
{
	wrap([$class: 'AnsiColorBuildWrapper']) {
		println "\u001B[32m[INFO] Creating UK prod deploy pipeline job " + jobName + " at " + jobDir
		jobDsl scriptText: """pipelineJob("${jobDir}/${jobName}"){
                        parameters {
                                stringParam('DOCKER_TAG', '', 'Please enter the docker build tag you want to deploy example :- qa1-<build_number>.<timestamp>')
                                choiceParam('ENVIRONMENT', ["STG"], 'Please select the environment you would like to deploy the tag')
				choiceParam('REGION', ["REGION3", "REGION4"], 'Please select the region you would like to deploy the tag') 
 				stringParam('CR_TITLE', '', 'REQUIRED FIELD - Please enter change  title for this deployment. This will be used for CHANGE JIRA title')
								textParam('CR_DESCRIPTION', '', 'REQUIRED FIELD - Please enter additional information about this release. This will be added to the description of the change ticket ')
								                        }

			definition {
				cpsScm {
					scm {
						git {
							remote {
								url('${gitUrl}')
								branches('${branch}')
								scriptPath('${jenkinsFile}')
							}
						}
					}
				}
			}
		}"""
	}
}


def prFromMaster(def jobDir, def branch, def jobName, def gitUrl, def jenkinsFile)
{
	wrap([$class: 'AnsiColorBuildWrapper']) {
		println "\u001B[32m[INFO] Creating pipeline job " + jobName + " at " + jobDir
		jobDsl scriptText: """pipelineJob("${jobDir}/${jobName}")
		{
			definition {
			 	cpsScm {
				 	scm {
					 	git {
						 	remote {
							 	url('${gitUrl}')
							 	branches('${branch}')
							 	scriptPath('${jenkinsFile}')
							}
						}
					}
				}
				triggers {
					cron('*/60 * * * *')
				}
			}
		}"""
	}
}
