/*
 * This file will create multibranch pipeline jobs
 * There are two fuctions to support poll and no poll scm
 */

def call(String jobDir, String jobName, String bitbucketUrl, String branches) 
{
	try 
	{
		wrap([$class: 'AnsiColorBuildWrapper']) 
		{
			println "\u001B[32m[INFO] Creating multipipeline job " + jobName + " at " + jobDir
			def gitBranches = branches.split()
			def branchList = ""
			for( def gitBranch : gitBranches )
			{
				branchList = branchList + gitBranch + " | "
			}

			if( jobName.contains("deploy-pipelines"))
			{
				this.jobWithoutPollScm(jobDir, jobName, bitbucketUrl, branchList)
			}
			else if( jobName.contains("hotfix"))
			{
				this.jobWithoutPollScm(jobDir, jobName, bitbucketUrl, branchList)
			}
			else
			{
				this.jobWithPollScm(jobDir, jobName, bitbucketUrl, branchList)
			}
		}
	}
	catch(err)
	{
		wrap([$class: 'AnsiColorBuildWrapper']) 
		{
			print "\u001B[31m[ERROR]: Failed to create multipieline job " + jobName + " at " + jobDir
			currentBuild.result = "FAILED"
			throw err
		}
	}
}

def jobWithPollScm(String jobDir, String jobName, String bitbucketUrl, String branchList)
{
	jobDsl scriptText: """multibranchPipelineJob("${jobDir}/${jobName}")
	{
		branchSources
		{
			git
			{
				id('3d9bee85-412a-47ab-b081-541981dde14a')
				remote('${bitbucketUrl}')
				includes('${branchList}')
			}
		}

		orphanedItemStrategy
		{
			discardOldItems
			{
				daysToKeep(10)
				numToKeep(20)
			}
		}

		triggers
		{
			periodic(5)
		}
	}"""
}

def jobWithoutPollScm(String jobDir, String jobName, String bitbucketUrl, String branchList)
{
	jobDsl scriptText: """multibranchPipelineJob("${jobDir}/${jobName}")
	{
		branchSources
		{
			git
			{
				remote('${bitbucketUrl}')
				includes('${branchList}')
				ignoreOnPushNotifications(true)
			}
                }

		configure { project ->
	    		project / 'sources' / 'data' / 'jenkins.branch.BranchSource'/ strategy(class: 'jenkins.branch.DefaultBranchPropertyStrategy') {
		        	properties(class: 'java.util.Arrays\$ArrayList') {
			        	a(class: 'jenkins.branch.BranchProperty-array'){
				        	'jenkins.branch.NoTriggerBranchProperty'()
						}
					}
				}
			}

		orphanedItemStrategy
                {
		        discardOldItems
		        {
			        daysToKeep(10)
			        numToKeep(20)
			}
		}

		triggers
                {
                        periodic(5)
                }
        }"""
}
