import org.hamcrest.core.StringContains
import org.codehaus.groovy.control.messages.ExceptionMessage

import java.text.SimpleDateFormat

def createPR(def destBranch, def repo) {
def logs=new logs()
    logs.infoMessage " Creating PR - ${repo} :  Master --> ${destBranch} \n"

    // sh("curl -S -X POST  -H 'cache-control: no-cache' -H 'content-type: application/json' -d '{\"destination\": {\"branch\": {\"name\": \"'${destBranch}'\"}},\"source\": {\"branch\": {\"name\": \"master\"}},\"title\":\"Pulling changes from master to dev1/2/3 to get latest production  changes into downstream\"}' --user  $BITBUCKET_API_USER:$BITBUCKET_API_TOKEN  https://bitbucket.org/api/2.0/repositories/ftd1platform/${repo}/pullrequests")
    sh("curl -S -X POST  -H 'cache-control: no-cache' -H 'content-type: application/json' -d '{\"destination\": {\"branch\": {\"name\": \"'${destBranch}'\"}},\"source\": {\"branch\": {\"name\": \"master\"}},\"title\":\"CAL-8691 : Pulling changes from master to ${destBranch} to get latest production  changes into downstream\"}' --user  $BITBUCKET_API_USER:$BITBUCKET_API_TOKEN  https://bitbucket.org/api/2.0/repositories/ftd1platform/${repo}/pullrequests")

}

def mergePR(def repo, def serviceName) {
    def logs=new logs()
    def cmd = "curl -s -X GET   https://bitbucket.org/api/2.0/repositories/ftd1platform/${repo}/pullrequests   -H 'Authorization: Basic amVua2luc2NpLXVzZXI6dVA4bURMTEhlVFdwR0RFdWE0OFM='   -H 'Cache-Control: no-cache'   -H 'Postman-Token: 0ac9736a-e0ad-4c6d-92ab-f50535037bd6' | jq '.values[].id'"
    def openPRs = sh(returnStdout: true, script: cmd)
    openPRs = openPRs.replace("\n", ",")
    PRlist = openPRs.split(',')
    for (def PR : PRlist) {
        PR = PR.trim()
        cmd = "curl -s -X GET   https://bitbucket.org/api/2.0/repositories/ftd1platform/${repo}/pullrequests/${PR}   -H 'Authorization: Basic amVua2luc2NpLXVzZXI6dVA4bURMTEhlVFdwR0RFdWE0OFM=' | jq '.title'"
        if (sh(returnStdout: true, script: cmd).contains("changes from master")) {
            cmd = "curl -s -X POST  -H 'Authorization: Basic amVua2luc2NpLXVzZXI6dVA4bURMTEhlVFdwR0RFdWE0OFM='  https://bitbucket.org/api/2.0/repositories/ftd1platform/${repo}/pullrequests/${PR}/approve"
            sh(returnStdout: true, script: cmd)
            cmd = "curl -s -X POST  -H 'Authorization: Basic amVua2luc2NpLXVzZXI6dVA4bURMTEhlVFdwR0RFdWE0OFM='  https://bitbucket.org/api/2.0/repositories/ftd1platform/${repo}/pullrequests/${PR}/merge"
            mergeStatus = sh(returnStdout: true, script: cmd)
            if (mergeStatus.contains("You can't merge until you resolve all merge conflicts")) {
                echo " Couldn't Complete the merge"
                currentBuild.result = "SUCCESS"
                mailStep = "pullRequest"
                mailSubject = "$serviceName - ${PR}- MERGE CONFLICTS!!! PLEASE REVIEW & RESOLVE "
                EmailNotifications(serviceName, mailStep, mailSubject)
                prMessage = "$serviceName - ${PR}- MERGE CONFLICTS!!! PLEASE REVIEW & RESOLVE"
                // jiraAction.update(jiraKey, prMessage)


            } else if (mergeStatus.contains("error")) {


                echo " Couldn't Complete the merge"
                currentBuild.result = "SUCCESS"
                mailStep = "pullRequest"
                mailSubject = "$serviceName - ${PR}- MERGE Aborted !!! PLEASE Make sure ftdtools has WRITE access to dev branches "
                EmailNotifications(serviceName, mailStep, mailSubject)
                prMessage = "$serviceName - ${PR}-  MERGE Aborted !!! PLEASE Make sure ftdtools has WRITE access to dev branches"
                // jiraAction.update(jiraKey, prMessage)


            } else {
                echo " MERGE COMPLETED !!!"
                currentBuild.result = "SUCCESS"
                mailStep = "pullRequest"
                mailSubject = "$serviceName - ${PR}- MERGE COMPLETED !! PLEASE REVIEW "
                EmailNotifications(serviceName, mailStep, mailSubject)
                prMessage = "$serviceName - ${PR}- MERGE COMPLETED!!! PLEASE REVIEW "

            }
        }
    }
}

def getPrevTag(def serviceName) {

def logs=new logs()
    cmd = "kubectl get pods -n prod  -o json | jq -r '.items[].status.containerStatuses[] | { \"image\": .image}' | grep ${serviceName} | cut -d':' -f3 | sed 's/\"//' | sort -u"
    prevTag=sh(returnStdout: true, script: cmd).trim()
    (prevTag == "" ? prevTag="New Deployment" : prevTag)
    logs.infoMessage("PREV TAG - ${prevTag}")

    return prevTag
}


def checkout(def serviceName)
{
    def logs=new logs()
    logs.infoMessage("$serviceName")
//    serviceName=serviceName.toString()

//    def serviceGitUrl =   (serviceName.contains("fol")) ?   "git@bitbucket.org:ftd1platform/fol.git" : "git@bitbucket.org:ftd1platform/${serviceName}.git"
//    checkout([$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: 'temp1'], [$class: 'CheckoutOption', timeout: 30], [$class: 'CloneOption', timeout: 30]], submoduleCfg: [], userRemoteConfigs: [[url: serviceGitUrl]]])





}

 def mergeFlow(def updateTag,def serviceName,def props,def stageConfig,def jiraKey)
 {
def logs=new logs()
        def jiraAction= new jira()
        def executeShell=new executeShell()
        def serviceList = stageConfig['serviceList']
        // def logs=new logs()

      def mergeMessage
                try {
                    stage("Merging tag to master")
                            {
                                // dir("temp1")
                                 dir("/root/workspace/${serviceName}/${serviceName}-prod-deploy-pipelines/temp1")
                                        {
logs.infoMessage ("INITIATING MERGE of ${updateTag} to MASTER !!!")

                                            if (updateTag.startsWith("hotfix") ||  updateTag.contains("hotfix") ) {
                                                // if (buildTag.contains("hotfix")) {
                                                //if (branchList.contains("origin/master")) {
                                                /*
                                        executeShell("git checkout master ; git pull --no-edit")
                                                            executeShell("git merge ${updateTag}")
                                                                executeShell("git push origin master -f") */
                                                print "Merging hotfix tag into master : ${updateTag}"
                                                executeShell.exec("git checkout master ; git pull --no-edit")
                                                executeShell.exec("git rebase -s recursive -Xours ${updateTag}")
                                                executeShell.exec("git push origin master -f")
                                                /*   } else {
                                                       print "master branch doesn't exist. Creating it from $updateTag"
                                                       sh("git checkout -b master $updateTag")
                                                       sh("git push --set-upstream origin master")
                                                   }*/

                                            } else {

                                                branchList = sh(returnStdout: true, script: "git branch -r").trim()
                                                print branchList
                                                if (branchList.contains("origin/master")) {
                                                    /*
                                            sh("git checkout master ; git pull --no-edit")
                                                                sh("git merge ${updateTag}")
                                                                    sh("git push origin master -f") */
                                                    executeShell.exec("git checkout master ; git pull --no-edit")
                                                    executeShell.exec("git rebase -s recursive -Xours ${updateTag}")
                                                    executeShell.exec("git push origin master -f")
                                                } else {
                                                    print "master branch doesn't exist. Creating it from $updateTag"
                                                    executeShell.exec("git checkout -b master $updateTag")
                                                    executeShell.exec("git push --set-upstream origin master")
                                                }


                                            }

                                            currentBuild.result = "SUCCESS"
                                            mailStep = "codeMerge"
                                            mailSubject = "$serviceName -  $updateTag merged to master"
                                            EmailNotifications(serviceName, mailStep, mailSubject)
                                            //println "There might be conflicts in merging $updateTag to master. Please merge manually"

                                            mergeMessage = "MergeUpdate:$updateTag successfully merged to Master "
                                            jiraAction.update(jiraKey, mergeMessage)


                                        }
                            }

                }
                catch (err) {
                    mailStep = "codeMerge"
                    mailSubject = "$serviceName - Failed merging $updateTag to master. Please merge manually"
                    EmailNotifications(serviceName, mailStep, mailSubject)
                    println "There might be conflicts in merging $updateTag to master. Please merge manually"
                    mergeMessage = "MergeUpdate: There might be conflicts in merging $updateTag to master. Please merge manually"
                    jiraAction.update(jiraKey, mergeMessage)


                    def userChoice
                    logs.warningMessage(" Not able to merge to master , do you want to continue?")
                    userChoice = input(message: "!!Not able to merge to master.. try manually merging with below commands and then press continue \n git checkout master ; git pull --no-edit \n  git rebase -s recursive -Xours ${updateTag} \n git push origin master -f", parameters: [
                           choice(
                                    name: 'Next Action',
                                    choices: ['Continue', 'Abort'].join('\n'),
                                    description: 'Whats your next action?'
                            )
                    ])

                    switch (userChoice) {

                        case 'Continue':
                            logs.warningMessage 'Manually merged bu the user'
                            return null;
                        default:
                            logs.errorMessage 'Aborting the build'
                            throw exception;
                    }
                    
                    
                }

                try {
                    stage("Create PR - master to dev1/2/3")
                            {
                                //front-end web-orchestration payment-gateway common web-api-gateway
                                def repoName
                                serviceSubstr = serviceName[0..serviceName.lastIndexOf('-') - 1]
                                if (serviceList.contains("${serviceSubstr}")) {
                                    repoName = serviceSubstr
                                } else if (serviceName.contains("fol-admin-service") || serviceName.contains("fol-site-service")) {
                                    repoName = "fol"
                                } else {
                                    repoName = serviceName
                                }

                                createPR("dev1", "$repoName")
                                createPR("dev2", "$repoName")
                                createPR("dev3", "$repoName")
//                stage("Merge - master to dev1/2/3"){ mergePR("$repoName") }


                            }

                    currentBuild.result = "SUCCESS"
                    mailStep = "pullRequest"
                    mailSubject = "$serviceName - Pull-request: Pull-request successfully created for dev1/2/3"
                    EmailNotifications(serviceName, mailStep, mailSubject)
                    prMessage = " Pull-request:  successfully created for dev1/2/3"
                    jiraAction.update(jiraKey, prMessage)


                }

                catch (err) {
                    currentBuild.result = "UNSTABLE"
                    mailStep = "pullRequest"
                    mailSubject = "$serviceName - Failed PR Creation.. Please pull latest changes from master into dev1/2/3"
                    EmailNotifications(serviceName, mailStep, mailSubject)
                    mergeMessage = "PR Created for dev1/2/3 - Please review and merge"
                    jiraAction.update(jiraKey, mergeMessage)

                }


                try {

                    stage("Merge - master to dev1/2/3")
                            {
                                //front-end web-orchestration payment-gateway common web-api-gateway
                                def repoName
                                serviceSubstr = serviceName[0..serviceName.lastIndexOf('-') - 1]
                                if (serviceList.contains("${serviceSubstr}")) {
                                    repoName = serviceSubstr
                                } else if (serviceName.contains("fol-admin-service") || serviceName.contains("fol-site-service")) {
                                    repoName = "fol"
                                } else {
                                    repoName = serviceName
                                }


                                mergePR("$repoName", "$serviceName")


                            }

                    currentBuild.result = "SUCCESS"


                }
                catch (err) {
                    currentBuild.result = "UNSTABLE"
                    mailStep = "pullRequest"
                    mailSubject = "$serviceName - Downstream merge failed ..please merge manually. "
                    EmailNotifications(serviceName, mailStep, mailSubject)
                    mergeMessage = "$serviceName - Downstream merge failed ..please merge manually. "
                }


           
 }