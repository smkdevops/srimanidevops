// import java.util.UUID
// def exec(command) {
//     def logs=new logs()
//     command = "set -x;" + command
//     logs.infoMessage("${command} ")
//     def uuid = UUID.randomUUID()
//     def filename = "cmd-${uuid}"
//     echo filename
    
//     sh ("${command} > ${filename}")
//     def result = readFile(filename).trim()
//     sh "rm ${filename}"
//     return result
// }

def exec(def command)
{
def logs=new logs()
command = "set -x;" + command
    logs.infoMessage("${command} ")
// cmd = ". ../scripts/setup.sh && updateValue ${ns1} ${serviceName} minReplicas ${ns1minReplicas} && applyKubectl ${ns1} ${serviceSubstr}-hpa.yaml"
                tempOut =  sh(returnStdout: true, script: command)
				logs.infoMessage("Command Results : ${tempOut}")
				return tempOut
//    logs.infoMessage("sh(returnStdout: true, script: ${command})")
 
}

def execInt(def command)
{

	def logs=new logs()
command = "set -x;" + command
    logs.infoMessage("${command} ")

                    tempOut =   sh(returnStdout: true, script: command) as int
					logs.infoMessage("Command Results : ${tempOut} ")
				return tempOut

}
def prepNode()
{


			sh("cp /home/jenkins/.netrc /root/")
			sh("cp /home/jenkins/.gitconfig /root/")
			sh("cp -rfp /home/jenkins/.ssh /root/")
			sh("chown root:root /root/.ssh/config")}
