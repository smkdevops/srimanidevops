/*
 * Runs docker build and then push the image to GCR
 * images are tagged as <branchName>-<version>.<buildNumber>
 */

def call(script) 
{
	try
        {
        	def jobObj = new com.ftd.workflow.JobManager(script)
                def pipeline = jobObj.getPipelineName()
		def serviceName = jobObj.getServiceName()

                if( ! pipeline.contains("deploy")) 
		{
			if( ! serviceName.equals("common-service"))
			{
				wrap([$class: 'AnsiColorBuildWrapper']) {
        	                	println "\u001B[32m[INFO] Creating Docker Image and Pushing to GCR"
					stage('Docker Build and Push to GCR')
					{
						def jobConfiguration = libraryResource 'com/ftd/workflow/job-configuration.properties'
						writeFile file: 'job-configuration.properties', text: jobConfiguration
	
						def props = readProperties file: "job-configuration.properties"
						def project = props['project']
						
						/*if( serviceName.equals("web-api-gateway-service"))
						{
							serviceName = "api-gateway-service"
						}*/
						def branchName = jobObj.getBranchName()
						def branch
						if(branchName.toLowerCase().contains("hotfix"))
							branch = "hotfix"
						else
							branch = branchName

						if(serviceName.contains("-alt"))

						{

							def imageTag = "gcr.io/${project}/${serviceName}:dev3-alt-${BUILD_NUMBER}.${env.TIMESTAMP}"
							sh("gcloud container clusters get-credentials prod-devops-primary-1 --project gcp-ftd-prod-devops --zone us-central1-a")
							sh("docker build --no-cache --pull -t ${imageTag} .")
							sh("gcloud docker -- push ${imageTag}")

							currentBuild.displayName = "dev3-alt-${BUILD_NUMBER}.${env.TIMESTAMP}"
							// ContainerAnalysis(imageTag,  serviceName, pipeline, branch)
						}
						else
						{
							def imageTag = "gcr.io/${project}/${serviceName}:${branch}-${BUILD_NUMBER}.${env.TIMESTAMP}"
							sh("gcloud container clusters get-credentials prod-devops-primary-1 --project gcp-ftd-prod-devops --zone us-central1-a")
							sh("gcloud auth configure-docker")
							sh("docker build --no-cache --pull -t ${imageTag} .")
//							sh("gcloud docker -- push ${imageTag}")
							sh("docker push ${imageTag}")


							currentBuild.displayName = "${branch}-${BUILD_NUMBER}.${env.TIMESTAMP}"
							// branchName.toLowerCase().contains("qa") ? ContainerAnalysis(imageTag,  serviceName, pipeline, branch) : ""

						}

					}
				}
			}
		}
		currentBuild.result = "SUCCESS"
	}
	catch (err) {
                wrap([$class: 'AnsiColorBuildWrapper']) {
                        println "\u001B[31m[ERROR]: Caused by error at Docker Build and Push to GCR stage"
                        currentBuild.result = "FAILED"
			EmailNotifications(this)
                        throw err
                }
        }
}


