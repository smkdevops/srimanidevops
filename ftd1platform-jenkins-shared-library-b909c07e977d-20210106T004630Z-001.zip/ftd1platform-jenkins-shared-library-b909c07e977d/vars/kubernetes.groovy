def switchTraffic(def region,def serviceName, def nameSpace, def props, def action,def jiraKey,def node) {
        def logs=new logs()
        def jiraAction= new jira()
        def git=new git()
        def executeShell=new executeShell()
    def targetDir = props['k8sTargetDir']
    println "ACTIOn -  $action!!!!"
    String saveNS = "$nameSpace"
    String actualNS = nameSpace
    def deployStatus = "false"
    def serviceSubstr = serviceName[0..serviceName.lastIndexOf('-') - 1]
//    def props = readProperties file: "job-configuration.properties"
    def stageConfig = libraryResource 'com/ftd/workflow/stage-config.properties'
    writeFile file: 'stage-config.properties', text: stageConfig
    stageConfig = readProperties file: "stage-config.properties"
        def pciList = stageConfig['pciList']

    def sleepTime = stageConfig["sleepTime"]
    def nettyService = stageConfig["netty"]
    def scaleTo 
    def saveMaxReplica
    def  cluster = props["${nameSpace}Cluster"]
    def zone = props["${nameSpace}Zone"]
def  misc = new misc()
def deployProject = props["${nameSpace}DeployProject"]
    logs.infoMessage("$region - ")
    dir("$targetDir/$serviceName") {


                if (!serviceName.contains("ingestion") && !serviceName.contains("-job") && !serviceName.contains("fol-admin")){



     (region.matches("REGION1")) ? ns = "prod1,prod2" : (region.matches("REGION2")) ? ns = "prod3,prod4" : (region.matches("REGION3")) ? ns = "prod5,prod6" : (region.matches("REGION4")) ? ns = "prod7,prod8" : (region.matches("Active-Active") && (node.matches("NODE1"))) ? ns = "prod1,prod2" : (region.matches("Active-Active") && (node.matches("NODE2"))) ? ns = "prod3,prod4" : (region.matches("Active-Active") && (node.matches("cluster1"))) ? ns = "prod1,prod2" : (region.matches("Active-Active") && (node.matches("cluster2"))) ? ns = "prod3,prod4":"Check Arguments again"
logs.infoMessage("${region}")
        ns1 = ns.split(',')[0]
        ns2 = ns.split(',')[1]
        cmd = "cat ./values-${ns1}.sh | grep minReplicas  | cut -d \"=\" -f 2 | sed s/\\\"//g"
        // ns1minReplicas = sh(returnStdout: true, script: cmd) as int
        ns1minReplicas = executeShell.execInt(cmd)
        cmd = "cat ./values-${ns2}.sh | grep minReplicas  | cut -d \"=\" -f 2 | sed s/\\\"//g"
        // ns2minReplicas = sh(returnStdout: true, script: cmd) as int
        ns2minReplicas = executeShell.execInt(cmd)
cmd = "cat ./values-${ns1}.sh | grep maxReplicas  | cut -d \"=\" -f 2 | sed s/\\\"//g"
     saveMaxReplica = executeShell.execInt(cmd)   
        logs.infoMessage(" NS1 - $ns1minReplicas NS2 - $ns2minReplicas - maxReplica - $saveMaxReplica")
}
       if ( (nameSpace.contains("prod") || nameSpace.contains("stag") ) && (misc.searchList(serviceName,pciList).contains("true")) ){

                //   logs.infoMessage(props["${nameSpace}Cluster"] $zone, $deployProject  )

  this.justK8s(props["pci${nameSpace}Cluster"], props["pci${nameSpace}Zone"], props["pci${nameSpace}DeployProject"] )
  executeShell.exec("kubectl config current-context")
       logs.infoMessage("$region --> ")

       }
    //    else if ( (nameSpace.contains("prod") || nameSpace.contains("stag") ) && !(pciList.contains(serviceSubstr)) ){
               else if ( (nameSpace.contains("prod") || nameSpace.contains("stag") ) && !(misc.searchList(serviceName,pciList).contains("true")) ){



            //  logs.infoMessage("$cluster, $zone, $deployProject  ")

  this.justK8s(props["${nameSpace}Cluster"], props["${nameSpace}Zone"], props["${nameSpace}DeployProject"] )
  executeShell.exec("kubectl config current-context")
//       logs.infoMessage("$region --> $ns")

       }


     

//    saveminReplicas = ns1minReplicas

//    }
//    dir("$targetDir/$serviceName") {
        if ( nameSpace.contains("prod") && action.contains("deployment") && ((!serviceName.contains("ingestion")) && (!serviceName.contains("-job")) && (!serviceName.contains("fol-admin"))))
        {
            actualNS = actualNS.replaceAll("\\d", "")
            if(region.contains("REGION"))
            {
//replace numbers in the namespace


                passiveNS = ("${saveNS}" == "prod1") ? "prod2" : ("${saveNS}" == "prod2") ? "prod1" : ("${saveNS}" == "prod3") ? "prod4" : ("${saveNS}" == "prod4") ? "prod3" :  ("${saveNS}" == "prod5") ? "prod6" : ("${saveNS}" == "prod6") ? "prod5" : ("${saveNS}" == "prod7") ? "prod8" : ("${saveNS}" == "prod8") ? "prod7" : "Check the ${nameSpace} value"
            cmd = "kubectl get pods -n $actualNS | grep  ^${serviceName} | grep ${passiveNS} |  wc -l"
            scaleTo = sh(returnStdout: true, script: cmd).replaceAll("[\n\r]", "") as int
            cmd = "kubectl get pods -n $actualNS | grep  ^${serviceName} | grep ${saveNS} |  wc -l"
            scaleTo += sh(returnStdout: true, script: cmd).replaceAll("[\n\r]", "") as int
// scaleTo += scaleTo

            }
            else if(region.contains("Active-Active"))
            {
//                actualNS = actualNS.replaceAll("\\d", "")


                passiveNS = (saveNS.contains("prod1") ? "prod2" : saveNS.contains("prod2")  ? "prod1" : saveNS.contains("prod3")  ? "prod4" : saveNS.contains("prod4")  ? "prod3" : "Check the ${nameSpace} value")
                cmd = "kubectl get pods -n $actualNS | grep  ^${serviceName} | grep ${passiveNS} |  wc -l"
            scaleTo = sh(returnStdout: true, script: cmd).replaceAll("[\n\r]", "") as int
            cmd = "kubectl get pods -n $actualNS | grep  ^${serviceName} | grep ${saveNS} |  wc -l"
            scaleTo += sh(returnStdout: true, script: cmd).replaceAll("[\n\r]", "") as int
// scaleTo += scaleTo

            }
            
            saveminReplicas = 3
            println "!!!ServiceName - $serviceName"

         
//        scaleTo = (scaleTo > 10) ? 10 : (serviceName.contains("web-") ? scaleTo
//        scaleTo = ((scaleTo > 10) ? (scaleTo = 10) : scaleTo)
            if ((scaleTo > saveMaxReplica)){
                 logs.infoMessage("Desired Count is more than tha maxReplica($saveMaxReplica) - Setting it to $saveMaxReplica ")
                scaleTo = saveMaxReplica
            }


            // if ((scaleTo > saveMaxReplica) && serviceName.contains("web-"))

            // {
            //     logs.infoMessage("Desired Count is more $scaleTo - settting it to $saveMaxReplica  ")
            //     scaleTo = saveMaxReplica
            // }

            //skipping scaleup for new services
            if ((executeShell.execInt("kubectl get hpa -n prod | grep ${serviceName} | wc -l")) != 0) {

                try {

                    timeout(time: 5, unit: 'MINUTES') {
                        stage("Scale up $saveNS ")
                                {

                                    cmd = ". ../scripts/setup.sh && updateValue ${saveNS} ${serviceName} minReplicas ${scaleTo} && applyKubectl ${saveNS} ${serviceSubstr}-hpa.yaml"
                                    executeShell.exec(cmd)
                                    while (true) {

                                        cmd = "kubectl get pods --selector=app=${serviceSubstr},ns=${saveNS} -n $actualNS  -o json | jq -r '.items[].status.containerStatuses[] | { \"ready\": .ready}'  | grep  'true' |  wc -l"


                                        podsCount = executeShell.execInt(cmd)
                                        // podsCount = (serviceName.contains("front-end")) ? podsCount : (serviceName.contains("pci-web-api-gateway") || serviceName.contains("pci-token") || serviceName.contains("payment-gateway") || !misc.searchList(serviceName,nettyService).contains("true")) ? podsCount.div(2) : podsCount.div(3)
                                        // echo "Current PODS Count - ${podsCount} || Desired after scaleup - ${scaleTo}"

                                    cmd = "kubectl  get deployment -n $actualNS ${serviceName}-${saveNS} -o json | grep '\"image\":' | wc -l"
                                        divBy = executeShell.execInt(cmd)
                                        // podsCount = (serviceName.contains("front-end")) ? podsCount : (serviceName.contains("pci-web-api-gateway") || serviceName.contains("pci-token") || serviceName.contains("payment-gateway") || !misc.searchList(serviceName,nettyService).contains("true")) ? podsCount.div(2) : podsCount.div(3)
                                       podsCount = podsCount.div(divBy)
                                           logs.infoMessage("Current PODS Count - ${podsCount} || Desired after scaleup - ${scaleTo}") 

                                        if ("${podsCount}" >= "${scaleTo}")   {
                                                logs.infoMessage("Desired Count acquired")
                                            break
                                        }
                                        sleep(10)
                                    }

                                }
                    }

                    }
                
                catch (e)
                {
                    def userChoice
                    stage("User Input required"){
// , parameters: [[$class: 'StringParameterDefinition', defaultValue: 'master', description: '', name: 'branch']]
            // echo "BRANCH NAME: ${branchInput}"

                    logs.warningMessage(" Not able to scaleup allpods in 5min, do you want to continue?")
                    // userChoice = input(message: "Not able to scaleup allpods in 5min, do you want to continue?", parameters: [
                    //        choice(
                    //                 name: 'Next Action',
                    //                 choices: ['Continue', 'Abort'].join('\n'),
                    //                 description: 'Whats your next action?'
                    //         )
                    // ])
                    userChoice = input message: 'Not able to scaleup allpods in 5min, do you want to continue?', parameters: [choice(choices: ['Continue', 'Abort'], description: 'Whats your next action?', name: 'Next Action')]

                    switch (userChoice) {

                        case 'Continue':
                            logs.warningMessage 'Check manually if all pods are up & running.'
                            // return null;
                                            break

                        default:
                            logs.errorMessage 'Aborting the build'
                            throw exception;
                    }

                    }
                    


                }


            } else {
                println("HPA file is missing - Scaling up wont happen ")
            }


            stage("Switch $serviceName Traffic to $saveNS"){

                println "\u001B Switching traffic to $saveNS "
                executeShell.exec(".  ../scripts/setup.sh && switchTraffic ${saveNS} $serviceName")
            }
            jiraAction.transition(jiraKey, 21) //Inprogress

            if(serviceName.contains("web-api"))
            {
            addSleep(320)

            }
            else{
                            addSleep(sleepTime)

            }




        }

        else if ( (saveNS.contains("Cluster"))   &&  ((!serviceName.contains("ingestion")) && (!serviceName.contains("-job")) && (!serviceName.contains("fol-admin"))))

        {


//


            logs.infoMessage(" NS1 - $ns1minReplicas NS2 - $ns2minReplicas")
            stage("Switch $serviceName Traffic to $saveNS") {
def environment
                    saveNS = saveNS.split("\\(")[0]
                                  (saveNS.contains("Cluster1") ? environment="prod1" : saveNS.contains("Cluster2") ? environment="prod3" : "")


                    println("!!!!!!!! SWITCHING TRAFFIC to both in  $saveNS !!!!!! ")
                    
                    // this.justK8s( props["${environment}Cluster"], props["${environment}Zone"], props["${environment}DeployProject"] )


                    sh(". ../scripts/setup.sh && 'switchTrafficToBothIn${saveNS}' $serviceName")

                    (saveNS == "Cluster1") ? ns = "prod1,prod2" : (saveNS == "Cluster2") ? ns = "prod3,prod4" : "Check Arguments again"
                    ns1 = ns.split(',')[0]
                    ns2 = ns.split(',')[1]

                    logs.infoMessage("SWITCHING TO $saveNS with NS1 - $ns1minReplicas NS2 - $ns2minReplicas")

                    cmd = ". ../scripts/setup.sh && updateValue ${ns1} ${serviceName} minReplicas ${ns1minReplicas} && applyKubectl ${ns1} ${serviceSubstr}-hpa.yaml"
                    tempOut = sh(returnStdout: true, script: cmd)
                    cmd = ". ../scripts/setup.sh && updateValue ${ns2} ${serviceName} minReplicas ${ns2minReplicas} && applyKubectl ${ns2} ${serviceSubstr}-hpa.yaml"
                    tempOut = sh(returnStdout: true, script: cmd)
                    logs.infoMessage("SWITCHING TO $saveNS with NS1 - $ns1minReplicas NS2 - $ns2minReplicas")
//                                sh "git commit -am 'updated from ${serviceName}-${buildTag} build'"
//                                sh("git pull --no-edit origin ${k8sGitBranch}"




            }

        } else if ( (saveNS.contains(""))   &&  ((!serviceName.contains("ingestion")) && (!serviceName.contains("-job")) && (!serviceName.contains("fol-admin")))){

        }
        
        else {
            saveminReplicas = 1
            println("$saveminReplicas - No ScaleUP is needed")
        }

    }

}


def justK8s(def cluster, def zone, def deployProject) {
        def executeShell=new executeShell()
        def logs=new logs()

logs.infoMessage("Setting gcloud credentials !!!")
    executeShell.exec("gcloud config set project ${deployProject}")
    executeShell.exec("gcloud container clusters get-credentials ${cluster} --zone ${zone} --project ${deployProject}")
}
def setCreds(def key) {
    def executeShell=new executeShell()

    executeShell.exec("gcloud config set project ${deployProject}")
    executeShell.exec("gcloud container clusters get-credentials ${cluster} --zone ${zone} --project ${deployProject}")
}

def addSleep(def sleepTime)
{
        def executeShell=new executeShell()

    stage("wait for ${sleepTime} sec")
                    {
                        executeShell.exec("sleep ${sleepTime}")
                    }
}