/*
 * This file will create an SCM tag for each qa1, qa2 and qa3 branch builds
 */

def call(script) 
{
	try
        {
		def jobObj = new com.ftd.workflow.JobManager(script)
                def pipeline = jobObj.getPipelineName()
		def branchName = jobObj.getBranchName()

                if( ! pipeline.contains("deploy"))
                {
	        	if((branchName.matches("qa1|qa2|qa3") || branchName.contains("hotfix")) && env.tagStatus.equals("false")) 
			{
				wrap([$class: 'AnsiColorBuildWrapper']) {
        	                	println "\u001B[32m[INFO] Tagging SCM Code"
					stage('SCM Tagging Build')
					{
						def branch
						if(branchName.toLowerCase().contains("hotfix"))
							branch = "hotfix"
						else
							branch = branchName
						def serviceName = jobObj.getServiceName()
						version = "${branch}-${BUILD_NUMBER}.${env.TIMESTAMP}"
						sh "git tag -m 'Tag for ${branchName} branch & version ${version}' '${version}'"
						sh "git push origin '${version}'"
						env.tagStatus = "true"
					}
				}
			}
		}
		currentBuild.result = "SUCCESS"
	}
	catch (err) {
                wrap([$class: 'AnsiColorBuildWrapper']) {
                        println "\u001B[31m[ERROR]: Caused by error at Tagging SCM"
                        currentBuild.result = "FAILED"
                        throw err
                }
        }
}


