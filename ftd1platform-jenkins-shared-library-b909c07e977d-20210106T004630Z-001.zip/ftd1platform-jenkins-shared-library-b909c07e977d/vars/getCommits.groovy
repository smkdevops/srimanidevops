def commits(def currentTag, dev previousTag)
{
    sh ("git log --pretty=oneline $currentTag $previousTag | grep CAL | cut -d \" \" -f2| sed 's/://g'")

}