def searchList(def serviceName,def searchList)
{

    // /def serviceName = "test-service"    
// def pciList = "fol-admin,fol-site,pci-token,payment-gateway,pci-test,pci-web-api-gateway,test"    
def serviceSubstr =   serviceName[0..serviceName.lastIndexOf('-') - 1]
   def executeShell=new executeShell()
        def logs=new logs()
            // def pciList = stageConfig['pciList']
def matchFound = false
index = serviceName.lastIndexOf('-')
echo "$searchList - ${serviceSubstr}"
searchListSplit = searchList.split(" ")
searchListSplit.each{
    if (it.matches("${serviceSubstr}")) { 
logs.infoMessage(" $serviceName is part of the List - ${it}")
// print("MATCH FOUND")
matchFound = true
}
// else
// {
//     logs.infoMessage(" $serviceName is Not part of the List - ${it}")

//     // print("MATCH NOT FOUND")
//     return false

// }
    
}
return matchFound.toString()
}
