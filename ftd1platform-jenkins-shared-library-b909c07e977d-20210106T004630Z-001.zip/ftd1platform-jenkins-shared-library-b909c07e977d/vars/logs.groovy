String boldGreenMessage(final String message) { return "\033[1;32m${message}\033[0m" }
String boldBlueMessage(final String message) { return "\033[1;34m${message}\033[0m" }
String boldRedMessage(final String message) { return "\033[1;31m${message}\033[0m" }
String boldYellowMessage(final String message) { return "\033[1;33m${message}\033[0m" }
String triplePrefixMessage(final Closure<String> colour, final String prefix, final String message) {
    def colouredPrefix = "${colour("${prefix}")}"
    return "${colouredPrefix}\n${colouredPrefix} ${message}\n${colouredPrefix}"
}
void successMessage(final String message) { ansiColor('xterm') { echo triplePrefixMessage(this.&boldGreenMessage, '[SUCCESS]', message) } }
void infoMessage(final String message) { ansiColor('xterm') { echo triplePrefixMessage(this.&boldBlueMessage, '[INFO]', message) } }
void sleepMessage(final String message) { ansiColor('xterm') { echo triplePrefixMessage(this.&boldBlueMessage, '[INFO]', message)
sleep(15)
 } }

void warningMessage(final String message) { ansiColor('xterm') { echo triplePrefixMessage(this.&boldYellowMessage, '[WARNING]', message) } }
void errorMessage(final String message) { ansiColor('xterm') { echo triplePrefixMessage(this.&boldRedMessage, '[ERROR]', message) } }
