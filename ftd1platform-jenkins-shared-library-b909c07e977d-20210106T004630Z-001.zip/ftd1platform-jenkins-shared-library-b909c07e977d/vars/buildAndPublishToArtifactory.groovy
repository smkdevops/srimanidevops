
def buildAndPublishToArtifactory() {
    def rtMaven = Artifactory.newMavenBuild()
    rtMaven.tool = "Maven 3.x"
    rtMaven.deployer releaseRepo:'libs-release-local', snapshotRepo:'libs-snapshot-local', server: server
    rtMaven.resolver releaseRepo:'libs-release', snapshotRepo:'libs-snapshot', server: server
    rtMaven.run pom: 'pom.xml', goals: 'deploy', buildInfo: buildInfo
    server.publishBuildInfo buildInfo
}