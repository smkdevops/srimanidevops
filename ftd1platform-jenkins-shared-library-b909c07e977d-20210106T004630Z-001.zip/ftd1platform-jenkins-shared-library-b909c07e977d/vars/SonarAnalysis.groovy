/*
 * This file will run Sonar Analysis for the project
 * It will create sepearate sonar project for each branch
 */

def call(script)
{
	try
        {
		def jobObj = new com.ftd.workflow.JobManager(script)
                def pipeline = jobObj.getPipelineName()
		def serviceName = jobObj.getServiceName()
		def branchName = jobObj.getBranchName()
			def serviceSubstr = serviceName[0..serviceName.lastIndexOf('-') - 1]
		def stageConfig = libraryResource 'com/ftd/workflow/stage-config.properties'
                writeFile file: 'stage-config.properties', text: stageConfig
                def props = readProperties file: "stage-config.properties"
			def sonarLimits = props['sonarLimits']
			def serviceList = props['serviceList']
		def skipSonar = props['skipSonar']
		def runSonar = props['runSonar']

                if(! pipeline.contains("deploy") && ! pipeline.contains("hotfix")) 
                {
			if((! serviceName.contains("-job")) || ( runSonar.contains("${serviceName}")))
			{
				if( ! skipSonar.contains("${serviceName}"))
				{
	                		wrap([$class: 'AnsiColorBuildWrapper']) {
        	                		println "\u001B[32m[INFO] Doing Sonar Analysis"
						stage('Sonar Analysis')
						{

							def scannerHome = tool 'Sonar_Scanner'
							if(serviceName.contains("front-end")) {
								sh("npm run test:c")
								withSonarQubeEnv('sonar') {
									sh "${scannerHome}/bin/sonar-scanner -Dsonar.host.url=${SONAR_HOST_URL} -Dsonar.branch=${branchName}"
								}
							}
							else{
								withSonarQubeEnv('sonar'){
									sh "${scannerHome}/bin/sonar-scanner -Dsonar.host.url=${SONAR_HOST_URL} -Dsonar.branch=${branchName}"
							}


							}

						}
					}
					stage('Quality Gate check') {
						timeout(time: 1, unit: 'HOURS') {
							def qg = waitForQualityGate()
							if (qg.status != 'OK') {
								mailStep = "sonarFailure"
								mailSubject = "$serviceName $branchName - Sonar Quality Gate - FAILURE"
								FetchSonarCoverage(this)
								wrap([$class: 'AnsiColorBuildWrapper']) {
									println "\u001B[31m[ERROR]: Caused by error at Sonar Quality Gate stage"
								}
								//if (branchName.matches("qa1|qa2|qa3")) {
									//currentBuild.result = "FAILED"
									EmailNotifications(serviceName, mailStep, mailSubject)
									//throw err
								/*}
								else if (branchName.matches("dev1|dev2|dev3")) {
									EmailNotifications(serviceName, mailStep, mailSubject)
								}*/
							}
							else
							{


								FetchSonarCoverage(this)
							}
						}

						def saveServiceName
						if (serviceList.contains("${serviceSubstr}")) {
							saveServiceName = serviceSubstr
						} else {
							saveServiceName = serviceName
						}

						sonar_new_coverage = sh (script: "curl -X GET -u 77052dd6a4877116bc14a7638dd279e738c92b58:  'https://sonar.ftdi.com/api/measures/component?component=${saveServiceName}:${branchName}&metricKeys=new_coverage' | jq '.component.measures[0].periods[0].value' |sed 's/\"//g' ",returnStdout: true).trim()
						echo "SONAR NEW COVERAGE ${sonar_new_coverage}"

						overall_coverage = sh (script: "curl  -X GET -u 77052dd6a4877116bc14a7638dd279e738c92b58:  'https://sonar.ftdi.com/api/measures/component?component=${saveServiceName}:${branchName}&metricKeys=coverage' | jq '.component.measures[0].value' |sed 's/\"//g' ",returnStdout: true).trim()
						echo "OVERALL SONAR  COVERAGE ${overall_coverage}"

						if(serviceName.contains("front-end"))
						{

							if (overall_coverage < "${sonarLimits}") {
								wrap([$class: 'AnsiColorBuildWrapper']) {
									//currentBuild.result = "FAILED"
                                     echo "******SONAR COVERAGE thresholds : (${sonarLimits}\\\")  - Overall Coverage for ${serviceName}:${branchName} is ${overall_coverage}"
									//error("\\u001B[31m[ERROR]: SONAR COVERAGE thresholds : (${sonarLimits}\")  - Overall Coverage for ${serviceName}:${branchName} is ${overall_coverage}")

								}
							}


						}
						else{


							if (overall_coverage < sonarLimits  && overall_coverage != "100.0" ) {
								wrap([$class: 'AnsiColorBuildWrapper']) {
									currentBuild.result = "FAILED"

									error("[ERROR]: SONAR COVERAGE thresholds : (${sonarLimits})  - Overall Coverage for ${serviceName}:${branchName} is ${overall_coverage}")

								}
							}
						}








					}
				}
			}
		}
		currentBuild.result = "SUCCESS"
	}
	catch (err) {
		wrap([$class: 'AnsiColorBuildWrapper']) {
			println "\u001B[31m[ERROR]: Caused by error at Sonar Aalysis stage"
			currentBuild.result = "FAILED"
			EmailNotifications(this)
			throw err
		}
	}
}
