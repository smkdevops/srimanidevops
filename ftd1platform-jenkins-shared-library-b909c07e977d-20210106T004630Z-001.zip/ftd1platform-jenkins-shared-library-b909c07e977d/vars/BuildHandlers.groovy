/*
 * This files will run build tools for respective services
 */

def call(script) 
{
	try
	{
		// create Job Manager object and fetch pipeline jobs details to be used in conditions
		def jobObj = new com.ftd.workflow.JobManager(script)
		def pipeline = jobObj.getPipelineName()
		def serviceName = jobObj.getServiceName()

		def stageConfig = libraryResource 'com/ftd/workflow/stage-config.properties'
		writeFile file: 'stage-config.properties', text: stageConfig
		def props = readProperties file: "stage-config.properties"

		def skipBuild = props['skipBuild']
		def runBuild = props['runBuild']

		//Skipping the build stage for deploy only jobs
		if( ! pipeline.contains("deploy"))
		{
			if(( ! serviceName.contains("-job")) || ( runBuild.contains("${serviceName}")))
			{
			print serviceName
                        //skipping build stage for wiremock service
			if( ! skipBuild.contains("${serviceName}"))
			{
				wrap([$class: 'AnsiColorBuildWrapper']) {
					def buildObj = new com.ftd.workflow.BuildHandlers(serviceName)
                                        def buildCommand = buildObj.getBuildArgs()
					def buildTool = buildCommand[0..buildCommand.indexOf('|') - 1]
                                        buildTool = buildTool.trim()

					println "\u001B[32m[INFO] Building the Code"
					stage('Build the Code')
					{
						buildCommand = buildCommand[buildCommand.indexOf('|') + 1..-1]
	
						if( buildTool == "mvn" )
						{
							withMaven(maven:'default') {
								env.PATH = "/opt/google-cloud-sdk/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/usr/local/nodejs/bin:/usr/local/nodejs/bin"
								sh "${buildCommand} -DskipTests=true "
							}
						}
						else if( buildTool == "npm" )
						{
							sh("${buildCommand}")
						}
						else if(buildTool == "gradle")
						{
							sh("${buildCommand}")
						}
					}

					if( buildTool == "mvn" )
					{
						def skipUnitTests = props['skipUnitTests']
						
						if(! skipUnitTests.contains("${serviceName}"))
						{
							println "\u001B[32m[INFO] running unit tests"
							stage('Unit tests')
							{

								withMaven(maven:'default') {
	                                                               	env.PATH = "/opt/google-cloud-sdk/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/usr/local/nodejs/bin:/usr/local/nodejs/bin"
	                                                               	sh "mvn test  -B -Dmaven.javadoc.skip=true -Dcheckstyle.skip=true"
	                                                       	}
							}
						}
					}
					else if( buildTool == "npm" )
					{
						def skipUnitTests = props['skipUnitTests']

						if(! skipUnitTests.contains("${serviceName}") && ! serviceName.contains("conductor-"))
						{
							println "\u001B[32m[INFO] running unit tests"
							stage('Unit tests')
									{
										env.PATH = "/opt/google-cloud-sdk/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/usr/local/nodejs/bin:/usr/local/nodejs/bin"
										sh("npm run test")
									}
						}
					}



					if( ! pipeline.contains("hotfix"))
					{
						if( buildTool == "mvn" )
                                        	{
                                                	def skipDeploy = props['skipDeploy']
	                                                if(! skipDeploy.contains("${serviceName}"))
        	                                        {
                	                                       	println "\u001B[32m[INFO] running deploy to artifactory"
	                	                                stage('Deploy to Artifactory')
        	                	                	{
                	                	                	withMaven(maven:'default') {
                        	                	                	env.PATH = "/opt/google-cloud-sdk/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/usr/local/nodejs/bin:/usr/local/nodejs/bin"
                                	                	                sh "mvn deploy -Dspotless.check.skip=true -DskipTests=true"
                                        	        		}
                                                		}
                                                	}
						}
					}
				}
					
			}
			}
		}
		currentBuild.result = "SUCCESS"
	}
	catch (err) {
		wrap([$class: 'AnsiColorBuildWrapper']) {
			println "\u001B[31mERROR]: caused by error at Build Stage"
			currentBuild.result = "FAILED"
			EmailNotifications(this)
			throw err
		}
	}
}
