import org.apache.tools.ant.taskdefs.condition.Or

/*
 * This file is used to run the main deployment logic
 * For frontend it runs the deployment twice. One for ftd and another for proflowers
 */

def call(
        def serviceName,
        def cluster, def zone, def deployProject, def nameSpace, def imageTag, def k8sGitBranch, def targetDir) {

    def jiraAction= new jira()
    def serviceSubstr = serviceName[0..serviceName.lastIndexOf('-') - 1]
        def executeShell=new executeShell()
        def logs=new logs()
def rootDir
//           def saveSN = ((serviceName.contains("pci-test") ||  (serviceName.contains("pci-web")))? serviceName.replaceAll("pci-","").trim() : serviceName )
    def saveSN = (( (serviceName.contains("pci-web") || serviceName.contains("pci-test") ))? serviceName.replaceAll("pci-","").trim() : serviceName )

    logs.infoMessage("****** ${saveSN}  ${serviceName}  ${serviceSubstr} ${nameSpace} ****")
    if (nameSpace.matches("dev3-alt")) {
        nameSpace = "dev3"
    }
    if (nameSpace.matches("qa3-alt")) {
        nameSpace = "qa3"
    }

    def jobConfiguration = libraryResource 'com/ftd/workflow/job-configuration.properties'
        writeFile file: 'job-configuration.properties', text: jobConfiguration

    def props = readProperties file: "job-configuration.properties"
    def OMSlist = props['OMSlist']
    def pipelineName = "${env.JOB_NAME}"
    // stage("Deploying $serviceName to $nameSpace $cluster")
            // {
                wrap([$class: 'AnsiColorBuildWrapper']) {
                    // println "\u001B[32m[INFO] Deploying the Code"
                    logs.infoMessage("Deploying $serviceName to $nameSpace $cluster")
                    def deployStatus = "false"
                   

                //    if (serviceName == "web-api-gateway-service" || serviceName == "test-service") {
                    // if (serviceName == "web-api-gateway-service") {
                        //This call to deploy is to deploy the web-api-gateway service
                        // to dev1,dev2,dev3,qa1,qa2,qa3,prod1,prod2,prod3,prod4,stag
//    dir("/root/workspace/test-service/test-service-prod-deploy-pipelines/"){    stash name: "ws-n", includes: "**/*" }  
// parallel(

// "${serviceName}-${nameSpace}": {
logs.infoMessage("DPLOYING TO ${serviceName}")


if(!(nameSpace.contains("prod") || nameSpace.contains("stag")))
{

rootDir="$targetDir"
}
else
{
rootDir="/root/workspace/${pipelineName}/${targetDir}"

}
stage("Deploying $serviceName to $nameSpace $cluster")
            {
                logs.infoMessage(" ${cluster} ")
                sh("gcloud config set project ${deployProject}")
                     sh("gcloud container clusters get-credentials ${cluster} --zone ${zone} --project ${deployProject}")
            //    if (nameSpace.contains("qa") || nameSpace.contains("dev") || nameSpace.contains("hotfix")){
            //          sh("gcloud config set project ${deployProject}")
            //          sh("gcloud container clusters get-credentials ${cluster} --zone ${zone} --project ${deployProject}")
            //          }
                        //NONPCI DEPLOY
                                        //   dir("/root/workspace/test-service/test-service-prod-deploy-pipelines/"){unstash "ws-n"}  
  executeShell.exec("kubectl config current-context")

                        this.deploy(serviceName, nameSpace, imageTag, targetDir,rootDir)
                        if (deploymentStatus(serviceSubstr, nameSpace, serviceName, imageTag, 20) == 1) {
                            println(" Deployment Completed !!! ")

                        }
                    if (((serviceName == "web-api-gateway-service") || (serviceName == "test-service")) &&  (nameSpace.contains("qa") || nameSpace.contains("dev"))) {
  executeShell.exec("kubectl config current-context")

                        this.deploy("pci-${serviceName}", nameSpace, imageTag, targetDir,rootDir)
                        if (deploymentStatus("pci-${serviceSubstr}", nameSpace, "pci-${serviceName}", imageTag, 20) == 1) {
                            println(" Deployment Completed !!! ")

                        }



                      }



}

if(!(nameSpace.contains("prod") || nameSpace.contains("stag"))) {

stage("Intiating Automation/Regression test case job for $serviceName"){

if (nameSpace.contains("qa"))
	{
		blockBuild =  true
	}else 
	{
		blockBuild =  false
	}
	
if (("${serviceName}" == "front-end-service") && !(nameSpace.contains("dev"))) {
          println("Calling Frontend automation test cases job for")
          println("Frontend Automation test suite env is ${nameSpace}")

parallel(
		"FTD":{
				node{
def handle = triggerRemoteJob(
        remoteJenkinsName: 'jenkins-automation',
        job: 'https://jenkins-automation.ftdi.com/job/Automation-Jobs/job/Calyx-Automation/',
        parameters: "RepoName=calyx-automation\nbranch=common\nTestName=FTD\nGroups=BVT\nThreadCount=2\nBrowserStack=true\nemail=Calyx_QA@ftdi.com\nBrowserStackLocal=true\nBrowserStackEnvironment=chrome\nBrowser=NotApplicable\nKlovDashboard=enable\nDoNotLoadImages=false\nBrand=NotApplicable\nAutomationEnv=${nameSpace}",
        enhancedLogging: false,
        overrideTrustAllCertificates: true,
        trustAllCertificates: true,
        useCrumbCache: true,
	abortTriggeredJob: true,
	pollInterval: 60,
	shouldNotFailBuild: true,
        blockBuildUntilComplete: "${blockBuild}",
        )
FTDfrontURL = handle.getBuildUrl().toString()
FTDfrontStatus = handle.getBuildResult().toString()
}
},
		"PROFLOWERS":{
						node{
def handle = triggerRemoteJob(
        remoteJenkinsName: 'jenkins-automation',
        job: 'https://jenkins-automation.ftdi.com/job/Automation-Jobs/job/Calyx-Automation/',
        parameters: "RepoName=calyx-automation\nbranch=common\nTestName=PROFLOWERS\nGroups=BVT\nThreadCount=2\nBrowserStack=true\nemail=Calyx_QA@ftdi.com\nBrowserStackLocal=true\nBrowserStackEnvironment=chrome\nBrowser=NotApplicable\nKlovDashboard=enable\nDoNotLoadImages=false\nBrand=NotApplicable\nAutomationEnv=${nameSpace}",
        enhancedLogging: false,
        overrideTrustAllCertificates: true,
        trustAllCertificates: true,
        useCrumbCache: true,
        abortTriggeredJob: true,
	pollInterval: 60,
        shouldNotFailBuild: true,
        blockBuildUntilComplete: "${blockBuild}",
        )
PROfrontURL = handle.getBuildUrl().toString()
PROfrontStatus = handle.getBuildResult().toString()		
}
}
	)
echo "The Frontend automation test cases job for FTD is having status ${FTDfrontStatus} -- please check the following URL ${FTDfrontURL}"
echo "The Frontend automation test cases job for PROFLOWERS is having status ${PROfrontStatus} -- please check the following URL ${PROfrontURL}"
}else if (OMSlist.contains("$serviceName") || "$serviceName" == 'test-service'){

def handle = triggerRemoteJob(
        remoteJenkinsName: 'jenkins-automation',
        job: 'https://jenkins-automation.ftdi.com/job/Regressions-TestSuite/job/regressions-test/',
        parameters: "priority=P0\nEmail=oms-qa-hyd@ftdi.com\nservice=${serviceName}\ntargetEnv=${nameSpace}\nbranch=${nameSpace}",
        enhancedLogging: false,
        overrideTrustAllCertificates: true,
        trustAllCertificates: true,
        useCrumbCache: true,
        abortTriggeredJob: true,
        shouldNotFailBuild: true,
	pollInterval: 60,
        blockBuildUntilComplete: "${blockBuild}",
        )
regURL = handle.getBuildUrl().toString()
regStatus = handle.getBuildResult().toString()
echo "The regression test cases for ${serviceName} is having status ${regStatus}  --- Please check the following URL ${regURL}"
}else if ((serviceName.contains("fol-site")) && !(nameSpace.contains("dev"))) {
          println("Calling FOL test cases job")
          println("Automation test suite env is ${nameSpace}")

parallel(
		"US":{
				node{
def handle = triggerRemoteJob(
        remoteJenkinsName: 'jenkins-automation',
        job: 'https://jenkins-automation.ftdi.com/job/Frontend-Automation-FOL/job/FOL_Build_Verification_Tests-pipeline/',
        parameters: "Groups=BVT\nExcludedGroups=NotApplicable\nTestName=FOL_desktop\nBrand=US\nBrowserStack=false\nBrowserStackLocal=NotApplicable\nThreadCount=5\nBrowserStackEnvironment=NotApplicable\nBrowser=chrome\nBrowserMode=headless\nKlovDashboard=enable\nDoNotLoadImages=false\nAutomationEnv=${nameSpace}",
        enhancedLogging: false,
        overrideTrustAllCertificates: true,
        trustAllCertificates: true,
        useCrumbCache: true,
	abortTriggeredJob: true,
	pollInterval: 60,
	shouldNotFailBuild: true,
        blockBuildUntilComplete: "${blockBuild}",
        )
USURL = handle.getBuildUrl().toString()
USStatus = handle.getBuildResult().toString()
}
},
		"CANADA":{
						node{
def handle = triggerRemoteJob(
        remoteJenkinsName: 'jenkins-automation',
        job: 'https://jenkins-automation.ftdi.com/job/Frontend-Automation-FOL/job/FOL_Build_Verification_Tests-pipeline/',
	parameters: "Groups=BVT\nExcludedGroups=NotApplicable\nTestName=FOL_desktop\nBrand=CA\nBrowserStack=false\nBrowserStackLocal=NotApplicable\nThreadCount=5\nBrowserStackEnvironment=NotApplicable\nBrowser=chrome\nBrowserMode=headless\nKlovDashboard=enable\nDoNotLoadImages=false\nAutomationEnv=${nameSpace}",
        enhancedLogging: false,
        overrideTrustAllCertificates: true,
        trustAllCertificates: true,
        useCrumbCache: true,
        abortTriggeredJob: true,
	pollInterval: 60,
        shouldNotFailBuild: true,
        blockBuildUntilComplete: "${blockBuild}",
        )
CANADAURL = handle.getBuildUrl().toString()
CANADAStatus = handle.getBuildResult().toString()		
}
}
	)
echo "The FOL automation test cases job for brand US is having status ${USStatus} -- please check the following URL ${USURL}"
echo "The FOL automation test cases job for CANADA is having status ${CANADAStatus} -- please check the following URL ${CANADAURL}"
}
else {
	println("No Need of Initiating regression job for the $serviceName, as the test cases already been executed as part of the build")
}
}
}


                   dir(rootDir)
                   
                    // dir("$targetDir/temp")
                            {
                                // def pwd=executeShell.exec("pwd")
// logs.infoMessage("$targetDir/$serviceName - PWD : $pwd\n")
                            // executeShell.exec("cd  ${serviceName}")
                            executeShell.exec("pwd")

                                try{


                                    retry(15)
                                            {
                                                if (deployStatus.equals("false")) {
                                                    deployStatus = "true"
                                                    sh "git commit -am 'updated from ${saveSN}-${imageTag} build'"
                                                } else {
                                                    println "\u001B[32m[INFO] Retrying pushing to k8-config"
                                                    sh("git pull --no-edit origin ${k8sGitBranch}")
                                                }
//                                                dir("$targetDir/$serviceName")
//                                                        {
                                            }
                                                            retry(15)
                                                                    {

                                                                        // sh "sleep 10"
                                                                        if (deployStatus.equals("false")) {
                                                                            deployStatus = "true"
                                                                            sh "git commit -am 'updated from ${saveSN}-${imageTag} build'"
                                                                        } else {
                                                                            println "\u001B[32m[INFO] Retrying pushing to k8-config"
                                                                           sh("git pull --no-edit origin ${k8sGitBranch}")
                                                                            // sh ("git pull --rebase origin ${k8sGitBranch}")
                                                                        }

                                                                        sh "git push origin HEAD:${k8sGitBranch} -f"
                                                                        // sleep 5
                                                                    }
//                                                        }
//                                            }

                                }
                                catch(e)
                                {
                                    println( "Not able to commit the latest changes")
                                    this.conflicts(imageTag, k8sGitBranch, saveSN ,nameSpace)
                                }

                            }
                }
            // }
}

def conflicts(def imageTag, def k8sGitBranch, def saveSN , def nameSpace) {
	      def logs=new logs()
          def notify = new notify()

              println "\u001B[32m[INFO] checking for conflicts now"
              sh ("git ls-files --unmerged | cut -f2 | sort -u > conflict_output.txt")
              sh ("git ls-files --others --exclude standard >> conflict_output.txt") //the output of this required the least manipulation
              sh ("sed -i '/conflict_output.txt/d' ./conflict_output.txt")  //because the newly created file shows up in the output
              sh ("cat conflict_output.txt")
              cmd = "wc -c < conflict_output.txt"
              def clength
              clength = sh(returnStdout: true, script: cmd).replaceAll("[\n\r]", "") as int
          if ( clength != 0 ) {
              println "\u001B[32m[INFO] conflicts are there"
              def output = readFile('conflict_output.txt').trim()
              println output
            //   slackSend channel: "ftddevops", message: "<${env.JOB_URL}|${env.JOB_NAME}> ran into an error while merging changes into the k8's ${k8sGitBranch} branch,Please resolve the below conflicts manually:\n```\n${output}\n```\n<${env.BUILD_URL}/console|See the full output>", color: 'warning'
              (! nameSpace.contains("dev")) ? notify.slack("ftddevops","<${env.JOB_URL}|${env.JOB_NAME}> ran into an error while merging changes into the k8's ${k8sGitBranch} branch, please udate k8 value files with ${imageTag} manually. ","warning") : "Dev env no action needed"
              }
            //   def userChoice
            //   logs.warningMessage("Not able to merge to ${k8sGitBranch}, do you want to continue?")
            //   userChoice = input(message: "!!Not able to merge to ${k8sGitBranch}.. try manually updating the required tag and fix the confilicst manually and then press continue else abort it.", parameters: [
            //        choice(
            //                 name: 'Next Action',
            //                 choices: ['Continue', 'Abort'].join('\n'),
            //                 description: 'Whats your next action?'
            //                 )
            //         ])

            //         switch (userChoice) {

            //        case 'Continue':
            //                  logs.warningMessage 'Devops Manually updated the tag'
			//     // def output = readFile('conflict_output.txt').trim()
			//     // sh "git rm ${output}"
            //       //           sh "git commit -am 'updated from ${saveSN}-${imageTag} build'"
            //         //         sh("git pull --no-edit origin ${k8sGitBranch}")
			//      // sh "git commit -am 'updated from ${saveSN}-${imageTag} build'"
            //        //          sh "git push origin ${k8sGitBranch} -f"
            //                  return null;
            //         default:
            //                  logs.errorMessage 'Aborting the build'
            //                  throw exception;
            //         }
}

def deploy(def serviceName, def nameSpace, def imageTag, def targetDir, def rootDir) {
          def executeShell=new executeShell()
                  def logs=new logs()

    if (serviceName.equals("search-solr-config-service")) {
        serviceName = "search-solr-config"
    }
    if (serviceName =~ "job" && nameSpace =~ "stag") {
        println "\u001B[32m[INFO] Stage deploy is not required for scheduler"
    } else {
        if (nameSpace.matches("dev3-alt")) {
            nameSpace = "dev3"
        }
        if (nameSpace.matches("qa3-alt")) {
            nameSpace = "qa3"
        }
//           def saveSN = ((serviceName.contains("pci-test") ||  (serviceName.contains("pci-web")))? serviceName.replaceAll("pci-","").trim() : serviceName )
        def saveSN = (( (serviceName.contains("pci-web") || serviceName.contains("pci-test")) && ((nameSpace.contains("qa") || nameSpace.contains("dev"))) )? serviceName.replaceAll("pci-","").trim() : serviceName )

    dir("${rootDir}/${serviceName}")
                            // dir("$targetDir/temp")

                {
                       def pwd=sh("pwd")
logs.infoMessage("$targetDir/$serviceName - PWD : $pwd\n")
                    // println " \u001B[32m[INFO]*** $serviceName **** "
                    cmd = "chmod +x *.sh ; cd ../scripts ; chmod +x *.sh ;  . ./setup.sh && updateImageTag $nameSpace $serviceName $imageTag ; cd ../${serviceName} ;  . ./values-${nameSpace}.sh && cat values-${nameSpace}.sh|grep imageTag"
                    executeShell.exec(cmd)
                    

                    def deployFiles = findFiles(glob: '*.yaml')
                    // for (i = 0; i < deployFiles.length; i++) {
                        // file = deployFiles[i].name

                      deployFiles.each{
                      file = it
                                                      logs.infoMessage("$file on $nameSpace")

                        if (serviceName =~ "job") {
                            if (serviceName.equals("search-solr-config-job")) {
                                cmd = ". ../scripts/setup.sh && deleteKubectl $nameSpace $file ; . ../scripts/setup.sh && applyKubectl $nameSpace $file"
                                executeShell.exec(cmd)
                            } else {
                                cmd=". ../scripts/setup.sh && applyKubectl $nameSpace $file"
                                executeShell.exec(cmd)
                            }
                        } 
                        
                        
                        else 
                        
                        
                        {


                              String actualNS = nameSpace
                            actualNS = (nameSpace.contains("prod") || nameSpace.contains("stag")) ? actualNS.replaceAll("\\d", "") : nameSpace
                            if (file =~ "deployment") 
                            
                            {
                                logs.infoMessage("Deployment of $file on $nameSpace")
                                cmd=". ../scripts/setup.sh && applyKubectl $nameSpace $file"
                                executeShell.exec(cmd)
//                                if (file =~ "pci-web-api-gateway-deployment.yaml") {
//                                    println("Waiting for pci-web-api-gateway deployment to complete !!")
//                                    sh("sleep 180")
//                                }


                            }
                        
                          else if (file =~ "service") {

//                                actualNS = actualNS.replaceAll("\\d", "")
                                cmd = "kubectl get svc -n $actualNS | grep  ^${serviceName} | wc -l"

                                def tempOut //= sh(returnStdout: true, script: cmd).replaceAll("[\n\r]", "") as int
                                tempOut = sh(returnStdout: true, script: cmd).replaceAll("[\n\r]", "") as int
//                                println(" !!!!!!!! SERVICE IS THERE ??  --> $tempOut ")
                                tempOut == 0 ? println("Service endpoint  is not there -- will be created") : println("Service endpoint is present - #count - $tempOut")
                                if ((tempOut == 0) && (nameSpace.contains("prod")))
                                {
                                                                    logs.infoMessage("Deployment of $file on $nameSpace")

                                    cmd = ". ../scripts/setup.sh && applyKubectl $nameSpace $file"
                                    executeShell.exec(cmd)
                                    cmd = ". ../scripts/setup.sh && applyKubectl ${nameSpace}A $file"
                                    executeShell.exec(cmd)
                                }
                            else if ((tempOut == 1) && (nameSpace.contains("prod")))
                            {
                                cmd = ". ../scripts/setup.sh && applyKubectl ${nameSpace}A $file"
                                    executeShell.exec(cmd) 
                            }
                            else if ((tempOut == 2) && (nameSpace.contains("prod")))
                            {
                                cmd = "kubectl get svc -n $actualNS | grep  ^${serviceName} | grep ${nameSpace}A | wc -l"
                                tempOut = sh(returnStdout: true, script: cmd).replaceAll("[\n\r]", "") as int
                                cmd = ". ../scripts/setup.sh && applyKubectl ${nameSpace}A $file"
                                tempOut == 0 ? executeShell.exec(cmd) : println("A Services exists ..No action needed")
                                    
                            }
 

                               else if ((tempOut == 0) && (!nameSpace.contains("prod"))) // uncomment after PCI changes are done
                                // else if ((!nameSpace.contains("prod")))
                                {
                                                                    logs.infoMessage("Deployment of $file on $nameSpace")

                                    cmd=". ../scripts/setup.sh && applyKubectl $nameSpace $file"
                                    executeShell.exec(cmd)
                                }

                            }
                            else if (file =~ "-pdb")
                                    {
                                        hpacmd = "kubectl get pdb -n $actualNS | grep  ^${serviceName} | wc -l"
                                       cmd =  ((sh(returnStdout: true, script: hpacmd).replaceAll("[\n\r]", "") as int) == 0) ?  ". ../scripts/setup.sh && applyKubectl $nameSpace $file":  "echo NOACTIONNEEDED"
                                        executeShell.exec(cmd) 

                                    }
                            else if (file =~ "-hpa")
                            {
                                pdbcmd = "kubectl get hpa -n $actualNS | grep  ^${serviceName} | wc -l"
                                cmd = ((sh(returnStdout: true, script: pdbcmd).replaceAll("[\n\r]", "") as int) == 0) ?  ". ../scripts/setup.sh && applyKubectl $nameSpace $file" :  "echo NOACTIONNEEDED"
                                executeShell.exec(cmd) 


                            }

                        }
                    }
                }
    }
}
