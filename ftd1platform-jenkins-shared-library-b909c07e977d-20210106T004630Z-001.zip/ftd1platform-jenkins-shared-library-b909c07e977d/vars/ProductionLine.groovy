/*
 * This file will handle release deployments to UAT, STRESS and PROD
 * It will also do some validations before deploying to PROD
 */

import org.hamcrest.core.StringContains


String boldGreenMessage(final String message) { return "\033[1;32m${message}\033[0m" }

String boldBlueMessage(final String message) { return "\033[1;34m${message}\033[0m" }

String boldRedMessage(final String message) { return "\033[1;31m${message}\033[0m" }

String boldYellowMessage(final String message) { return "\033[1;33m${message}\033[0m" }

String triplePrefixMessage(final Closure<String> colour, final String prefix, final String message) {
    def colouredPrefix = "${colour("${prefix}")}"
    return "${colouredPrefix}\n${colouredPrefix} ${message}\n${colouredPrefix}"
}

void successMessage(final String message) {
    ansiColor('xterm') { echo triplePrefixMessage(this.&boldGreenMessage, '[SUCCESS]', message) }
}

void infoMessage(final String message) {
    ansiColor('xterm') { echo triplePrefixMessage(this.&boldBlueMessage, '[INFO]', message) }
}

void warningMessage(final String message) {
    ansiColor('xterm') { echo triplePrefixMessage(this.&boldYellowMessage, '[WARNING]', message) }
}

void errorMessage(final String message) {
    ansiColor('xterm') { echo triplePrefixMessage(this.&boldRedMessage, '[ERROR]', message) }
}

import org.codehaus.groovy.control.messages.ExceptionMessage

import java.text.SimpleDateFormat






def call(script) {
    try {
        def logs=new logs()

        def jiraAction= new jira()
        def git=new git()
        def bq=new bq()
        def executeShell=new executeShell()
        def kubernetes=new kubernetes()
        def pipeline= new manualApproval()
        def jobObj = new com.ftd.workflow.JobManager(script)
        def serviceName = jobObj.getServiceName()
        def pipelineName = jobObj.getPipelineName()
        def serviceSubstr = serviceName[0..serviceName.lastIndexOf('-') - 1]
def notify = new notify()
        def jobConfiguration = libraryResource 'com/ftd/workflow/job-configuration.properties'
        writeFile file: 'job-configuration.properties', text: jobConfiguration

        def props = readProperties file: "job-configuration.properties"

        def stageConfig = libraryResource 'com/ftd/workflow/stage-config.properties'
        writeFile file: 'stage-config.properties', text: stageConfig
        stageConfig = readProperties file: "stage-config.properties"
        def skipProd = stageConfig["skipProd"]

        def project = props['project']
        def k8sGitUrl = props['k8sGitUrl']
        def k8sGitBranch = props['k8sGitProd']
        def k8sTargetDir = props['k8sTargetDir']
        // def approverList = props['approverList']
        def approverList = jiraAction.usersInGroup("jenkins-prod-approvers")
        logs.infoMessage("${approverList}")
        // def jiraApproverList = props['jiraApproverList']
        def jiraApproverList = jiraAction.usersInGroup("CHNG Approvers")
        logs.infoMessage("${jiraApproverList}")
        def testID = 'rkande@ftdi.com'
        def serviceList = stageConfig['serviceList']
        def pciList = stageConfig['pciList']
//        def jiraApproverList = props["jiraApproverList"]
        def projectID = props["projectID"]
        def issueTypeID = props["issueTypeID"]
        def componentID = props["componentID"]
        def jiraURL = props["jiraURL"]
        def buildTag = "${params.DOCKER_TAG}"
        def environment = "${params.ENVIRONMENT}"
        def sleepTime = stageConfig["sleepTime"]
        def skipStag = stageConfig["skipStag"]
        def reporter
        def enableDisable = props["enableDisable"]
        def deployStatus = "false"
        def overWriteProdDeploys = props["overWriteProdDeploys"]
        def adminApprover = props["adminApprover"]
        def misc = new misc()
//        def nettyService = stageConfig["netty"]
        def imageTag = buildTag
        def defaultDescription=""
        def prod13activeby
        def prod24activeby 
        def user = env.BUILD_USER_ID
        def dateFormat = new SimpleDateFormat("yyyy-MM-dd")        
        def date = new Date()
        // def sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'")
        // sdf.setTimeZone(TimeZone.getTimeZone("CST"))
        def sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss")
        def jiraDateTime=sdf.format(date)
        
        def prod1newcodeActiveby
        def prod2newcodeActiveby
        def prod3newcodeActiveby
        def prod4newcodeActiveby
        def status="\"Open\""
        wrap([$class: 'BuildUser']) {
            user = env.BUILD_USER_ID
            tempId = user.split("@")
            reporter = tempId[0]
        }

        //echo "$Id"

        def region = "${params.REGION}"
        //	def crId = "${params.CR_ID}"

        def nonProdImage, releaseTag, mailStep, mailSubject, prodSequence, stageEnv, currentEnv, nextEnv, prodCluster, serviceGitUrl

        /*  if (crId == "")
          {
              error ("CRID cant be empty!!!" )
          }*/


        def crTitle = "${params.CR_TITLE}"
        def crDescription = "${params.CR_DESCRIPTION}"
        if (crTitle.isEmpty()) {
            errorMessage(">>>>>>>>>>>>>>>>>Change Title field cant be empty!!!")
            error(">>>>>>>>>>>>>>>>>Change Title field cant be empty!!!")
            
        }
        if (crDescription.isEmpty()) {
            errorMessage(">>>>>>>>>>>>>>>>>>Change Description cant be empty!!!")
            error(">>>>>>>>>>>>>>>>>>Change Description cant be empty!!!")
            
        }

        if (buildTag == "") {
            error(">>>>>>>>>>>>>>>>>>>>>Tags cannot be null value!!!! Please enter appropriate build tag to be deployed to $environment")
        } else if (!buildTag.startsWith("qa1") && !buildTag.startsWith("hotfix")) {
            error(">>>>>>>>>>>>>>>>>>>>>>Please enter qa/hotfix deployed docker tags. Dev deployed tags will not be deployed to production environments")
        } else if (enableDisable.contains("disable") && !overWriteProdDeploys.contains(serviceSubstr)) {
            errorMessage("PRODUCTION BUILDS ARE DISABLED UNTIL FURTHER NOTICE")
            error("PRODUCTION BUILDS ARE DISABLED UNTIL FURTHER NOTICE")
        }




        environment = environment.toLowerCase()
        println("STG - ${environment} ******")
        def gitBranch = buildTag[0..buildTag.indexOf('-') - 1]
        def updateTag = "uat-${buildTag}"

       


        if (region.matches("REGION1")) {
            prodSequence = ["${environment}1", 'prod1', 'prod2', 'Cluster1(US Central)', "${environment}2", 'prod3', 'prod4', 'Cluster2(US West)']
        } else if (region.matches("REGION2")) {
            prodSequence = ["${environment}2", 'prod3', 'prod4', 'Cluster2(US West', "${environment}1", 'prod1', 'prod2', 'Cluster1(US Central)']
        } else if (region.matches("REGION3")) {
            prodSequence = ["${environment}3", 'prod5', 'prod6', 'Cluster1(EU West3)', "${environment}4", 'prod7', 'prod8', 'Cluster2(EU West2)']
        } else if (region.matches("REGION4")) {
            prodSequence = ["${environment}4", 'prod7', 'prod8', 'Cluster2(EU West2)', "${environment}3", 'prod5', 'prod6', 'Cluster1(EU West3)']
        }  else if (region.matches("Active-Active")) {
        prodSequence = ["${environment}1",'prod1:prod3', 'prod2:prod4', 'Cluster1(US Central):Cluster2(US West)']
    } else if (region.matches("PROD13")) {
        prodSequence = ["${environment}1", 'prod1:prod3']
    }else if (region.matches("PROD24")) {
            prodSequence = ["${environment}2", 'prod2:prod4']
        }


        println(" ${prodSequence}  ******")
        println(props["${environment}NameSpace"])


        environment = prodSequence[0]

        def servicePath

        if (serviceList.contains("${serviceSubstr}")) {
            servicePath = serviceSubstr


        }
    
        else {
            servicePath = serviceName


        }

servicePath = (servicePath.contains("pci-web")|| servicePath.contains("pci-test")) ? servicePath.replaceAll("pci-","").trim() : servicePath 
    def dockerTagSN = (( (serviceName.contains("pci-web") || serviceName.contains("pci-test") ))? serviceName.replaceAll("pci-","").trim() : serviceName )

         nonProdImage = "gcr.io/${project}/${dockerTagSN}:${buildTag}"
        releaseTag = "gcr.io/${project}/${dockerTagSN}:${updateTag}"
      
        if (environment.matches("uat1|stg1|stg2|stg3|stg4|pcistg1|pcistg2|pcistg3|pcistg4")) {
            //validate params first
            this.checkParams(project, serviceName, environment, "$buildTag")
//            git.checkout(serviceName)
            serviceGitUrl=(serviceName.contains("fol")) ?   "git@bitbucket.org:ftd1platform/fol.git" : "git@bitbucket.org:ftd1platform/${servicePath}.git"

            checkout([$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: 'temp1'], [$class: 'CheckoutOption', timeout: 30], [$class: 'CloneOption', timeout: 30]], submoduleCfg: [], userRemoteConfigs: [[url: serviceGitUrl]]])

            if (buildTag.contains("hotfix-")) {

                dir("temp1")
                        {
                            executeShell.exec("git checkout ${buildTag}")
                            def cmd = "curl -s  -X GET -H 'Authorization: Basic amVua2luc2NpLXVzZXI6dVA4bURMTEhlVFdwR0RFdWE0OFM=' https://bitbucket.org/api/2.0/repositories/ftd1platform/$servicePath/refs/branches/master | jq '.target.hash'"
                            def masterCommit =  executeShell.exec(cmd) //sh(returnStdout: true, script: cmd)
                            masterCommit = masterCommit.trim()
                            List<String> sourceChanged = sh(returnStdout: true, script: "git log --pretty=format:'%H'").split()
                            def isMasterCommitIn = false
                            for (int i = 0; i < sourceChanged.size(); i++) {
//
                                if (sourceChanged[i].contains("$masterCommit")) {
                                    isMasterCommitIn = true
                                    echo "**** $sourceChanged[i] ****"
                                }
                            }
                            if (isMasterCommitIn == false) {
//                                error(" Hotfix Tag doesn't contain the latest master commit hash -  $masterCommit ")
                            }


                        }

            }
            executeShell.exec("gcloud docker -- pull ${nonProdImage}")
            executeShell.exec("docker tag ${nonProdImage} ${releaseTag}")
            executeShell.exec("gcloud docker -- push ${releaseTag}")
            if (serviceName =~ "test") {
                println "\u001B[32m[INFO] Stage deploy is not required for test"
            }

if(region.contains("Active-Active")){

    dir("/root/workspace/${serviceName}/${serviceName}-prod-deploy-pipelines/"){    stash name: "ws-stag", includes: "**/*" , useDefaultExcludes: false }  

stage("Cross-cluster stag deploy"){
    tempEnv = "stg1:stg2".split(":")
stag1Env=tempEnv[0].toString()
stag2Env=tempEnv[1].toString()
stag1Env=stag1Env.trim()
stag2Env=stag2Env.trim()
parallel(
"${serviceName}-${stag1Env}": {

              node{                      
                  executeShell.prepNode()

                                    dir("/root/workspace/${serviceName}/${serviceName}-prod-deploy-pipelines/")
                                    {


                                        unstash "ws-stag"
                                        sh "ls -la ${pwd()}"
                                        // sh "cd temp; git stash; git pull origin preprod" 
                                        sh "cd temp; git stash; git pull --rebase origin preprod" 

                                    }
                                               runStag(region,stag1Env,pipelineName,serviceName,pciList,skipStag,updateTag,k8sGitBranch,k8sTargetDir)
   
              }
},
"${serviceName}-${stag2Env}": {

              node{                      
                  executeShell.prepNode()

                                    dir("/root/workspace/${serviceName}/${serviceName}-prod-deploy-pipelines/")
                                    {


                                        unstash "ws-stag"
                                        sh "ls -la ${pwd()}"
                                        // sh "cd temp; git stash; git pull origin preprod" 
                                        sh "cd temp; git stash; git pull --rebase origin preprod" 
                                    }
                                                // kubernetes.justK8s("")
                                               runStag(region,stag2Env,pipelineName,serviceName,pciList,skipStag,updateTag,k8sGitBranch,k8sTargetDir)
   
              }
}


)



}
}
else
{
                                               runStag(region,environment,pipelineName,serviceName,pciList,skipStag,updateTag,k8sGitBranch,k8sTargetDir)


}





// Fetch sonar results and store in env variables for email template
            FetchSonarCoverage(serviceName, buildTag)
            //Fetch Jira details from commit & summary from JIRA and add to the email template


            def commitJIRAList = sh(script: "curl -s -X GET 'https://bitbucket.org/api/2.0/repositories/ftd1platform/${servicePath}/commits/$buildTag?exclude=master' -H 'Authorization: Basic amVua2luc2NpLXVzZXI6dVA4bURMTEhlVFdwR0RFdWE0OFM=' -H 'Cache-Control: no-cache'  | jq '.values[]?.summary.raw' | grep -oEi 'CAL-[0-9]+' | sort -u ", returnStdout: true).trim()


            commitJIRAList = commitJIRAList.replace("\n", ",")
            // def jiraAndDescription
            def jiraList = commitJIRAList.split(',')
            def issueList


            if (jiraList.size() != 0) {


                issueList = "<h2>Individual JIRA's part of this release:</h2><ul>"
                for (def jira : jiraList) {
                    jira = jira.trim()
                    jira = jira.toUpperCase()
                    //println(jira.toUpperCase())

                    //toLowerCase()
                    if (jira.contains("CAl-") || jira.contains("CAL")) {
                        def issue
                        def summary
                        if (jira.matches("CAL-0000")) {
                            println "!!!WARNING: CAL-0000 is not valid jira"
                        } else {
                            try {
                                issue = jiraGetIssue idOrKey: "$jira", site: 'jira' // Retrieves the Jira issue
                                summary = issue.data.fields.summary.toString() // Retrieves the summary field

                                issueList = issueList.concat("<li><a href=\"${jiraURL}/browse/${jira}\">${jira} : ${summary}</a></li>")
                            }
                            catch (err) {
                                echo "$jira doesnt exist !!!"

                            }
                                                            jiraAction.addLabel("${jira}","${updateTag}")



                        }

                    } else {
                        issueList = "<h2>JIRA # are not part of the commit messages. </h2><ul>"
                    }

                }



            }

            env.ISSUE_LIST = issueList

            //send stage/uat deploy success mail
            mailStep = "deploy"
            mailSubject = "$serviceName deployment to $environment is ${currentBuild.result}"
            EmailNotifications(serviceName, mailStep, mailSubject)






            stage("Tagging SCM")
                    {

                        saveBuildTag = buildTag
                        dir("temp1")
                                {
                                    executeShell.exec("git tag ${updateTag} ${buildTag} --force")
                                    executeShell.exec("git push origin ${updateTag} --force")
                                }
                    }

            //update job display name
            currentBuild.displayName = "$updateTag"
    // cmd = "kubectl get pods -n prod  -o json | jq -r '.items[].status.containerStatuses[] | { \"image\": .image}' | grep ${serviceName} | cut -d':' -f3 | sed 's/\"//' | sort -u"
                prevTag = git.getPrevTag(serviceName)
logs.infoMessage("${prevTag}")
            //wait for manual approval from approvers to proceed to next step
            milestone 1
            tempOut = pipeline.manualApproval(48, "HOURS", "Do you want to  create CHNG ticket now?", user, "CHNG:${prevTag}", serviceName, adminApprover, reporter)


            echo "!!!$tempOut \n\n\n"

            def jiraKey
            def jiraID
            
    stage('CHNG ticket creation') 
    {


                // if (serviceName.matches("test-service")) {
                //     jiraKey = "CAL-3636"
                //     jiraID = "31030"


                // } else 
                if (tempOut.contains("CAL-")) {
                    println "########## NO new CHANGE TICKET #### \n\n"
                    tempOut = tempOut.trim()
                    jiraKey = tempOut

                    response = jiraGetIssue idOrKey: "${jiraKey}", site: 'jira'
                    def responseString = response.data.toString()
                    def splitString = responseString.split(':')
                    jiraID = splitString[2]
                    jiraID = jiraID.replace(", self", "")
                    echo "1 -**** $jiraKey : $jiraID****"

                    // jiraID =

                } else if (tempOut.contains("CREATE") || tempOut == "") {

                    
                    tempOut = tempOut.trim()
                    // def due = dateFormat.format(date)
                    //println(dateFormat.format(date))

                    impact = env.impact
                    changeType = env.changeType
                    rollback = env.rollback

                    println " Impact - $impact \n Rollback - $rollback \n ChangeType = $changeType "

//jiraApproverList="rkande,sellis"
                    def testIssue = [fields: [
                            project          : [id: "$projectID"],
                            summary          : "${serviceName} - ${crTitle}",
                            description      : "Jira Created using Jenkins auto build - ${crDescription}",
                            issuetype        : [id: "$issueTypeID"],
                            components       : [[id: "$componentID", name: 'CHNG']],
                            duedate          : dateFormat.format(date),
                            labels           : ["$REGION"],
                            customfield_10036: [value: "$impact"],
                            customfield_10037: [value: "$changeType"],
                            customfield_10110: "$rollback",
                            reporter         : [name: "$reporter"],
                            customfield_10040: "$jiraDateTime"
//                            customfield_10035: [[name: "$jiraApproverList"]],


                    ]]



                    response = jiraNewIssue issue: testIssue, site: 'jira'


                    echo response.successful.toString()
                    def responseString = response.data.toString()

                    def splitString = responseString.split(',')

                    jiraKey = splitString[1]


                    jiraKey = jiraKey.replace("key:", "")
                    jiraKey = jiraKey.toString()
                    jiraKey = jiraKey.trim()
                    jiraID = splitString[0]


                    jiraID = jiraID.replace("[id:", "")
                    echo "**** $jiraKey : $jiraID****"


                }
                (serviceName.matches("front-end-service")) ? notify.slack("calyx-prod-mgmt","$jiraKey : Production deployment triggered , Visit ${env.BUILD_URL} for more info","good") :  notify.noslacking()
            milestone 2

                if (jiraID != "") {


                    jiraAction.update(jiraKey, "EDIT:$serviceName")


                }


                println "2 - **** $jiraKey : $jiraID****"

                currentBuild.displayName = "$updateTag - $jiraKey"

                if (jiraList.size() != 0) {
                    issueList = issueList.concat("<h2>Change Request details:</h2><ul>")
                    issueList = issueList.concat("<li><a href=\"${jiraURL}/browse/${jiraKey}\">${jiraKey} : ${crTitle}</a></li>")
//                    issueList = issueList.concat("<h2>Individual JIRA's part of this release:</h2><ul>")
                    for (def jira : jiraList) {
                        jira = jira.trim()
                        if (jira.contains("CAl-") || jira.contains("CAL")) {

                            if (jira.matches("CAL-0000")) {
                                println "!!!WARNING: CAL-0000 is not valid jira"
                            } else {

                                try {
                                    jiraLinkIssues type: 'Relates', inwardKey: "$jiraKey", outwardKey: "$jira", site: 'jira'
                                }
                                catch (err) {
                                    echo "$jira doesnt exist - It will not be linked to CHNG!!!"
                                }
                            }

                        }


                    }
                } else {
                    issueList = "<h2>JIRA # are not part of the commit messages. </h2><ul>"

                }


                jiraAssignIssue idOrKey: "${jiraID}", userName: "$reporter", site: 'jira'


                env.JIRA_KEY = jiraKey
                env.JIRA_SUMMARY = crTitle
                env.ISSUE_LIST = issueList
            // Add logic to insert data into bigquery
             cmd="curl -s -X GET 'https://ftdcorp.atlassian.net/rest/agile/1.0/issue/${jiraKey}?issuelinks' -H 'Authorization: Basic cmthbmRlQGZ0ZGkuY29tOmRtYjVlcjRNUGZaNzBOaFBSbHRHQUYxRA==' -H 'Cookie: atlassian.xsrf.token=f3d6ac08-35f0-4b2d-ba56-bab6df28c90e_8759e77ec652bb39c6336812d439bc273026de3e_lin' -H 'Host: ftdcorp.atlassian.net' | jq '.fields.issuelinks[].inwardIssue.fields.summary'   &&   curl -s -X GET 'https://ftdcorp.atlassian.net/rest/agile/1.0/issue/${jiraKey}?issuelinks' -H 'Authorization: Basic cmthbmRlQGZ0ZGkuY29tOmRtYjVlcjRNUGZaNzBOaFBSbHRHQUYxRA==' -H 'Cookie: atlassian.xsrf.token=f3d6ac08-35f0-4b2d-ba56-bab6df28c90e_8759e77ec652bb39c6336812d439bc273026de3e_lin' -H 'Host: ftdcorp.atlassian.net' | jq '.fields.issuelinks[].outwardIssue.fields.summary'"

                cmdOutput=sh(returnStdout: true, script: cmd).trim()
                description=cmdOutput.replaceAll("null","").trim()
                savedefaultDescription=defaultDescription+"\n"
                savedescription="\n"+description
                description=description.replaceAll("[\n\r]", "")
                //saveing default description for jira insert and other for bq insert
                description=crDescription+description
                savedescription=crDescription+"\n"+savedescription
                description=description.replaceAll("\"", "")
                bdescription=description.replaceAll("\n",".")
                                bdescription=bdescription.replaceAll("\"", "")

                bdescription="\"${bdescription}\""
                bjiraKey="\"${jiraKey}\""
                bserviceName="\"${serviceName}\""
                bupdateTag="\"${updateTag}\""
                breporter="\"${reporter}\""
                jobUrl="\"${env.BUILD_URL}\""
                bcrTitle="\"${crTitle}\""
                changeStartDate="\"PlaceHolder\""
                startTime="\"${jiraDateTime}\""
                logs.infoMessage("Description is ....${description} \n\n changeStarttime is ${startTime} \n\n")


                if (tempOut.contains("CAL-")) 
                { 
                logs.infoMessage(" Updating Change ticket with current time - ${startTime} \n\n")
                jiraAction.updateStartTime(jiraKey,jiraDateTime)
                bq.bqUpdate("startTime",startTime.replaceAll("\"",""),bjiraKey.replaceAll("\"",""))
                }
                else if (tempOut.contains("CREATE") || tempOut == "") 
                {
                // cmd="bq query  --nouse_legacy_sql --quiet 'INSERT into  `gcp-ftd-prod-devops.ReleaseData.release_info`  values (" + bjiraKey +"," + bserviceName +"," + bupdateTag +","+ description + "," + breporter + "," +jobUrl +"," + changeStartDate+","+bcrTitle + ","+ startTime+")'"
                cmd="bq query  --nouse_legacy_sql --quiet 'INSERT into  `gcp-ftd-prod-devops.ReleaseData.release_info`  values (" + bjiraKey +"," + bserviceName +","+bcrTitle +","+ bdescription + "," + bupdateTag +","+ startTime+","+ prod1newcodeActiveby +","+ prod2newcodeActiveby +","+ prod3newcodeActiveby +","+ prod3newcodeActiveby +","+ breporter +","+  jobUrl +","+  status +")'"
                cmdOutput=bq.bqInsert(cmd)
                jiraAction.updateDesc(jiraKey,savedescription)

                }
                // cmdOutput=sh(returnStdout: true, script: cmd)
                logs.infoMessage("cmdOutput was ....${cmdOutput} \n\n") 


            }
            jiraAction.update(jiraKey, "Approval:${serviceName} ")
            
            jiraAction.transition(jiraKey, 171) //Ready for approval
                        status="Ready for approval"
            bq.bqUpdate("Status",status,jiraKey)

// SO FAR GOOD with one node


            //set current and next environment
            currentEnv = prodSequence[1]  //prod1 or 3 / prod1 & prod3
            nextEnv = prodSequence[2]   //prod2 or 4 / prod2 & prod4


            mailStep = "input"
            mailSubject = "$serviceName - $updateTag - ${currentEnv}  deployment Approval"
            EmailNotifications(serviceName, mailStep, mailSubject)

            //get jira status
            pipeline.manualApproval(72, "HOURS", "Do you approve to deploy $updateTag?", approverList, "[APPROVAL]", serviceName, adminApprover, reporter)
                        milestone 3

//          stage
            stage("Waiting for $jiraKey to be Approved ") {
                try {
                    while (jiraAction.getIssueStatus(jiraKey).toUpperCase() != "APPROVED") {
                        logs.infoMessage("Waiting for $jiraKey to be Approved !! \n")
                        sleep(10)
//
                    }
                }
                catch (e) {

                    errorMessage("$e")
                    error("$e")

                }

            }
            jiraAction.transition(jiraKey, 21) //Inprogress
              status="Inprogress"
            bq.bqUpdate("Status",status,jiraKey)

          //runProd method  
          milestone 4
          runProd(region, serviceName,currentEnv, nextEnv,updateTag,jiraKey,pciList,"Y",reporter,k8sTargetDir)
       
           jiraAction.update(jiraKey, currentEnv)
           date = new Date()
           currDateTime=sdf.format(date)
           cEnv=currentEnv
           cEnv=cEnv.split(":")
           bq.bqUpdate(cEnv[0]+"newcodeActiveby",currDateTime,jiraKey)
           bq.bqUpdate(cEnv[1]+"newcodeActiveby",currDateTime,jiraKey)
            // jiraAction.addLabel(jiraKey,currentEnv)

            //set current and next environment
            currentEnv = prodSequence[2] //prod2 or 4
            nextEnv = prodSequence[1] //prod 1 or 3
            milestone 5
        // pipeline.manualApproval(72, "HOURS", "Do you approve to deploy $updateTag ?", approverList, "[APPROVAL]", serviceName, adminApprover, reporter)
milestone 6
                    runProd(region, serviceName,currentEnv, nextEnv,updateTag,jiraKey,pciList,"Y",reporter,k8sTargetDir)

milestone 7
           


           jiraAction.update(jiraKey, currentEnv)
           date = new Date()
            currDateTime=sdf.format(date)
           cEnv=currentEnv
           cEnv=cEnv.split(":")
           bq.bqUpdate(cEnv[0]+"newcodeActiveby",currDateTime,jiraKey)
           bq.bqUpdate(cEnv[1]+"newcodeActiveby",currDateTime,jiraKey)

            // jiraAction.addLabel(jiraKey,currentEnv)

            mailStep = "deploy"
            mailSubject = "$serviceName deployment to ${currentEnv} is ${currentBuild.result}"
            EmailNotifications(serviceName, mailStep, mailSubject)

            mailStep = "input"
            mailSubject = "$serviceName - $updateTag - ${currentEnv} - QA verification Approval"
            EmailNotifications(serviceName, mailStep, mailSubject)

            prodCluster = prodSequence[3]
            prodCluster.contains(":") ? prodCluster.split(":") : ""
milestone 8
             if(misc.searchList(serviceName,skipProd).contains("true")){

    logs.infoMessage("No Switch action is needed for ${serviceName}")
 }
 else
 {
                 pipeline.manualApproval(72, "HOURS", "Good to SwitchTraffic to both ${nextEnv}/${currentEnv}?", approverList, "Pending Aprroval to SwitchTraffic to BothIn${prodCluster}", serviceName, adminApprover, reporter)

//  }

            // this will kill any job which is still before milestone 4
            
            //below block can be deleted  when PF & FTD are merged to one
            if (prodCluster.contains(":"))
            {
            (prodCluster.split(":")).each{
                logs.infoMessage("${it}")
              (it.contains("Cluster1") ? environment="prod1" : it.contains("Cluster2") ? environment="prod3" : "")
                            (it.contains("Cluster1") ? node="cluster1" : it.contains("Cluster2") ? node="cluster2" : "")
            if (serviceName.contains("fol-admin-service") || serviceName.contains("fol-site-service")  ) {
                                    kubernetes.justK8s(props["pci${environment}Cluster"], props["pci${environment}Zone"], props["pci${environment}DeployProject"])
                kubernetes.switchTraffic(region,"fol-admin-service", nextEnv, props, "fol",jiraKey,node)
            } 
            

            else 
            {
                                  

                //    if (pciList.contains("${serviceSubstr}")  ) {
                    if(misc.searchList(serviceName,pciList).contains("true")){
                                     kubernetes.justK8s(props["pci${environment}Cluster"], props["pci${environment}Zone"], props["pci${environment}DeployProject"])

                kubernetes.switchTraffic(region,serviceName, "${it}", props, "cluster",jiraKey,node)
            } 
            else{

                  kubernetes.justK8s(props["${environment}Cluster"], props["${environment}Zone"], props["${environment}DeployProject"])

                kubernetes.switchTraffic(region,serviceName, "${it}", props, "cluster",jiraKey,node)
            }
            }

                 



            }
            
           

            }
        else
            {

       if (serviceName.contains("fol-admin-service") || serviceName.contains("fol-site-service")) {
           node="TEMP"
                kubernetes.switchTraffic(region,"fol-admin-service", nextEnv, props, "fol",jiraKey,node)
            } else {
                node="TEMP"
                kubernetes.switchTraffic(region,serviceName, "${prodCluster}", props, "cluster",jiraKey,node)

                    //    if (serviceName.contains("test-service") || serviceName.contains("web-api-gateway-service")) {

                // if (serviceName.contains("web-api-gateway-service")) {

                //     kubernetes.justK8s(props["pci${environment}Cluster"], props["pci${environment}Zone"], props["pci${environment}DeployProject"])

                //     kubernetes.switchTraffic(region,"pci-${serviceName}", "${prodCluster}", props, "cluster",jiraKey,node)
                //     kubernetes.justK8s(props["${environment}Cluster"], props["${environment}Zone"], props["${environment}DeployProject"])


                // } else {
                //     echo "!!! NO PCI "
                // }
            }


            }
        }
     
milestone 9
            if ((region.matches("REGION1") || region.matches("REGION2") || region.matches("Active-Active")) && !(serviceName.contains("pci-web")||serviceName.contains("pci-test"))) {

            // pipeline.manualApproval(72, "HOURS", "Do you want to continue with the Merge ??", approverList, "Pending Aprroval to for Merge", serviceName, adminApprover, reporter)

               git.mergeFlow(updateTag,serviceName,props,stageConfig,jiraKey) 


            }
            jiraAction.transition(jiraKey, 191) //done
            status="Done"
            bq.bqUpdate("Status",status,jiraKey)

//Commenting cluster2 syncs            
/*if (region.matches("REGION1") || region.matches("REGION2")) {
            //sync prod3/prod4 to prod1/prod2
            stageEnv = prodSequence[4]

            currentEnv = prodSequence[5]

            nextEnv = prodSequence[6]

            prodCluster = prodSequence[7]

            //     jiraAction.transition(jiraKey,201) //closed


            mailStep = "input"
            mailSubject = "$serviceName - $updateTag - sync confirmation for ${stageEnv}/${currentEnv}/${nextEnv}"
            EmailNotifications(serviceName, mailStep, mailSubject)

            //timeout sync activity
milestone 10
            pipeline.manualApproval(72, "HOURS", "Do you approve to sync ${stageEnv}/${currentEnv}/${nextEnv} with $updateTag ?", approverList, "${prodCluster} Sync", serviceName, adminApprover, reporter)
            milestone 11


            this.sync(project, serviceName, stageEnv, updateTag, k8sGitBranch, k8sTargetDir, props)
            jiraAction.update(jiraKey, stageEnv)
            this.sync(project, serviceName, currentEnv, updateTag, k8sGitBranch, k8sTargetDir, props)
            jiraAction.update(jiraKey, currentEnv)
            this.sync(project, serviceName, nextEnv, updateTag, k8sGitBranch, k8sTargetDir, props)
            jiraAction.update(jiraKey, nextEnv)
}*/

        } else {
            currentBuild.result = "FAILED"
            error("Environment Doesn't Match")
        }
    }
    catch (err) {
        wrap([$class: 'AnsiColorBuildWrapper'])
                {
                    println "\u001B[31m[ERROR]: Caued by error at Production Release Deployment Stage"
                    currentBuild.result = "FAILED"
                    throw err
                }
    }
}

def sync(def project, def serviceName, def environment, def updateTag, def k8sGitBranch, def k8sTargetDir, def props) {

    def executeShell = new executeShell()
    def  misc = new misc()
    if (serviceName.contains("fol")) {
        this.checkParams(project, "fol-admin-service", environment, "$updateTag")
    } else {
        this.checkParams(project, serviceName, environment, "$updateTag")
    }

    def stageConfig = libraryResource 'com/ftd/workflow/stage-config.properties'
    writeFile file: 'stage-config.properties', text: stageConfig
    stageConfig = readProperties file: "stage-config.properties"


    def pciList = stageConfig['pciList']
    def serviceSubstr = serviceName[0..serviceName.lastIndexOf('-') - 1]

    for (def service : serviceName.split()) {

        region = sh(returnStdout: true, script: "host stag-web-front-end.gcp.ftd.com | grep -ioE primary-[1-2] | sort -u").trim()
        (region.matches("primary-1") && (environment.matches("prod1") || environment.matches("prod2"))) ? input("Sync Activity Can't be done  to Active environment Env - $region ") : (region.matches("primary-2") && (environment.matches("prod3") || environment.matches("prod4"))) ? input("Sync Activity Can't be done  to Active environment Env - $region ") : "CHECK the sync activity"
//        (cluster2sync.cotains("No")  ?

        //switch traffic before deployment
        /* if (environment.matches("prod1"))
             this.switchTraffic(service, "prod2", props, "sync")
         else if (environment.matches("prod2"))
             this.switchTraffic(service, "prod1", props, "sync")
         else if (environment.matches("prod3"))
             this.switchTraffic(service, "prod4", props, "sync")
         else if (environment.matches("prod4"))
             this.switchTraffic(service, "prod3", props, "sync")



         if (environment.matches("prod5"))
             this.switchTraffic(service, "prod6", props, "sync")
         else if (environment.matches("prod6"))
             this.switchTraffic(service, "prod5", props, "sync")
         else if (environment.matches("prod7"))
             this.switchTraffic(service, "prod8", props, "sync")
         else if (environment.matches("prod8"))
             this.switchTraffic(service, "prod7", props, "sync") */

        // if ((pciList.contains("${serviceSubstr}") || serviceName.contains("pci-web")) && (environment.contains("prod") || environment.contains("stg"))) {
                                // if(searchList(serviceName,pciList).contains("true")){
        if ((misc.searchList(serviceName,pciList).contains("true") || serviceName.contains("pci-web")) && (environment.contains("prod") || environment.contains("stg"))) {

     kubernetes.justK8s(props["${environment}Cluster"], props["${environment}Zone"], props["${environment}DeployProject"])
                     executeShell.exec("kubectl config current-context")
//        if ((pciList.contains("${serviceSubstr}"))  && (environment.contains("prod") || environment.contains("stg"))) {
            DeploymentHandler(service, props["pci${environment}Cluster"], props["pci${environment}Zone"], props["pci${environment}DeployProject"], props["pci${environment}NameSpace"], updateTag, k8sGitBranch, k8sTargetDir)

            if (serviceName.contains("fol-admin-service")) {
                serviceName = "fol-site-service"
                stage(" Waiting 2min for  fol-admin to get ready ") {
                    // executeShell("sleep 120")
                    addSleep(120)
                }

                DeploymentHandler(service, props["pci${environment}Cluster"], props["pci${environment}Zone"], props["pci${environment}DeployProject"], props["pci${environment}NameSpace"], updateTag, k8sGitBranch, k8sTargetDir)

            }
        } else if (environment.matches("hotfix")) {
              kubernetes.justK8s(props["${environment}Cluster"], props["${environment}Zone"], props["${environment}DeployProject"])
                     executeShell.exec("kubectl config current-context")
            DeploymentHandler(service, props["${environment}Cluster"], props["${environment}Zone"], props["${environment}DeployProject"], props["${environment}NameSpace"], updateTag, k8sGitBranch, k8sTargetDir)
        } else {
              kubernetes.justK8s(props["${environment}Cluster"], props["${environment}Zone"], props["${environment}DeployProject"])
                     executeShell.exec("kubectl config current-context")
            DeploymentHandler(service, props["${environment}Cluster"], props["${environment}Zone"], props["${environment}DeployProject"], props["${environment}NameSpace"], updateTag, k8sGitBranch, k8sTargetDir)
        }

        // if (environment.matches("prod2"))
        //     this.switchTraffic(service, "Cluster1", props)
        // else if (environment.matches("prod4"))
        //     this.switchTraffic(service, "Cluster2", props)
    }
}

def checkParams(def project, def serviceName, def environment, def buildTag) {
    def executeShell = new executeShell()
    def dockerTagSN = (( (serviceName.contains("pci-web") || serviceName.contains("pci-test") ))? serviceName.replaceAll("pci-","").trim() : serviceName )

    // def tagStatus = sh(returnStdout: true, script: "gcloud container images list-tags gcr.io/${project}/${serviceName} --filter='tags:$buildTag'")
    def tagStatus = executeShell.exec("gcloud container images list-tags gcr.io/${project}/${dockerTagSN} --filter='tags:$buildTag'")
// def executeShell = new executeShell()
    if ((tagStatus == "") && (environment == "prod")) {
        currentBuild.result = "FAILED"
        error("Please deploy $buildTag to previous environment first and then deploy to Production")
    } else if (tagStatus == "") {
        currentBuild.result = "FAILED"
        error("Tag missing in GCR. Please check the tag $buildTag and re-deploy with correct tag.")
    }
}






def addSleep(def sleepTime)
{
        def executeShell=new executeShell()

    stage("wait for ${sleepTime} sec")
                    {
                        executeShell.exec("sleep ${sleepTime}")
                    }
}

//def runDeploy(def environment,def region)

def runStag(def region,def stagEnv,def pipelineName,def serviceName,def pciList, def skipStag,def updateTag,def k8sGitBranch,def k8sTargetDir)
{


def logs= new logs()
        def executeShell=new executeShell()

        def serviceSubstr = serviceName[0..serviceName.lastIndexOf('-') - 1]
        def props = readProperties file: "job-configuration.properties"
                    def kubernetes=new kubernetes()
                    def  misc = new misc()

    // if (pciList.contains("${serviceSubstr}")) {
        logs.infoMessage("#####"+misc.searchList(serviceName,pciList)+"####")
if(misc.searchList(serviceName,pciList).contains("true"))
{

    logs.infoMessage("!!!!!!!! Inside PCI ${pciList} \n  ${serviceSubstr} \n ${stagEnv}  !!!!!! ")


        if (serviceName.contains("fol-admin-service") || pipelineName.contains("job-prod") || skipStag.contains("${serviceName}")) {
            

                stage(" NO DEPLOY TO STAG ") {
                    //    executeShell("sleep 120")
                    if ((region.matches("REGION3")) || (region.matches("REGION4"))) {
                        kubernetes.justK8s(props["pci${stagEnv}Cluster"], props["pci${stagEnv}Zone"], props["pci${stagEnv}DeployProject"])
                    } else {
                        kubernetes.justK8s(props["pci${stagEnv}Cluster"], props["pci${stagEnv}Zone"], props["pci${stagEnv}DeployProject"])
                    }

                }

            }

        else {

            if (pipelineName.contains("job-prod") || skipStag.contains("${serviceName}")) {
                stage(" NO DEPLOY TO STAG ") {

                    kubernetes.justK8s(props["pci${stagEnv}Cluster"], props["pci${stagEnv}Zone"], props["pci${stagEnv}DeployProject"])
//                            }


                }

            } else {
                //  this.run(serviceName, props["pci${environment}Cluster"], props["pci${environment}Zone"], props["pci${environment}DeployProject"], props["pci${environment}NameSpace"], updateTag, k8sGitBranch, k8sTargetDir))
                        kubernetes.justK8s(props["pci${stagEnv}Cluster"], props["pci${stagEnv}Zone"], props["pci${stagEnv}DeployProject"])

                DeploymentHandler(serviceName, props["pci${stagEnv}Cluster"], props["pci${stagEnv}Zone"], props["pci${stagEnv}DeployProject"], props["pci${stagEnv}NameSpace"], updateTag, k8sGitBranch, k8sTargetDir)
            }


        }



} else 
{
        logs.infoMessage("!!!!!!!! Outside PCI  \n  ${serviceSubstr} \n ${stagEnv}  !!!!!! ")


        if (pipelineName.contains("job-prod") || skipStag.contains("${serviceName}")) {
            stage(" NO DEPLOY TO STAG ") {
//                        executeShell("sleep 120")

                kubernetes.justK8s(props["${stagEnv}Cluster"], props["${stagEnv}Zone"], props["${stagEnv}DeployProject"])

            }

        } else {
            
             logs.infoMessage("ENVIRONMENT - ${stagEnv}")
                             kubernetes.justK8s(props["${stagEnv}Cluster"], props["${stagEnv}Zone"], props["${stagEnv}DeployProject"])

                            DeploymentHandler(serviceName, props["${stagEnv}Cluster"], props["${stagEnv}Zone"], props["${stagEnv}DeployProject"], props["${stagEnv}NameSpace"], updateTag, k8sGitBranch, k8sTargetDir)


        }


    }

}




def runProd(def region, def serviceName,def currentEnv, def nextEnv,def updateTag,def jiraKey,def pciList,def flag,def reporter,def k8sTargetDir)
{
            def props = readProperties file: "job-configuration.properties"
            def stageConfig = readProperties file: "stage-config.properties"
            def  misc = new misc()
                    def sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss")
                          def kubernetes=new kubernetes()
def serviceSubstr = serviceName[0..serviceName.lastIndexOf('-') - 1]
def logs=new logs()
        def pipeline= new manualApproval()
    def executeShell = new executeShell()

def project = props['project']
        def k8sGitUrl = props['k8sGitUrl']
        def k8sGitBranch = props['k8sGitProd']
        // def k8sTargetDir = props['k8sTargetDir']
                def approverList = props['approverList']

             def adminApprover = props["adminApprover"]
             def skipProd = stageConfig["skipProd"]
             logs.infoMessage("${skipProd}")
 if(misc.searchList(serviceName,skipProd).contains("true")){

    logs.infoMessage("No Production deploy is needed for thie ${serviceName} -->Proceeding with merge")
 }
 else
 {

 if(flag == "Y")
{           
    // milestone = 6
            // pipeline.manualApproval(milestone, 72, "HOURS", "Do you approve to deploy $updateTag to ${currentEnv}?", approverList, "Do you approve to deploy $updateTag to ${currentEnv}?", serviceName, adminApprover, reporter)
            pipeline.manualApproval(72, "HOURS", "SwitchTraffic to ${nextEnv}?", approverList, "SwitchTraffic Approval", serviceName, adminApprover, reporter)

}
 if (region.contains("REGION")){

// if (pciList.contains("${serviceSubstr}")) { 
        if(misc.searchList(serviceName,pciList).contains("true")){


  println("!!!!!!!! PCI - SWITCHING TRAFFIC to $nextEnv !!!!!! ")

      kubernetes.justK8s(props["pci${nextEnv}Cluster"], props["pci${nextEnv}Zone"], props["pci${nextEnv}DeployProject"])
      kubernetes.switchTraffic(region,serviceName, nextEnv, props, "deployment",jiraKey,"NONE")
                 

 }

else
{


      println("!!!!!!!! SWITCHING TRAFFIC to $nextEnv !!!!!! ")
  executeShell.exec("kubectl config current-context")

      kubernetes.justK8s(props["${nextEnv}Cluster"], props["${nextEnv}Zone"], props["${nextEnv}DeployProject"])
      kubernetes.switchTraffic(region,serviceName, nextEnv, props, "deployment",jiraKey,"NONE")
              
}
          


            mailStep = "input"
            mailSubject = "$serviceName - $updateTag - ${nextEnv} deployment Approval"
            EmailNotifications(serviceName, mailStep, mailSubject)
        

            if(flag == "Y")
{        
       
         stage("Deployment Approval")   {pipeline.manualApproval(72, "HOURS", "Do you approve to deploy $updateTag ?", approverList, "Do you approve to deploy $updateTag?", serviceName, adminApprover, reporter)}

}



//   if (pciList.contains("${serviceSubstr}")) {
    if(misc.searchList(serviceName,pciList).contains("true")){
                kubernetes.justK8s(props["pci${currentEnv}Cluster"], props["pci${currentEnv}Zone"], props["pci${currentEnv}DeployProject"])
  executeShell.exec("kubectl config current-context")
        if (!(serviceName.contains("fol-admin-service") && (currentEnv.contains("prod2") || currentEnv.contains("prod4") || currentEnv.contains("prod6") || currentEnv.contains("prod8")))) {
            DeploymentHandler(serviceName, props["pci${currentEnv}Cluster"], props["pci${currentEnv}Zone"], props["pci${currentEnv}DeployProject"], props["pci${currentEnv}NameSpace"], updateTag, k8sGitBranch, k8sTargetDir)
        }
                if (serviceName.contains("fol-admin-service")) {
                    serviceName = "fol-site-service"
                    stage(" Waiting 4min for  fol-admin to get ready ") {
                        // executeShell("sleep 240")
                        addSleep(240)
                    }

                    DeploymentHandler(serviceName, props["pci${currentEnv}Cluster"], props["pci${currentEnv}Zone"], props["pci${currentEnv}DeployProject"], props["pci${currentEnv}NameSpace"], updateTag, k8sGitBranch, k8sTargetDir)

                }
            } else {

                  kubernetes.justK8s(props["${currentEnv}Cluster"], props["${currentEnv}Zone"], props["${currentEnv}DeployProject"])
                    executeShell.exec("kubectl config current-context")

                DeploymentHandler(serviceName, props["${currentEnv}Cluster"], props["${currentEnv}Zone"], props["${currentEnv}DeployProject"], props["${currentEnv}NameSpace"], updateTag, k8sGitBranch, k8sTargetDir)



}

 }

 else if(region.contains("Active-Active"))
 {

nextEnv=nextEnv.split(":")     
nextEnv0=nextEnv[0]
nextEnv1=nextEnv[1]
currentEnv=currentEnv.split(":")
currentEnv0=currentEnv[0]
currentEnv1=currentEnv[1]
logs.infoMessage("!!!!!1. $nextEnv --> $nextEnv0 --> $nextEnv1 \n $currentEnv --> $currentEnv0 --> $currentEnv1 \n !!!!")


stage("Scaling pods & Switch Traffic"){
    dir("/root/workspace/${serviceName}/${serviceName}-prod-deploy-pipelines/"){    stash name: "ws-scale", includes: "**/*" , useDefaultExcludes: false }  


    parallel(

        "Scale-${nextEnv0}":{
        
              node{                      
                  executeShell.prepNode()

      dir("/root/workspace/${serviceName}/${serviceName}-prod-deploy-pipelines/")
                                    {


                                        unstash "ws-scale"
                                          sh "ls -la ${pwd()}"
                                        // sh "cd temp; git stash; git pull origin preprod" 
                                        sh "cd temp; git stash; git pull --rebase origin preprod" 
                                    }


nodeString = (nextEnv0.contains("prod1") ||  nextEnv0.contains("prod2")) ? "cluster1" : (nextEnv0.contains("prod3") ||  nextEnv0.contains("prod4")) ? "cluster2" : "CheckArgs"
// stage("Traffic Switch to ${it}"){
logs.infoMessage("!!!!!!!! $region \n ${pciList} \n  ${serviceSubstr} \n ${nextEnv0}  \n ${nodeString}!!!!!! ")

    //   (pciList.contains("${serviceSubstr}")) ? kubernetes.justK8s(props["pci${nextEnv0}Cluster"], props["pci${nextEnv0}Zone"], props["pci${nextEnv0}DeployProject"]) : kubernetes.justK8s(props["${nextEnv0}Cluster"], props["${nextEnv0}Zone"], props["${nextEnv0}DeployProject"])
      (misc.searchList(serviceName,pciList).contains("true")) ? kubernetes.justK8s(props["pci${nextEnv0}Cluster"], props["pci${nextEnv0}Zone"], props["pci${nextEnv0}DeployProject"]) : kubernetes.justK8s(props["${nextEnv0}Cluster"], props["${nextEnv0}Zone"], props["${nextEnv0}DeployProject"])

  executeShell.exec("kubectl config current-context")

      kubernetes.switchTraffic(region,serviceName, nextEnv0, props, "deployment",jiraKey,nodeString)
      
              }    

            
          
        },
        "Scale-${nextEnv1}":{


            node{                      
                  executeShell.prepNode()

      dir("/root/workspace/${serviceName}/${serviceName}-prod-deploy-pipelines/")
                                    {


                                        unstash "ws-scale"
                                          sh "ls -la ${pwd()}"
                                        // sh "cd temp; git stash; git pull origin preprod" 
                                        sh "cd temp; git stash; git pull --rebase origin preprod" 
                                    }


                  nodeString = (nextEnv1.contains("prod1") ||  nextEnv1.contains("prod2")) ? "cluster1" : (nextEnv1.contains("prod3") ||  nextEnv1.contains("prod4")) ? "cluster2" : "CheckArgs"
// stage("Traffic Switch to ${it}"){
logs.infoMessage("!!!!!!!! SWITCHING TRAFFIC to ${pciList} \n  ${serviceSubstr} \n ${nextEnv1}  \n ${nodeString}!!!!!! ")
 (misc.searchList(serviceName,pciList).contains("true")) ?   kubernetes.justK8s(props["pci${nextEnv1}Cluster"], props["pci${nextEnv1}Zone"], props["pci${nextEnv1}DeployProject"]) :  kubernetes.justK8s(props["${nextEnv1}Cluster"], props["${nextEnv1}Zone"], props["${nextEnv1}DeployProject"])

  executeShell.exec("kubectl config current-context")

      kubernetes.switchTraffic(region,serviceName, nextEnv1, props, "deployment",jiraKey,nodeString)
     

            }
            
         
        }




    )
}




            mailStep = "input"
            mailSubject = "$serviceName - $updateTag - ${currentEnv0} deployment Approval"
            EmailNotifications(serviceName, mailStep, mailSubject)
// stage("deploy $updateTag to ${currentEnv}?")  {
    pipeline.manualApproval(72, "HOURS", "Do you approve to deploy $updateTag to ${currentEnv}?", approverList, "Do you approve to deploy $updateTag to ${currentEnv}?", serviceName, adminApprover, reporter)
    // } 
addSleep(45)

try {
   dir("/root/workspace/${serviceName}/${serviceName}-prod-deploy-pipelines/"){    stash name: "ws", includes: "**/*" ,useDefaultExcludes: false}  
    //  dir("/root/workspace/test-service/test-service-prod-deploy-pipelines/temp"){    stash name: "temp", includes: "/"}

}
catch (e)
{
    errorMessage("$e")
    error("$e")
}

// logs.infoMessage("!!!!! 1. $nextEnv0 --> $nextEnv1 \n  $currentEnv0 --> $currentEnv1 \n !!!!")
serviceSubstr =  serviceName[0..serviceName.lastIndexOf('-') - 1]
stage("Cross-cluster Deploys"){
parallel (
    "${serviceName}-${currentEnv0}" : {
        
        // logs.infoMessage("!!!!! INSIDE NODE1 for ${currentEnv0}\n !!!!")
        // logs.infoMessage("!!!!! 1. $nextEnv --> $nextEnv0 --> $nextEnv1 \n $currentEnv --> $currentEnv0 --> $currentEnv1 \n !!!!")
                     node {  
                    //  unstash "ws"
                    executeShell.prepNode()
                  dir("/root/workspace/${serviceName}/${serviceName}-prod-deploy-pipelines/"){unstash "ws"  
                    sh "ls -la ${pwd()}"
                                        // sh "cd temp; git stash; git pull origin preprod" 
                                        sh "cd temp; git stash; git pull --rebase origin preprod" 
                  }  
      

stage("Deploying to ${currentEnv0}"){

//  k8sTargetDir="~/workspace/test-service/test-service-prod-deploy-pipelines"

  if (misc.searchList(serviceName,pciList).contains("true")) {

                kubernetes.justK8s(props["pci${currentEnv0}Cluster"], props["pci${currentEnv0}Zone"], props["pci${currentEnv0}DeployProject"])
  executeShell.exec("kubectl config current-context")
                DeploymentHandler(serviceName, props["pci${currentEnv0}Cluster"], props["pci${currentEnv0}Zone"], props["pci${currentEnv0}DeployProject"], props["pci${currentEnv0}NameSpace"], updateTag, k8sGitBranch, k8sTargetDir)

                if (serviceName.contains("fol-admin-service")) {
                    serviceName = "fol-site-service"
                    stage(" Waiting 4min for  fol-admin to get ready ") {
                        // executeShell("sleep 240")
                        addSleep(240)
                    }

                    DeploymentHandler(serviceName, props["pci${currentEnv0}Cluster"], props["pci${currentEnv0}Zone"], props["pci${currentEnv0}DeployProject"], props["pci${currentEnv0}NameSpace"], updateTag, k8sGitBranch, k8sTargetDir)

                }
            } else {

                kubernetes.justK8s(props["${currentEnv0}Cluster"], props["${currentEnv0}Zone"], props["${currentEnv0}DeployProject"])
                  executeShell.exec("kubectl config current-context")

                DeploymentHandler(serviceName, props["${currentEnv0}Cluster"], props["${currentEnv0}Zone"], props["${currentEnv0}DeployProject"], props["${currentEnv0}NameSpace"], updateTag, k8sGitBranch, k8sTargetDir)



            } 


}
            
}//NODE ENDS HERE 
},//parallel call end heres
 "${serviceName}-${currentEnv1}" : {
                     node {  
                                             executeShell.prepNode()

                        //  println("!!!!!!!! SWITCHING TRAFFIC to $nextEnv1 !!!!!! ")
                        //  logs.infoMessage("!!!!! 1. $nextEnv --> $nextEnv0 --> $nextEnv1 \n $currentEnv --> $currentEnv0 --> $currentEnv1 \n !!!!")
                  dir("/root/workspace/${serviceName}/${serviceName}-prod-deploy-pipelines/"){unstash "ws"  
                    sh "ls -la ${pwd()}"
                                        // sh "cd temp; git stash; git pull origin preprod" 
                                        sh "cd temp; git stash; git pull --rebase origin preprod" 
                  
                   }  
         
stage("Deploying to ${currentEnv1}"){


// if (pciList.contains("${serviceSubstr}")) {
    if(misc.searchList(serviceName,pciList).contains("true")){
                kubernetes.justK8s(props["pci${currentEnv1}Cluster"], props["pci${currentEnv1}Zone"], props["pci${currentEnv1}DeployProject"])
  executeShell.exec("kubectl config current-context")

                DeploymentHandler(serviceName, props["pci${currentEnv1}Cluster"], props["pci${currentEnv1}Zone"], props["pci${currentEnv1}DeployProject"], props["pci${currentEnv1}NameSpace"], updateTag, k8sGitBranch, k8sTargetDir)

                if (serviceName.contains("fol-admin-service")) {
                    serviceName = "fol-site-service"
                    stage(" Waiting 4min for  fol-admin to get ready ") {
                        // executeShell("sleep 240")
                        addSleep(240)
                    }

                    DeploymentHandler(serviceName, props["pci${currentEnv1}Cluster"], props["pci${currentEnv1}Zone"], props["pci${currentEnv1}DeployProject"], props["pci${currentEnv1}NameSpace"], updateTag, k8sGitBranch, k8sTargetDir)

                }
            } else {

                   kubernetes.justK8s(props["${currentEnv1}Cluster"], props["${currentEnv1}Zone"], props["${currentEnv1}DeployProject"])
                     executeShell.exec("kubectl config current-context")

                DeploymentHandler(serviceName, props["${currentEnv1}Cluster"], props["${currentEnv1}Zone"], props["${currentEnv1}DeployProject"], props["${currentEnv1}NameSpace"], updateTag, k8sGitBranch, k8sTargetDir)


            } 
            

}

  
            
            } 
                   }



          )

} //cros cluster deploys
            
        }



 }

 


}


def incr(def i)
{
    return i++
}

