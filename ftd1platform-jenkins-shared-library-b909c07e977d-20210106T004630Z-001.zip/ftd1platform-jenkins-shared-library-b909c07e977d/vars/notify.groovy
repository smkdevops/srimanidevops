def slack(def channel,def message, def color){
  stage('Slack Message') {
         

                slackSend channel: "#${channel}",
                    color: "color",
                    message: "*${message}"
            
      
        }


}

def noslacking()
{
    print "No Slack notification configured"
}
      