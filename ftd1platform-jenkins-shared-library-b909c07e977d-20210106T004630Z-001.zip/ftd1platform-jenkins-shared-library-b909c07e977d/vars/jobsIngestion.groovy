/*
 * This file will handle release deployments to UAT, STRESS and PROD
 * It will also do some validations before deploying to PROD
 */

import org.hamcrest.core.StringContains


String boldGreenMessage(final String message) { return "\033[1;32m${message}\033[0m" }

String boldBlueMessage(final String message) { return "\033[1;34m${message}\033[0m" }

String boldRedMessage(final String message) { return "\033[1;31m${message}\033[0m" }

String boldYellowMessage(final String message) { return "\033[1;33m${message}\033[0m" }

String triplePrefixMessage(final Closure<String> colour, final String prefix, final String message) {
    def colouredPrefix = "${colour("${prefix}")}"
    return "${colouredPrefix}\n${colouredPrefix} ${message}\n${colouredPrefix}"
}

void successMessage(final String message) {
    ansiColor('xterm') { echo triplePrefixMessage(this.&boldGreenMessage, '[SUCCESS]', message) }
}

void infoMessage(final String message) {
    ansiColor('xterm') { echo triplePrefixMessage(this.&boldBlueMessage, '[INFO]', message) }
}

void warningMessage(final String message) {
    ansiColor('xterm') { echo triplePrefixMessage(this.&boldYellowMessage, '[WARNING]', message) }
}

void errorMessage(final String message) {
    ansiColor('xterm') { echo triplePrefixMessage(this.&boldRedMessage, '[ERROR]', message) }
}

import org.codehaus.groovy.control.messages.ExceptionMessage

import java.text.SimpleDateFormat






def call(script) {
    try {
        def logs=new logs()

        def jiraAction= new jira()
        def git=new git()
        def executeShell=new executeShell()
        def kubernetes=new kubernetes()
        def pipeline= new manualApproval()
        def jobObj = new com.ftd.workflow.JobManager(script)
        def serviceName = jobObj.getServiceName()
        def pipelineName = jobObj.getPipelineName()
        def serviceSubstr = serviceName[0..serviceName.lastIndexOf('-') - 1]

        def jobConfiguration = libraryResource 'com/ftd/workflow/job-configuration.properties'
        writeFile file: 'job-configuration.properties', text: jobConfiguration

        def props = readProperties file: "job-configuration.properties"

        def stageConfig = libraryResource 'com/ftd/workflow/stage-config.properties'
        writeFile file: 'stage-config.properties', text: stageConfig
        stageConfig = readProperties file: "stage-config.properties"

        def project = props['project']
        def k8sGitUrl = props['k8sGitUrl']
        def k8sGitBranch = props['k8sGitProd']
        def k8sTargetDir = props['k8sTargetDir']
        def approverList = props['approverList']
        def jiraApproverList = props['jiraApproverList']
        def testID = 'rkande@ftdi.com'
        def serviceList = stageConfig['serviceList']
        def pciList = stageConfig['pciList']
//        def jiraApproverList = props["jiraApproverList"]
        def projectID = props["projectID"]
        def issueTypeID = props["issueTypeID"]
        def componentID = props["componentID"]
        def jiraURL = props["jiraURL"]
        def buildTag = "${params.DOCKER_TAG}"
        def environment = "${params.ENVIRONMENT}"
        def sleepTime = stageConfig["sleepTime"]
        def skipStag = stageConfig["skipStag"]
        def reporter
        def enableDisable = props["enableDisable"]
        def deployStatus = "false"
        def overWriteProdDeploys = props["overWriteProdDeploys"]
        def adminApprover = props["adminApprover"]
        def misc = new misc()
//        def nettyService = stageConfig["netty"]
        def imageTag = buildTag
        def user
        wrap([$class: 'BuildUser']) {
            user = env.BUILD_USER_ID
            tempId = user.split("@")
            reporter = tempId[0]
        }

        //echo "$Id"

        def region = "${params.REGION}"
        //	def crId = "${params.CR_ID}"

        def nonProdImage, releaseTag, mailStep, mailSubject, prodSequence, stageEnv, currentEnv, nextEnv, prodCluster, serviceGitUrl

        /*  if (crId == "")
          {
              error ("CRID cant be empty!!!" )
          }*/


        def crSummary = "${params.CR_SUMMARY}"
        if (crSummary.isEmpty()) {

            error("crSummary cant be empty!!!")
        }






        if (buildTag == "") {
            error("Tags cannot be null value!!!! Please enter appropriate build tag to be deployed to $environment")
        } else if (!buildTag.startsWith("qa1") && !buildTag.startsWith("hotfix")) {
            error("Please enter qa/hotfix deployed docker tags. Dev deployed tags will not be deployed to production environments")
        } else if (enableDisable.contains("disable") && !overWriteProdDeploys.contains(serviceSubstr)) {
            errorMessage("PRODUCTION BUILDS ARE DISABLED UNTIL FURTHER NOTICE")
            error("PRODUCTION BUILDS ARE DISABLED UNTIL FURTHER NOTICE")
        }




        environment = environment.toLowerCase()
        println("STG - ${environment} ******")
        def gitBranch = buildTag[0..buildTag.indexOf('-') - 1]
        def updateTag = "uat-${buildTag}"

       


        if (region.matches("REGION1")) {
            prodSequence = ["${environment}1", 'prod1', 'prod2', 'Cluster1(US Central)', "${environment}2", 'prod3', 'prod4', 'Cluster2(US West)']
        } else if (region.matches("REGION2")) {
            prodSequence = ["${environment}2", 'prod3', 'prod4', 'Cluster2(US West', "${environment}1", 'prod1', 'prod2', 'Cluster1(US Central)']
        } else if (region.matches("REGION3")) {
            prodSequence = ["${environment}3", 'prod5', 'prod6', 'Cluster1(EU West3)', "${environment}4", 'prod7', 'prod8', 'Cluster2(EU West2)']
        } else if (region.matches("REGION4")) {
            prodSequence = ["${environment}4", 'prod7', 'prod8', 'Cluster2(EU West2)', "${environment}3", 'prod5', 'prod6', 'Cluster1(EU West3)']
        }  else if (region.matches("Active-Active")) {
        prodSequence = ["${environment}1",'prod1:prod3', 'prod2:prod4', 'Cluster1(US Central):Cluster2(US West)']
    } else if (region.matches("PROD13")) {
        prodSequence = ["${environment}1", 'prod1:prod3']
    }else if (region.matches("PROD24")) {
            prodSequence = ["${environment}2", 'prod2:prod4']
        }


        println(" ${prodSequence}  ******")
        println(props["${environment}NameSpace"])


        environment = prodSequence[0]

        def servicePath

        if (serviceList.contains("${serviceSubstr}")) {
            servicePath = serviceSubstr


        }
    
        else {
            servicePath = serviceName


        }

servicePath = (servicePath.contains("pci-web")|| servicePath.contains("pci-test")) ? servicePath.replaceAll("pci-","").trim() : servicePath 
    def dockerTagSN = (( (serviceName.contains("pci-web") || serviceName.contains("pci-test") ))? serviceName.replaceAll("pci-","").trim() : serviceName )

         nonProdImage = "gcr.io/${project}/${dockerTagSN}:${buildTag}"
        releaseTag = "gcr.io/${project}/${dockerTagSN}:${updateTag}"
      
        if (environment.matches("uat1|stg1|stg2|stg3|stg4|pcistg1|pcistg2")) {
            //validate params first
            this.checkParams(project, serviceName, environment, "$buildTag")
//            git.checkout(serviceName)
            serviceGitUrl=(serviceName.contains("fol")) ?   "git@bitbucket.org:ftd1platform/fol.git" : "git@bitbucket.org:ftd1platform/${servicePath}.git"

            checkout([$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: 'temp1'], [$class: 'CheckoutOption', timeout: 30], [$class: 'CloneOption', timeout: 30]], submoduleCfg: [], userRemoteConfigs: [[url: serviceGitUrl]]])

            if (buildTag.contains("hotfix-")) {

                dir("temp1")
                        {
                            executeShell.exec("git checkout ${buildTag}")
                            def cmd = "curl -s  -X GET -H 'Authorization: Basic amVua2luc2NpLXVzZXI6dVA4bURMTEhlVFdwR0RFdWE0OFM=' https://bitbucket.org/api/2.0/repositories/ftd1platform/$servicePath/refs/branches/master | jq '.target.hash'"
                            def masterCommit =  executeShell.exec(cmd) //sh(returnStdout: true, script: cmd)
                            masterCommit = masterCommit.trim()
                            List<String> sourceChanged = sh(returnStdout: true, script: "git log --pretty=format:'%H'").split()
                            def isMasterCommitIn = false
                            for (int i = 0; i < sourceChanged.size(); i++) {
//
                                if (sourceChanged[i].contains("$masterCommit")) {
                                    isMasterCommitIn = true
                                    echo "**** $sourceChanged[i] ****"
                                }
                            }
                            if (isMasterCommitIn == false) {
//                                error(" Hotfix Tag doesn't contain the latest master commit hash -  $masterCommit ")
                            }


                        }

            }
            executeShell.exec("gcloud docker -- pull ${nonProdImage}")
            executeShell.exec("docker tag ${nonProdImage} ${releaseTag}")
            executeShell.exec("gcloud docker -- push ${releaseTag}")
            if (serviceName =~ "test") {
                println "\u001B[32m[INFO] Stage deploy is not required for test"
            }

if(region.contains("Active-Active")){

    dir("/root/workspace/${serviceName}/${serviceName}-prod-deploy-pipelines/"){    stash name: "ws-stag", includes: "**/*" , useDefaultExcludes: false }  

stage("Cross-cluster stag deploy"){
    tempEnv = "stg1:stg2".split(":")
stag1Env=tempEnv[0].toString()
stag2Env=tempEnv[1].toString()
stag1Env=stag1Env.trim()
stag2Env=stag2Env.trim()
parallel(
"${serviceName}-${stag1Env}": {

              node{                      
                  executeShell.prepNode()

                                    dir("/root/workspace/${serviceName}/${serviceName}-prod-deploy-pipelines/")
                                    {


                                        unstash "ws-stag"
                                    }
                                               runStag(region,stag1Env,pipelineName,serviceName,pciList,skipStag,updateTag,k8sGitBranch,k8sTargetDir)
   
              }
},
"${serviceName}-${stag2Env}": {

              node{                      
                  executeShell.prepNode()

                                    dir("/root/workspace/${serviceName}/${serviceName}-prod-deploy-pipelines/")
                                    {


                                        unstash "ws-stag"
                                    }
                                                // kubernetes.justK8s("")
                                               runStag(region,stag2Env,pipelineName,serviceName,pciList,skipStag,updateTag,k8sGitBranch,k8sTargetDir)
   
              }
}


)



}
}
else
{
                                               runStag(region,environment,pipelineName,serviceName,pciList,skipStag,updateTag,k8sGitBranch,k8sTargetDir)


}





// Fetch sonar results and store in env variables for email template
            FetchSonarCoverage(serviceName, buildTag)
            //Fetch Jira details from commit & summary from JIRA and add to the email template


            def commitJIRAList = sh(script: "curl -s -X GET 'https://bitbucket.org/api/2.0/repositories/ftd1platform/${servicePath}/commits/$buildTag?exclude=master' -H 'Authorization: Basic amVua2luc2NpLXVzZXI6dVA4bURMTEhlVFdwR0RFdWE0OFM=' -H 'Cache-Control: no-cache'  | jq '.values[]?.summary.raw' | grep -oEi 'CAL-[0-9]+' | sort -u ", returnStdout: true).trim()


            commitJIRAList = commitJIRAList.replace("\n", ",")
            // def jiraAndDescription
            def jiraList = commitJIRAList.split(',')
            def issueList


            if (jiraList.size() != 0) {


                issueList = "<h2>Individual JIRA's part of this release:</h2><ul>"
                for (def jira : jiraList) {
                    jira = jira.trim()
                    jira = jira.toUpperCase()
                    //println(jira.toUpperCase())

                    //toLowerCase()
                    if (jira.contains("CAl-") || jira.contains("CAL")) {
                        def issue
                        def summary
                        if (jira.matches("CAL-0000")) {
                            println "!!!WARNING: CAL-0000 is not valid jira"
                        } else {
                            try {
                                issue = jiraGetIssue idOrKey: "$jira", site: 'jira' // Retrieves the Jira issue
                                summary = issue.data.fields.summary.toString() // Retrieves the summary field

                                issueList = issueList.concat("<li><a href=\"${jiraURL}/browse/${jira}\">${jira} : ${summary}</a></li>")
                            }
                            catch (err) {
                                echo "$jira doesnt exist !!!"

                            }

                        }

                    } else {
                        issueList = "<h2>JIRA # are not part of the commit messages. </h2><ul>"
                    }

                }

            }

            env.ISSUE_LIST = issueList

            //send stage/uat deploy success mail
            mailStep = "deploy"
            mailSubject = "$serviceName deployment to $environment is ${currentBuild.result}"
            EmailNotifications(serviceName, mailStep, mailSubject)






            stage("Tagging SCM")
                    {

                        saveBuildTag = buildTag
                        dir("temp1")
                                {
                                    executeShell.exec("git tag ${updateTag} ${buildTag} --force")
                                    executeShell.exec("git push origin ${updateTag} --force")
                                }
                    }

            //update job display name
            currentBuild.displayName = "$updateTag"
    // cmd = "kubectl get pods -n prod  -o json | jq -r '.items[].status.containerStatuses[] | { \"image\": .image}' | grep ${serviceName} | cut -d':' -f3 | sed 's/\"//' | sort -u"
                prevTag = git.getPrevTag(serviceName)
logs.infoMessage("${prevTag}")
            //wait for manual approval from approvers to proceed to next step
            milestone 1
            tempOut = pipeline.manualApproval(48, "HOURS", "Do you want to  create CHNG ticket now?", user, "CHNG:${prevTag}", serviceName, adminApprover, reporter)


            echo "!!!$tempOut \n\n\n"

            def jiraKey
            def jiraID
            stage('CHNG ticket creation') 
            {


                if (serviceName.matches("test-service")) {
                    jiraKey = "CAL-3636"
                    jiraID = "31030"

                } else if (tempOut.contains("CAL-")) {
                    println "########## NO new CHANGE TICKET #### \n\n"
                    tempOut = tempOut.trim()
                    jiraKey = tempOut

                    response = jiraGetIssue idOrKey: "${jiraKey}", site: 'jira'
                    def responseString = response.data.toString()
                    def splitString = responseString.split(':')
                    jiraID = splitString[2]
                    jiraID = jiraID.replace(", self", "")
                    echo "1 -**** $jiraKey : $jiraID****"

                    // jiraID =

                } else if (tempOut.contains("CREATE") || tempOut == "") {
                    def dateFormat = new SimpleDateFormat("yyyy-MM-dd")
                    def date = new Date()
                    tempOut = tempOut.trim()
                    // def due = dateFormat.format(date)
                    //println(dateFormat.format(date))

                    impact = env.impact
                    changeType = env.changeType
                    rollback = env.rollback

                    println " Impact - $impact \n Rollback - $rollback \n ChangeType = $changeType "

//jiraApproverList="rkande,sellis"
                    def testIssue = [fields: [
                            project          : [id: "$projectID"],
                            summary          : "${serviceName} - ${crSummary}",
                            description      : 'New JIRA Created from Jenkins.',
                            issuetype        : [id: "$issueTypeID"],
                            components       : [[id: "$componentID", name: 'CHNG']],
                            duedate          : dateFormat.format(date),
                            labels           : ["$REGION"],
                            customfield_10036: [value: "$impact"],
                            customfield_10037: [value: "$changeType"],
                            customfield_10110: "$rollback",
                            reporter         : [name: "$reporter"],
//                            customfield_10035: [[name: "$jiraApproverList"]],


                    ]]



                    response = jiraNewIssue issue: testIssue, site: 'jira'


                    echo response.successful.toString()
                    def responseString = response.data.toString()

                    def splitString = responseString.split(',')

                    jiraKey = splitString[1]


                    jiraKey = jiraKey.replace("key:", "")
                    jiraKey = jiraKey.toString()
                    jiraKey = jiraKey.trim()
                    jiraID = splitString[0]


                    jiraID = jiraID.replace("[id:", "")
                    echo "**** $jiraKey : $jiraID****"


                }

            milestone 2

                if (jiraID != "") {


                    jiraAction.update(jiraKey, "EDIT:$serviceName")


                }


                println "2 - **** $jiraKey : $jiraID****"

                currentBuild.displayName = "$updateTag - $jiraKey"

                if (jiraList.size() != 0) {
                    issueList = issueList.concat("<h2>Change Request details:</h2><ul>")
                    issueList = issueList.concat("<li><a href=\"${jiraURL}/browse/${jiraKey}\">${jiraKey} : ${crSummary}</a></li>")
//                    issueList = issueList.concat("<h2>Individual JIRA's part of this release:</h2><ul>")
                    for (def jira : jiraList) {
                        jira = jira.trim()
                        if (jira.contains("CAl-") || jira.contains("CAL")) {

                            if (jira.matches("CAL-0000")) {
                                println "!!!WARNING: CAL-0000 is not valid jira"
                            } else {

                                try {
                                    jiraLinkIssues type: 'Relates', inwardKey: "$jiraKey", outwardKey: "$jira", site: 'jira'
                                }
                                catch (err) {
                                    echo "$jira doesnt exist - It will not be linked to CHNG!!!"
                                }
                            }

                        }


                    }
                } else {
                    issueList = "<h2>JIRA # are not part of the commit messages. </h2><ul>"

                }


                jiraAssignIssue idOrKey: "${jiraID}", userName: "$reporter", site: 'jira'


                env.JIRA_KEY = jiraKey
                env.JIRA_SUMMARY = crSummary
                env.ISSUE_LIST = issueList


            }
            
            jiraAction.update(jiraKey, "Approval:${serviceName} ")
            
            jiraAction.transition(jiraKey, 171) //Ready for approval

// SO FAR GOOD with one node


            //set current and next environment
            currentEnv = prodSequence[1]  //prod1 or 3 / prod1 & prod3
            nextEnv = prodSequence[2]   //prod2 or 4 / prod2 & prod4


            mailStep = "input"
            mailSubject = "$serviceName - $updateTag - ${currentEnv}  deployment Approval"
            EmailNotifications(serviceName, mailStep, mailSubject)

            //get jira status
            pipeline.manualApproval(72, "HOURS", "Do you approve to deploy $updateTag?", approverList, "[APPROVAL]", serviceName, adminApprover, reporter)
                        milestone 3

//          stage
            stage("Waiting for $jiraKey to be Approved ") {
                try {
                    while (jiraAction.getIssueStatus(jiraKey).toUpperCase() != "APPROVED") {
                        logs.infoMessage("Waiting for $jiraKey to be Approved !! \n")
                        sleep(10)
//
                    }
                }
                catch (e) {

                    errorMessage("$e")
                    error("$e")

                }

            }
            jiraAction.transition(jiraKey, 21) //Inprogress

          //runProd method  
          milestone 4
     

def checkParams(def project, def serviceName, def environment, def buildTag) {
    def executeShell = new executeShell()
    def dockerTagSN = (( (serviceName.contains("pci-web") || serviceName.contains("pci-test") ))? serviceName.replaceAll("pci-","").trim() : serviceName )

    // def tagStatus = sh(returnStdout: true, script: "gcloud container images list-tags gcr.io/${project}/${serviceName} --filter='tags:$buildTag'")
    def tagStatus = executeShell.exec("gcloud container images list-tags gcr.io/${project}/${dockerTagSN} --filter='tags:$buildTag'")
// def executeShell = new executeShell()
    if ((tagStatus == "") && (environment == "prod")) {
        currentBuild.result = "FAILED"
        error("Please deploy $buildTag to previous environment first and then deploy to Production")
    } else if (tagStatus == "") {
        currentBuild.result = "FAILED"
        error("Tag missing in GCR. Please check the tag $buildTag and re-deploy with correct tag.")
    }
}






def addSleep(def sleepTime)
{
        def executeShell=new executeShell()

    stage("wait for ${sleepTime} sec")
                    {
                        executeShell.exec("sleep ${sleepTime}")
                    }
}




def sequence(def currentEnv)
{



}




def incr(def i)
{
    return i++
}

