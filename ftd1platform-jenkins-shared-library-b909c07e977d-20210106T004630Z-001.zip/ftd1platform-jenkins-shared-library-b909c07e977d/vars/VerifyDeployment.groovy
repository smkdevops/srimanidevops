/*
 * This script will fetch the SonarQube coverage metrics/measurements which can then be sent via email
*/

def call(script)
{
	try
  {
    wrap([$class: 'AnsiColorBuildWrapper']) {
      println "\u001B[32m[INFO] Verifying deployment to pods"
		}

		def jobObj = new com.ftd.workflow.JobManager(script)
		def serviceName = jobObj.getServiceName()


		git log -1 --pretty="%H"
		
		// if () {
		// 	sh "curl http://10.89.220.5/?env=prod&service=${serviceName} > nodeHealth.json"
		// } else {
		// 	sh "curl http://10.89.220.5/?env=prod&service=${serviceName} > nodeHealth.json"
		// }

		// def nodeHealth = readJSON file:'nodeHealth.json'

    // sh "kubectl get pods -n prod | grep ${serviceName} | awk '{print \$1,\$3}'"

		// sh "curl 'https://sonar.ftdi.com/api/measures/component?component=${serviceName}:${branchName}&metricKeys=bugs,vulnerabilities,code_smells,coverage,tests,duplicated_lines_density,duplicated_blocks,new_bugs,new_vulnerabilities,new_technical_debt,new_code_smells,new_coverage,new_duplicated_lines_density' > result.json"

		// def result = readJSON file:'result.json'

		// for (i=0; i < result.component.measures.size(); i++) {
		// 	if (result.component.measures[i].metric.contains("new")) {
		// 		sonarMap.put(result.component.measures[i].metric, result.component.measures[i].periods[0].value)
		// 	}
		// 	else {
		// 		sonarMap.put(result.component.measures[i].metric, result.component.measures[i].value)
		// 	}
		// }

	}
	catch (err) {
                wrap([$class: 'AnsiColorBuildWrapper']) {
                        println "\u001B[31m[ERROR]: Caused by error while verifying deployments to pods"
                        currentBuild.result = "FAILED"
                        throw err
                }
        }
}
