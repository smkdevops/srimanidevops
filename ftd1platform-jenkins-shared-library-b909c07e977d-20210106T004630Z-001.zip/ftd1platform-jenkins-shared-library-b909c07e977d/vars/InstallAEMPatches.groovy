def call(script) {
  stage('Installing patches') {
    def patches = ['AEM-6.3-Service-Pack-1-6.3.1.zip','AEM-CFP-6.3.1.2-2.0.zip','cq-6.3.0-featurepack-19008-1.0.6.zip','cq-6.3.0-featurepack-19614-1.0.8.zip','cq-6.3.0-featurepack-20593-1.8.zip','cq-6.3.0-featurepack-20696-1.0.0.zip']

    for (i=0; i < patches.size(); i++) {

      def patch = patches[i].take(patches[i].lastIndexOf('.'))

      sh "curl -u admin:admin -F file=@\"${patches[i]}\" -F name=\"${patch}\" -F force=true -F install=true http://${params.HOSTNAME}/crx/packmgr/service.jsp > output.log"

      sh "tail -n 3 output.log > result.log"

      def file = readFile 'result.log'

      println file.split("\n")[0]

      if (file.split("\n")[0].contains('200')) {
        println "${patches[i]} installed successfully."
      }
      else {
        error "${patches[i]} did not install successfully."
        currentBuild.result = "FAILED"
      }
    }
  }
}
