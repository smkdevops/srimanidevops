
def manualApproval(
        
        def timeValue,
        def unit, def message, def approverList, def stageName, def serviceName, def adminApprover, def reporter) {

     def jiraAction= new jira()
        def git=new git()
        def executeShell=new executeShell()
        def kubernetes=new kubernetes()
  def logs=new logs()
logs.infoMessage("${stageName}")
stageName = stageName.toString()
// savestageName = (stageName.contains(":") ? stageName.split(':') :stageName)
savestageName = stageName.toString()
stageName = stageName.split(':')[0]
logs.infoMessage("${stageName}")

                // we need a milestone step so that all jobs entering this point are tracked and can be aborted if next job has reached next milestone

                //  milestone mileStone 
                //   milestone()

                if (stageName.matches("CHNG")) {

                    prevTag = savestageName.split(':')[1]
// stageName = savestageName.split(':')[0].trim()
stage("$stageName")

            {
                // prevTag = git.getPrevTag(serviceName)

//                    println("!!!! Tag on production - $prevTag")
                    timeout(time: timeValue, unit: "$unit")
                            {

                                try {
                                    def userInput = input(id: 'userInput', message: "Ok to create CHNG?", parameters: [

                                            choice(
                                                    name: 'Change',
                                                    choices: ['CREATE', 'Enter CHNG#'].join('\n'),
                                                    description: 'Choose'
                                            )])
//                                              println("1 ##### $userInput ####")
                                    saveInput = userInput
                                    if (!saveInput.contains("CREATE") && !saveInput.contains("ABORT")) {

//                                        autoCancelled = true
                                        error('Aborting creation of NEW CHANGE RECORD.')
//                                        userInput = input(
//                                                id: 'userInput', message: "Enter the CHNG created as part of previous build/if you have manually create it already", parameters: [
//                                                [$class: 'TextParameterDefinition', description: 'Change Ticket#', name: 'CHNG']
//                                        ])
////                                        return userInput
                                    }

                                    rollback = input(
                                            id: 'rollback', message: "Enter below details for CR Creation", parameters: [
                                            [$class: 'TextParameterDefinition', defaultValue: "Rollback to previous deployed tag - \n ${prevTag}", description: 'Rollback Steps', name: 'rollback']])

                                    changeType = input(
                                            id: 'changeType', message: "Enter below details for CR Creation", parameters: [

                                            choice(
                                                    name: 'ChangeType',
                                                    choices: ['Standard', 'Emergency', 'Normal'].join('\n'),
                                                    description: 'Choose Change Type'
                                            )])

                                    impact = input(
                                            id: 'impact', message: "Enter below details for CR Creation", parameters: [
                                            choice(

                                                    name: 'Impact',
                                                    choices: ['Extensive / Widespread', 'Significant / Large', 'Moderate / Limited', 'Minor / Localized'].join('\n'),
                                                    description: 'Choose Impact Type'
                                            )])

//                                    println " 11111 Impact - $impact \n Rollback - $rollback \n ChangeType = $changeType "

//else
//{
                                    env.impact = impact
                                    env.changeType = changeType
                                    env.rollback = rollback

//}


                                    println " Impact - $impact \n Rollback - $rollback \n ChangeType = $changeType "

                                    return saveInput

                                }
                                catch (e) {
                                    println "\n\n !!! $e !!!\n\n"
                                    // e=e.toString()
                                    // if(! e.contains("FlowInterruptedException")){
                                         userInput = input(
                                            id: 'userInput', message: "Enter the CHNG created as part of previous build/if you have manually create it already", parameters: [
                                            [$class: 'TextParameterDefinition', description: 'Change Ticket#', name: 'CHNG']
                                    ])
                                    return userInput
                                    // }
                                    // else{
                                    //     error("$e")
                                    // }
                                   
                                }


                            }
            }
                    
                } 
                else if((serviceName.contains("-job") || serviceName.contains("ingestion"))  && (message.contains("SwitchTraffic"))) {
                                    input(message: "Do you want to continue?", ok: 'Approve', submitter: approverList, submitterParameter: 'approver')
                    logs.infoMessage "Jobs no need no traffic switch activity!!!"
                }
                
                else if (message.contains("Merge")){ 

                    input(message: "$message", ok: 'Proceed')
                }

                else if (!serviceName.contains("-job") && !serviceName.contains("ingestion") && !message.contains("Merge")){ 
                    //|| ((serviceName.contains("-job")  || serviceName.contains("ingestion"))  && (!message.contains("SwitchTraffic"))) ) //&& (message.contains("approve")) && (message.contains("apprSwitchTrafficove"))){

stage("$stageName"){

     timeout(time: timeValue, unit: "$unit")
                            {
                                def userApproving



                                try {



                                    // approverList = jiraAction.usersInGroup("jenkins-prod-approvers")
                                    // logs.infoMessage("Approver List - ${approverList}")
                                    // jiraApproverList = jiraAction.usersInGroup("CHNG Approvers")
                                    // logs.infoMessage("jiraApproverList - ${jiraApproverList}")
                                    // adminApprover = jiraAction.usersInGroup("devops-admins")   
                                    // logs.infoMessage("adminApprover - ${adminApprover}")
                                    approverList = jiraAction.usersInGroup("jenkins-prod-approvers")
				    echo "${approverList}--first"
                                    userApproving = input(message: "$message", ok: 'Approve', submitter: approverList, submitterParameter: 'approver')
                                    // userApproving = userApproving.toString().replaceAll("@ftdi.com","")
				    echo "${userApproving}--first"

                                    logs.infoMessage("userApproving - ${userApproving} || reporter - ${reporter}")
                                    // (approverList.contains("${userApproving}") ? "Good to proceed " : input(message: "Do you want to retry?", ok: 'Retry')
                                //    (approverList.contains("${userApproving}") && (!userApproving.contains("${reporter}"))) ?  "Good to proceed !!!" : (approverList.contains("${userApproving}") && userApproving.contains("${reporter}") && adminApprover.contains("${reporter}")) ? "Good to proceed !!!" : input(message: "Do you want to retry?", ok: 'Retry')

                                        // () ?  logs.infoMessage("Proceeding with deployment!!!") : logs.errorMessage("User approving is not part of jenkins-prod-approvers group")
                                        // () ? (jiraAction.usersInGroup("devops-admins").contains("${reporter}")) ? logs.infoMessage "Proceeding with deployment!!!" : exitWithMessage(" User approving is not authorized ..please reach out to Devops team for access!! ")
                                if((jiraAction.usersInGroup("jenkins-prod-approvers").contains("${userApproving}") && (!userApproving.contains("${reporter}"))) || jiraAction.usersInGroup("devops-admins").contains("${userApproving}"))
                                {
 logs.infoMessage(" ${userApproving} has permissions to deploy..proceeding with dpeloyment")                                }

                                else{
                                    
exitWithMessage(" ${userApproving}  is not authorized ..please reach out to Devops team for access !! ")

                                }

                                    }
                                catch (e) {

                                    def subject = "Job '${env.JOB_NAME} [${env.BUILD_NUMBER}]' triggered by ${reporter}"
                                    def details = """ ${reporter} is trying to push to production -  '${
                                        env.JOB_NAME
                                    } [${env.BUILD_NUMBER}]':
                                                     Admins cannot push their code to production ${env.BUILD_URL} """
                                    emailext(
                                            subject: subject,
                                            body: details,
                                            to: "rkande@ftdi.com"
                                    )
                                                                        approverList = jiraAction.usersInGroup("jenkins-prod-approvers")
					echo "${approverList}--second"
                                    userApproving = input(message: "$message", ok: 'Approve', submitter: approverList, submitterParameter: 'approver')
                                    // userApproving = userApproving.toString().replaceAll("@ftdi.com","")
                                    userApproving = userApproving.toLowerCase()
				    echo "${userApproving}--second"	
//                                    (adminApprover.contains("${reporter}") && approverList.contains("${reporter}")) ? "Good to proceed " : error("NOT AUTHORISED TO APPROVE YOUR OWN BUILDS")

//                                     while (jiraAction.usersInGroup("devops-admins").contains("${reporter}") || (userApproving != "$reporter")) {
//                                         logs.infoMessage("NOT AUTHORISED TO APPROVE YOUR OWN BUILDS")
// //                                       input(message: "NOT AUTHORISED TO APPROVE YOUR OWN BUILDS", ok: 'ok')
//                                         sleep(10)
//                                     }

while(true) {
approverList = jiraAction.usersInGroup("jenkins-prod-approvers")

//  userApproving = userApproving.toString().replaceAll("@ftdi.com","")
 userApproving = userApproving.toLowerCase()
echo "${approverList}--third"
echo "${userApproving}--third"

if(jiraAction.usersInGroup("jenkins-prod-approvers").contains("${userApproving}") && (!userApproving.contains("${reporter}"))  || jiraAction.usersInGroup("devops-admins").contains("${userApproving}"))
{
   logs.infoMessage(" $userApproving has permissions to deploy..proceeding with dpeloyment")

    break;
}
else{

userApproving = input(message: "Do you want to continue?", ok: 'Continue', submitter: approverList, submitterParameter: 'approver')
userApproving = userApproving.toLowerCase()

sleep(10)

}                                 

                                   } 
                                   
                                   



// ? "Good to proceed " : input(message: "NOT AUTHORISED TO APPROVE YOUR OWN BUILDS", ok: 'ok')
                                }

                                


                            }
                }
}

                   
            
}

def retrier(int retries, Closure body) {
    for(int i=0; i<retries; i++) {
        try {
            body.call()
            break
        } catch (org.jenkinsci.plugins.workflow.steps.FlowInterruptedException fie) {
            throw fie
        } catch (Exception e) {
            echo "${e}"
            continue
        }
    }
}


def exitWithMessage(def message)
{
def logs=new logs()
logs.errorMessage("${message}")
exit

}
