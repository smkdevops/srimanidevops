/*
 * This files will run integration Tests for respective services
 */


def call(script)
{
	// create Job Manager object and fetch pipeline jobs details to be used in conditions
	def jobObj = new com.ftd.workflow.JobManager(script)

	def pipeline = jobObj.getPipelineName()
	def serviceName = jobObj.getServiceName()
	def branchName = jobObj.getBranchName()
	def cmd

	def props = readProperties file: "stage-config.properties"

	def skipIntegrationTests = props['skipIntegrationTests']
	def runIntegrationTests = props['runIntegrationTests']
	def serviceList = props['serviceList']

	def serviceSubstr = serviceName[0..serviceName.lastIndexOf('-') - 1]
	def imageTag = "${branchName}-${BUILD_NUMBER}.${env.TIMESTAMP}"





	try
	{


                //Skipping the integration tests stage for deploy only jobs
                if(( ! pipeline.contains("deploy")))
                {


			if(( ! serviceName.contains("-job")) || ( runIntegrationTests.contains("${serviceName}")))
			{
				if( ! skipIntegrationTests.contains("${serviceName}") && ! pipeline.contains("hotfix") )
				{
					wrap([$class: 'AnsiColorBuildWrapper']) {
	                	                println "\u001B[32m[INFO] Integration Tests Stage."
						stage('Integration Tests')
						{
							withMaven(maven:'default') {
								env.PATH = "/opt/google-cloud-sdk/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/usr/local/nodejs/bin:/usr/local/nodejs/bin"
								def count=0
								sh("mvn test-compile failsafe:integration-test -DENV=$branchName")
//								println("Waiting for deployment to complete .. $imageTag  - $kubTag ")
//								printf "["
//								println("Waiting for deployment to complete ..")
							
							/*	while(true)
								{

									cmd = "kubectl get pods --selector=app=${serviceSubstr} -n ${branchName}  -o json | jq -r '.items[].status.containerStatuses[] | { \"image\": .image}' | grep ${serviceName} | cut -d':' -f3 | sed 's/\"//' | sort -u | wc -l"
									count = sh(returnStdout: true, script: cmd)
									count = count.replaceAll("[\n\r]", "").toInteger()
									cmd = "kubectl get pods --selector=app=${serviceSubstr} -n ${branchName}  -o json | jq -r '.items[].status.containerStatuses[] | { \"image\": .image}' | grep ${serviceName} | cut -d':' -f3 | sed 's/\"//' | sort -u "
									kubTag = sh(returnStdout: true, script: cmd)
									kubTag = kubTag.replaceAll("[\n\r]", "")


									if(count == 1 && kubTag.contains(imageTag) ) { break} else
									{
										printf(".")
										sleep 15


									}							} */
                             //   deploymentStatus(serviceSubstr,branchName,serviceName,imageTag)

//								if(deploymentStatus(serviceSubstr,branchName,serviceName,imageTag,10) == 1)
//								{
//									println "Running Integration test on new Image : $imageTag"
//									println("mvn test-compile failsafe:integration-test -DENV=$branchName")
//								sh("mvn test-compile failsafe:integration-test -DENV=$branchName")
//								}

//								printf "] "

							}
						}
					}
					this.copyArtifacts(serviceName)
				}
				else
				{
					wrap([$class: 'AnsiColorBuildWrapper']) {
                                		println "\u001B[32m[INFO] Integration Tests Stage. Not yet implemented"
					}
				}
			}
		}
		currentBuild.result = "SUCCESS"
	}
        catch (err) {
                wrap([$class: 'AnsiColorBuildWrapper']) {
                        println "\u001B[31mERROR]: caused by error at Integration Tests Stage"
			this.copyArtifacts(serviceName)	
                        currentBuild.result = "FAILED"
                        EmailNotifications(this)
                        throw err
                }
	}
}

def copyArtifacts(def serviceName)
{
        //copy build artifcts that are generated for mvn builds
	def buildObj = new com.ftd.workflow.BuildHandlers(serviceName)
        def buildCommand = buildObj.getBuildArgs()
        def buildTool = buildCommand[0..buildCommand.indexOf('|') - 1]
        buildTool = buildTool.trim()

	if( buildTool == "mvn")
	{
        	stage('Archive Artifacts')
        	{
                	archive '**/target/*.jar, **/target/*.war/, **/target/surefire-reports/*.xml, **/target/checkstyle*.xml, **/target/cpd*.xml, **/target/pmd*.xml, **/target/*Report*.html'
        	}
	}
}
