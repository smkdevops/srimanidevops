def  bqInsert (def cmd)
{
    def logs= new logs()
    logs.infoMessage(cmd) 
 cmdOutput=sh(returnStdout: true, script: cmd)
 return cmdOutput
}

def bqUpdate (def key,def value,def changeKey)
{
     def logs= new logs()
changeKey="\"${changeKey}\""
value="\"${value}\""
def cmd = "bq query  --nouse_legacy_sql --quiet 'update  `gcp-ftd-prod-devops.ReleaseData.release_info` set "+ key+"="+value+" where changeTicket="+changeKey+"'"
logs.infoMessage(cmd) 

cmdOutput=sh(returnStdout: true, script: cmd)
return cmdOutput

}