import org.jenkinsci.plugins.workflow.multibranch.WorkflowMultiBranchProject

/**
 * Maintains a build history limit across ALL branches in a pipeline, not just per branch.
 *
 * <p>This script could be tweaked to save last successfull, discard artificats, exclude certain
 * branches, include only a certain pipeline, etc. See <a
 * href="https://github.com/jenkinsci/jenkins/blob/master/core/src/main/java/hudson/tasks/LogRotator.java">LogRotator.java</a>
 * for more examples.
 *
 * <p>Usage: Run in the /script console for dry run. If you are happy with the output, uncomment
 * delete() below to take effect.
 */

def NUM_BUILDS_TO_KEEP = 30

Jenkins.instance.getAllItems(WorkflowMultiBranchProject.class).each { workflow ->
    def builds = []

    workflow.items.each { branch ->
        builds += branch.getBuilds()
    }

    builds = builds.sort{it.time}.reverse().subList(Math.min(builds.size(), NUM_BUILDS_TO_KEEP), builds.size())
    if (builds.size() > 0) {
        println "Found $builds.size builds to delete from $workflow.fullName workflow."
    }

    builds.each { build ->
        if (build.isBuilding()) {
            println "Skipping $build because it's building."
        } else if (build.isKeepLog()) {
            println "Skipping $build because it's marked as keep."
        } else {
            println "Deleting build $build"
            // Uncomment below to actually delete!
            // build.delete()
        }
    }
}