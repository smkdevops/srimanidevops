/*
 * This file is used to manage deployments to ay environment
 * It is used to delegate the deployment tasks to further class files based on environments
 */

def call(script)
{
	try
        {
		def jobObj = new com.ftd.workflow.JobManager(script)
		def branchName = jobObj.getBranchName()
		def pipelineName = jobObj.getPipelineName()
		def serviceName = jobObj.getServiceName()
			def imageTag

			if( ! serviceName.equals("common-service"))
		{

			if(branchName.matches("dev3-web-api-gateway"))
			{
				imageTag = "dev3-${BUILD_NUMBER}.${env.TIMESTAMP}"
			}
			else{
				imageTag = "${branchName}-${BUILD_NUMBER}.${env.TIMESTAMP}"
			}


			def jobConfiguration = libraryResource 'com/ftd/workflow/job-configuration.properties'
			writeFile file: 'job-configuration.properties', text: jobConfiguration

			def props = readProperties file: "job-configuration.properties"
			def k8sGitUrl = props['k8sGitUrl']
			def k8sGitBranch = props['k8sGitBranch']
			def zone = props['zone']
			def targetDir = "temp"

			def deployProject = props['deployProject']
			def cluster = props['cluster']

			// temporary config changes to deploy in parallel to new QA/dev project
			//def zoneNewQA = props['zoneNewQA']
			//def deployProjectNewQA = props['deployProjectNewQA']
			//def clusterNewQA = props['clusterNewQA']


			if( pipelineName.contains("prod-deploy") || pipelineName.contains("uk-deploy")  )
			{
				 k8sGitBranch = props['k8sGitProd']
				checkout([$class: 'GitSCM', branches: [[name: k8sGitBranch]], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: targetDir],[$class: 'CheckoutOption', timeout: 30], [$class: 'CloneOption', depth: 0, honorRefspec: true, noTags: true, reference: '', shallow: true, timeout: 30]], submoduleCfg: [], userRemoteConfigs: [[ url: k8sGitUrl ]]])
				ProductionLine(this)
			}
			else if( pipelineName.contains("manual-deploy"))
			{
				 k8sGitBranch = props['k8sGitProd']
				checkout([$class: 'GitSCM', branches: [[name: k8sGitBranch]], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: targetDir],[$class: 'CheckoutOption', timeout: 30], [$class: 'CloneOption', depth: 0, honorRefspec: true, noTags: true, reference: '', shallow: true, timeout: 30]], submoduleCfg: [], userRemoteConfigs: [[ url: k8sGitUrl ]]])
				ReleaseDeployment(this)
			}
			/*
			else if( pipelineName.contains("production"))
			{

				 k8sGitBranch = props['k8sGitProd']
				checkout([$class: 'GitSCM', branches: [[name: k8sGitBranch]], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: targetDir],[$class: 'CheckoutOption', timeout: 30], [$class: 'CloneOption', depth: 0, honorRefspec: true, noTags: true, reference: '', shallow: true, timeout: 30]], submoduleCfg: [], userRemoteConfigs: [[ url: k8sGitUrl ]]])
				ProductionLine(this)
			}
			*/
			else if(branchName.matches("dev1|dev2|dev3|qa1|qa2|qa3||dev3-alt"))
			{



				checkout([$class: 'GitSCM', branches: [[name: k8sGitBranch]], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: targetDir],[$class: 'CheckoutOption', timeout: 30], [$class: 'CloneOption', depth: 0, honorRefspec: true, noTags: true, reference: '', shallow: true, timeout: 30]], submoduleCfg: [], userRemoteConfigs: [[ url: k8sGitUrl ]]])
				DeploymentHandler(serviceName, cluster, zone, deployProject, branchName, imageTag, k8sGitBranch, targetDir)

				if(serviceName.contains("fol-admin-service"))
				{
					serviceName = "fol-site-service"
					stage(" Waiting 2min for  fol-admin to get ready ") {
						sh("sleep 120")
					}

						DeploymentHandler(serviceName, cluster, zone, deployProject, branchName, imageTag, k8sGitBranch, targetDir)

				}

				// Temp change to deploy to new QA cluster in parallel with old one

				//k8sGitBranch = props['k8sGitProd']
				//checkout([$class: 'GitSCM', branches: [[name: k8sGitBranch]], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: targetDir],[$class: 'CheckoutOption', timeout: 30], [$class: 'CloneOption', depth: 0, honorRefspec: true, noTags: true, reference: '', shallow: true, timeout: 30]], submoduleCfg: [], userRemoteConfigs: [[ url: k8sGitUrl ]]])
				//DeploymentHandler(serviceName, clusterNewQA, zoneNewQA, deployProjectNewQA, branchName, imageTag, k8sGitBranch, targetDir)
			}
			else if(branchName.toLowerCase().contains("hotfix"))
			{
 println "\u001B[31m[INFO]: No Deployment for hotfix branches..."

				/*k8sGitBranch = props['k8sGitProd']
	                        checkout([$class: 'GitSCM', branches: [[name: k8sGitBranch]], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: targetDir],[$class: 'CheckoutOption', timeout: 30], [$class: 'CloneOption', depth: 0, honorRefspec: true, noTags: true, reference: '', shallow: true, timeout: 30]], submoduleCfg: [], userRemoteConfigs: [[ url: k8sGitUrl ]]])
				zone = props['hotfixZone']
				deployProject = props['hotfixDeployProject']
				cluster = props['hotfixCluster']
				nameSpace = props['hotfixNameSpace']
				imageTag = "hotfix-${BUILD_NUMBER}.${env.TIMESTAMP}"
				DeploymentHandler(serviceName, cluster, zone, deployProject, nameSpace, imageTag, k8sGitBranch, targetDir)

				if(serviceName.contains("fol-admin-service"))
				{
					serviceName = "fol-site-service"
					stage(" Waiting 2min for  fol-admin to get ready ") {
						sh("sleep 120")
					}

					DeploymentHandler(serviceName, cluster, zone, deployProject, nameSpace, imageTag, k8sGitBranch, targetDir)

				} */
			}



			else
			{
				currentBuild.result = "FAILED"
				error("Environment Doesnt match")
			}
			currentBuild.result = "SUCCESS"
		}
	}
	catch (err) {
                wrap([$class: 'AnsiColorBuildWrapper']) {
                        println "\u001B[31m[ERROR]: Caused by error at Deployment Stage"
                        currentBuild.result = "FAILED"
			EmailNotifications(this)
                        throw err
                }
        }
}
