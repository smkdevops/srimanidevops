def call(def relTags)
{
	try
        {
                stage('Wait for Input')
                {
                        wrap([$class: 'AnsiColorBuildWrapper']) {
                                println "\u001B[32m[INFO] Please input release tags to deploy"
				
				def tagsList = relTags.split("\\r?\\n")
				def choiceList = []
				def choiceStr = []
				for( def tag : tagsList )
                                {
                                        if( tag.contains(","))
                                        {
                                                tag = tag[tag.indexOf(',') + 1..-1]
		                        }
                                        choiceList.add(tag)
                                }
				def choiceParam = new ChoiceParameterDefinition('version', choiceList as String[], 'Please select docker image tag you want to deploy')
				choiceStr.add(choiceParam)
				return choiceStr
			}
		}
	}
	catch (err) {
                wrap([$class: 'AnsiColorBuildWrapper']) {
                        println "\u001B[31m[ERROR]: Caused by error at input create stage"
                        currentBuild.result = "FAILED"
                        throw err
		}
	}
}
			
