/*
 * Email notifications file
 * Seperate email subjects for dev//qa and uat//prod
 */

def call(script)
{
	wrap([$class: 'AnsiColorBuildWrapper']) {
		println "\u001B[32m[INFO] Sending Email Notifications \u001B[30m \u001B[1m"
		def jobObj = new com.ftd.workflow.JobManager(script)
        	def pipeline = jobObj.getPipelineName()
		def serviceName = jobObj.getServiceName()

		// load email configs from email properties file
		def emailConfig = libraryResource 'com/ftd/workflow/email.properties'
		writeFile file: 'email.properties', text: emailConfig

		def props = readProperties file: "email.properties"
		def recipientList = props["${serviceName}List"]
		if( ! recipientList?.trim())
		{
			recipientList = props["defaultList"]
		}
		def replyToList = props['replyToList']

		def jobName
		def subject



		if( ! pipeline.contains("deploy") && ! serviceName.contains("test") )
	        {
			jobName = jobObj.getFullJobName()
			subject = "$jobName - Pipeline - ${currentBuild.result}"
			emailext body: '${SCRIPT, template="email.template"}', mimeType: 'text/html', replyTo: "$replyToList ", subject: "${subject}", to: recipientList
		}
		else if( pipeline.contains("prod-deploy") && ! serviceName.contains("test"))
		{
			subject = "$serviceName - Deploy - Pipeline - ${currentBuild.result}"
			emailext body: '${SCRIPT, template="deploy.template"}', mimeType: 'text/html', replyTo: "$replyToList ", subject: "${subject}", to: "${recipientList},cc:Operations@ftdi.com,Calyx_QA@ftdi.com"
		}
		else if( pipeline.contains("deploy") && ! serviceName.contains("test"))
		{
			def environmet = "${params.ENVIRONMENT}"
			subject = "$serviceName - $environment Deploy - Pipeline - ${currentBuild.result}"
			emailext body: '${SCRIPT, template="deploy.template"}', mimeType: 'text/html', replyTo: "$replyToList ", subject: "${subject}", to: recipientList
		}

		else
		{

			emailext body: '${SCRIPT, template="deploy.template"}', mimeType: 'text/html', replyTo: "rkande@ftdi.com", subject: "${subject}", to: "rkande@ftdi.com"

		}
	}
}

def call(def serviceName, def mailStep, def subject)
{
	def emailConfig = libraryResource 'com/ftd/workflow/email.properties'
        writeFile file: 'email.properties', text: emailConfig
        def props = readProperties file: "email.properties"
	def recipientList = props["${serviceName}List"]
        if( ! recipientList?.trim())
        {
	        recipientList = props["defaultList"]
	}
        def replyToList = props['replyToList']

	def jobConfiguration = libraryResource 'com/ftd/workflow/job-configuration.properties'
        writeFile file: 'job-configuration.properties', text: jobConfiguration

        def props1 = readProperties file: "job-configuration.properties"
	def approverMailList = props1['approverMailList']

	if(mailStep.equals("deploy") && ! serviceName.contains("test"))
	{
		emailext body: '${SCRIPT, template="deployProd.template"}', mimeType: 'text/html', replyTo: "$replyToList ", subject: "${subject}", to: recipientList
	}
	else if( mailStep.equals("input") && ! serviceName.contains("test"))
	{
		emailext body: '${SCRIPT, template="inputNew.template"}', mimeType: 'text/html', replyTo: "$replyToList ", subject: "${subject}", to: "${approverMailList},cc:Operations@ftdi.com"
	}
	else if( mailStep.equals("sonarFailure") && ! serviceName.contains("test"))
	{
		emailext body: '${SCRIPT, template="sonar.template"}', mimeType: 'text/html', replyTo: "$replyToList ", subject: "${subject}", to: recipientList
	}
	else if( mailStep.equals("codeMerge") && ! serviceName.contains("test"))
	{
		emailext body: '${SCRIPT, template="code-merge.template"}', mimeType: 'text/html', replyTo: "$replyToList ", subject: "${subject}", to: recipientList
	}
	else if( mailStep.equals("pullRequest") && ! serviceName.contains("test"))
	{
		emailext body: '${SCRIPT, template="pull-request.template"}', mimeType: 'text/html', replyTo: "$replyToList ", subject: "${subject}", to: recipientList
	}
	else if( mailStep.equals("input") &&  serviceName.contains("test"))
	{
		emailext body: '${SCRIPT, template="inputNew.template"}', mimeType: 'text/html', replyTo: "rkande@ftdi.com", subject: "${subject}", to: "rkande@ftdi.com"
	}
	else if(mailStep.equals("deploy") &&  serviceName.contains("test"))
	{
		emailext body: '${SCRIPT, template="deployProd.template"}', mimeType: 'text/html', replyTo: "rkande@ftdi.com", subject: "${subject}", to: "rkande@ftdi.com"
	}
	else if( mailStep.equals("vulnReport") &&  ! serviceName.contains("test"))
	{
		emailext body: '${SCRIPT, template="vulnReport.template"}', mimeType: 'text/html', replyTo: "$replyToList ", subject: "${subject}", to: recipientList
	}
	
	else
	{

		emailext body: '${SCRIPT, template="deploy.template"}', mimeType: 'text/html', replyTo: "rkande@ftdi.com", subject: "${subject}", to: "rkande@ftdi.com"

	}
}
