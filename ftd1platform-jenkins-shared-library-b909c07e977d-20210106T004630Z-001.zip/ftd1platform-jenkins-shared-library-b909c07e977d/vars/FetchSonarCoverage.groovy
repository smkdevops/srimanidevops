/*
 * This script will fetch the SonarQube coverage metrics/measurements which can then be sent via email
 */

def call(script)
{
	try
  {
    wrap([$class: 'AnsiColorBuildWrapper']) {
      println "\u001B[32m[INFO] Fetching SonarQube measurments"
		}

		def jobObj = new com.ftd.workflow.JobManager(script)
		def serviceName = jobObj.getServiceName()
		def branchName = jobObj.getBranchName()
		def branch

		if(branchName.toLowerCase().contains("hotfix"))
			branch = "hotfix"
		else
			branch = branchName

		def stageConfig = libraryResource 'com/ftd/workflow/stage-config.properties'
		writeFile file: 'stage-config.properties', text: stageConfig
		stageConfig = readProperties file: "stage-config.properties"
		def serviceList = stageConfig['serviceList']

		def serviceSubstr = serviceName[0..serviceName.lastIndexOf('-') - 1]
		if (serviceList.contains("${serviceSubstr}")) 
		{
			serviceName = serviceSubstr
		}

		def imageTag = "${branch}-${BUILD_NUMBER}.${env.TIMESTAMP}"

		def sonarMap = [:]

	  def sonarLimits = stageConfig['sonarLimits']


		sh "curl  -X GET -u 77052dd6a4877116bc14a7638dd279e738c92b58: 'https://sonar.ftdi.com/api/measures/component?component=${serviceName}:${branchName}&metricKeys=bugs,vulnerabilities,code_smells,coverage,tests,duplicated_lines_density,duplicated_blocks,new_bugs,new_vulnerabilities,new_technical_debt,new_code_smells,new_coverage,new_duplicated_lines_density' > result.json"


		def result = readJSON file:'result.json'

		for (i=0; i < result.component.measures.size(); i++) {
			if (result.component.measures[i].metric.contains("new")) {
				sonarMap.put(result.component.measures[i].metric, result.component.measures[i].periods[0].value)
			}
			else {
				sonarMap.put(result.component.measures[i].metric, result.component.measures[i].value)
			}
		}
		withCredentials([usernamePassword(credentialsId: 'mysql-sonardb', usernameVariable: 'MYSQL_USERNAME', passwordVariable: 'MYSQL_PASSWORD',)]) {
			if (branchName.contains("qa") || branchName.contains("hotfix")) {
				sh "echo check=\$(mysql -ss --host=127.0.0.1 --user=${MYSQL_USERNAME} --password=${MYSQL_PASSWORD} -e 'use sonarcoverage; select * from coverage where imageTag = \"${imageTag}\"' | wc -l) > check.properties"

				def check = readProperties file:'check.properties'

				if (check['check'] == '1') {
					// Deleting existing record to insert updated one
					println "record exists, deleting"
					sh "mysql -ss --host=127.0.0.1 --user=${MYSQL_USERNAME} --password=${MYSQL_PASSWORD} -e 'use sonarcoverage; delete from coverage where imageTag = \"${imageTag}\"'"
				}
				// Inserting new/updated record
				println "inserting new record"
				sh "mysql -ss --host=127.0.0.1 --user=${MYSQL_USERNAME} --password=${MYSQL_PASSWORD} -e 'use sonarcoverage; insert into coverage values(\"${serviceName}\",\"${imageTag}\",${sonarMap.get('bugs')},${sonarMap.get('vulnerabilities')},${sonarMap.get('code_smells')},${sonarMap.get('coverage')},${sonarMap.get('tests')},${sonarMap.get('duplicated_lines_density')},${sonarMap.get('duplicated_blocks')},${sonarMap.get('new_bugs')},${sonarMap.get('new_vulnerabilities')},${sonarMap.get('new_technical_debt')},${sonarMap.get('new_code_smells')},${sonarMap.get('new_coverage')},${sonarMap.get('new_duplicated_lines_density')})'"
			}
		}

		env.SONARBUGS=sonarMap.get('bugs')
		env.SONARVULNERABILITIES = sonarMap.get('vulnerabilities')
		env.SONARCODESMELLS = sonarMap.get('code_smells')
		env.SONARCOVERAGE = sonarMap.get('coverage')
		env.SONARTESTS = sonarMap.get('tests')
		env.SONARDUPLICATEDLINES = sonarMap.get('duplicated_lines_density')
		env.SONARDUPLICATEDBLOCKS = sonarMap.get('duplicated_blocks')

		env.SONARNEWBUGS = sonarMap.get('new_bugs')
		env.SONARNEWVULNERABILITIES = sonarMap.get('new_vulnerabilities')
		env.SONARNEWDEBT = sonarMap.get('new_technical_debt')
		env.SONARNEWCODESMELLS = sonarMap.get('new_code_smells')
		env.SONARNEWCOVERAGE = sonarMap.get('new_coverage')
		env.SONARNEWDUPLICATEDLINES = sonarMap.get('new_duplicated_lines_density')

/*
	   sonar_new_coverage = sh (script: "curl 'https://sonar.ftdi.com/api/measures/component?component=${serviceName}:${branchName}&metricKeys=new_coverage' | jq '.component.measures[0].periods[0].value' |sed 's/\"//g' ",returnStdout: true).trim()
       echo "SONAR NEW COVERAGE ${sonar_new_coverage}"

       overall_coverage = sh (script: "curl 'https://sonar.ftdi.com/api/measures/component?component=${serviceName}:${branchName}&metricKeys=coverage' | jq '.component.measures[0].value' |sed 's/\"//g' ",returnStdout: true).trim()
	  echo "OVERALL SONAR  COVERAGE ${overall_coverage}"




	  if (overall_coverage < "${sonarLimits}") {
		  wrap([$class: 'AnsiColorBuildWrapper']) {
			  currentBuild.result = "FAILED"

			  error("\\u001B[31m[ERROR]: SONAR COVERAGE thresholds : (${sonarLimits}\")  - Overall Coverage for ${serviceName}:${branchName} is ${overall_coverage}")

		  }
	  }*/



	}
	catch (err) {
                wrap([$class: 'AnsiColorBuildWrapper']) {
                        println "\u001B[31m[ERROR]: Caused by error while fetching SonarQube measurements"
                        currentBuild.result = "FAILED"
                        throw err
                }
        }
}

def call(def serviceName, def imageTag) {
	
	def stageConfig = libraryResource 'com/ftd/workflow/stage-config.properties'
        writeFile file: 'stage-config.properties', text: stageConfig
        stageConfig = readProperties file: "stage-config.properties"
        def serviceList = stageConfig['serviceList']
        def serviceSubstr = serviceName[0..serviceName.lastIndexOf('-') - 1]
        if (serviceList.contains("${serviceSubstr}"))
        {
	        serviceName = serviceSubstr
	}
	println "Fetching Sonar coverage data from DB for service: ${serviceName} and tag: ${imageTag}"
	withCredentials([usernamePassword(credentialsId: 'mysql-sonardb', usernameVariable: 'MYSQL_USERNAME', passwordVariable: 'MYSQL_PASSWORD',)]) {
		// Added temporarily for debug purposes
		sh "mysql -ss --host=127.0.0.1 --user=${MYSQL_USERNAME} --password=${MYSQL_PASSWORD} -e 'use sonarcoverage; select * from coverage where imageTag = \"${imageTag}\"'"
		sh "mysql -ss --host=127.0.0.1 --user=${MYSQL_USERNAME} --password=${MYSQL_PASSWORD} -e 'use sonarcoverage; select * from coverage where imageTag = \"${imageTag}\"' > db_output.txt"
	}
	sh '''
		while IFS='' read -r line || [[ -n "$line" ]];
		do
			echo "serviceName=$(echo $line | awk '{print $1}')" >> results.properties
			echo "imageTag=$(echo $line | awk '{print $2}')" >> results.properties
			echo "bugs=$(echo $line | awk '{print $3}')" >> results.properties
			echo "vulnerabilities=$(echo $line | awk '{print $4}')" >> results.properties
			echo "codeSmells=$(echo $line | awk '{print $5}')" >> results.properties
			echo "coverage=$(echo $line | awk '{print $6}')" >> results.properties
			echo "unitTests=$(echo $line | awk '{print $7}')" >> results.properties
			echo "duplicatedLines=$(echo $line | awk '{print $8}')" >> results.properties
			echo "duplicatedBlocks=$(echo $line | awk '{print $9}')" >> results.properties
			echo "newBugs=$(echo $line | awk '{print $10}')" >> results.properties
			echo "newVulnerabilities=$(echo $line | awk '{print $11}')" >> results.properties
			echo "newDebt=$(echo $line | awk '{print $12}')" >> results.properties
			echo "newCodeSmells=$(echo $line | awk '{print $13}')" >> results.properties
			echo "newCoverage=$(echo $line | awk '{print $14}')" >> results.properties
			echo "newDuplicatedLines=$(echo $line | awk '{print $15}')" >> results.properties
		done < "db_output.txt"
	'''

	def props = readProperties  file:'results.properties'

	env.SONARBUGS = props['bugs']
	env.SONARVULNERABILITIES = props['vulnerabilities']
	env.SONARCODESMELLS = props['codeSmells']
	env.SONARCOVERAGE = props['coverage']
	env.SONARTESTS = props['unitTests']
	env.SONARDUPLICATEDLINES = props['duplicatedLines']
	env.SONARDUPLICATEDBLOCKS = props['duplicatedBlocks']

	env.SONARNEWBUGS = props['newBugs']
	env.SONARNEWVULNERABILITIES = props['newVulnerabilities']
	env.SONARNEWDEBT = props['newDebt']
	env.SONARNEWCODESMELLS = props['newCodeSmells']
	env.SONARNEWCOVERAGE = props['newCoverage']
	env.SONARNEWDUPLICATEDLINES = props['newDuplicatedLines']
}
