/*
 * This files will trigger selenium Tests
 */


def call(script) {
    // create Job Manager object and fetch pipeline jobs details to be used in conditions
    def jobObj = new com.ftd.workflow.JobManager(script)

    def pipeline = jobObj.getPipelineName()
    def serviceName = jobObj.getServiceName()
    def branchName = jobObj.getBranchName()
    def cmd

    def jobConfiguration = libraryResource 'com/ftd/workflow/job-configuration.properties'
    writeFile file: 'job-configuration.properties', text: jobConfiguration

    def jobProps = readProperties file: "job-configuration.properties"

    def stageConfig = libraryResource 'com/ftd/workflow/stage-config.properties'
        writeFile file: 'stage-config.properties', text: stageConfig
    def props = readProperties file: "stage-config.properties"

    def OMSTests = props['OMSTests']

    def ftdAurl = jobProps['ftdAurl']
    def Abranch = jobProps['Abranch']
    def proflowersAurl = jobProps['proflowersAurl']
    def ftdtargetDir = "C:\\jenkins-automation\\workspace\\${JOB_BASE_NAME}\\temp\\ftd"
    def proflowerstargetDir = "C:\\jenkins-automation\\workspace\\${JOB_BASE_NAME}\\temp\\proflowers"

stage('Automation'){
                       parallel(
                                "FTD": {
                                        node("jenkins-automation-slave") {
                                 try {
                                        stage('FTD') {
                                            echo "################$ftdAurl  ###############"
                                            withMaven(maven: 'default') {
                                                 dir("$ftdtargetDir\\calyx-automation-ftd\\${AutomationEnv}\\${TagName}") {
                                                    // git branch: "master", url: "$ftdAurl"
						    checkout(scm)
						checkout([$class: 'GitSCM', branches: [[name: Abranch]], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'CheckoutOption', timeout: 30], [$class: 'CloneOption', honorRefspec: true, noTags: true, reference: '', shallow: true, timeout: 30]], submoduleCfg: [], userRemoteConfigs: [[ url: ftdAurl ]]])
                                                    // bat "git pull origin master"
                                                    bat "mvn clean test -DENV=${AutomationEnv} -DTagName=${TagName}"
						    
                                                }
                                        }
                                }
                                                post {
                                                        always {
                                                        dir("$ftdtargetDir\\calyx-automation-ftd\\${AutomationEnv}\\${TagName}\\target") {
                                                        bat "copy surefire-reports\\emailable-report.html emailable-report.html"
                                                        currentBuild.result = "SUCCESS"
							emailext attachmentsPattern: '*.html', body: '${FILE,path="emailable-report.html"}', mimeType: 'text/html', replyTo: 'jenkins-notifications-daemon@ftdi.com', subject: "Automation test cases are success for FTD ${AutomationEnv} Env of tag ${TagName}", to: "Calyx_QA@ftdi.com,cc:ftddevops@ftdi.com"
                                                        // emailext attachmentsPattern: '*.html', body: 'Please check the attached report for automation test cases', mimeType: 'text/html', replyTo: 'ftddevops@ftdi.com', subject: "Automation test cases are Success for FTD ${AutomationEnv} Env", to: "kmohamme@ftdi.com,nanil@ftdi.com,ashaik@ftdi.com,singha@ftdi.com,rkande@ftdi.com,cc:ftddevops@ftdi.com"
        }
}
    }
                                   }catch (err) {
                                        wrap([$class: 'AnsiColorBuildWrapper']) {
                                        dir("$ftdtargetDir\\calyx-automation-ftd\\${AutomationEnv}\\${TagName}\\target") {
                                        bat "copy surefire-reports\\emailable-report.html emailable-report.html"
                                        currentBuild.result = "FAILED"
					emailext attachmentsPattern: '*.html', body: '${FILE,path="emailable-report.html"}', mimeType: 'text/html', replyTo: 'jenkins-notifications-daemon@ftdi.com', subject: "Automation test cases are Failed for FTD ${AutomationEnv} Env of tag ${TagName}", to: "Calyx_QA@ftdi.com,cc:ftddevops@ftdi.com"
                                        // emailext attachmentsPattern: '*.html', body: 'Please check the attached report for automation test cases', mimeType: 'text/html', replyTo: 'ftddevops@ftdi.com', subject: "Automation test cases are Failed for FTD ${AutomationEnv} Env", to: "kmohamme@ftdi.com,nanil@ftdi.com,ashaik@ftdi.com,singha@ftdi.com,rkande@ftdi.com,cc:ftddevops@ftdi.com"
                        throw err
                }
}
                                }
                        }
                },

                                "PROFLOWERS": {
                                        node("jenkins-automation-slave") {
                                 try {
                                        stage('PROFLOWERS') {
                                            echo "################$proflowersAurl###############"
                                            withMaven(maven: 'default') {
                                                dir("$proflowerstargetDir\\calyx-automation-pro\\${AutomationEnv}\\${TagName}") {
                                                   // git branch: "master", url: "$proflowersAurl"
						    checkout(scm)
                                                checkout([$class: 'GitSCM', branches: [[name: Abranch]], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'CheckoutOption', timeout: 30], [$class: 'CloneOption', honorRefspec: true, noTags: true, reference: '', shallow: true, timeout: 30]], submoduleCfg: [], userRemoteConfigs: [[ url: proflowersAurl ]]])
                                                    // bat "git pull origin master"
                                                    bat "mvn clean test -DENV=${AutomationEnv} -DTagName=${TagName}"
                                                }
                                        }
                                }
                                                post {
                                                        always {
                                                        dir("$proflowerstargetDir\\calyx-automation-pro\\${AutomationEnv}\\${TagName}\\target") {
                                                        bat "copy surefire-reports\\emailable-report.html emailable-report.html"
                                                        currentBuild.result = "SUCCESS"
                                                        emailext attachmentsPattern: '*.html', body: '${FILE,path="emailable-report.html"}', mimeType: 'text/html', replyTo: 'jenkins-notifications-daemon@ftdi.com', subject: "Automation test cases are success for Proflowers ${AutomationEnv} Env of tag ${TagName}", to: "Calyx_QA@ftdi.com,cc:ftddevops@ftdi.com"
                                                        // emailext attachmentsPattern: '*.html', body: 'Please check the attached report for automation test cases', mimeType: 'text/html', replyTo: 'ftddevops@ftdi.com', subject: "Automation test cases are success for Proflowers ${AutomationEnv} Env", to: "kmohamme@ftdi.com,nanil@ftdi.com,ashaik@ftdi.com,singha@ftdi.com,rkande@ftdi.com,cc:ftddevops@ftdi.com"
        }
}
    }
                                   }catch (err) {
                                        wrap([$class: 'AnsiColorBuildWrapper']) {
                                        dir("$proflowerstargetDir\\calyx-automation-pro\\${AutomationEnv}\\${TagName}\\target") {
                                        bat "copy surefire-reports\\emailable-report.html emailable-report.html"
                                        currentBuild.result = "FAILED"
					emailext attachmentsPattern: '*.html', body: '${FILE,path="emailable-report.html"}', mimeType: 'text/html', replyTo: 'jenkins-notifications-daemon@ftdi.com', subject: "Automation test cases are failed for Proflowers ${AutomationEnv} Env of tag ${TagName}", to: "Calyx_QA@ftdi.com,cc:ftddevops@ftdi.com"
                                        // emailext attachmentsPattern: '*.html', body: 'Please check the attached report for automation test cases', mimeType: 'text/html', replyTo: 'ftddevops@ftdi.com', subject: "Automation test cases are Failed for ProFlowers ${AutomationEnv} Env", to: "kmohamme@ftdi.com,nanil@ftdi.com,ashaik@ftdi.com,singha@ftdi.com,rkande@ftdi.com,cc:ftddevops@ftdi.com"
                        throw err
                }
}
                                }
                        }
                }				
				
				)
}
}
