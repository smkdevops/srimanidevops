def  call (def destBranch, def repo){

    println " Creating PR - ${repo} :  Master --> ${destBranch} \n"

    // sh("curl -S -X POST  -H 'cache-control: no-cache' -H 'content-type: application/json' -d '{\"destination\": {\"branch\": {\"name\": \"'${destBranch}'\"}},\"source\": {\"branch\": {\"name\": \"master\"}},\"title\":\"Pulling changes from master to dev1/2/3 to get latest production  changes into downstream\"}' --user  $BITBUCKET_API_USER:$BITBUCKET_API_TOKEN  https://bitbucket.org/api/2.0/repositories/ftd1platform/${repo}/pullrequests")
    sh("curl -S -X POST  -H 'cache-control: no-cache' -H 'content-type: application/json' -d '{\"destination\": {\"branch\": {\"name\": \"'${destBranch}'\"}},\"source\": {\"branch\": {\"name\": \"master\"}},\"title\":\"Pulling changes from master to ${destBranch} to get latest production  changes into downstream\"}' --user  $BITBUCKET_API_USER:$BITBUCKET_API_TOKEN  https://bitbucket.org/api/2.0/repositories/ftd1platform/${repo}/pullrequests")

}
