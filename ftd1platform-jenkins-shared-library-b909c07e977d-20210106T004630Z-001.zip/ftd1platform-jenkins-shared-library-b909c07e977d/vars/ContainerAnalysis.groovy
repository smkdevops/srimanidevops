/*
* Checks the status of the Vulnerability Scan of the image built
*/
def call(def imageUrl, def serviceName, def pipeline, def branchName)
{
        try
        {
                if( ! pipeline.contains("deploy"))
                {
                        wrap([$class: 'AnsiColorBuildWrapper']) {
                                println "\u001B[32m[INFO] Checking the status of vulnerability scan for the current image"
                                stage('Docker Image Scan for vulnerabilities')
                                {
                                        sh("sleep 120")
                                        def analysisStatus = ["SCANNING"]
                                        def urlSplit = imageUrl.split(':')
                                        def repoName = urlSplit[0]
                                        def dockerTag = urlSplit[1]
                                        env.dTag = dockerTag
                                        def gcComnd = "gcloud beta container images list-tags --show-occurrences --filter=${dockerTag} --format=json ${repoName}"
                                        while(analysisStatus[-1] == "SCANNING")
                                        {
                                                sh("sleep 30")
                                                def tempVar = sh(script: "${gcComnd}|jq -r '.[]|.DISCOVERY[].discovered.analysisStatus'", returnStdout: true).trim()
                                                analysisStatus << ("${tempVar}")
                                        }
                                        if(analysisStatus[-1] == "FINISHED_SUCCESS")
                                        {
                                                println "\u001B[32m[INFO] Docker Image Scan Process Succeeded"
                                                def countVuln = sh(script: "${gcComnd} | jq -c '.[]|.vuln_counts|length'", returnStdout: true).toInteger()
                                                def vulnRep = sh(script: "${gcComnd} | jq -c '.[]|.vuln_counts'", returnStdout: true)
                                                env.CRITICAL = sh(script: "echo '${vulnRep}' |jq '.CRITICAL'", returnStdout: true)
                                                env.HIGH = sh(script: "echo '${vulnRep}' |jq '.HIGH'", returnStdout: true)
                                                env.MEDIUM = sh(script: "echo '${vulnRep}' |jq '.MEDIUM'", returnStdout: true)
                                                env.LOW = sh(script: "echo '${vulnRep}' |jq '.LOW'", returnStdout: true)
                                                env.DIGEST = sh(script: "${gcComnd}|jq -r '.[]|.digest'", returnStdout: true)
                                                if( countVuln != 0)
                                                {
                                                        println "\u001B[31m[ERROR] Vulnerabilities are found in the current image. Below are the severity and number of vulnerabilities"
                                                        println "${vulnRep}"
                                                        def mailStep = "vulnReport"
                                                        def subject = "${serviceName} - ${branchName} Vulnerability Scan for Docker Image - FAILURE"
                                                        EmailNotifications(serviceName, mailStep, subject)
                                                }
                                                else
                                                {
                                                        println "\u001B[32m[INFO] No Vulnerabilities found in the current image"
                                                }
                                        }
                                        else
                                        {
                                                println "\u001B[32m[INFO] Docker Image Scan Process Failed."
                                        }
                                }
                        }
                }
                currentBuild.result = "SUCCESS"
        }
        catch (err) {
                wrap([$class: 'AnsiColorBuildWrapper']) {
                        println "\u001B[31m[ERROR]: Caused by error at Vulnerability Scan Analysis of the current image stage"
                        currentBuild.result = "FAILED"
                        EmailNotifications(this)
                        throw err
                }
        }
}