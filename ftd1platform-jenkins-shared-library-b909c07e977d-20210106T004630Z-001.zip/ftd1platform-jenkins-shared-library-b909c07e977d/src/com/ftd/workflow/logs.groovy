package com.ftd.workflow
String boldGreenMessage(final String message) { return "\033[1;32m${message}\033[0m" }
String boldBlueMessage(final String message) { return "\033[1;34m${message}\033[0m" }
String boldRedMessage(final String message) { return "\033[1;31m${message}\033[0m" }
String boldYellowMessage(final String message) { return "\033[1;33m${message}\033[0m" }
String triplePrefixMessage(final Closure<String> colour, final String prefix, final String message) {
    def colouredPrefix = "${colour("${prefix}")}"
    return "${colouredPrefix}\n${colouredPrefix} ${message}\n${colouredPrefix}"
}
public void successMessage(final String message) { ansiColor('xterm') { echo triplePrefixMessage(this.&boldGreenMessage, '[SUCCESS]', message) } }
public void infoMessage(final String message) { ansiColor('xterm') { echo triplePrefixMessage(this.&boldBlueMessage, '[INFO]', message) } }
public void warningMessage(final String message) { ansiColor('xterm') { echo triplePrefixMessage(this.&boldYellowMessage, '[WARNING]', message) } }
public void errorMessage(final String message) { ansiColor('xterm') { echo triplePrefixMessage(this.&boldRedMessage, '[ERROR]', message) } }
