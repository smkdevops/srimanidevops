package com.ftd.workflow

import jenkins.model.Jenkins

class BuildHandlers implements Serializable
{
	def buildCommand
	def serviceName

//	BuildHandlers(def script)
//	{
//		this.script = script
//	}
	
	BuildHandlers(def serviceName) 
	{
		this.serviceName = serviceName
	}
	

	public def getBuildArgs()
	{
		def buildCommand = setBuildArgs()
		return buildCommand
	}

	private def setBuildArgs()
	{
		if( serviceName.matches("front-end-service|backoffice-front-end-service|front-end-alt-service|conductor-front-end-oms-service|canvasreactpoc-service|microui-service"))
		{
			buildCommand = "npm install"
			return "npm |" + buildCommand
		} else if (serviceName.matches("conductor-oms-service"))
		{
		   buildCommand = "gradle build -x test --refresh-dependencies"
			return "gradle |" + buildCommand
		}
		else
		{
			buildCommand = "mvn clean install -U -Dspotless.check.skip=true"
			return "mvn |" + buildCommand
		}
		
	}	
}
