package com.ftd.workflow

import jenkins.model.Jenkins

class FetchAppDetails implements Serializable
{
	def workspace
	def script
	def appName
	def version

	FetchAppDetails(def script)
	{
		this.script = script
		this.workspace = "${script.WORKSPACE}"
	}
	
	public def getVersion(def serviceName)
	{
		return this.findVersion(serviceName)

	}

	private def findVersion(def serviceName)
	{
		if(serviceName == "front-end-service")
		{
			def lines = script.readFile("${workspace}/package.json").split("\\r?\\n")
	                for ( def line : lines )
	                {
	                        if(line.contains("version>"))
	                        {
	                                version = line[line.indexOf(':') + 3..-3]
		                        break
		                }
		        }
		}
		else if( serviceName == "wiremock-service")
		{	
			version = "1.0.0"
		}
		else
		{
			def lines = script.readFile("${workspace}/pom.xml").split("\\r?\\n")
	                for ( def line : lines )
        	        {
                	        if(line.contains("<version>"))
                        	{
                                	version = line[line.indexOf('>') + 1..line.indexOf('/') - 2]
	                                break
        	                }
               		}
		}
		return version
	}
}
