package com.ftd.workflow

import jenkins.model.Jenkins

class JobManager implements Serializable
{
	def jobName
	def script

	JobManager(def script)
	{
		this.script = script
		this.jobName = "$script.env.JOB_NAME"
	}
	
	public def getFullJobName()
	{
		def serviceName = getServiceName()
		def branchName = getBranchName()
		return serviceName + " " + branchName
	}	

	public def getServiceName()
	{
		return this.findServiceName()
		
	}

	public def getPipelineName()
	{
		return this.findPipelineName()

	}


	public def getBranchName()
	{
		return this.findBranchName()

	}

	private def findServiceName()
	{
		def serviceName = jobName[0..jobName.indexOf('/') - 1]
		return serviceName
	}

	private def findBranchName()
	{
		def branchName = jobName[jobName.lastIndexOf('/') + 1..-1]
		if(branchName.contains("%2"))
		{
			branchName = branchName.replaceAll("%2","/")
		}
		return branchName
	}

	private def findPipelineName()
	{
		def pipelineName
		def subStr = jobName[jobName.indexOf('/') + 1..-1]
		if( subStr.contains("/"))
			pipelineName = jobName[jobName.indexOf('/') + 1..jobName.lastIndexOf('/') -1]
		else
			pipelineName = subStr

		return pipelineName
	}


	public def getpciList()

	 {
		  def stageConfig = libraryResource 'com/ftd/workflow/stage-config.properties'
        writeFile file: 'stage-config.properties', text: stageConfig 
		  stageConfig = readProperties file: "stage-config.properties"
		  return stageConfig['pciList']


	 }

	 public def serviceiList()

	 {
		 def stageConfig = libraryResource 'com/ftd/workflow/stage-config.properties'
        writeFile file: 'stage-config.properties', text: stageConfig
		  stageConfig = readProperties file: "stage-config.properties"
		  return stageConfig['serviceList']


	 }

	 public def skipStag()
	 {
def stageConfig = libraryResource 'com/ftd/workflow/stage-config.properties'
        writeFile file: 'stage-config.properties', text: stageConfig
		  stageConfig = readProperties file: "stage-config.properties"
		  return stageConfig["skipStag"]
		       
	 }






}
