package com.ftd.seed

import com.cloudbees.hudson.plugins.folder.Folder
import jenkins.model.Jenkins

class folderUtils implements Serializable
{
	String folderPath
 println "\u001B[32m[INFO]  $folderPath"
	public def setFolderPath(String folderPath) 
	{
		println "\u001B[32m[INFO]  SET $folderPath"
		this.folderPath = folderPath
		print this.folderPath
	}
	
	private authorize(){

		Jenkins.getInstance().checkPermission(Jenkins.RUN_SCRIPTS)
		}

	

	Folder create() {
		this.authorize()
		def  folder = Jenkins.instance.getItemByFullName(folderPath);
		folder = folder?: Jenkins.instance.createProject(Folder.class, folderPath);
		return folder

		}

	public def createStructure()
	{
		//try
		//{
		//	wrap([$class: 'AnsiColorBuildWrapper']) 
		//	{
				println "\u001B[32m[INFO] creating jenkins folder at $folderPath"
				def tokens = folderPath.tokenize("/")
				def folders
				def startIndex = 0
				for(String token : tokens)
				{
					def slashIndex = folderPath.indexOf('/',startIndex)

					if( slashIndex == -1 ) 
					{
						folders = folderPath 
						println "\u001B[32m[INFO] creating jenkins folder at $slashIndex"
					}
					else 
					{
						folders = folderPath[0..slashIndex - 1]
						startIndex = slashIndex + 1
						println "\u001B[32m[INFO] ELSE -creating jenkins folder at $slashIndex"
					}	
		//			jobDsl scriptText: 'folder("${folders}")'
					//folder('${folders}')
				}	
		//	}
	//	}
	//	catch(err) 
	//	{
	//		wrap([$class: 'AnsiColorBuildWrapper']) 
	//		{
	//			print "\u001B[41m[ERROR]: failed creating jenkins folder at $folderPath"
	//			currentBuild.result = "FAILED"
	//			throw err
	//		}
	//	}
	}
}
