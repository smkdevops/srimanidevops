package com.ftd.seed

class multiBranchPipelineJobUtils implements Serializable 
{
	String jobDir
	String jobName
	String gitUrl
	String branches
	String credentialsId

	multiBranchPipelineJobUtils(String jobDir, String jobName, String gitUrl, String branches, String credentialsId) 
	{
		this.jobDir = jobDir
		this.jobName = jobName
		this.gitUrl = gitUrl
		this.branches = branches
		this.credetialsId = credentialsId
	}

	createJob()
	{
		try 
		{
			wrap([$class: 'AnsiColorBuildWrapper']) 
			{
				println "\u001B[32m[INFO] Creating multipipeline job " + jobName + " at " + jobDir
				def gitBranches = branches.split()
				def branchList = ""
				for( def gitBranch : gitBranches )
				{
					branchList = branchList + gitBranch + "|"
				}
				jobDsl scriptText: """multibranchPipelineJob("${jobDir}/${jobName}")
				{
					branchSources
					{
						git
						{
							id(UUID.nameUUIDFromBytes(repo.getBytes()).toString())
							id = UUID.nameUUIDFromBytes(repo.getBytes())
							
							remote('${gitUrl}')
							includes('${branchList}')
							credentialsId('${credentialsId}')
						}
					}

  
					orphanedItemStrategy 
					{
						discardOldItems 
						{
							daysToKeep(10)
							numToKeep(20)
						}
					}
					
					triggers
					{
						periodic(10)
					}
				}"""
			}
		}
		catch(err)
		{
			wrap([$class: 'AnsiColorBuildWrapper']) 
			{
				print "\u001B[41m[ERROR]: Failed to create multipieline job " + jobName + " at " + jobDir
				currentBuild.result = "FAILED"
				throw err
			}
		}
	}
}
