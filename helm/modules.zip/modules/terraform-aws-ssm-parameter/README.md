# Anthem AWS SSM Parameter

This module creates SSM Parameter service

## HIPPA eligibility status

1. AWS Systems Manager service is eligible.

## Security Guardrail reference

https://confluence.anthem.com/pages/viewpageattachments.action?pageId=299009562&preview=/299009562/516937786/Anthem%20AWS%20Security%20Patterns%20-%20Systems%20Manager.docx

## Pre-requisite

* Conditional resource creation is enabled with "create_ssm_parameter" variable, setting this variable to "true" will create the resource and setting this to "false" will skip the resource creation.
* The name contains a path (e.g. any forward slashes (/)), it must be fully qualified with a leading forward slash (/).
* Valid KMS key ARN is required for type SecureString.

## Mandatory Tags Note:
*	As per redesigned new mandatory tags, mandatory tags along with any additional tags have to be added through template configuration within the modules as below
*	Have a reference of mandatory tags module within the template configuration as shown in example script below.
```bash
# Mandatory Tag Workspace Variables
variable "apm-id" {}
variable "application-name" {}
variable "app-support-dl" {}
variable "app-servicenow-group" {}
variable "business-division" {}
variable "company" {}
variable "compliance" {}
variable "costcenter" {}
variable "environment" {}
variable "PatchGroup" {}
variable "PatchWindow" {}
variable "ATLAS_WORKSPACE_NAME" {}

# Mandatory Tags Module 
module "mandatory_tags" {
  source               = "cps-terraform.anthem.com/<ORG_NAME>/terraform-aws-mandatory-tags-v2/aws"
  tags                 = {}
  apm-id               = var.apm-id
  application-name     = var.application-name
  app-support-dl       = var.app-support-dl
  app-servicenow-group = var.app-servicenow-group
  business-division    = var.business-division
  compliance           = var.compliance
  company              = var.company
  costcenter           = var.costcenter
  environment          = var.environment
  PatchGroup           = var.PatchGroup
  PatchWindow          = var.PatchWindow
  workspace            = var.ATLAS_WORKSPACE_NAME
}
```
*	Mandatory tags module should be referred in tags attribute as below:
tags = module.mandatory_tags.tags
*	Any additional tags can be merged to tags attribute as below:
tags = merge(module.mandatory_tags.tags, {"sample" = "abc"})


## Usage

To run this example you need to execute:

```bash
#Example script
module "ssmparameter" {
  source = "cps-terraform.anthem.com/<ORGANIZATION NAME>/terraform-aws-ssm-parameter/aws"

 tags = merge(module.mandatory_tags.tags)

    /******** Parameter required for resource creation ****/

  ssm_parameter_name        = ""
  ssm_parameter_description = ""
  type                      = ""
  value                     = ""
  tier                      = ""
  kms_key_id                = ""
  overwrite                 = ""
  allowed_pattern           = ""
  data_type                 = ""
}

#Initialize Terraform
terraform init

#Terraform Dry-Run
terraform plan

#Create the resources
terraform apply

#Destroy the resources saved in the tfstate
terraform destroy
```
## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| allowed\_pattern | (Optional) "Default : null".A regular expression used to validate the parameter value. | `string` | `""` | no |
| create\_ssm\_parameter | (Optional) "Default : true".Need to create a new ssm parameter True or False | `bool` | `true` | no |
| data\_type | (Optional) "Default : text".The data\_type of the parameter. Valid values: text and aws:ec2:image for AMI format, see the https://docs.aws.amazon.com/systems-manager/latest/userguide/parameter-store-ec2-aliases.html | `string` | `"text"` | no |
| kms\_key\_id | (Required) The KMS key id or arn for encrypting a SecureString. | `string` | n/a | yes |
| overwrite | (Optional) "Default : false".Overwrite an existing parameter. If not specified, will default to false if the resource has not been created by terraform to avoid overwrite of existing resource and will default to true otherwise (terraform lifecycle rules should then be used to manage the update behavior). | `bool` | `false` | no |
| ssm\_parameter\_description | (Optional) "Default : null".The description of the parameter. | `string` | `""` | no |
| ssm\_parameter\_name | (Required) The name of the parameter. If the name contains a path (e.g. any forward slashes (/)), it must be fully qualified with a leading forward slash (/). For additional requirements and constraints, see the https://docs.aws.amazon.com/systems-manager/latest/userguide/sysman-parameter-name-constraints.html | `string` | n/a | yes |
| tags | (Required) A mapping of tags to assign to all resources. | `map(string)` | n/a | yes |
| tier | (Optional) "Default : Standard".The tier of the parameter. If not specified, will default to Standard. Valid tiers are Standard and Advanced. For more information on parameter tiers, see the https://docs.aws.amazon.com/systems-manager/latest/userguide/parameter-store-advanced-parameters.html | `string` | `"Standard"` | no |
| type | (Optional) "Default : SecureString".The type of the parameter. Valid types are String, StringList and SecureString. | `string` | `"SecureString"` | no |
| value | (Required) The value of the parameter. | `string` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| ssm\_parameter\_arn | The ARN of the parameter. |
| ssm\_parameter\_description | The description of the parameter. |
| ssm\_parameter\_name | The name of the parameter. |
| type | The type of the parameter. Valid types are String, StringList and SecureString. |
| value | The value of the parameter. |
| version | The version of the parameter. |

## Testing

* Created SSM parameter.
* Created Lambda function with get parameter permission for SSM.
* Uploaded python code to lambda to fetch value for SSM parameter.
* Tested the Lambda function and verified the results.
* Able to fetch the value for given SSM parameter.