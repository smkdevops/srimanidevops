# Anthem AWS Cloudfront Cache Resource

This module create aws Cloudfront Cache Resource.

<span style="color: red">**This module should only be used by Contact Center Project.**</span>


## HIPAA eligibility status

* N/A


## Security Guardrail reference

[security Guardrails Link](https://confluence.anthem.com/download/attachments/717965086/Anthem%20AWS%20Security%20Patterns%20-%20AWS_CloudFront%20-%20Deliotte%20Digital%20CCaaS%20use%20case.docx?version=1&modificationDate=1628274246000&api=v2)

## Pre-requisite

- Dependent resources will be needed if any & Usage for Complex Parameter/s given below.
```
parameters_in_cache_key_and_forwarded_to_origin = [{
    cookies_config = [{
      cookie_behavior = <VALUE>
      cookies = [{
        items = = [value1,value2,...]
      }]
    }]
    enable_accept_encoding_brotli = <VALUE>
    enable_accept_encoding_gzip   = <VALUE>
    headers_config = [{
      header_behavior = <VALUE>
      headers = [{
        items = = [value1,value2,...]
      }]
    }]
    query_strings_config = [{
      query_string_behavior = <VALUE>
      query_strings = [{
        items = = [value1,value2,...]
      }]
    }]
  }]
}

```
## Usage

To run this example you need to execute:

```bash
#Initialize Terraform
terraform init

#Terraform Dry-Run
terraform plan

#Create the resources
terraform apply

#Destroy the resources saved in the tfstate
terraform destroy
```

## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | >=3.35.0 |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [aws_cloudfront_cache_policy.this](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/cloudfront_cache_policy) | resource |
## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_comment"></a> [comment](#input\_comment) | (Optional) A comment to describe the cache policy. | `string` | `null` | no |
| <a name="input_create_cache_policy"></a> [create\_cache\_policy](#input\_create\_cache\_policy) | Controls if CloudFront cache policy should be created | `bool` | `true` | no |
| <a name="input_default_ttl"></a> [default\_ttl](#input\_default\_ttl) | (Optional) The default amount of time, in seconds, that you want objects to stay in the CloudFront cache before CloudFront sends another request to the origin to see if the object has been updated. | `number` | `null` | no |
| <a name="input_etag"></a> [etag](#input\_etag) | (optional) | `string` | `null` | no |
| <a name="input_max_ttl"></a> [max\_ttl](#input\_max\_ttl) | (Optional) The maximum amount of time, in seconds, that objects stay in the CloudFront cache before CloudFront sends another request to the origin to see if the object has been updated. | `number` | `null` | no |
| <a name="input_min_ttl"></a> [min\_ttl](#input\_min\_ttl) | (Required) The minimum amount of time, in seconds, that you want objects to stay in the CloudFront cache before CloudFront sends another request to the origin to see if the object has been updated. | `number` | `null` | no |
| <a name="input_name"></a> [name](#input\_name) | (Required) A unique name to identify the cache policy. | `string` | n/a | yes |
| <a name="input_parameters_in_cache_key_and_forwarded_to_origin"></a> [parameters\_in\_cache\_key\_and\_forwarded\_to\_origin](#input\_parameters\_in\_cache\_key\_and\_forwarded\_to\_origin) | (Optional) The HTTP headers, cookies, and URL query strings to include in the cache key. See Parameters In Cache Key And Forwarded To Origin for more information. | <pre>set(object(<br>    {<br>      cookies_config = list(object(<br>        {<br>          cookie_behavior = string<br>          cookies = list(object(<br>            {<br>              items = set(string)<br>            }<br>          ))<br>        }<br>      ))<br>      enable_accept_encoding_brotli = bool<br>      enable_accept_encoding_gzip   = bool<br>      headers_config = list(object(<br>        {<br>          header_behavior = string<br>          headers = list(object(<br>            {<br>              items = set(string)<br>            }<br>          ))<br>        }<br>      ))<br>      query_strings_config = list(object(<br>        {<br>          query_string_behavior = string<br>          query_strings = list(object(<br>            {<br>              items = set(string)<br>            }<br>          ))<br>        }<br>      ))<br>    }<br>  ))</pre> | `= [value1,value2,...]` | no |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_etag"></a> [etag](#output\_etag) | returns a string |
| <a name="output_id"></a> [id](#output\_id) | returns a string |
| <a name="output_this"></a> [this](#output\_this) | n/a |
