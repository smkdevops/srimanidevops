# Anthem Lambda create source event mapping Module

This module create source event mapping for lambda.

## HIPAA eligibility status

NA. This is supporting module for lambda.

## Security Guardrail reference

NA. This is supporting module for lambda.

## Pre-Requisite

1. The Lambda function should be exist.
2. Source ARN should be provided.
3. Failed queue (Destination arn) is optional. Can be configured with stream services (DynamoDB or Kinesis).
4. Destination arn should be SQS or SNS arn for failed messages.
5. Batch size for SQS is 10 and for DynamoDB and Kinesis is 100. If the batch size is not provided for these stream services then internally it will go with the default values.
6. event_source value should be provided. Eg(DynamoDB, Kinesis, MSK and SQS)

## Usage
To run this example you need to execute:

```bash

module "lambda-function_event_source_mapping" {
  source = "cps-terraform.anthem.com/<ORG>/terraform-aws-lambda-event-source-mapping-test/aws"

  batch_size                         = 10
  event_source                       = "SQS"
  maximum_batching_window_in_seconds = 60
  event_source_arn                   = module.api_sqs_queue.sqs_queue_arn
  enabled                            = true
  function_name                      = module.lambda.function_arn
  starting_position                  = "LATEST"
  starting_position_timestamp        = 0
  parallelization_factor             = null
  maximum_retry_attempts             = null
  maximum_record_age_in_seconds      = null
  bisect_batch_on_function_error     = null
  topics                             = null 
  destination_arn                    = null

}

#Initialize Terraform
terraform init

#Terraform Dry-Run
terraform plan

#Create the resources
terraform apply

#Destroy the resources saved in the tfstate
terraform destroy
```

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| batch\_size | The largest number of records that Lambda will retrieve from your event source at the time of invocation. Defaults to 100 for DynamoDB and Kinesis, 10 for SQS. | `number` | n/a | yes |
| bisect\_batch\_on\_function\_error | Default : false. If the function returns an error, split the batch in two and retry. Only available for stream sources (DynamoDB and Kinesis). Defaults to false. | `bool` | `null` | no |
| destination\_arn | An Amazon SQS queue or Amazon SNS topic destination for failed records. Only available for stream sources. The Amazon Resource Name (ARN) of the destination resource. | `string` | `null` | no |
| enabled | Default : true.Determines if the mapping will be enabled on creation. Defaults to true. | `bool` | `true` | no |
| event\_source | The source of event. It can be a Kinesis, DynamoDB or SQS. | `string` | n/a | yes |
| event\_source\_arn | The event source ARN - can be a Kinesis stream, DynamoDB stream, or SQS queue. | `string` | n/a | yes |
| function\_name | The name or the ARN of the Lambda function that will be subscribing to events. | `string` | n/a | yes |
| maximum\_batching\_window\_in\_seconds | Default: 0.The maximum amount of time to gather records before invoking the function, in seconds(between 0 and 300). Records will continue to buffer until either maximum\_batching\_window\_in\_seconds expires or batch\_size has been met. Defaults to as soon as records are available in the stream. If the batch it reads from the stream only has one record in it, Lambda only sends one record to the function. | `number` | `0` | no |
| maximum\_record\_age\_in\_seconds | Default : 604800. The maximum age of a record that Lambda sends to a function for processing. Only available for stream sources (DynamoDB and Kinesis). Minimum of 60, maximum and default of 604800. | `number` | `null` | no |
| maximum\_retry\_attempts | Default : 10000. The maximum number of times to retry when the function returns an error. Only available for stream sources (DynamoDB and Kinesis). Minimum of 0, maximum and default of 10000. | `number` | `null` | no |
| parallelization\_factor | Default : 1.The number of batches to process from each shard concurrently. Only available for stream sources (DynamoDB and Kinesis). Minimum and default of 1, maximum of 10. | `number` | `null` | no |
| starting\_position | Default : "LATEST".The position in the stream where AWS Lambda should start reading. Must be one of AT\_TIMESTAMP (Kinesis only), LATEST or TRIM\_HORIZON if getting events from Kinesis or DynamoDB. Must not be provided if getting events from SQS. | `string` | `null` | no |
| starting\_position\_timestamp | Default: 0 .A timestamp in RFC3339 format of the data record which to start reading when using starting\_position set to AT\_TIMESTAMP. If a record with this exact timestamp does not exist, the next later record is chosen. If the timestamp is older than the current trim horizon, the oldest available record is chosen. | `number` | `0` | no |
| topics | The name of the Kafka topics. Only available for MSK sources. A single topic name must be specified. | `list(string)` | `null` | no |

## Outputs

| Name | Description |
|------|-------------|
| function\_arn | The the ARN of the Lambda function the event source mapping is sending events to. (Note: this is a computed value that differs from function\_name above.) |
| last\_modified | The date this resource was last modified. |
| last\_processing\_result | The result of the last AWS Lambda invocation of your Lambda function. |
| state | The state of the event source mapping. |
| state\_transition\_reason | The reason the event source mapping is in its current state. |
| uuid | The UUID of the created event source mapping. |

## Testing

1. Created a SQS mapping in Lambda.
2. Push message to SQS queue
3. Could see in the cloud watch log that the message has been polled by Lambda.