# Anthem AWS Mandatory tags

This is a custom module which can be leveraged in all the catalog modules. Each Service should have all the proposed/mandatory tags we have here. In addition, application teams can also add tags specific yto their teams. 

## Reference

This root resource documentation in this [repository](https://bitbucket.anthem.com/projects/ACSCB/repos/terraform-aws-mandatorytags-internal/browse)

## Note:

Updated 4 tags with newer ones by reusing the same variables and changing the key names in order not to update tags.tf files and variables in all the modules that has tags.
Users will have to use the same variables, so as not to change their scripts or the modules, but the key names, i.e., tags will be populated with newer ones.  
Users now have to pass appropriate values for the updated tags, i.e., users will use the same variables, but the values have to be defined according to the updated key names(tags)
```bash
**Variable** 		**Key name**			**Example Value**
application_dl		app-support-dl			dl-ccoe-cloud-service-catalog@anthem.com
application			application-name		scapp1
it-department		business-division		DIGITAL
layer				schedule-window			mon-fri-8am-6pm-est
```



## Usage

To run this example you need to execute:
	
```bash
	#Initialize Terraform
	terraform init
	
	#Terraform Dry-Run
	terraform plan
	
	#Create the resources
	terraform apply
	
	#Destroy the resources saved in the tfstate
	terraform destroy
```

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| application | application is now application-name.  Based upon application nomenclature in server naming convention policy.Use up to six (6) characters to name your application. | `string` | `null` | no |
| application\_dl | application-dl is now app-support-dl. Pass appropriate value. | `string` | `null` | no |
| barometer-it-num | barometer-it-num is now baramoter-it. Pass appropriate value. | `string` | `null` | no |
| company | Based upon company that owns resource-ANTM–Anthem | `string` | `null` | no |
| compliance | PHI, PCI, PII, SOX, None | `string` | `null` | no |
| costcenter | n/a | `string` | `null` | no |
| environment | DBx,SIT,PERF,PRODX,UAT,UTILx | `string` | `null` | no |
| it-department | it-department is now business-division. Pass appropriate value. | `string` | `null` | no |
| layer | layer is now schedule-window.  Used to identify the window for a resource to be started or stoppedautomatically from cost optimization stand point. Pass appropriate value. | `string` | `null` | no |
| owner-department | n/a | `string` | `null` | no |
| resource-type | Based upon the type of resource. | `string` | `null` | no |
| tags | Any other tags that needs to be attached in the resource | `map(string)` | `{}` | no |

## Outputs

| Name | Description |
|------|-------------|
| tags | n/a |