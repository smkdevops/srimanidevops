# Anthem AWS API Gateway Request Validator Module

This module manages an API Gateway Request Validator.

## HIPAA eligibility status

1. Amazon API Gateway is eligible

## Security Guardrail reference

https://confluence.anthem.com/pages/viewpageattachments.action?pageId=299009562&sortBy=date&startIndex=60&preview=/299009562/370573552/Anthem%20AWS%20Security%20Patterns%20-%20API%20Gateway.docx

## Pre-Requisites

1. Rest API should be created.
2. Name of the request validator.

## Important Note

## Usage
To run this example you need to execute:

```bash

module "api-validator" {
  source = "cps-terraform.anthem.com/<ORG>/terraform-aws-api-gateway-request-validator/aws"

  name                        = "First Request Validator"
  rest_api_id                 = ""
  validate_request_body       = false
  validate_request_parameters = false
}

#Initialize Terraform
terraform init

#Terraform Dry-Run
terraform plan

#Create the resources
terraform apply

#Destroy the resources saved in the tfstate
terraform destroy
```

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| create\_apigateway\_validator | (Optional) A boolean that indicates whether to create API Gateway validator or not. Default is true | `bool` | `true` | no |
| name | (Required) The name of the request validator | `string` | n/a | yes |
| rest\_api\_id | (Required) The ID of the associated Rest API | `string` | n/a | yes |
| validate\_request\_body | (Optional) Boolean whether to validate request body. Defaults to false. | `bool` | `false` | no |
| validate\_request\_parameters | (Optional) Boolean whether to validate request parameters. Defaults to false. | `bool` | `false` | no |

## Outputs

| Name | Description |
|------|-------------|
| id | The unique ID of the request validator |

## Testing

1. Able to create the validator.