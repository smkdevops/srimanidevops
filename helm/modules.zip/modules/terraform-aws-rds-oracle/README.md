# ElevanceHealth AWS RDS Oracle Module

This module creates AWS RDS Oracle database Single/MultiAZ.

Configuration in this directory creates set of RDS resources including DB instance, DB subnet group, security groups and DB parameter & option group.

# Release Notes:
## New Version - 0.1.0 ##
1. Log Group creation for Audit, Alert, Listener and Trace logs has been added into this module.
2. Now users need to input each log group retention period accordingly in the templates. If not specified value has been defaulted to 7 days for all the log groups.
3. Log Group will be deleted as part of the decomissioning process.
4. KMS Key Module for encryption of log groups has been added in the templates.
5. Postscripts automation has been added in the templates.
6. Subscription event has been added in the template.
7. Added Pre-patch-snapshot-flag to lifecycle ignore changes.
### Adoption of the New Version - 0.1.0 ###
1. For existing RDS instance when you update the module to latest version and run the terraform apply you will recieve an error stating log group with the given name already exists. In such Cases login to the console go to cloudwatch and under the log groups section search with the instance Identifier which is shown in the error and delete them manually and after that run the terraform apply.
2. When you are creating a new DB instance and if you recieve an error saying the log group with the name already exists then check if there is any instance available with instance identifier that is stated in the error in the console and if there is no instance available, delete the log group manually and re-run the code.
3. Additional security group rule has been added to this module with description of "ElevanceHealth PostScripts Automation", DO NOT remove this security group rule while launching DB using this template.
4. When you run the new templates an ec2 instance will be created and the postscripts are downloaded from the s3 and ec2 connects to the database and runs the postscripts. Once the postscripts are run successfully ec2 instance will be destroyed automatically. Make a note that everytime you run this module ec2 will be created and terminated.
5. For the event subscription to create, update the AWS REGION and ACCOUNT Number in sns_rds_topic_policy.json file accordingly.
6. As the tags "prepatch-snapshot-flag" is added to the lifecycle ignore changes you will not be able to modify the value from the second apply.

## RDS Oracle module reference

[Terraform RDS Oracle](https://bitbucket.elevancehealth.com/projects/ACSC/repos/terraform-aws-rds-oracle/browse)


## Pre-requisites
* VPC Id
* Raise Hashicorp Vault Access request using this link [Hashi corp Vault Name Space Request](https://elevancehealth.service-now.com/ess?id=ant_sc_cat_item&sys_id=ae669e704739d550cb5ee731e36d4303) and provide the following details in the ticket. Only after this ticket is closed proceed with next steps.
    1. Assignment Group: Application security cloud ops
    2. Summary of work being requested: Move vault namespace to root for DB Automation.
    3. Detailed Description: Please provide the below details.
         Account Type: 
         Account Number: 
         Workspace Name: 
         Vault Namespace: 
         oba_code: 
         org_code:
* Please send out an email to dl-CCOE-Cloud-Service-Catalog@anthem.com for getting access to this bitbuket repo [ElevanceHealthDB-RDS-Oracle-Single/MultiAZ](https://bitbucket.elevancehealth.com/projects/ACSCT/repos/elevancehealthdb-rds-oracle/browse). This repo contains the template for Provisioning RDS Oracle DB.
* After getting the access Clone the Repository, Make the necessary changes in the Template and run init.
* DB Encryption is enforced using dynamically generated CMK.
* Master Database Credentials used by DBA's are housed in Vault.

1. Login to the TARGET AWS Accounts prior to executing TFE Modules to make sure none of the Services you are trying to provision are already created via UI/CLI. Any manually precreated assets cannot be managed by TFE.
2. Only use the provider.tf file which is provided in the ElevanceHealthDB-RDS-Oracle Repository by making changes in organization, hostname and workspace name, Region.
```bash
terraform {
  backend "remote" {
    hostname     = "<TFE-URL>"
    organization = "<ORGANIZATION-NAME>"
    workspaces {
      name = "<WORKSPACE-NAME>"
    }
  }
}
```
4. Set organization name in the source of the modules. <ORGANIZATION-NAME>
```bash
source  = "cps-terraform.anthem.com/<ORGANIZATION-NAME>/terraform-aws-kms-service/aws"
```
5. vpc ID set in the vpc-id variable of the workspace or set in main.tf file.
6. To Hydrate an Instance using existing Snapshot, Un-comment and Update the template variable snapshot_identifier with the Snapshot Name before apply
7. To Recover an instance using Point In Time Recovery (PITR), Un-comment and Update restore_to_point_in_time by passing existing DB Instance Identifier in source_db_instance_identifier and the Time it should be recovered to in restore_time. restore_time has to be in UTC Timezone and in RFC3339 format. REF [https://medium.com/easyread/understanding-about-rfc-3339-for-datetime-formatting-in-software-engineering-940aa5d5f68a]
	
	For Example: If the Restore Time is April 28 2021, 12:55:45PM then restore_Time = "2021-04-28T12:55:45Z"

8. Kindly pass <Application_tags> as per Application teams requirements and no value has to collide each other.
9. Kindly pass <Max_allocated_storage> value greater than <Alloctaed storage>.

## Notes
- The security group for this DB instance, defaults to the following ingress rules:
```bash
  ingress_rules = [
    {
      from_port   = 1521
      to_port     = 1521
      protocol    = "tcp"
      cidr_blocks = ["33.0.0.0/8"]
      description = "Carelon OnPrem"
    },
    {
      from_port   = 1521
      to_port     = 1521
      protocol    = "tcp"
      cidr_blocks = ["22.173.0.0/20"]
      description = "Imperva Primary"
    },
    {
      from_port   = 1521
      to_port     = 1521
      protocol    = "tcp"
      cidr_blocks = ["10.114.0.0/24"]
      description = "Imperva Secondary"
    },
    {
      from_port   = 1521
      to_port     = 1521
      protocol    = "tcp"
      cidr_blocks = ["30.0.0.0/8"]
      description = "ElevanceHealth OnPrem"
    },
    {
      from_port                = 1521
      to_port                  = 1521
      protocol                 = "tcp"
      source_security_group_id = "${data.aws_security_group.db_security_group.id}"
      description              = "ElevanceHealth PostScripts Automation"
    },
    {
      from_port                = 1521
      to_port                  = 1521
      protocol                 = "tcp"
      source_security_group_id = "<SECURITY GROUP ID>"
      description              = "Application Tier Security Group ID"
    }
```
In case to need a security group as a source, this can be added in the source_security_group_id parameter as documented above.
- Performance Insights is enabled by default in this template, to see PI dashboard attach the required role to the user. Please refer [User Performance Insights](https://docs.aws.amazon.com/AmazonRDS/latest/UserGuide/USER_PerfInsights.UsingDashboard.html) to get more information.
- Enhanced monitoring is enabled by default in this template. All the RDS Oracle available cloudwatch log exports are set in the configuration of this feature.
- Native Nettwork Encryption is the default option in the option group created as part of this execution. To switch to SSL option(DMS required configuration), set the enable_ssl_option to true and the ssl_option_security_group_memberships parameter with the security group of the DMS replication instance.

## FOR DAM & GOVERNANCE USAGE

1. Do not alter any of the existing parameters in Oracle_Parameter_Option_Group.json file as these are required for DAM/GOVERNANCE Auditing purpose. Add parameters if required for DB Tuning and other COTS Products asks.
2. Do not make any changes in IAM Enhanced Monitoring Role Module.
3. Do not make any changes in the RDS S3 Integration Policy Module.

## Notes

- Do not remove any of the existing ingress rules from the security group for this DB instance. Add Rule as per the requirement.
- For any DB Issues related to this provisioning, please open [Incident Ticket](https://elevancehealth.service-now.com/ess?id=ant_sc_cat_item&sys_id=e420efc0db889f40eed27bedae9619d7) and assign it to Deloitte Cloud Database Support.
- After successful creation of DB Please raise a Service ID request to DBA Team by using this steps [Service ID Request](https://confluence.elevancehealth.com/display/ENTCLOUD/How+to+Request+Service+Id+Access+to+a+Database) and for Individual user access Please raise a request by following this steps [Individual User Request](https://confluence.elevancehealth.com/display/ENTCLOUD/How+to+Request+Personal+Access+to+a+Database)

## Usage

To run this example you need to execute:

```bash
#Initialize Terraform
terraform init

#Terraform Dry-Run
terraform plan

#Create the resources
terraform apply

#Destroy the resources saved in the tfstate
terraform destroy
```

## Providers

| Name | Version |
|------|---------|
| aws | n/a |
| random | n/a |
| vault | n/a |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| allocated\_storage | The allocated storage in gigabytes | `string` | `null` | no |
| allow\_major\_version\_upgrade | Indicates that major version upgrades are allowed. Changing this parameter does not result in an outage and the change is asynchronously applied as soon as possible. Allowed values are true/false. Defaults to true. | `bool` | `true` | no |
| application-name | Based upon application nomenclature in server naming convention policy.Use up to six (6) characters to name your application. | `string` | n/a | yes |
| application\_tag1 | Manged by APP teams | `string` | n/a | yes |
| application\_tag2 | Manged by APP teams | `string` | n/a | yes |
| application\_tag3 | Manged by APP teams | `string` | n/a | yes |
| application\_tag4 | Manged by APP teams | `string` | n/a | yes |
| application\_tag5 | Manged by APP teams | `string` | n/a | yes |
| apply\_immediately | Specifies whether any database modifications are applied immediately, or during the next maintenance window. Allowed values are true/false. Defaults to false. | `bool` | `false` | no |
| auto\_minor\_version\_upgrade | Indicates that minor engine upgrades will be applied automatically to the DB instance during the maintenance window. Allowed values are true/false. Defaults to true. | `bool` | `true` | no |
| availability\_zone | The Availability Zone of the RDS instance | `string` | `null` | no |
| aws\_db\_instance\_role\_association | whether to create role association or not. | `bool` | `false` | no |
| backup\_retention\_period | The days to retain backups for. Must be a value from 0 to 35. Defauls to 7. | `string` | `"7"` | no |
| backup\_window | The daily time range (in UTC) during which automated backups are created if they are enabled. Example: '09:46-10:16'. Must not overlap with maintenance\_window | `string` | `"21:00-00:00"` | no |
| bcp-tier | Application BCP tier | `string` | n/a | yes |
| character\_set\_name | (Optional) The character set name to use for DB encoding in Oracle instances. This can't be changed. See Oracle Character Sets Supported in Amazon RDS for more information | `string` | `"AL32UTF8"` | no |
| copy\_tags\_to\_snapshot | On delete, copy all Instance tags to the final snapshot (if final\_snapshot\_identifier is specified) | `bool` | `true` | no |
| created-by | who created the instance | `string` | n/a | yes |
| cross\_region | Whether the instance is a cross region replica | `bool` | `false` | no |
| database-platform | Names of the Database | `string` | n/a | yes |
| database-state | State providing direction for InfoHub to manage Metadata elements. | `string` | n/a | yes |
| db-patch-schedule | Schedules coordinated with Application Team. As general guidelines, we don't want to patch Databases during Q4 due to Annual Enrollment and Holiday season.  We also don't want to AWS Auto Patch Schedule used for Data Platforms as there are application dependency in play. | `string` | n/a | yes |
| db-patch-time-window | 2-Hour slots Weekend Window for Patching starting late Friday night till Sunday evening 6pm US EST. | `string` | n/a | yes |
| db\_instance\_creation\_timeout | Used for Creating Instances, Replicas, and restoring from Snapshots. Defaults to 40 minutes. | `string` | `"40m"` | no |
| delete\_all\_versions | Only applicable for kv-v2 stores. If set to true, permanently deletes all versions for the specified key. The default behavior is to only delete the latest version of the secret. | `bool` | `true` | no |
| deletion\_protection | The database can't be deleted when this value is set to true. Defaults to false. | `bool` | `true` | no |
| enable\_ssl\_option | Set to true to enable SSL option in RDS Oracle option group. Default is false. | `bool` | `false` | no |
| enabled\_cloudwatch\_logs\_exports | List of log types to enable for exporting to CloudWatch logs. If omitted, no logs will be exported. Valid values: alert, audit, listener, trace. Defaults to all values mentioned above. | `list(string)` | <pre>[<br>  "alert",<br>  "audit",<br>  "listener",<br>  "trace",<br>  "oemagent"<br>]</pre> | no |
| engine | The Oracle RDS database engine to use. Valid values are: 'oracle-se', 'oracle-se1', 'oracle-se2', 'oracle-ee'. Defaults to 'oracle-ee'. To see more information, please refer [RDS engines](https://docs.aws.amazon.com/AmazonRDS/latest/APIReference/API_CreateDBInstance.html) | `string` | `"oracle-ee"` | no |
| engine\_name | Specifies the name of the engine that this option group should be associated with. Valid values are: 'oracle-se', 'oracle-se1', 'oracle-se2', 'oracle-ee'. Defaults to 'oracle-ee'. | `string` | `"oracle-ee"` | no |
| engine\_version | The engine version to use. To see available Oracle versions, please refer [Engine versions](https://docs.aws.amazon.com/AmazonRDS/latest/UserGuide/Appendix.Oracle.PatchComposition.html). Defaults to 19.0.0.0. | `string` | `"19.0.0.0.ru-2019-07.rur-2019-07.r1"` | no |
| environment | DBx,SIT,PERF,PRODX,UAT,UTILx | `string` | n/a | yes |
| family | The family of the DB parameter group | `string` | `"oracle-ee-19"` | no |
| final\_snapshot\_identifier | The name of your final DB snapshot when this DB instance is deleted. | `string` | `null` | no |
| iam\_database\_authentication\_enabled | Specifies whether or mappings of AWS Identity and Access Management (IAM) accounts to database accounts is enabled | `string` | n/a | yes |
| identifier | The name of the RDS instance, if omitted, Terraform will assign a random, unique identifier | `string` | n/a | yes |
| ingress\_rules | The parameters to create security group ingress rules in the form of a list and referencing each rule with brackets. | `any` | `null` | no |
| instance\_class | The instance type of the RDS instance | `string` | n/a | yes |
| instance\_count | The number of DB instance to create. | `number` | `1` | no |
| iops | The amount of provisioned IOPS. Setting this implies a storage\_type of 'io1'. Must be a multiple between .5 and 50 of the storage amount for the DB instance. Defaults to 4000. | `string` | `null` | no |
| keepers | (Map of String) Arbitrary map of values that, when changed, will trigger recreation of resource. See the main provider documentation for more information | `map(string)` | `null` | no |
| kms\_key\_id | The ARN for the CMK encryption key. | `string` | n/a | yes |
| kms\_key\_id\_log\_group | The ARN for the KMS encryption key for Log Groups. | `string` | n/a | yes |
| length | (Number) The length of the string desired. | `number` | `16` | no |
| license\_model | License model information for this DB instance | `string` | `"bring-your-own-license"` | no |
| lower | (Boolean) Include lowercase alphabet characters in the result. Default value is true. | `bool` | `true` | no |
| maintenance\_window | The window to perform maintenance in. Syntax: 'ddd:hh24:mi-ddd:hh24:mi'. Eg: 'Mon:00:00-Mon:03:00' | `string` | `"Sun:00:00-Sun:03:00"` | no |
| major\_engine\_version | Specifies the major version of the engine that this option group should be associated with | `string` | `"19"` | no |
| max\_allocated\_storage | The allocated storage in gibibytes. If max\_allocated\_storage is configured, this argument represents the initial storage allocation and differences from the configuration will be ignored automatically when Storage Autoscaling occurs. | `string` | `null` | no |
| min\_lower | (Number) Minimum number of lowercase alphabet characters in the result. Default value is 0. | `number` | `3` | no |
| min\_numeric | (Number) Minimum number of numeric characters in the result. Default value is 0. | `number` | `3` | no |
| min\_special | (Number) Minimum number of special characters in the result. Default value is 0. | `number` | `3` | no |
| min\_upper | (Number) Minimum number of uppercase alphabet characters in the result. Default value is 0. | `number` | `3` | no |
| monitoring\_interval | The interval, in seconds, between points when Enhanced Monitoring metrics are collected for the DB instance. To disable collecting Enhanced Monitoring metrics, specify 0. The default is 0. Valid Values: 0, 1, 5, 10, 15, 30, 60. | `string` | `"0"` | no |
| monitoring\_role\_arn | The ARN for the IAM role that permits RDS to send enhanced monitoring metrics to CloudWatch Logs. Must be specified if monitoring\_interval is non-zero. | `string` | `""` | no |
| multi\_az | Specifies if the RDS instance is multi-AZ | `string` | `true` | no |
| numeric | (Boolean) Include numeric characters in the result. Default value is true. | `bool` | `true` | no |
| oracle\_parameter\_option\_group | According to the requirement DBA's can change the details. | `string` | n/a | yes |
| override\_special | (String) Supply your own list of special characters to use for string generation. This overrides the default character list in the special argument. The special argument must still be set to true for any overwritten characters to be used in generation. | `string` | `"!#$%^&"` | no |
| performance\_insights\_enabled | Specifies whether Performance Insights are enabled. Defaults to false. | `bool` | `false` | no |
| performance\_insights\_kms\_key\_id | The ARN for the KMS key to encrypt Performance Insights data. When specifying performance\_insights\_kms\_key\_id, performance\_insights\_enabled needs to be set to true. Once KMS key is set, it can never be changed. | `string` | `null` | no |
| performance\_insights\_retention\_period | The amount of time in days to retain Performance Insights data. Either 7 (7 days) or 731 (2 years) | `string` | `7` | no |
| port | The port on which the DB accepts connections | `string` | `"1521"` | no |
| prepatch-snapshot-flag | Tag for patching | `string` | n/a | yes |
| read\_replica | Whether this instance is a read replica single region. Set false to use a single region or to create CRRR. Defaults to false | `bool` | `false` | no |
| replicate\_source\_db | Specifies that this resource is a Replicate database, and to use this value as the source database. This correlates to the identifier of another Amazon RDS Database to replicate. | `string` | `null` | no |
| restore\_to\_point\_in\_time | A configuration block for restoring a DB instance to an arbitrary point in time. Requires the identifier argument to be set with the name of the new DB instance to be created. See Restore To Point In Time below for details | `any` | `null` | no |
| retention\_in\_days\_rds\_alert | Specifies the number of days you want to retain Alert log events in the specified log group. Possible values are: 1, 3, 5, 7, 14, 30, 60, 90, 120, 150, 180, 365, 400, 545, 731, 1096, 1827, 2192, 2557, 2922, 3288, 3653, and 0. If you select 0, the events in the Alert log group are always retained and never expire. | `number` | `7` | no |
| retention\_in\_days\_rds\_audit | Specifies the number of days you want to retain Audit log events in the specified log group. Possible values are: 1, 3, 5, 7, 14, 30, 60, 90, 120, 150, 180, 365, 400, 545, 731, 1096, 1827, 2192, 2557, 2922, 3288, 3653, and 0. If you select 0, the events in the Audit log group are always retained and never expire. | `number` | `7` | no |
| retention\_in\_days\_rds\_listener | Specifies the number of days you want to retain Listener log events in the specified log group. Possible values are: 1, 3, 5, 7, 14, 30, 60, 90, 120, 150, 180, 365, 400, 545, 731, 1096, 1827, 2192, 2557, 2922, 3288, 3653, and 0. If you select 0, the events in the Listener log group are always retained and never expire. | `number` | `7` | no |
| retention\_in\_days\_rds\_trace | Specifies the number of days you want to retain Trace log events in the specified log group. Possible values are: 1, 3, 5, 7, 14, 30, 60, 90, 120, 150, 180, 365, 400, 545, 731, 1096, 1827, 2192, 2557, 2922, 3288, 3653, and 0. If you select 0, the events in the Trace log group are always retained and never expire. | `number` | `7` | no |
| role\_arn | Amazon Resource Name (ARN) of the IAM Role to associate with the DB Instance. | `string` | `""` | no |
| serial\_number | Database Identifier Serial number | `string` | n/a | yes |
| skip\_final\_snapshot | Determines whether a final DB snapshot is created before the DB instance is deleted. If true is specified, no DBSnapshot is created. If false is specified, a DB snapshot is created before the DB instance is deleted, using the value from final\_snapshot\_identifier. Defaults to false. | `bool` | `false` | no |
| snapshot\_identifier | Specifies whether or not to create this database from a snapshot. This correlates to the snapshot ID you'd find in the RDS console, e.g: rds:production-2015-06-26-06-05. | `string` | `null` | no |
| special | (Boolean) Include special characters in the result. These are !@#$%&\*()-\_=+[]{}<>:?. Default value is true. | `bool` | `true` | no |
| ssl\_option\_security\_group\_memberships | A list of VPC Security Groups for which the option is enabled. | `list` | `[]` | no |
| storage\_type | One of 'standard' (magnetic), 'gp2' (general purpose SSD), or 'io1' (provisioned IOPS SSD). The default is 'io1' if iops is specified, 'standard' if not. Note that this behaviour is different from the AWS web console, where the default is 'gp2'. | `string` | `"gp2"` | no |
| tags | A mapping of tags to assign to all resources | `map(string)` | `{}` | no |
| upper | (Boolean) Include uppercase alphabet characters in the result. Default value is true. | `bool` | `true` | no |
| vpc\_id | VPC Id to attach the instance | `string` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| db\_name | Name of the RDS DB |
| engine\_version | The database engine version. |
| hosted\_zone\_id | The canonical hosted zone ID of the DB instance (to be used in a Route 53 Alias record). |
| iam\_role\_name | The name to use in the IAM role name creation for RDS enhanced monitoring. |
| instance\_address | Address of the RDS instance |
| instance\_arn | The ARN of the RDS instance |
| instance\_class | The RDS instance class. |
| instance\_endpoint | DNS Endpoint of the RDS instance |
| instance\_id | ID of the RDS instance |
| instance\_maintenance\_window | The RDS instance maintenance window time |
| instance\_name | Name of the RDS instance |
| instance\_status | The RDS instance status |
| option\_group\_id | The db option group name. |
| parameter\_group\_id | The db parameter group name. |
| resource\_id | The RDS Resource ID of this instance. |
| result | (String, Sensitive) The generated random string |
| username | The master username for the database. |

## Unit Testing 

Submit & able to execute job. 
* Creates an RDS Oracle Instance
* Creates a Parameter Group and a Option Group
* Creates the RDS Oracle Identifier using the Naming Convention Module

## RR Testing

* Creates an RDS Oracle Instance
* call the Main Oracle RDS instance in the parameter replicate_sourcedb
* Give instance_count = number of instances to launch(max 5 RR)
* Kindly check the Serial number before creating RR and CRRR, As Terraform updated the new release <NAME> attribute doesn't require for RR and CRRR.Kindly check the serial number before creation.

## CRRR Testing

* Creates an RDS Oracle Instance
* call the Main Oracle RDS instance in the parameter replicate_sourcedb
* Added Cross_region Variable to support a logic for skipping the option group creation in CRRR
* Due to Time out error  we need to do “Terraform apply” TWO times to launch CRRR. 
* Firstly, we have to comment resource-CRRR and launch Primary Instance and in second apply have to un-comment the CRRR code.
* To launch one DB instance it will take 35-40mins.



Note: Make sure to have your aws credentials refreshed when executing in TFE
