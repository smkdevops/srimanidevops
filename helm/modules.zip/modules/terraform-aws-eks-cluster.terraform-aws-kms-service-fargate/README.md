# Anthem AWS KMS Terraform Module

This module creates an AWS KMS key per service basis using terraform. It is only to create the CMK. AWS KMS is a secure and resilient service that uses hardware security modules that have been validated under FIPS 140-2, or are in the process of being validated, to protect your keys. AWS KMS is integrated with AWS services. Refer https://aws.amazon.com/kms/features/.

## HIPPA eligibility status

1. AWS Key management service is eligible.

## Security Guardrail reference

https://confluence.anthem.com/download/attachments/299009562/Anthem%20AWS%20Security%20Patterns%20-%20AWS%20KMS.docx?api=v2


## Pre-Requisites
## Note: Do not use default KMS keys, rather create any and all required KMS keys using this module.
1. This module is to create custom KMS key with the rotation is set to true.
2. Deletion window is set to 30 days by default.
3. Below are the list of services which are anthem approved and can be used for kms key creation.
"backup","dms","ssm","ec2","elasticfilesystem","es","fsx", "glue","kinesis","kinesisvideo","lambda","kafka","redshift", "rds","secretsmanager","sns","s3","sqs","xray","documentdb", "dynamodb","aurora", "athena", "eks","elasticache","emr", "glacier","sagemaker","codebuild","cloudtrail","codedeploy","storagegateway", "ecr".
4. User need to pass the service name from above list otherwise the code will fail with error that the service name is not valid.
5. User need to pass the service name in the form of list. E.g. ["s3", "fsx"]
6. One KMS key will be created for one service and can create various KMS Keys for different services in a single execution.
7. Services can be created by leveraging the kms key arn.

Note: - Services creation has been tested but production scenario is not tested due to unavailability of test data. In addition, some of the services use kms keys from other services e.g., documentdb uses rds key, glacier uses s3 key.

8. The KMS key alias name is generated in the form  including version, when ever any update on KMS the version number need to be given example (V2). Alias name can be formulated like - alias/sc-var.application-var.environment-service_name-V2. The version is automatically suffixed to the alias name.
Alias name should be provided in the template as shown
"${module.mandatory_tags.tags["application-name"]}-${module.mandatory_tags.tags["environment"]}". 
8.	This will create SYMMETRIC Key by default. This is the only option approved by anthem security team. 
9.	Key can not be shared with other account using this module. SNOW ticket should be raised to share the key. 
10.	Kms key will be created with below policy. It will allow access only to that service which user will provide. Other service will not be able to use this KMS key and will fail. 
```
{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Sid": "Enable Access for Key Administrators",
            "Effect": "Allow",
            "Principal": {
                "AWS": "arn:aws:iam::<Current Account number>:role/antm-ees-admin"
            },
            "Action": "kms:*",
            "Resource": "*"
        },
        {
            "Sid": "Enable Terraform Role Permissions",
            "Effect": "Allow",
            "Principal": {
                "AWS": [
                    "arn:aws:iam::<Current Account number>:role/OlympusVaultServiceRole"
                ]
            },
            "Action": [
                "kms:UpdateKeyDescription",
                "kms:UpdateAlias",
                "kms:UntagResource",
                "kms:TagResource",
                "kms:ScheduleKeyDeletion",
                "kms:List*",
                "kms:GetKeyRotationStatus",
                "kms:GetKeyPolicy",
                "kms:Encrypt",
                "kms:EnableKeyRotation",
                "kms:EnableKey",
                "kms:DisableKey",
                "kms:DescribeKey",
                "kms:DeleteAlias",
                "kms:Decrypt",
                "kms:CreateKey",
                "kms:CreateAlias",
                "kms:CancelKeyDeletion",
                "kms:ReplicateKey"
            ],
            "Resource": [
                "arn:aws:iam::<Current Account number>:key/*",
                "arn:aws:iam::<Current Account number>:alias/*"
            ]
        },
        {
            "Sid": "S3 Permissions",
            "Effect": "Allow",
            "Principal": {
                "AWS": "arn:aws:iam::<Current Account number>:root"
            },
            "Action": [
                "kms:Decrypt",
                "kms:DescribeKey",
                "kms:Encrypt*",
                "kms:GenerateDataKey*",
                "kms:ReEncrypt*",
                "kms:ListGrants",
                "kms:TagResource",
                "kms:UntagResource"
            ],
            "Resource": [
                "arn:aws:kms:*:<Current Account number>:key/*",
                "arn:aws:kms:*:<Current Account number>:alias/*"
            ],
            "Condition": {
                "StringEquals": {
                    "kms:ViaService": [
                        "s3.<REGION-NAME>.amazonaws.com",
                        "lambda.<REGION-NAME>.amazonaws.com",
                        "sns.<REGION-NAME>.amazonaws.com",
                        "sqs.<REGION-NAME>.amazonaws.com"
                    ]
                }
            }
        },
        {
            "Sid": "Lambda Permissions",
            "Effect": "Allow",
            "Principal": {
                "AWS": "arn:aws:iam::<Current Account number>:root"
            },
            "Action": [
                "kms:Decrypt",
                "kms:DescribeKey",
                "kms:Encrypt*",
                "kms:GenerateDataKey*",
                "kms:ReEncrypt*",
                "kms:ListGrants",
                "kms:TagResource",
                "kms:UntagResource"
            ],
            "Resource": [
                "arn:aws:kms:*:<Current Account number>:key/*",
                "arn:aws:kms:*:<Current Account number>:alias/*"
            ],
            "Condition": {
                "StringEquals": {
                    "kms:ViaService": [
                        "s3.<REGION-NAME>.amazonaws.com",
                        "lambda.<REGION-NAME>.amazonaws.com",
                        "sns.<REGION-NAME>.amazonaws.com"
                    ]
                }
            }
        },
        {
            "Sid": "EC2 Permissions",
            "Effect": "Allow",
            "Principal": {
                "AWS": "arn:aws:iam::<Current Account number>:root"
            },
            "Action": [
                "kms:Decrypt",
                "kms:DescribeKey",
                "kms:Encrypt*",
                "kms:GenerateDataKey*",
                "kms:ReEncrypt*",
                "kms:ListGrants",
                "kms:TagResource",
                "kms:UntagResource"
            ],
            "Resource": [
                "arn:aws:kms:*:<Current Account number>:key/*",
                "arn:aws:kms:*:<Current Account number>:alias/*"
            ],
            "Condition": {
                "StringEquals": {
                    "kms:ViaService": [
                        "s3.<REGION-NAME>.amazonaws.com",
                        "lambda.<REGION-NAME>.amazonaws.com",
                        "ec2.<REGION-NAME>.amazonaws.com",
                        "sns.<REGION-NAME>.amazonaws.com",
                        "sqs.<REGION-NAME>.amazonaws.com",
                        "logs.<REGION-NAME>.amazonaws.com",
                        "ssm.<REGION-NAME>.amazonaws.com",
                        "rds.<REGION-NAME>.amazonaws.com"
                    ]
                }
            }
        },
        {
            "Sid": "SNS Permissions",
            "Effect": "Allow",
            "Principal": {
                "AWS": "arn:aws:iam::<Current Account number>:root"
            },
            "Action": [
                "kms:Decrypt",
                "kms:DescribeKey",
                "kms:Encrypt*",
                "kms:GenerateDataKey*",
                "kms:ReEncrypt*",
                "kms:ListGrants",
                "kms:TagResource",
                "kms:UntagResource"
            ],
            "Resource": [
                "arn:aws:kms:*:<Current Account number>:key/*",
                "arn:aws:kms:*:<Current Account number>:alias/*"
            ],
            "Condition": {
                "StringEquals": {
                    "kms:ViaService": [
                        "s3.<REGION-NAME>.amazonaws.com",
                        "lambda.<REGION-NAME>.amazonaws.com",
                        "sns.<REGION-NAME>.amazonaws.com",
                        "logs.<REGION-NAME>.amazonaws.com"
                    ]
                }
            }
        },
        {
            "Sid": "SQS Permissions",
            "Effect": "Allow",
            "Principal": {
                "AWS": "arn:aws:iam::<Current Account number>:root"
            },
            "Action": [
                "kms:Decrypt",
                "kms:DescribeKey",
                "kms:Encrypt*",
                "kms:GenerateDataKey*",
                "kms:ReEncrypt*",
                "kms:ListGrants",
                "kms:TagResource",
                "kms:UntagResource"
            ],
            "Resource": [
                "arn:aws:kms:*:<Current Account number>:key/*",
                "arn:aws:kms:*:<Current Account number>:alias/*"
            ],
            "Condition": {
                "StringEquals": {
                    "kms:ViaService": [
                        "sqs.<REGION-NAME>.amazonaws.com",
                        "lambda.<REGION-NAME>.amazonaws.com",
                        "sns.<REGION-NAME>.amazonaws.com"
                    ]
                }
            }
        },
        {
            "Sid": "Dynamic Services Permissions",
            "Effect": "Allow",
            "Principal": {
                "AWS": "arn:aws:iam::<Current Account number>:root"
            },
            "Action": [
                "kms:Decrypt",
                "kms:DescribeKey",
                "kms:Encrypt*",
                "kms:GenerateDataKey*",
                "kms:ReEncrypt*",
                "kms:ListGrants",
                "kms:TagResource",
                "kms:UntagResource"
            ],
            "Resource": [
                "arn:aws:kms:*:<Current Account number>:key/*",
                "arn:aws:kms:*:<Current Account number>:alias/*"
            ],
            "Condition": {
                "StringEquals": {
                    "kms:ViaService": [
                        "<SERVICE>.<REGION-NAME>.amazonaws.com"
                    ]
                }
            }
        },
        {
            "Sid": "Enable view KMS key detials in console",
            "Effect": "Allow",
            "Principal": {
                "AWS": "arn:aws:iam::<Current Account number>:root"
            },
            "Action": [
                "kms:List*",
                "kms:GetKeyRotationStatus",
                "kms:GetKeyPolicy",
                "kms:DescribeKey"
            ],
            "Resource": [
                "arn:aws:iam::<Current Account number>:key/*",
                "arn:aws:iam::<Current Account number>:alias/*"
            ]
        },
        
        {
            "Sid": "Restrict post-key-creation policy modification",
            "Effect": "Deny",
            "Principal": {
                "AWS": "*"
            },
            "Action": "kms:PutKeyPolicy",
            "Resource": "*",
            "Condition": {
                "StringNotEquals": {
                    "aws:PrincipalArn": [
                        "arn:aws:iam::<Current Account number>:key/*",
                        "arn:aws:iam::<Current Account number>:alias/*"
                    ]
                }
            }
        },
        {
            "Sid": "Allow attachment of persistent resources",
            "Effect": "Allow",
            "Principal": {
                "AWS": "arn:aws:iam::<Current Account number>:root"
            },
            "Action": [
                "kms:RevokeGrant",
                "kms:RetireGrant",
                "kms:ListGrants",
                "kms:CreateGrant"
            ],
            "Resource": "*",
            "Condition": {
                "Bool": {
                    "kms:GrantIsForAWSResource": "true"
                }
            }
        },
        {
            "Sid": "CloudWatch Permissions",
            "Effect": "Allow",
            "Principal": {
                "Service": "logs.${data.aws_region.current.name}.amazonaws.com"
            },
            "Action": [
                "kms:Describe*",
                "kms:Encrypt",
                "kms:Decrypt",
                "kms:ReEncrypt*",
                "kms:GenerateDataKey*"
            ],
            "Resource": [
                "*"
            ],
            "Condition": {
                "ArnLike": {
                    "kms:EncryptionContext:aws:logs:arn": [
                        "arn:aws:logs:${data.aws_region.current.name}:${data.aws_caller_identity.current.account_id}:*"
                    ]
                }
            }
        }
    ]
}
```

10. The KMS Key is created with "Enable" status everytime.
11. Conditional resource creation is enabled with "create_kms_key" variable, setting this variable to "true" will create the resource and setting this to "false" will skip the resource creation

## Important Note
`multi_region` variable should be used only when provisioing the `aws_kms_replica_key (KMS multi-Region replica key)` resource for disastor recovery purpose
KMS Key will be created with generic policy, if there is a need to add additional statements, Please follow the below process: https://confluence.anthem.com/display/ENTCLOUD/AWS+Key+Policy+Modification+Process. For your reference: Sample Request - RITM13640527
To update old KMS Keys with New Key Policy, Please follow the below process: https://confluence.anthem.com/display/ENTCLOUD/How+to+update+KMS+Key+Policy+for+old+AWS+KMS+Keys
KMS alias name has to be provided in the template : 
kms_alias_name = "${module.mandatory_tags.tags["application-name"]}-${module.mandatory_tags.tags["environment"]}"


## Mandatory Tags Note:

*	As per redesigned new mandatory tags, mandatory tags along with any additional tags have to be added through template configuration within the modules as below
*	Have a reference of mandatory tags module within the template configuration as shown in example script below.

```bash

# Mandatory Tag Workspace Variables
variable "apm-id" {}
variable "application-name" {}
variable "app-support-dl" {}
variable "app-servicenow-group" {}
variable "business-division" {}
variable "company" {}
variable "compliance" {}
variable "costcenter" {}
variable "environment" {}
variable "PatchGroup" {}
variable "PatchWindow" {}
variable "ATLAS_WORKSPACE_NAME" {}

# Mandatory Tags Module 
module "mandatory_tags" {
  source               = "cps-terraform.anthem.com/<ORG_NAME>/terraform-aws-mandatory-tags-v2/aws"
  tags                 = {}
  apm-id               = var.apm-id
  application-name     = var.application-name
  app-support-dl       = var.app-support-dl
  app-servicenow-group = var.app-servicenow-group
  business-division    = var.business-division
  compliance           = var.compliance
  company              = var.company
  costcenter           = var.costcenter
  environment          = var.environment
  PatchGroup           = var.PatchGroup
  PatchWindow          = var.PatchWindow
  workspace            = var.ATLAS_WORKSPACE_NAME
}
```
*	Mandatory tags module should be referred in tags attribute as below:
tags = module.mandatory_tags.tags
*	Any additional tags can be merged to tags attribute as below:
tags = merge(module.mandatory_tags.tags, {"sample" = "abc"})

## Usage
To run this example you need to execute:

```bash

# Example Script
module "kms-key" {
  source  = "cps-terraform.anthem.com/<ORGANIZATION NAME>/terraform-aws-kms-service/aws"

  tags                    = module.mandatory_tags.tags
  service_name            = ["<SERVICE-NAME>"]
  description             = "<DESCRIPTION>"
  kms_alias_name          = "${module.mandatory_tags.tags["application-name"]}-${module.mandatory_tags.tags["environment"]}"
}


#Initialize Terraform
terraform init

#Terraform Dry-Run
terraform plan

#Create the resources
terraform apply

#Destroy the resources saved in the tfstate
terraform destroy
```

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| create\_kms\_key | (Optional) "Default : true". A boolean that indicates whether to create KMS key or not. Default is true | `bool` | `true` | no |
| description | (Required) The description of the key as viewed in AWS console. | `string` | n/a | yes |
| kms\_alias\_name | (Required) KMS key alias name | `string` | n/a | yes |
| multi\_region | (Optional) "Default : false". Indicates whether the KMS key is a multi-Region (true) or regional {false). Default is false. Note: It should be enbled only for 'Distator Recovery' purpose | `bool` | `false` | no |
| service\_name | (Required) Service name to allow for KMS access in a form of list. E.g. ['s3', 'fsx'] | `list(string)` | n/a | yes |
| tags | (Required) A mapping of tags to assign to the resource | `map(string)` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| key\_id | The globally unique identifier for the key. |
| kms\_alias\_arn | The Amazon Resource Name (ARN) of the key alias. |
| kms\_arn | The Amazon Resource Name (ARN) of the key. |
| target\_key\_arn | The Amazon Resource Name (ARN) of the target key identifier. |


## Testing

1. KMS key is created for EC2 and S3 and other services.
2. Tried to create the EC2  service  with S3 KMS key it is failing. This is expected to ensure kms key can be used by that service only.
3. The KMS key alias name is generated in the form alias/sc-var.application-var.environment-service_name-V1 to reflect one key per service per application.  
4. Alias name created if the given alias name doesn't exist in the account.
5. If changing the Service Name for an existing key, the Key is not changed, this is a expected behaviour, proves that KMS Key is immutable.
6. End user is not able to delete the tfstate file from Terraform Enterprise.
7. KMS key are SYMMETRIC and mateial gets rotated automatcally.
8. Attempt to create one key for multiple services names in the KMS module is not supported.