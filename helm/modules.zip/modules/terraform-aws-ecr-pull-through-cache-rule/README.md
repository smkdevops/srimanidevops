## Anthem ECR Terraform Module

This module creates an ECR pull through Cache rule using Terraform

## HIPAA eligibility status

1. Amazon Elastic Container Registry (ECR)


## Security Guardrail reference

[AWS Security Pattern](https://confluence.anthem.com/download/attachments/299009562/Anthem%20AWS%20Security%20Patterns%20-%20ECR%20-%20v1.docx?api=v2)

## Pre-Requisite

- Conditional resource creation is enabled with "create_ecr_pull_through_cache_rule" variable, setting this variable to "true" will create the resource and setting this to "false" will skip the resource creation.
- Ecr repository prefix and Upstream registry url parameters are mandatory.

## Usage
To run this example you need to execute:

```bash

# Example Script

module "terraform-aws-ecr-pull-through-cache-rule" {
  source  = "cps-terraform.anthem.com/<ORGANIZATION NAME>/terraform-aws-ecr-pull-through-cache-rule/aws"
  
  ecr_repository_prefix = ""
  upstream_registry_url = ""
}


#Initialize Terraform
terraform init

#Terraform Dry-Run
terraform plan

#Create the resources
terraform apply

#Destroy the resources saved in the tfstate
terraform destroy
```

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| create\_ecr\_pull\_through\_cache\_rule | Need to create a new aws batch scheduling policy True or False | `bool` | `true` | no | 
| ecr\_repository\_prefix | The repository name prefix to use when caching images from the source registry. | `string` | n/a | yes |
| upstream\_registry\_url | The registry URL of the upstream public registry to use as the source. | `string` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| registry\_id | The registry ID where the repository was created. |

## Testing 

* Created ECR Pull Through Cache Rule service.
* Able to see the pull through Cache rule in AWS console
