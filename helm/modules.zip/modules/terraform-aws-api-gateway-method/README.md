# Anthem AWS API Gateway Method Module

This module provides a HTTP Method for an API Gateway Resource.

## HIPAA eligibility status

1. Amazon API Gateway is eligible

## Security Guardrail reference

https://confluence.anthem.com/pages/viewpageattachments.action?pageId=299009562&sortBy=date&startIndex=60&preview=/299009562/370573552/Anthem%20AWS%20Security%20Patterns%20-%20API%20Gateway.docx

## Pre-Requisites

1. Rest API should be created
2. API resource ID need to be created
3. Method is required. Eg: (GET, POST, PUT, DELETE, HEAD, OPTIONS, ANY)
4. Type of authorization is required.    

## Usage
To run this example you need to execute:

```bash

module "api_method" {
  source = "cps-terraform.anthem.com/<ORGNAME>/terraform-aws-api-gateway-method/aws"

  #Parameters
  rest_api_id          = "" #module.rest_api.id
  resource_id          = "" #module.api_resource.id
  http_method          = "GET"
  authorization        = "NONE"
  authorizer_id        = ""
  authorization_scopes = []
}

#Initialize Terraform
terraform init

#Terraform Dry-Run
terraform plan

#Create the resources
terraform apply

#Destroy the resources saved in the tfstate
terraform destroy
```

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| api\_key\_required | (Optional) Specify if the method requires an API key. Defaults to false | `bool` | `false` | no |
| authorization | (Required) The type of authorization used for the method (NONE, CUSTOM, AWS\_IAM, COGNITO\_USER\_POOLS) | `string` | n/a | yes |
| authorization\_scopes | (Optional) The authorization scopes used when the authorization is COGNITO\_USER\_POOLS | `list(string)` | `null` | no |
| authorizer\_id | (Optional) The authorizer id to be used when the authorization is CUSTOM or COGNITO\_USER\_POOLS | `string` | `null` | no |
| create\_apigateway\_method | (Optional) A boolean that indicates whether to create API Gateway method or not. Default is true | `bool` | `true` | no |
| http\_method | (Required) The HTTP Method (GET, POST, PUT, DELETE, HEAD, OPTIONS, ANY) | `string` | n/a | yes |
| operation\_name | (Optional) The function name that will be given to the method when generating an SDK through API Gateway. If omitted, API Gateway will generate a function name based on the resource path and HTTP verb | `string` | `null` | no |
| request\_models | (Optional) A map of the API models used for the request's content type where key is the content type (e.g. application/json) and value is either Error, Empty (built-in models) or aws\_api\_gateway\_model's name. | `map(string)` | `null` | no |
| request\_parameters | (Optional) A map of request parameters (from the path, query string and headers) that should be passed to the integration. The boolean value indicates whether the parameter is required (true) or optional (false). | `map(string)` | `{}` | no |
| request\_validator\_id | (Optional) The ID of a aws\_api\_gateway\_request\_validator | `string` | `null` | no |
| resource\_id | (Required) The API resource ID | `string` | n/a | yes |
| rest\_api\_id | (Required) The ID of the associated REST API | `string` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| http\_method | The HTTP method |

## Testing

1. Able to create Method with the pre-requisites.
