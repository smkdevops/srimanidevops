# ElevanceHealth AWS Mandatory Tags

This is a custom module which can be leveraged in all the catalog modules. Each Service should have all the proposed/mandatory tags we have here. In addition, application teams can also add tags specific to their teams. 

## Usage

To run this example you need to execute:
	
```bash
# Example Script showing usage of new mandatory tags module: 
# Mandatory Tag Workspace Variables
variable "apm-id" {}
variable "application" {}
variable "application-name" {}
variable "app-support-dl" {}
variable "app-servicenow-group" {}
variable "business-division" {}
variable "company" {}
variable "compliance" {}
variable "costcenter" {}
variable "environment" {}
variable "PatchGroup" {}
variable "PatchWindow" {}
variable "ATLAS_WORKSPACE_NAME" {}
 
# Reference of Mandatory Tags Module
module "mandatory_tags" {
  source               = "cps-terraform.anthem.com/<ORGANIZATION NAME>/terraform-aws-new-mandatory-tags/aws"
  version              = "0.0.1"
  tags                 = {}
  apm-id               = var.apm-id
  application-name     = var.application-name
  app-support-dl       = var.app-support-dl
  app-servicenow-group = var.app-servicenow-group
  business-division    = var.business-division
  compliance           = var.compliance
  company              = var.company
  costcenter           = var.costcenter
  environment          = var.environment
  PatchGroup           = var.PatchGroup
  PatchWindow          = var.PatchWindow
  workspace            = var.ATLAS_WORKSPACE_NAME
}
 
# Example KMS Module to show how to use new mandatory tags module to pass mandatory tags.
module "kms-key" {
  source  = "cps-terraform.anthem.com/<ORGANIZATION NAME>/terraform-aws-kms-service/aws"
  version = "0.3.5"
 
# Different ways of passing/merging mandatory tags:
  tags    = merge(module.mandatory_tags.tags, var.additional_tags)
  tags    = merge(module.mandatory_tags.tags, {"abc" = "test"})
  tags    = module.mandatory_tags.tags
 
  service_name = ["ec2"]
  description  = "KMS Key"
}
 
variable "additional_tags" {
   default = {
     "abc" = "test"
   }
 }
 
#Initialize Terraform
terraform init
 
#Terraform Dry-Run
terraform plan
	
#Create the resources
terraform apply
	
#Destroy the resources saved in the tfstate
terraform destroy
```

## Requirements

| Name | Version |
|------|---------|
| terraform | >= 0.12 |

## Providers

No provider.

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| PatchGroup | PatchGroup tag will be added automatically for every instance that gets spun up with value Default Make sure you add this to all automation templates (CFT or Terraform) This will have only one value ALLOWED VALUES: • Default | `string` | n/a | yes |
| PatchWindow | PatchWindow tag will be added automatically for every instance that get spun up with value Default. But you need to update your automation templates (CFT or Terraform) if you would like to control the patching window. | `string` | n/a | yes |
| apm-id | APM ID Number (https://elevancehealth.service-now.com/apm?id=apm_home_page_anthem). Example: APM1006369 | `string` | n/a | yes |
| app-servicenow-group | Application SNOW Group to which auto ticketing incidents or alerts can be assigned to in case of issues with resources. | `string` | n/a | yes |
| app-support-dl | application-dl is now app-support-dl. Pass appropriate value. | `string` | n/a | yes |
| application-name | Based upon application nomenclature in server naming convention policy.Use up to six (6) characters to name your application. | `string` | n/a | yes |
| business-division | Based upon BU that owns the resource | `string` | n/a | yes |
| company | Based upon company that owns the resource | `string` | n/a | yes |
| compliance | Allowed Values : PHI, PCI, PII, PHI-PII, SOX, None. | `string` | n/a | yes |
| costcenter | A valid 10-digit costcenter number must be used EXAMPLE: 0123456789 | `string` | n/a | yes |
| environment | DBx,SIT,PERF,PRODX,UAT,UTILx | `string` | n/a | yes |
| tags | Any other tags that needs to be attached to the resource | `map(string)` | `{}` | no |
| workspace | Name of the TFE workspace. | `string` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| tags | n/a |