# Dynamodb Single-AZ/Multi-AZ

This template provisions Dynamodb with enhanced monitoring, CloudWatch Contributor Insights enabled and KMS to encrypt database.

## Dynamodb Module reference

[Terraform Dynamodb](https://bitbucket.anthem.com/projects/ACSC/repos/terraform-aws-dynamodb/browse)

# Release Notes:
## New Version - 0.0.5
1. With Mandatory Tags Redesign that happened early part of this year, we had to refactor all our templates to include central Mandatory Tag Module and remove variable references from the code.
2. All the new templates has been pushed in and you should be able to see the changes. Below are the highlights.
3. Added Deletion protection variable. 

### Adoption of the New Version - 0.0.5

1.	There is a new file tags.tf that is now included and integral part of our code base.
2.	We now have only Application Specific Tags in DMS modules of each templates. The entire code is now bit sleek. 
3.	Each module refers to mandatory tags module.

## Prerequisite

1. Login to the TARGET AWS Accounts prior to executing TFE Modules to make sure none of the Services you are trying to provision are already created via UI/CLI. Any manually precreated assets cannot be managed by TFE.
2. Please send out an email to dl-CCOE-Cloud-Service-Catalog@anthem.com for getting access to this bitbuket repo [AnthemDB-DynamoDB-Single/MultiAZ](https://bitbucket.anthem.com/projects/ACSCT/repos/anthemdb-dynamodb/browse). This repo contains the template for Provisioning Dynamo DB.
3. After getting the access Clone the Repository, Make the necessary changes in the Template and run init.
4. DB Encryption is enforced using dynamically generated CMK.
5. Configured provider.tf file with organization, hostname and workspace name.

```bash
terraform {
  backend "remote" {
    hostname     = "<TFE-URL>"
    organization = "<ORGANIZATION-NAME>"
    workspaces {
      name = "<WORKSPACE-NAME>"
    }
  }
}
```
4. Set organization name in the source of the modules. <ORGANIZATION-NAME>
```bash
source  = "cps-terraform.anthem.com/<ORGANIZATION-NAME>/terraform-aws-kms-service/aws"
```
5. All Key Attributes (for GSI and LSI) must be defined in dynamodb_attributes. Non Key Attributes for GSI/LSI must be defined in non_key_attributes 

## Notes
- For any DB Issues related to this provisioning, please open [Incident Ticket](https://anthem.service-now.com/ess?id=ant_sc_cat_item&sys_id=e420efc0db889f40eed27bedae9619d7) and assign it to Deloitte Cloud Database Support.
- The parameters of GSI and LSI must be passed in the form of a list of objects. e.g: :
```bash
  global_secondary_index_map = [
      {
        index_name         = "scores"
        hash_key           = "TopScore" 
        range_key          = "GamerID"
        write_capacity     = 5
        read_capacity      = 5
        projection_type    = "INCLUDE" 
        non_key_attributes = ["Country"] 
     },
      {
        index_name         = "countries"
        hash_key           = "Country" 
        range_key          = "GamerID"
        write_capacity     = 5
        read_capacity      = 5
        projection_type    = "ALL"
        non_key_attributes = null
     }   
  ]
```

## Usage

To run this example you need to execute:

```bash
#Initialize Terraform
terraform init

#Terraform Dry-Run
terraform plan

#Create the resources
terraform apply

#Destroy the resources saved in the tfstate
terraform destroy
```

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| Patch-Group | Patch Group tag will be added automatically for every instance that gets spun up with value Default. Allowed values: Default | `string` | n/a | yes |
| Patch-Window | Patch Group tag will be added automatically for every instance that gets spun up with value Default. Please refer to documentation for allowed values. | `string` | n/a | yes |
| app-servicenow-group | Application snow group to which auto ticketing incidents or alerts can be assigned to in case of issues with resources | `string` | n/a | yes |
| app-support-dl | App support DL tag | `string` | n/a | yes |
| application | Based upon application nomenclature in server naming convention policy.Use up to six (6) characters to name your application. | `string` | n/a | yes |
| backup-enabled | Whether to enable point-in-time recovery - note that it can take up to 10 minutes to enable for new tables. If the point\_in\_time\_recovery block is not provided then this defaults to false. | `string` | `false` | no |
| barometer-it | The barometer it number. | `string` | n/a | yes |
| billing\_mode | Controls how you are charged for read and write throughput and how you manage capacity. The valid values are PROVISIONED and PAY\_PER\_REQUEST. Defaults to PROVISIONED. | `string` | `"PROVISIONED"` | no |
| company | Based upon company that owns resource. | `string` | n/a | yes |
| compliance | PHI, PCI, PII, SOX, None | `string` | n/a | yes |
| costcenter | The project cost center. | `string` | n/a | yes |
| database-platform | Names of the Database | `string` | n/a | yes |
| database-state | State providing direction for InfoHub to manage Metadata elements. | `string` | n/a | yes |
| db-patch-schedule | Schedules coordinated with Application Team. As general guidelines, we don't want to patch Databases during Q4 due to Annual Enrollment and Holiday season.  We also don't want to AWS Auto Patch Schedule used for Data Platforms as there are application dependency in play. | `string` | n/a | yes |
| db-patch-time-window | 2-Hour slots Weekend Window for Patching starting late Friday night till Sunday evening 6pm US EST. | `string` | n/a | yes |
| dynamodb\_attributes | Additional DynamoDB attributes in the form of a list of mapped values | <pre>list(object({<br>    name = string<br>    type = string<br>  }))</pre> | `[]` | no |
| environment | Allowed values are 'proof\_of\_concept', 'development', 'integration', 'user\_acceptance', 'testing', 'performance', 'production'. | `string` | n/a | yes |
| financial-internal-data | Allowed values can only be 'y' or 'n' case insensitive. | `string` | n/a | yes |
| financial-regulatory-data | Allowed values can only be 'y' or 'n' case insensitive. | `string` | n/a | yes |
| global\_secondary\_index\_map | A list of GSI parameters. | <pre>list(object({<br>    index_name         = string<br>    hash_key           = string<br>    non_key_attributes = list(string)<br>    projection_type    = string<br>    range_key          = string<br>    read_capacity      = number<br>    write_capacity     = number<br>  }))</pre> | n/a | yes |
| hash\_key | The attribute to use as the hash (partition) key. Must also be defined as an attribute. | `string` | n/a | yes |
| hash\_key\_type | Attribute type, which must be a scalar type: S, N, or B for (S)tring, (N)umber or (B)inary data | `string` | n/a | yes |
| kms\_key\_arn | The ARN of the CMK that should be used for the AWS KMS encryption. | `string` | n/a | yes |
| legal-data | Allowed values can only be 'y' or 'n' case insensitive. | `string` | n/a | yes |
| local\_secondary\_index\_map | A list of LSI parameters | <pre>list(object({    <br>    index_name         = string<br>    range_key          = string<br>    projection_type    = string<br>    non_key_attributes = list(string)<br>  }))</pre> | n/a | yes |
| owner-department | The name of the department owner. | `string` | n/a | yes |
| privacy-data | Allowed values can only be 'y' or 'n' case insensitive. | `string` | n/a | yes |
| range\_key | The attribute to use as the range (sort) key. Must also be defined as an attribute. | `string` | `null` | no |
| range\_key\_type | Attribute type, which must be a scalar type: S, N, or B for (S)tring, (N)umber or (B)inary data | `string` | n/a | yes |
| read\_capacity | The number of read units for this table. If the billing\_mode is PROVISIONED, this field is required. | `string` | n/a | yes |
| resource-type | Based upon the type of resource. | `string` | n/a | yes |
| schedule-window | Used to identify the window for a resource to be started or stoppedautomatically from cost optimization stand point. | `string` | n/a | yes |
| serial\_number | Database Identifier Serial number | `string` | n/a | yes |
| stream-enabled | Indicates whether Streams are to be enabled (true) or disabled (false). | `string` | n/a | yes |
| stream-view-type | When an item in the table is modified, StreamViewType determines what information is written to the table's stream. Valid values are KEYS\_ONLY, NEW\_IMAGE, OLD\_IMAGE, NEW\_AND\_OLD\_IMAGES. | `string` | n/a | yes |
| table\_name | The name for the DyanmoDB table | `string` | n/a | yes |
| tags | Additional tags (e.g. `map(`BusinessUnit`,`XYZ`)` | `map` | `{}` | no |
| ttl-attribute-name | The name of the table attribute to store the TTL timestamp in. | `string` | n/a | yes |
| ttl-enabled | Indicates whether ttl is enabled (true) or disabled (false). | `string` | n/a | yes |
| write\_capacity | The number of write units for this table. If the billing\_mode is PROVISIONED, this field is required. | `string` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| attributes | attributes of table |
| dynamodb-arn | The ARN of the DynamoDB. |
| dynamodb-id | The ID of the DynamoDB. |
| dynamodb-name | The ID of the DynamoDB. |
| dynamodb-stream-arn | DynamoDB table stream ARN |
| dynamodb-stream-label | DynamoDB table stream label |
