## Elevance Health EKS Fargate Profile Module

This module will create a EKS Fargate Profile.

## HIPPA eligibility status

1. AWS EKS is eligible.

## Security Guardrail reference

https://confluence.anthem.com/pages/viewpageattachments.action?pageId=299009562&sortBy=date&startIndex=0&preview=/299009562/407571792/Anthem%20AWS%20Security%20Patterns%20-%20AWS-EKS-BUNDLE.docx

## Pre-Requisite

1. This module is to create the EKS Fargate Profile. Below resources will be created as part of this module.
    * AmazonEKSFargatePodExecutionRolePolicy Policy
    * inline policy to send logs to cloud watch
    * IAM Role with above two policies attached
    * Fargate Profile
2. For this module, the EKS cluster has to be attached or created first.
3. Required IAM role is created within the module.
4. AmazonEKSFargatePodExecutionRolePolicy is attached to the IAM Role.
5. Below Cloud Watch policy is attached to the IAM role.
```json
{
    "Statement": [
        {
            "Action": [
                "logs:CreateLogStream",
                "logs:CreateLogGroup",
                "logs:DescribeLogStreams",
                "logs:PutLogEvents"
            ],
            "Effect": "Allow",
            "Resource": "*"
        }
    ],
    "Version": "2012-10-17"
}
```
6. Currently Fargate deploys pods only in private subnets. We need to pass only private subnets details while creating fargate.
7. Once Fargate Profile is created we cannot change/modify anything. If we try to update anything it will destroy the existing fargate profile and creates a new profile.

## Usage

To run this example you need to execute:

```bash
#Example script
module "eks_cluster" {
  source = "cps-terraform.anthem.com/CORP/terraform-aws-eks-cluster/aws"

  environment      = ""
  company          = ""
  costcenter       = ""
  owner-department = ""
  it-department    = ""
  barometer-it-num = ""
  application      = ""
  resource-type    = "eks"
  layer            = ""
  compliance       = ""
  application_dl   = ""
  tags             = {}

  cluster_name = ""
  master_user  = ""  
  # additional_roles = [   
  #   {
  #   rolearn  = "arn:aws:iam::<ACCOUNT NUMBER>:role/<ROLE NAME>"
  #   username = "system:node:{{EC2PrivateDNSName}}"
  #   groups = [
  #     "system:bootstrappers",
  #     "system:nodes",
  #     "apps",
  #     "batch",
  #     "extensions",
  #     "rbac.authorization.k8s.io"
  #   ]
  #   },
  #   {
  #   rolearn  = "arn:aws:iam::<ACCOUNT NUMBER>:role/<ROLE NAME>"
  #   username = "system:node:{{EC2PrivateDNSName}}"
  #   groups = [
  #     "system:bootstrappers",
  #     "system:nodes"
  #   ]
  #   }
  # ]
}

module "fargate" {
    source = "cps-terraform.anthem.com/<ORG_NAME>/terraform-aws-eks-fargate-profile/aws"
    tags                 = module.mandatory_tags.tags
    cluster_name         = module.eks_cluster.cluster_id
    fargate_profile_name = "default"
    subnet_ids = ["subnet-0d154855b1c2ec937", "subnet-0d47fa8aedf1c220b"]
    namespaces_selector = [
    {
      namespace = "kube-public"
      labels = {
        "app" = "nginx"
      }
    },
    {
      namespace = "kube-node-lease"
      labels = {
        "app" = "apache"
        "key" = "httpd"
      }
    }
    ]
}

#Example kubernetes.tf script, to include within the test build script.
  terraform {
    required_providers {
      kubernetes = {
        source = "hashicorp/kubernetes"
      }
    }
  }

  data "aws_eks_cluster" "cluster" {
    name = module.eks_cluster.cluster_id
  }

  data "aws_eks_cluster_auth" "cluster" {
    name = module.eks_cluster.cluster_id
  }

  provider "kubernetes" {  
    host                   = data.aws_eks_cluster.cluster.endpoint
    cluster_ca_certificate = base64decode(data.aws_eks_cluster.cluster.certificate_authority.0.data)
    token                  = data.aws_eks_cluster_auth.cluster.token
  }



#Initialize Terraform
terraform init

#Terraform Dry-Run
terraform plan

#Create the resources
terraform apply

#Destroy the resources saved in the tfstate
terraform destroy
```

## Providers

| Name | Version |
|------|---------|
| aws | n/a |
| kubernetes | n/a |
| null | n/a |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| cluster\_name | Name of the EKS cluster. | `string` | n/a | yes |
| fargate\_profile\_name | Name to the Fargate Profile | `string` | n/a | yes |
| namespaces\_selector | Namespaces that needs to be managed by Fargate | <pre>list(object({<br>  namespace = string<br>  labels = map(string)<br>  }))</pre> | n/a | yes |
| subnet\_ids | Identifiers of EC2 Subnets to associate with the EKS Node Group. These subnets must have the following resource tag: kubernetes.io/cluster/CLUSTER\_NAME (where CLUSTER\_NAME is replaced with the name of the EKS Cluster). | `list(string)` | n/a | yes |
| tags | A mapping of tags to assign to all resources | `map(string)` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| id | EKS Cluster name and EKS Fargate Profile name separated by a colon (:). |

## Testing

1. Created Cluster and Fargate Profile.
2. Could see the IAM ROle created with the required policies
2. Could see the Fargate profile created in the cluster
3. Created a sample deployment and could see the pods running in Fargate Nodes.
4. Could see the logs forwarded to Cloud Watch.