# Anthem AWS ECR Terraform Module

This module creates AWS ECR Registery Scanning Configuration

## Pre-Requisite

* Conditional resource creation is enabled with "create_ecr_registry_scanning_configuration" variable, setting this variable to "true" will create the resource and setting this to "false" will skip the resource creation.
* scan type parameter is mandatory.



## Usage

To run this example you need to execute:

```bash
#Example script

module "terraform-aws-ecr-registry-scanning-configuration" {
  source = "cps-terraform.anthem.com/<ORGANIZATION NAME>/terraform-aws-ecr-registry-scanning-configuration/aws"
  
  /******** Parameter required for resource creation ******/
 
  scan_type = ""

  /******** Optional Parameters *******/

rule = [{
    scan_frequency = ""
      }] 
  repository_filter = [{    
      filter      = ""
      filter_type = ""
      }]                         
}

#Initialize Terraform
terraform init

#Terraform Dry-Run
terraform plan

#Create the resources
terraform apply

#Destroy the resources saved in the tfstate
terraform destroy
```
## Providers

| Name | Version |
|------|---------|
| aws | n/a |


## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| create\_ecr\_registry\_scanning\_configuration | Need to create a new aws batch scheduling policy True or False | `bool` | `true` | no |
| repository\_filter | Default : [].Repository filter blocks, containing a filter and a filter\_type (required string, currently only WILDCARD is supported).. | `any` | `[]` | no |
| rule | Default : [].Scanning rules to determine which repository filters are used and at what frequency scanning will occur. | `any` | `[]` | no |
| scan\_type | The scanning type to set for the registry. Can be either ENHANCED or BASIC. | `string` | `"BASIC"` | yes |

## Outputs

| Name | Description |
|------|-------------|
| registry\_id | The registry ID the scanning configuration applies to. |

## Unit Testing 

* Created AWS ECR Registery Scanning Configuration service.
* Able to see the ECR Registery scanning configuration in AWS console
