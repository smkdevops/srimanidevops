# Anthem Lambda event invoke config Module

This module create a success or failure destination in lambda function for asynchornous event execution.

## HIPAA eligibility status

NA. This is supporting module for lambda.

## Security Guardrail reference

NA. This is supporting module for lambda.

## Pre-Requisite

1. The Lambda function should be exist.
2. Either success destination or failure destination should be mention. Both can not be null.
3. The destination configuration works only with asynchronous invocation.

## Usage
To run this example you need to execute:

```bash
#Initialize Terraform
terraform init

#Terraform Dry-Run
terraform plan

#Create the resources
terraform apply

#Destroy the resources saved in the tfstate
terraform destroy
```

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| failure\_destination | Amazon Resource Name (ARN) of the destination resource for failure event. See the Lambda Developer Guide for acceptable resource types and associated IAM permissions. | `string` | n/a | yes |
| function\_name | Name or Amazon Resource Name (ARN) of the Lambda Function, omitting any version or alias qualifier. | `string` | n/a | yes |
| maximum\_event\_age\_in\_seconds | Default : 60 . Maximum age of a request that Lambda sends to a function for processing in seconds. Valid values between 60 and 21600. | `number` | `60` | no |
| maximum\_retry\_attempts | Default : 2 . Maximum number of times to retry when the function returns an error. Valid values between 0 and 2. Defaults to 2. | `number` | `2` | no |
| qualifier | Default : "$LATEST" . Lambda Function published version, $LATEST, or Lambda Alias name. | `string` | `"$LATEST"` | no |
| success\_destination | Amazon Resource Name (ARN) of the destination resource for success event. See the Lambda Developer Guide for acceptable resource types and associated IAM permissions. | `string` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| id | Fully qualified Lambda Function name or Amazon Resource Name (ARN) |


## Testing

1. Created SQS and SNS destnation for lambda
2. executed lambda asynchonously using AWS CLI.
3. Could see the message appear in the SQS queue.