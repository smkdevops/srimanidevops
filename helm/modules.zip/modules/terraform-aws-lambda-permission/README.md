# Anthem AWS Lambda permission Module

This module creates Resource policy to Lambda function

## Pre-requisite

* Action,function name and principal attributes are mandatory
* Conditional resource creation is enabled with "create_lambda_permission" variable, setting this variable to "true" will create the resource and setting this to "false" will skip the resource creation.

## Usage
To run this example you need to execute:

```bash
#Example script

module "lambda-permission" {
  source = "cps-terraform.anthem.com/<ORGANIZATION NAME>/terraform-aws-lambda-permission/aws"

   /******** Parameter required for resource creation ******/

  action              = ""
  function_name       = ""
  principal           = ""
  source_arn          = ""
  statement_id        = ""
  
  /******** Optional Parameters *******/

  qualifier           = ""
  source_account      = ""
  event_source_token  = ""
  statement_id_prefix = ""
}

#Initialize Terraform
terraform init

#Terraform Dry-Run
terraform plan

#Create the resources
terraform apply

#Destroy the resources saved in the tfstate
terraform destroy
```

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| action | The AWS Lambda action you want to allow in this statement. | `string` | n/a | yes |
| create\_lambda\_permission | Need to create a new lambda permission True or False | `bool` | `true` | no |
| event\_source\_token | The Event Source Token to validate. | `string` | `null` | no |
| function\_name | Name of the Lambda function whose resource policy you are updating | `string` | n/a | yes |
| principal | The principal who is getting this permission. | `string` | n/a | yes |
| qualifier | Query parameter to specify function version or alias name. | `string` | `null` | no |
| source\_account | This parameter is used for S3 and SES. | `string` | `null` | no |
| source\_arn | When the principal is an AWS service, the ARN of the specific resource within that service to grant permission to. | `string` | `null` | no |
| statement\_id | A unique statement identifier. | `string` | `null` | no |
| statement\_id\_prefix | A statement identifier prefix. | `string` | `null` | no |

## Testing

* AWS Secrets Manager:
  1) Created Lambda funtion(eg:arn:aws:lambda:us-east-1:270824727330:function:test).
  2) Created Secrets Manager service(eg:arn:aws:secretsmanager:us-east-1:270824727330:secret:test5-ZTAAzB). Attached lambda function to secrets manager service to rotate secrets.
  3) executed the lambda permission script the particular secrets manager service got access to invoke lambda function.
  4) Whenever the secrets manager service rotates it will invoke lambda and it will rotate secrets.
  5) Check the cloud watch logs in monitoring tab in lambda function.
  