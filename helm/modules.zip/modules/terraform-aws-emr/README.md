# Anthem AWS EMR Terraform Module

This module creates a AWS EMR cluster using terraform

## HIPAA eligibility status

1. Amazon Elastic MapReduce (Amazon EMR) is eligible.
2. Amazon Auto Scaling is eligible.

## Security Guardrail reference

https://confluence.anthem.com/pages/viewpageattachments.action?pageId=299009562&sortBy=date&startIndex=60&preview=/299009562/363703199/Anthem%20AWS%20Security%20Patterns%20-%20AWS_EMR.docx

## Pre-requisite

1. This is to create EMR cluster by assuming that the required roles and permissions, KMS key, Security group, security configuration are in place.
2. For Multi master, the termination policy is enabled by default. 
3. Configuration should be specified in the configuration.json for the services whereever it is required i.e like for Hive, Presto glue catalog or external metastore is required while creating multi master cluster. 
4. Ensure to provide all the inputs required for the ami  you are using.
5. AMI should be compatible and optimized for EMR.
6. S3 bucket should be mentioned in the log URI to generate the logs. Ensure that the access log is enabled on the s3 bucket. 
7. Min Capacity and Max capacity need to be passed for auto scaling group.
8. ASG will be configured with the scale out rule "if Memory Available Percentage is less than 15".
9. Steps are optional to configure.
10. In-Transit encryption(https://) is mandatory. The non ssl(http:// and port 80) is not allowed. So ensure that security configuration is created with in-transit encryption.
11. At-rest encryption is mandatory. so ensure that the security configuration is created with at-rest encryption and with valid KMS Key.
12. With bootstrap action dynamic block, multiple bootstrap actions can be passed, path and name are required and args is optional.
13. Managed scaling policy is optional. if you want to use Managed scaling policy pass set_managed_policy variable as true.
14. target_on_demand_capacity is conflicting with target_spot_capacity while creating EMR cluster with fleet option.
15. Instance type config block is mandatory while creating instance fleet. User can pass one or more instance type config block.
16. While creating EMR cluster either instance fleet or instance group can be opted.
17. While EMR Cluster creating using Core instance group alteast one Master instance group needs to be specify.
18. While EMR Cluster creating with Core instance fleet alteast one Master instance fleet needs to be specify.
19. If user wants to provide vpc_id variable then can pass otherwise it will take by default
20. Below is the sample example Autoscaling policy.
``` bash
    {
    "Constraints": {
      "MinCapacity": 1,
      "MaxCapacity": 2
    },
    "Rules": [
      {
        "Name": "ScaleOutMemoryPercentage",
        "Description": "Scale out if YARNMemoryAvailablePercentage is less than 15",
        "Action": {
          "SimpleScalingPolicyConfiguration": {
            "AdjustmentType": "CHANGE_IN_CAPACITY",
            "ScalingAdjustment": 1,
            "CoolDown": 300
          }
        },
        "Trigger": {
          "CloudWatchAlarmDefinition": {
            "ComparisonOperator": "LESS_THAN",
            "EvaluationPeriods": 1,
            "MetricName": "YARNMemoryAvailablePercentage",
            "Namespace": "AWS/ElasticMapReduce",
            "Period": 300,
            "Statistic": "AVERAGE",
            "Threshold": 15.0,
            "Unit": "PERCENT"
          }
        }
      }
    ]
    }
```
21. When User want to use existing kms keys to create EMR security configuration, the below policy should be added to KMS Key policy, otherwise the the EMR cluster will fail with below similar error.
```bash
│ Error: error waiting for EMR Cluster (j-xxxxxx) to create: unexpected state 'TERMINATING', wanted target 'RUNNING, WAITING'. last error: VALIDATION_ERROR: On the master instance (i-xxxxxxx), User: arn:aws:sts::xxxxx:assumed-role/cluster_role_xxxx/i-xxxxxxx is not authorized to perform: kms:GenerateDataKey on resource: arn:aws:kms:awsregion:xxxxxx:key/xxx-xxx-xxxx-xxxx-xxxxx because no resource-based policy allows the kms:GenerateDataKey action
```
```bash
statement {
    sid    = "EC2 Permissions EMR"
    effect = "Allow"
    principals {
      type        = "AWS"
      identifiers = [""] #[var.emr_cluster_role] The EMR cluster iam role arn
    }
    actions = [
      "kms:Encrypt",
      "kms:Decrypt",
      "kms:ReEncrypt*",
      "kms:GenerateDataKey*",
      "kms:DescribeKey",
      "kms:CreateGrant",
      "kms:TagResource",
      "kms:UntagResource"
    ]
    resources = ["*"]
  }
```
22. To enable step_concurrency_level, ensure your release label is greater than 5.28.0. Min and Max concurrency levels are 1 and 256.

## Mandatory Tags Note:
*	As per redesigned new mandatory tags, mandatory tags along with any additional tags have to be added through template configuration within the modules as below
*	Have a reference of mandatory tags module within the template configuration as shown in example script below.
```bash
# Mandatory Tag Workspace Variables
variable "apm-id" {}
variable "application-name" {}
variable "app-support-dl" {}
variable "app-servicenow-group" {}
variable "business-division" {}
variable "company" {}
variable "compliance" {}
variable "costcenter" {}
variable "environment" {}
variable "PatchGroup" {}
variable "PatchWindow" {}
variable "ATLAS_WORKSPACE_NAME" {}

# Mandatory Tags Module 
module "mandatory_tags" {
  source               = "cps-terraform.anthem.com/<ORG_NAME>/terraform-aws-mandatory-tags-v2/aws"
  tags                 = {}
  apm-id               = var.apm-id
  application-name     = var.application-name
  app-support-dl       = var.app-support-dl
  app-servicenow-group = var.app-servicenow-group
  business-division    = var.business-division
  compliance           = var.compliance
  company              = var.company
  costcenter           = var.costcenter
  environment          = var.environment
  PatchGroup           = var.PatchGroup
  PatchWindow          = var.PatchWindow
  workspace            = var.ATLAS_WORKSPACE_NAME
}
```
*	Mandatory tags module should be referred in tags attribute as below:
tags = module.mandatory_tags.tags
*	Any additional tags can be merged to tags attribute as below:
tags = merge(module.mandatory_tags.tags, {"sample" = "abc"})


## Important Note

Usecase1:
1. This module will also create Security groups and IAM roles and EMR security configuration internally when creating EMR Cluster.

``` bash
## Usage1
module "terraform_aws_emr" {
  source = "cps-terraform.anthem.com/<ORG_NAME>/terraform-aws-emr/aws"

  tags          = merge(module.mandatory_tags.tags)
  cluster_name  = ""
  custom_ami_id = ""
  subnet_id     = ""
  #master_instance_group = []

  master_instance_group = [{
    instance_type = "m5.xlarge"
    name          = ""
    #bid_price      = ""
    #instance_count = 1

    #ebs_config = [{
    #   size = ""
    #  type = ""
    # iops = ""
    #volumes_per_instance = ""
    #}]

  }]

  #autoscaling_policy = file("./test.json")

  core_instance_group = [{
    instance_type = "m5.xlarge"
    #bid_price          = ""
    instance_count = 1
    name           = ""

    #ebs_config = [{
    #   size = ""
    #  type = ""
    # iops = ""
    #volumes_per_instance = ""
    # }]
  }]

  #vpc_id = "vpc-06627122cac92dc7f"
  #"vpc-03b408c5330c3936d"
  #additional_info = "./additional_info.json"
  #applications = ["Hadoop","Hive","Spark"]
  #bootstrap_action = ""
  #configurations_json = "./configurations.json"
  #ebs_root_volume_size              = 40
  #log_uri                           = ""
  #MaximumCapacityUnits          = 10
  #MaximumCoreCapacityUnits      = 2
  #MinimumCapacityUnits          = 3
  #OnDemandLimit                 = 2
  #release_label                 = "emr-5.30.0"
  #scale_down_behavior           = "TERMINATE_AT_TASK_COMPLETION"
  #set_managed_policy            = false
  #termination_protection        = false
  #visible_to_all_users          = true
  /*
  master_instance_fleet = [{
    name                      = ""
    target_on_demand_capacity = 1
    target_spot_capacity      = null

    instance_type_configs = [{
      instance_type = "m4.xlarge"

    }]
  }]
  */
  /*
  core_instance_fleet =[{
    name                      = ""
    target_on_demand_capacity = 1
    #target_spot_capacity      = ""
    instance_type_configs = [{
        instance_type                              = "m4.xlarge"
        #bid_price                                  = ""
        #bid_price_as_percentage_of_on_demand_price = ""
        #weighted_capacity = ""
        #configurations = [{
         #   classification = ""
          #  properties     = ""
        #}]
        #ebs_config = [{
        #size = ""
        #type = ""
        #iops = ""
        #volumes_per_instance = ""
      #}]
    }]
  }]
  */
  ####### To create IAM Roles, SG's and EMR Security Configuration internally when creating EMR Cluster, Need to add below dependent parameters to the module code #######
  create_cluster_iam_role             = true
  create_cluster_iam_instance_profile = true
  cluster_iam_servicerole             = true
  create_emr_cluster                  = true
  create_master_security_group        = true
  create_worker_security_group        = true
  create_cluster_security_group       = true
  create_s3_kms_key                   = true
  create_ec2_kms_key                  = true
  create_emr_security_configuration   = true
}
```
Usecase2:
1. Security groups and IAM Roles and S3 & EC2 KMS Keys with required policy have to be created before creating the EMR cluster.
2. Once Security groups are created we need to add security group ids into the cluster.
3. As security groups have cyclical dependenecy we need to create security group first and need to attach all the security group ids in ingress rules.

``` bash
## Usage2
############## EMR Cluster ########################
module "terraform_aws_emr" {
  source = "cps-terraform.anthem.com/<ORG_NAME>/terraform-aws-emr/aws"

  tags          = merge(module.mandatory_tags.tags)
  cluster_name  = ""
  custom_ami_id = ""
  subnet_id     = ""
  #master_instance_group = []

  master_instance_group = [{
    instance_type = "m5.xlarge"
    name          = ""
    #bid_price      = ""
    #instance_count = 1

    #ebs_config = [{
    #   size = ""
    #  type = ""
    # iops = ""
    #volumes_per_instance = ""
    #}]

  }]

  #autoscaling_policy = file("./test.json")

  core_instance_group = [{
    instance_type = "m5.xlarge"
    #bid_price          = ""
    instance_count = 1
    name           = ""

    #ebs_config = [{
    #   size = ""
    #  type = ""
    # iops = ""
    #volumes_per_instance = ""
    # }]
  }]

  #vpc_id = "vpc-06627122cac92dc7f"
  #"vpc-03b408c5330c3936d"
  #additional_info = "./additional_info.json"
  #applications = ["Hadoop","Hive","Spark"]
  #bootstrap_action = ""
  #configurations_json = "./configurations.json"
  #ebs_root_volume_size              = 40
  #log_uri                           = ""
  #MaximumCapacityUnits          = 10
  #MaximumCoreCapacityUnits      = 2
  #MinimumCapacityUnits          = 3
  #OnDemandLimit                 = 2
  #release_label                 = "emr-5.30.0"
  #scale_down_behavior           = "TERMINATE_AT_TASK_COMPLETION"
  #set_managed_policy            = false
  #termination_protection        = false
  #visible_to_all_users          = true
  /*
  master_instance_fleet = [{
    name                      = ""
    target_on_demand_capacity = 1
    target_spot_capacity      = null

    instance_type_configs = [{
      instance_type = "m4.xlarge"

    }]
  }]
  */
  /*
  core_instance_fleet =[{
    name                      = ""
    target_on_demand_capacity = 1
    #target_spot_capacity      = ""
    instance_type_configs = [{
        instance_type                              = "m4.xlarge"
        #bid_price                                  = ""
        #bid_price_as_percentage_of_on_demand_price = ""
        #weighted_capacity = ""
        #configurations = [{
         #   classification = ""
          #  properties     = ""
        #}]
        #ebs_config = [{
        #size = ""
        #type = ""
        #iops = ""
        #volumes_per_instance = ""
      #}]
    }]
  }]
  */
  ########## To Use Existing IAM Roles and Instance Profile to create EMR Cluster ###########
  create_cluster_iam_role             = false
  create_cluster_iam_instance_profile = false
  cluster_iam_servicerole             = false
  cluster_iam_instance_profile_id     = module.terraform_aws_emr_ec2_instance_profile.id
  cluster_iam_servicerole_arn         = module.terraform_aws_emr_instance_profile.name
  autoscaling_role                    = module.terraform_aws_emr_ec2_instance_profile.id
  ########## To Use Existing Security Groups to create EMR Cluster ###########
  create_master_security_group        = false
  create_worker_security_group        = false
  create_cluster_security_group       = false
  master_custom_security_group_id     = module.terraform_aws_emr_master_security_group.id[0]
  worker_custom_security_group_id     = module.terraform_aws_emr_worker_security_group.id[0]
  cluster_custom_security_group_id    = module.terraform_aws_emr_service_security_group.id[0]
  ########## To create EMR Security configuration using existing s3 and ec2 KMS keys ###########
  create_ec2_kms_key                  = false
  create_s3_kms_key                   = false
  create_emr_security_configuration   = true
  ec2_kms_key_id                      = lookup(module.terraform_aws_kms_service.kms_arn, "ec2")
  s3_kms_key_id                       = lookup(module.terraform_aws_kms_service.kms_arn, "s3")
}

module "terraform_aws_kms_service" {
  source  = "cps-terraform.anthem.com/<ORG_NAME>/terraform-aws-kms-service/aws"

  service_name = ["s3", "ec2"]
  description  = "Customer Managed Key for Secrets Manager"

  kms_alias_name = "${module.mandatory_tags.tags["application-name"]}-${module.mandatory_tags.tags["environment"]}-test"
  tags           = merge(module.mandatory_tags.tags)
}


module "terraform_aws_emr_role" {
  source = "cps-terraform.anthem.com/<ORG_NAME>/terraform-aws-iam-role/aws"

  tags = module.mandatory_tags.tags
  ########### Required Parameters ##############
  iam_role_name    = ""
  role_description = ""
  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Action = "sts:AssumeRole"
        Effect = "Allow"
        Sid    = ""
        Principal = {
          Service = ["elasticmapreduce.amazonaws.com"]
        }
      },
    ]
  })
  managed_policy_arns = ["arn:aws:iam::aws:policy/AmazonS3FullAccess",
    "arn:aws:iam::aws:policy/service-role/AmazonElasticMapReduceforEC2Role",
    "arn:aws:iam::aws:policy/AmazonElasticMapReduceFullAccess"
  ]
  inline_policy = [
    {
      name   = ""
      policy = "./filename.json"
    }
  ]
}

module "terraform_aws_emr_instance_profile" {
  source = "cps-terraform.anthem.com/<ORG_NAME>/terraform-aws-iam-instance-profile/aws"
  
  tags = module.mandatory_tags.tags
  ########### Required Parameters ##############
  instance_profile_name = module.terraform_aws_emr_role.iamrole_id
  role_name             = module.terraform_aws_emr_role.iamrole_name
}

module "terraform_aws_emr_ec2_role" {
  source = "cps-terraform.anthem.com/<ORG_NAME>/terraform-aws-iam-role/aws"
  
  tags = module.mandatory_tags.tags
  ########### Required Parameters ##############
  iam_role_name    = ""
  role_description = ""
  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Action = "sts:AssumeRole"
        Effect = "Allow"
        Sid    = ""
        Principal = {
          Service = ["elasticmapreduce.amazonaws.com", "ec2.amazonaws.com", "glue.amazonaws.com", "application-autoscaling.amazonaws.com", "comprehendmedical.amazonaws.com", "lambda.amazonaws.com"]
        }
      },
    ]
  })
  managed_policy_arns = ["arn:aws:iam::aws:policy/AWSLambda_FullAccess",
    "arn:aws:iam::aws:policy/AmazonAthenaFullAccess",
    "arn:aws:iam::aws:policy/service-role/AWSGlueServiceRole",
    "arn:aws:iam::aws:policy/service-role/AmazonEC2ContainerServiceforEC2Role",
    "arn:aws:iam::aws:policy/service-role/AmazonElasticMapReduceforAutoScalingRole",
    "arn:aws:iam::aws:policy/AWSStepFunctionsFullAccess",
    "arn:aws:iam::aws:policy/AmazonS3FullAccess"
  ]
  inline_policy = [
    {
      name   = ""
      policy = "./filename.json"
    }
  ]
}

module "terraform_aws_emr_ec2_instance_profile" {
  source = "cps-terraform.anthem.com/<ORG_NAME>/terraform-aws-iam-instance-profile/aws"
  
  tags = module.mandatory_tags.tags
  ########### Required Parameters ##############
  instance_profile_name = module.terraform_aws_emr_ec2_role.iamrole_id
  role_name             = module.terraform_aws_emr_ec2_role.iamrole_name
}

module "terraform_aws_emr_autoscaling_role" {
  source = "cps-terraform.anthem.com/<ORG_NAME>/terraform-aws-iam-role/aws"
  
  tags = module.mandatory_tags.tags
  ########### Required Parameters ##############
  iam_role_name    = ""
  role_description = ""
  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Action = "sts:AssumeRole"
        Effect = "Allow"
        Sid    = ""
        Principal = {
          Service = ["elasticmapreduce.amazonaws.com", "application-autoscaling.amazonaws.com"]
        }
      },
    ]
  })
  managed_policy_arns = ["arn:aws:iam::aws:policy/service-role/AmazonElasticMapReduceforAutoScalingRole"]
  inline_policy = [
    {
      name   = ""
      policy = "./filename.json"
    }
  ]
}

module "terraform_aws_emr_master_security_group" {
  source = "cps-terraform.anthem.com/CORP/terraform-aws-sg/aws"
  
  tags = module.mandatory_tags.tags
  ########### Required Parameters ##############
  name                       = ""
  security_group_description = ""
  vpc_id                     = ""
  ingress = [
    {
      cidr_blocks     = ["10.188.212.0/22", "30.0.0.0/8", "33.0.0.0/8"]
      from_port       = 22
      to_port         = 22
      protocol        = "tcp"
      self            = false
      security_groups = []
    },
    {
      cidr_blocks     = []
      from_port       = -1
      to_port         = -1
      protocol        = "icmp"
      self            = true
      security_groups = [] #["sg-xxxxxx"] # Worker Security Group ID
    },
    {
      cidr_blocks     = []
      from_port       = 0
      to_port         = 65535
      protocol        = "tcp"
      self            = true
      security_groups = [] #["sg-xxxxxx"] # Worker Security Group ID
    },
    {
      cidr_blocks     = []
      from_port       = 0
      to_port         = 65535
      protocol        = "udp"
      self            = true
      security_groups = [] #["sg-xxxxxx"] # Worker Security Group ID
    },
    {
      cidr_blocks     = ["10.188.212.0/22"]
      from_port       = 8443
      to_port         = 8443
      protocol        = "tcp"
      self            = false
      security_groups = [] #["sg-xxxxxx"]  # Cluster Security Group ID
    }
  ]
  egress = [
    {
      "cidr_blocks" : ["0.0.0.0/0"],
      protocol  = -1
      from_port = 0
      to_port   = 0
    }
  ]
}

module "terraform_aws_emr_worker_security_group" {
  source = "cps-terraform.anthem.com/<ORG_NAME>/terraform-aws-sg/aws"
  
  tags = module.mandatory_tags.tags
  ########### Required Parameters ##############
  name                       = ""
  security_group_description = ""
  vpc_id                     = ""
  ingress = [
    {
      cidr_blocks     = ["10.188.212.0/22", "30.0.0.0/8", "33.0.0.0/8"]
      from_port       = 22
      to_port         = 22
      protocol        = "tcp"
      self            = false
      security_groups = []
    },
    {
      cidr_blocks     = ["10.188.212.0/22"]
      from_port       = -1
      to_port         = -1
      protocol        = "icmp"
      self            = true
      security_groups = [] #["sg-xxxxxx"] # Master Security Group ID
    },
    {
      cidr_blocks     = ["10.188.212.0/22"]
      from_port       = 0
      to_port         = 65535
      protocol        = "tcp"
      self            = true
      security_groups = [] #["sg-xxxxxx"] # Master Security Group ID
    },
    {
      cidr_blocks     = ["10.188.212.0/22"]
      from_port       = 0
      to_port         = 65535
      protocol        = "udp"
      self            = true
      security_groups = [] #["sg-xxxxxx"] # Master Security Group ID
    },
    {
      cidr_blocks     = ["10.188.212.0/22"]
      from_port       = 8443
      to_port         = 8443
      protocol        = "tcp"
      self            = false
      security_groups = [] #["sg-xxxxxx"] # Cluster Security Group ID
    }
  ]
  egress = [
    {
      "cidr_blocks" : [
        "0.0.0.0/0"
      ],
      protocol  = -1
      from_port = 0
      to_port   = 0
    }
  ]
}


module "terraform_aws_emr_service_security_group" {
  source = "cps-terraform.anthem.com/<ORG_NAME>/terraform-aws-sg/aws"
  
  tags = module.mandatory_tags.tags
  ########### Required Parameters ##############
  name                       = ""
  security_group_description = ""
  vpc_id                     = ""
  egress = [
    {
      cidr_blocks     = ["10.188.212.0/22"]
      from_port       = 8443
      to_port         = 8443
      protocol        = "tcp"
      self            = false
      security_groups = [] #["sg-xxxxxx","sg-xxxxxx"] # Master Security Group ID & Worker Security Group ID
    }
  ]
  ingress = [
    {
      cidr_blocks     = ["10.188.212.0/22"]
      from_port       = 9443
      to_port         = 9443
      protocol        = "tcp"
      self            = false
      security_groups = [] #["sg-xxxxxx"]  # Master Security Group ID    
    }
  ]
}
```

To run this example you need to execute:

```bash
#Initialize Terraform
terraform init

#Terraform Dry-Run
terraform plan

#Create the resources
terraform apply

#Destroy the resources saved in the tfstate
terraform destroy
```

## Providers

| Name | Version |
|------|---------|
| aws | n/a |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| MaximumCapacityUnits | (Optional) "Default : 10" .The upper boundary of EC2 units | `string` | `"10"` | no |
| MaximumCoreCapacityUnits | (Optional) "Default : 10" .The upper boundary of EC2 units for core node type in a cluster | `string` | `"10"` | no |
| MinimumCapacityUnits | (Optional) "Default : 3" .The lower boundary of EC2 units | `string` | `"3"` | no |
| OnDemandLimit | (Optional) "Default : 2" .The upper boundary of On-Demand EC2 units | `string` | `"2"` | no |
| additional\_info | (Optional) "Default : null" .A JSON string for selecting additional features such as adding proxy information. Note: Currently there is no API to retrieve the value of this argument after EMR cluster creation from provider, therefore Terraform cannot detect drift from the actual EMR cluster if its value is changed outside Terraform. | `string` | `null` | no |
| applications | (Optional) "Default : ["Hadoop", "Hive", "Presto", "Hue"]" .A list of applications for the cluster. Valid values are: Flink, Hadoop, Hive, Mahout, Pig, Spark, and JupyterHub (as of EMR 5.14.0). Case insensitive. | `list(string)` | <pre>[<br>  "Hadoop",<br>  "Hive",<br>  "Presto",<br>  "Hue"<br>]</pre> | no |
| autoscaling\_policy | (Optional) "Default : null" .String containing the EMR Auto Scaling Policy JSON. | `string` | `null` | no |
| autoscaling\_role | (Optional) "Default : null" .IAM role for automatic scaling policies. The IAM role provides permissions that the automatic scaling feature requires to launch and terminate EC2 instances in an instance group. | `string` | `null` | no |
| bootstrap\_action | (Optional) "Default : []" .List nested bootstrap action. Location of the script to run during a bootstrap action. Can be either a location in Amazon S3 or on a local file system. List of command line arguments to pass to the bootstrap action script. | `any` | `[]` | no |
| cluster\_custom\_security\_group\_id | (Optional) "Default : null" .Identifier of the Amazon EC2 service-access security group - required when the cluster runs on a private subnet. | `string` | `null` | no |
| cluster\_iam\_instance\_profile\_id | (Optional) "Default : null" .Instance Profile for EC2 instances of the cluster assume this role. | `string` | `null` | no |
| cluster\_iam\_servicerole | (Optional) "Default : true" .A boolean that indicates whether to create iam service role for emr cluster or not. | `bool` | `true` | no |
| cluster\_iam\_servicerole\_arn | (Optional) "Default : null" .IAM role that will be assumed by the Amazon EMR service to access AWS resources on your behalf. | `string` | `null` | no |
| cluster\_name | (Required) The name of the job flow | `string` | n/a | yes |
| configurations\_json | (Optional) "Default : null" .A JSON string for supplying list of configurations for the EMR cluster. | `string` | `null` | no |
| core\_instance\_count\_max | (Optional) "Default : 4" .The maximum instance count for autoscaling. | `string` | `"4"` | no |
| core\_instance\_count\_min | (Optional) "Default : 3" .The minimum instance count for autoscaling. | `string` | `"3"` | no |
| core\_instance\_fleet | (Optional) "Default : []" .Indicates to create emr cluster core instance fleet. | `any` | `[]` | no |
| core\_instance\_group | (Optional) "Default : []" .Indicates to create emr cluster core instance group. | `any` | `[]` | no |
| create\_cluster\_iam\_instance\_profile | (Optional) "Default : true" .A boolean that indicates whether to create iam instance profile for emr cluster or not. | `bool` | `true` | no |
| create\_cluster\_iam\_role | (Optional) "Default : true" .A boolean that indicates whether to create iam role for emr cluster or not. | `bool` | `true` | no |
| create\_cluster\_security\_group | (Optional) "Default : true" .A boolean that indicates whether to create cluster security group for emr cluster or not. | `bool` | `true` | no |
| create\_ec2\_kms\_key | (Optional) "Default : true". A boolean that indicates whether to create ec2 KMS key or not. Default is true | `bool` | `true` | no |
| create\_emr\_cluster | (Optional) "Default : true" .A boolean that indicates whether to create emr cluster or not. | `bool` | `true` | no |
| create\_emr\_security\_configuration | (Optional) "Default : true" .A boolean that indicates whether to create emr security configuration for emr cluster or not. | `bool` | `true` | no |
| create\_master\_security\_group | (Optional) "Default : true" .A boolean that indicates whether to create master security group for emr cluster or not. | `bool` | `true` | no |
| create\_s3\_kms\_key | (Optional) "Default : true". A boolean that indicates whether to create s3 KMS key or not. Default is true | `bool` | `true` | no |
| create\_worker\_security\_group | (Optional) "Default : true" .A boolean that indicates whether to create worker security group for emr cluster or not. | `bool` | `true` | no |
| custom\_ami\_id | (Required) A custom Amazon Linux AMI for the cluster (instead of an EMR-owned AMI). Available in Amazon EMR version 5.7.0 and later. | `string` | n/a | yes |
| ebs\_root\_volume\_size | (Optional) "Default : 40" .Size in GiB of the EBS root device volume of the Linux AMI that is used for each EC2 instance. Available in Amazon EMR version 4.x and later. | `string` | `"40"` | no |
| ec2\_kms\_key\_id | (Optional) "Default : null" .Required when create\_ec2\_kms\_key is false. EC2 kms key arn | `string` | `null` | no |
| emr\_cluster\_role | (Optional) "Default : null" .Required When create\_cluster\_iam\_role is false .IAM Role arn for EC2 instances of the cluster | `string` | `null` | no |
| keep\_job\_flow\_alive\_when\_no\_steps | (Optional) "Default : true" .Switch on/off run cluster with no steps or when all steps are complete. | `bool` | `true` | no |
| key\_name | (Optional) "Default : "" " .Amazon EC2 key pair that can be used to ssh to the master node as the user called hadoop | `string` | `""` | no |
| log\_uri | (Optional) "Default : "" " .S3 bucket to write the log files of the job flow. If a value is not provided, logs are not created | `string` | `""` | no |
| master\_custom\_security\_group\_id | (Optional) "Default : null" .Identifier of the Amazon EC2 EMR-Managed security group for the master node. | `string` | `null` | no |
| master\_instance\_fleet | (Optional) "Default : []" .Indicates to create emr cluster master instance fleet. | `any` | `[]` | no |
| master\_instance\_group | (Required) Indicates to create emr cluster master instance group. | `any` | n/a | yes |
| release\_label | (Optional) "Default : "emr-5.30.0" " .The release label for the Amazon EMR release | `string` | `"emr-5.30.0"` | no |
| s3\_kms\_key\_id | (Optional) "Default : null" .Required when create\_s3\_kms\_key is false. S3 kms key arn | `string` | `null` | no |
| scale\_down\_behavior | (Optional) "Default : "TERMINATE\_AT\_TASK\_COMPLETION" " .The way that individual Amazon EC2 instances terminate when an automatic scale-in activity occurs or an instance group is resized. | `string` | `"TERMINATE_AT_TASK_COMPLETION"` | no |
| set\_managed\_policy | (Optional) "Default : false" .Set this to true, if you want to use EMR Managed scaling policy | `bool` | `false` | no |
| steps | (Optional) "Default : []" .List of steps to run when creating the cluster. | `any` | `[]` | no |
| step\_concurrency\_level | (Optional) Number of steps that can be executed concurrently. You can specify a maximum of 256 steps. Only valid for EMR clusters with release_label 5.28.0 or greater (default is 1). | `number` | null | no | 
| subnet\_id | (Required) VPC subnet id where you want the job flow to launch. | `string` | n/a | yes |
| tags | (Required) A mapping of tags to assign to the resource | `map(string)` | n/a | yes |
| termination\_protection | (Optional) "Default : false" .Switch on/off termination protection. Before attempting to destroy the resource when termination protection is enabled, this configuration must be applied with its value set to false. | `bool` | `false` | no |
| unit\_type | (Optional) "Default : "Instances" " .The unit type used for specifying a managed scaling policy. Valid Values: InstanceFleetUnits \| Instances \| VCPU. | `string` | `"Instances"` | no |
| visible\_to\_all\_users | (Optional) "Default : true" .Whether the job flow is visible to all IAM users of the AWS account associated with the job flow. | `bool` | `true` | no |
| vpc\_id | (Optional) "Default : null" .VPC ID | `string` | `null` | no |
| worker\_custom\_security\_group\_id | (Optional) "Default : null" .Identifier of the Amazon EC2 EMR-Managed security group for the slave nodes. | `string` | `null` | no |

## Outputs

| Name | Description |
|------|-------------|
| applications | The applications installed on this cluster. |
| arn | The ARN of the cluster. |
| bootstrap\_action | A list of bootstrap actions that will be run before Hadoop is started on the cluster nodes. |
| cluster\_custom\_security\_group\_id | Security group created for EMR cluster creation |
| configurations | The list of Configurations supplied to the EMR cluster. |
| ec2\_attributes | Provides information about the EC2 instances in a cluster grouped by category: key name, subnet ID, IAM instance profile, and so on. |
| id | The ID of the EMR Cluster |
| log\_uri | The path to the Amazon S3 location where logs for this cluster are stored. |
| master\_custom\_security\_group\_id | Security group created for EMR master cluster creation |
| master\_public\_dns | The public DNS name of the master EC2 instance. |
| name | The name of the cluster. |
| release\_label | The release label for the Amazon EMR release. |
| service\_role | The IAM role that will be assumed by the Amazon EMR service to access AWS resources on your behalf. |
| tags | The list of tags associated with a cluster. |
| visible\_to\_all\_users | Indicates whether the job flow is visible to all IAM users of the AWS account associated with the job flow. |
| worker\_custom\_security\_group\_id | Security group created for EMR worker cluster creation |

## Testing

Test Usecase1:
1. EMR cluster is created with below.
2. EC2 instances are in running state.
3. The boot strap actions applied.
4. The steps are configured.
5. Log url is configured and logs are generated in s3 bucket.
6. Encryption is applied.
7. All the configurations used to create the cluster.
8. All the tags are applied.
9. Termination protection is enabled.
10. intance fleet block configured.

Test Usecase2:
1. Security Groups and IAM Roles are created
2. EMR cluster created using SG's and IAM Roles.
3. Able to see EMR cluster in AWS Console.
