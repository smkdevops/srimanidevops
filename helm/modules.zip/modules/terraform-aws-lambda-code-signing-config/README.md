# Anthem AWS Lambda Code Signing Config Module

This module provides a Lambda Code Signing Config resource. A code signing configuration defines a list of allowed signing profiles and defines the code-signing validation policy (action to be taken if deployment validation checks fail).

For information about Lambda code signing configurations and how to use them, see configuring code signing for Lambda functions.

## HIPAA eligibility status

NA. This is supporting module for lambda.

## Security Guardrail reference

NA. This is supporting module for lambda.

## Pre-Requisite

1. Signing profile version arn should exist to input.

## Usage
To run this example you need to execute:

```bash
module "lambda-code-signing-config" {
  source = "cps-terraform.anthem.com/<ORGANIZATION NAME>/terraform-aws-lambda-code-signing-config/aws"

  #Required Parameters
  signing_profile_version_arns     = ["arn:aws:iam::<ACCOUNT ID>:user/<USER>"]
  untrusted_artifact_on_deployment = ""

  #Optional Parameters
  description                      = "This is a Lambda Code Signing Config"
}

#Initialize Terraform
terraform init

#Terraform Dry-Run
terraform plan

#Create the resources
terraform apply

#Destroy the resources saved in the tfstate
terraform destroy
```

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| description | Descriptive name for this code signing configuration. | `string` | `"lambda:InvokeFunction"` | no |
| signing\_profile\_version\_arns | The Amazon Resource Name (ARN) for each of the signing profiles. | `list(string)` | n/a | yes |
| untrusted\_artifact\_on\_deployment | Code signing configuration policy for deployment validation failure | `string` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| arn | The Amazon Resource Name (ARN) of the code signing configuration. |
| config\_id | Unique identifier for the code signing configuration. |
| last\_modified | The date and time that the code signing configuration was last modified. |

## Testing

1. Able to create lambda code signing config and see it on console.