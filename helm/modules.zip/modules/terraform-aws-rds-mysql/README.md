# ElevanceHealth AWS MySQL Module 

This module creates RDS MySQL Database. The RDS mysql module handles the provisioning of Security Group, parameter group, option group and DB subnet group along with Network encryption.

# Release Notes: #
## New Version - 0.1.1 ##
1. Log Group creation for audit, error, slowquery and general logs has been added in this module.
2. Now users need to input each log group retention period accordingly in the templates. If not specified value has been defaulted to 7 days for all the log groups.
3. Log Group will be deleted as part of the decomissioning process.
4. KMS Key Module for encryption of log groups has been added in the templates.
5. Postscripts automation has been added in the templates.
6. Subscription event has been added in the template.
7. Added Pre-patch-snapshot-flag to lifecycle ignore changes.
### Adoption of the New Version - 0.1.1 ###
1. For Existing RDS instance when you update the module to latest version and run the terraform apply you will recieve an error stating log group with the given name already exists. In such Cases login to the console go to cloudwatch and under the log groups section search with the instance Identifier which is shown in the error and delete them manually and after that run the terraform apply.
2. When you are creating a new DB instance and if you recieve an error saying the log group with the name already exists then check if there is any instance available with instance identifier that is stated in the error in the console and if there is no instance available, delete the log group manually and re-run the code.
3. Additional security group rule has been added to this module with description of "ElevanceHealth PostScripts Automation", DO NOT remove this security group rule while launching DB using this template.
4. When you run the new templates an ec2 instance will be created and the postscripts are downloaded from the s3 and ec2 connects to the database and runs the postscripts. Once the postscripts are run successfully ec2 instance will be destroyed automatically. Make a note that everytime you run this module ec2 will be created and terminated.
5. For the event subscription to create, update the AWS REGION and ACCOUNT Number in sns_rds_topic_policy.json file accordingly.
6. As the tags "prepatch-snapshot-flag" is added to the lifecycle ignore changes you will not be able to modify the value from the second apply.


## RDS MySQL module reference

[Terraform RDS MySQL](https://bitbucket.elevancehealth.com/projects/ACSC/repos/terraform-aws-rds-mysql/browse)

## Reference Videos

[RDS MySQL Single-AZ/Multi-AZ Single Region Provisioning](https://mysite.wellpoint.com/personal/ag68607_ad_wellpoint_com/_layouts/15/stream.aspx?id=%2Fpersonal%2Fag68607%5Fad%5Fwellpoint%5Fcom%2FDocuments%2FRecordings%2FRDS%20MySQL%20DB%20Automation%20Template%20Demo%2D20220906%5F180801%2DMeeting%20Recording%2Emp4&ga=1)

## Pre-requisites
* VPC Id
* Raise Hashicorp Vault Access request using this link [Hashi corp Vault Name Space Request](https://elevancehealth.service-now.com/ess?id=ant_sc_cat_item&sys_id=ae669e704739d550cb5ee731e36d4303) and provide the following details in the ticket. Only after this ticket is closed proceed with next steps.
    1. Assignment Group: Application security cloud ops
    2. Summary of work being requested: Move vault namespace to root for DB Automation.
    3. Detailed Description: Please provide the below details.                                                                                  
        Account Type - Silver/Gold/Platinum                                                                                                     
        Account Number - AWS Account Number you have in welcome letter.                                                                         
        Workspace Name - Workspace name you have in welcome letter.                                                                             
        Vault Namespace - Vault name space which is present in the workspace variables in the workspace.                                        
        Org Code - Organization name you have in welcome letter.                                                                                
* Please send out an email to dl-CCOE-Cloud-Service-Catalog@anthem.com for getting access to this bitbuket repo [ElevanceHealthDB-RDS-MySQL/MultiAZ](https://bitbucket.elevancehealth.com/projects/ACSCT/repos/elevancehealthdb-rds-mysql/browse). This repo contains the template for Provisioning RDS MySQL Cluster in the Primary Region.
* After getting the access Clone the Repository, Make the necessary changes in the Template and run init.
* DB Encryption is enforced using dynamically generated CMK.
* Master Database Credentials used by DBA's are housed in Vault.

1. Login to the TARGET AWS Accounts prior to executing TFE Modules to make sure none of the Services you are trying to provision are already created via UI/CLI. Any manually precreated assets cannot be managed by TFE.
2. Configured provider.tf file with organization, hostname and workspace name.
```bash
terraform {
  backend "remote" {
    hostname     = "<TFE-URL>"
    organization = "<ORGANIZATION-NAME>"
    workspaces {
      name = "<WORKSPACE-NAME>"
    }
  }
}
```
3. Set organization name in the source of the modules. <ORGANIZATION-NAME>
```bash
source  = "cps-terraform.anthem.com/<ORGANIZATION-NAME>/terraform-aws-kms-service/aws"
```
4. vpc ID set in the vpc-id variable of the workspace or set in main.tf file.
5. To Hydrate an Instance using existing Snapshot, Un-comment and Update the template variable snapshot_identifier with the Snapshot Name before apply
6. Do not change any DataDog Subscription Distribution Lists under dataplatform_event_subscription_instance module.
7. Kindly pass the AWS Account number in <sns_rds_topic_policy.json>
## Notes
- The security group for this DB instance, defaults to the following ingress rules:
```bash
  ingress_rules = [
    {
      from_port   = 3306
      to_port     = 3306
      protocol    = "tcp"
      cidr_blocks = ["33.0.0.0/8"]
      description = "Carelon OnPrem"
    },
    {
      from_port   = 3306
      to_port     = 3306
      protocol    = "tcp"
      cidr_blocks = ["30.0.0.0/8"]
      description = "ElevanceHealth OnPrem"
    },
    {
      from_port   = 3306
      to_port     = 3306
      protocol    = "tcp"
      cidr_blocks = ["10.152.0.0/15"]
      description = "ElevanceHealth Governance Team - Application Servers in IBM Private Hosting Ashburn"
    },
    {
      from_port   = 3306
      to_port     = 3306
      protocol    = "tcp"
      cidr_blocks = ["10.45.0.0/16"]
      description = "ElevanceHealth vDaaS"
    },
    {
      from_port                = 3306
      to_port                  = 3306
      protocol                 = "tcp"
      source_security_group_id = "${data.aws_security_group.db_security_group.id}"
      description              = "ElevanceHealth PostScripts Automation"
    },
    {
      from_port                = 3306
      to_port                  = 3306
      protocol                 = "tcp"
      source_security_group_id = "<SECURITY GROUP ID>"
      description              = "Application Tier Security Group ID"
    }
  ]
```
In case to need a security group as a source, this can be added in the source_security_group_id parameter as documented above.
- Performance Insights is enabled by default in this template, to see PI dashboard attach the required role to the user. Please refer [User Performance Insights](https://docs.aws.amazon.com/AmazonRDS/latest/UserGuide/USER_PerfInsights.UsingDashboard.html) to get more information.
- Enhanced monitoring is enabled by default in this template.

## FOR DAM & GOVERNANCE USAGE

1. Do not alter any of the existing parameters in Mysql_Parameter_Option_Group.json file as these are required for DAM/GOVERNANCE Auditing purpose. Add parameters if required for DB Tuning and other COTS Products asks.

## Notes
- Do not remove any of the existing ingress rules from the security group for this DB instance. Add Rule as per the requirement.
- For any DB Issues related to this provisioning, please open [Incident Ticket](https://elevancehealth.service-now.com/ess?id=ant_sc_cat_item&sys_id=e420efc0db889f40eed27bedae9619d7) and assign it to Deloitte Cloud Database Support.
- After successful creation of DB Please raise a Service ID request to DBA Team by using this steps [Service ID Request](https://confluence.elevancehealth.com/display/ENTCLOUD/How+to+Request+Service+Id+Access+to+a+Database) and for Individual user access Please raise a request by following this steps [Individual User Request](https://confluence.elevancehealth.com/display/ENTCLOUD/How+to+Request+Personal+Access+to+a+Database)

## Usage

To run this example you need to execute:

```bash
#Initialize Terraform
terraform init

#Terraform Dry-Run
terraform plan

#Create the resources
terraform apply

#Destroy the resources saved in the tfstate
terraform destroy
```

## Providers

| Name | Version |
|------|---------|
| aws | n/a |
| random | n/a |
| vault | n/a |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| allocated\_storage | The allocated storage in gibibytes. If max\_allocated\_storage is configured, this argument represents the initial storage allocation and differences from the configuration will be ignored automatically when Storage Autoscaling occurs. | `string` | `null` | no |
| allow\_major\_version\_upgrade | Indicates that major version upgrades are allowed. Changing this parameter does not result in an outage and the change is asynchronously applied as soon as possible. | `bool` | `true` | no |
| application-name | application is now application-name.  Based upon application nomenclature in server naming convention policy.Use up to six (6) characters to name your application. | `string` | n/a | yes |
| application\_tag1 | Manged by APP teams | `string` | n/a | yes |
| application\_tag2 | Manged by APP teams | `string` | n/a | yes |
| application\_tag3 | Manged by APP teams | `string` | n/a | yes |
| application\_tag4 | Manged by APP teams | `string` | n/a | yes |
| application\_tag5 | Manged by APP teams | `string` | n/a | yes |
| apply\_immediately | Specifies whether any database modifications are applied immediately, or during the next maintenance window. Allowed values are true/false. Defaults to false. | `bool` | `false` | no |
| auto\_minor\_version\_upgrade | Indicates that minor engine upgrades will be applied automatically to the DB instance during the maintenance window. Defaults to true. | `bool` | `true` | no |
| availability\_zone | The AZ for the RDS instance. | `string` | `null` | no |
| backup\_retention\_period | The days to retain backups for. Must be between 0 and 35. Must be greater than 0 if the database is used as a source for a Read Replica. | `string` | `"7"` | no |
| backup\_window | The daily time range (in UTC) during which automated backups are created if they are enabled. Example: '09:46-10:16'. Must not overlap with maintenance\_window. | `string` | n/a | yes |
| bcp-tier | Application BCP tier | `string` | n/a | yes |
| copy\_tags\_to\_snapshot | Copy all Instance tags to snapshots. Default is false | `bool` | `true` | no |
| created-by | who created the instance | `string` | n/a | yes |
| cross\_region | Whether the instance is a cross region replica | `bool` | `false` | no |
| database-platform | Names of the Database | `string` | n/a | yes |
| database-state | State providing direction for InfoHub to manage Metadata elements. | `string` | n/a | yes |
| db-patch-schedule | Schedules coordinated with Application Team. As general guidelines, we don't want to patch Databases during Q4 due to Annual Enrollment and Holiday season.  We also don't want to AWS Auto Patch Schedule used for Data Platforms as there are application dependency in play. | `string` | n/a | yes |
| db-patch-time-window | 2-Hour slots Weekend Window for Patching starting late Friday night till Sunday evening 6pm US EST. | `string` | n/a | yes |
| db\_instance\_creation\_timeout | Used for Creating Instances, Replicas, and restoring from Snapshots. Defaults to 40 minutes. | `string` | `"40m"` | no |
| delete\_all\_versions | Only applicable for kv-v2 stores. If set to true, permanently deletes all versions for the specified key. The default behavior is to only delete the latest version of the secret. | `bool` | `true` | no |
| deletion\_protection | If the DB instance should have deletion protection enabled. The database can't be deleted when this value is set to true. The default is false. | `bool` | `true` | no |
| enabled\_cloudwatch\_logs\_exports | List of log types to enable for exporting to CloudWatch logs. If omitted, no logs will be exported. Valid values (depending on engine): alert, audit, error, general, listener, slowquery, trace, postgresql (PostgreSQL), upgrade (PostgreSQL). | `list(string)` | n/a | yes |
| engine | The engine version to use. If auto\_minor\_version\_upgrade is enabled, you can provide a prefix of the version such as 5.7 (for 5.7.10) and this attribute will ignore differences in the patch version automatically (e.g. 5.7.17). | `string` | n/a | yes |
| engine\_version | The engine version to use. If auto\_minor\_version\_upgrade is enabled, you can provide a prefix of the version such as 5.7 (for 5.7.10) and this attribute will ignore differences in the patch version automatically (e.g. 5.7.17). | `string` | n/a | yes |
| environment | Allowed values are 'proof\_of\_concept', 'development', 'integration', 'user\_acceptance', 'testing', 'performance', 'production'. | `string` | n/a | yes |
| family | The family of the DB parameter group. | `string` | n/a | yes |
| final\_snapshot\_identifier | The name of your final DB snapshot when this DB instance is deleted. Must be provided if skip\_final\_snapshot is set to false. | `string` | `null` | no |
| iam\_database\_authentication\_enabled | Specifies whether or mappings of AWS Identity and Access Management (IAM) accounts to database accounts is enabled. | `string` | n/a | yes |
| identifier | The name of the RDS instance, if omitted, Terraform will assign a random, unique identifier. | `string` | n/a | yes |
| ingress\_rules | The parameters to create security group ingress rules in the form of a list and referencing each rule with brackets. | `any` | `null` | no |
| instance\_class | The instance type of the RDS instance. | `string` | n/a | yes |
| instance\_count | The number of DB instance to create. | `number` | `1` | no |
| iops | The amount of provisioned IOPS. Setting this implies a storage\_type of io1. | `string` | `null` | no |
| keepers | Arbitrary map of values that, when changed, will trigger recreation of resource. See the main provider documentation for more information. | `map(string)` | `null` | no |
| kms\_key\_id | The ARN for the KMS encryption key. If creating an encrypted replica, set this to the destination KMS ARN. | `string` | n/a | yes |
| kms\_key\_id\_log\_group | The ARN for the KMS encryption key for RDS Log Group. | `string` | n/a | yes |
| length | The length of the string desired | `number` | `16` | no |
| license\_model | License model information for this DB instance. | `string` | n/a | yes |
| lower | Include lowercase alphabet characters in the result. Default value is true. | `bool` | `true` | no |
| maintenance\_window | The window to perform maintenance in. Syntax: 'ddd:hh24:mi-ddd:hh24:mi'. Eg: 'Mon:00:00-Mon:03:00'. | `string` | n/a | yes |
| major\_engine\_version | Specifies the major version of the engine that this option group should be associated with. | `string` | n/a | yes |
| max\_allocated\_storage | The allocated storage in gibibytes. If max\_allocated\_storage is configured, this argument represents the initial storage allocation and differences from the configuration will be ignored automatically when Storage Autoscaling occurs. | `string` | `null` | no |
| min\_lower | Minimum number of lowercase alphabet characters in the result. Default value is 0. | `number` | `3` | no |
| min\_numeric | Minimum number of numeric characters in the result. Default value is 0. | `number` | `3` | no |
| min\_special | Minimum number of special characters in the result. Default value is 0. | `number` | `3` | no |
| min\_upper | Minimum number of uppercase alphabet characters in the result. Default value is 0. | `number` | `3` | no |
| monitoring\_interval | The interval, in seconds, between points when Enhanced Monitoring metrics are collected for the DB instance. To disable collecting Enhanced Monitoring metrics, specify 0. The default is 0. Valid Values: 0, 1, 5, 10, 15, 30, 60. | `string` | `"0"` | no |
| monitoring\_role\_arn | The ARN for the IAM role that permits RDS to send enhanced monitoring metrics to CloudWatch Logs. You can find more information on the AWS Documentation what IAM permissions are needed to allow Enhanced Monitoring for RDS Instances. | `string` | n/a | yes |
| multi\_az | Specifies if the RDS instance is multi-AZ | `string` | n/a | yes |
| mysql\_parameter\_option\_group | According to the requirement DBA's can change the details. | `string` | n/a | yes |
| numeric | Include numeric characters in the result. Default value is true. | `bool` | `true` | no |
| override\_special | Include numeric characters in the result. Default value is true. | `string` | `"!#$%^&"` | no |
| performance\_insights\_enabled | Specifies whether Performance Insights are enabled. Defaults to false. | `bool` | `false` | no |
| performance\_insights\_kms\_key\_id | The ARN for the KMS key to encrypt Performance Insights data. When specifying performance\_insights\_kms\_key\_id, performance\_insights\_enabled needs to be set to true. Once KMS key is set, it can never be changed. | `string` | `null` | no |
| performance\_insights\_retention\_period | The amount of time in days to retain Performance Insights data. Either 7 (7 days) or 731 (2 years) | `string` | `7` | no |
| port | The port on which the DB accepts connections. | `string` | `"3306"` | no |
| prepatch-snapshot-flag | Tag for patching | `string` | n/a | yes |
| read\_replica | Whether this instance is a read replica single region. Set false to use a single region or to create CRRR. Defaults to false | `bool` | `false` | no |
| replicate\_source\_db | Specifies that this resource is a Replicate database, and to use this value as the source database. This correlates to the identifier of another Amazon RDS Database to replicate. | `string` | `null` | no |
| restore\_to\_point\_in\_time | A configuration block for restoring a DB instance to an arbitrary point in time. Requires the identifier argument to be set with the name of the new DB instance to be created. See Restore To Point In Time below for details | `any` | `null` | no |
| retention\_in\_days\_rds\_audit | Specifies the number of days you want to retain Audit log events in the specified log group. Possible values are: 1, 3, 5, 7, 14, 30, 60, 90, 120, 150, 180, 365, 400, 545, 731, 1096, 1827, 2192, 2557, 2922, 3288, 3653, and 0. If you select 0, the events in the Audit log group are always retained and never expire. | `number` | `7` | no |
| retention\_in\_days\_rds\_error | Specifies the number of days you want to retain Error log events in the specified log group. Possible values are: 1, 3, 5, 7, 14, 30, 60, 90, 120, 150, 180, 365, 400, 545, 731, 1096, 1827, 2192, 2557, 2922, 3288, 3653, and 0. If you select 0, the events in the Error log group are always retained and never expire. | `number` | `7` | no |
| retention\_in\_days\_rds\_slowquery | Specifies the number of days you want to retain SlowQuery log events in the specified log group. Possible values are: 1, 3, 5, 7, 14, 30, 60, 90, 120, 150, 180, 365, 400, 545, 731, 1096, 1827, 2192, 2557, 2922, 3288, 3653, and 0. If you select 0, the events in the SlowQuery log group are always retained and never expire. | `number` | `7` | no |
| retention\_in\_days\_rds\_general | Specifies the number of days you want to retain General log events in the specified log group. Possible values are: 1, 3, 5, 7, 14, 30, 60, 90, 120, 150, 180, 365, 400, 545, 731, 1096, 1827, 2192, 2557, 2922, 3288, 3653, and 0. If you select 0, the events in the General log group are always retained and never expire. | `number` | `7` | no |
| serial\_number | Database Identifier Serial number | `string` | n/a | yes |
| skip\_final\_snapshot | Determines whether a final DB snapshot is created before the DB instance is deleted. If true is specified, no DBSnapshot is created. If false is specified, a DB snapshot is created before the DB instance is deleted, using the value from final\_snapshot\_identifier. Default is false. | `bool` | `false` | no |
| snapshot\_identifier | Specifies whether or not to create this database from a snapshot. This correlates to the snapshot ID you'd find in the RDS console, e.g: rds:production-2015-06-26-06-05. | `string` | `null` | no |
| special | Include numeric characters in the result. Default value is true. | `bool` | `true` | no |
| storage\_type | One of standard (magnetic), gp2 (general purpose SSD), or io1 (provisioned IOPS SSD). The default is io1 if iops is specified, gp2 if not. | `string` | `"gp2"` | no |
| tags | A mapping of tags to assign to all resources | `map(string)` | `{}` | no |
| upper | Include uppercase alphabet characters in the result. Default value is true. | `bool` | `true` | no |
| vpc\_id | VPC Id to attach the instance | `string` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| iam\_role\_name | The name to use in the IAM role name creation for RDS enhanced monitoring. |
| instance\_address | Address of the RDS instance |
| instance\_arn | The ARN of the RDS instance |
| instance\_endpoint | DNS Endpoint of the RDS instance |
| instance\_id | ID of the RDS instance |
| instance\_maintenance\_window | The RDS instance maintenance window time |
| instance\_name | Name of the RDS instance |
| instance\_status | The RDS instance status |
| option\_group\_id | The db option group name. |
| parameter\_group\_id | The db parameter group name. |
| result | (String, Sensitive) The generated random string |

## Unit Test

* Submit & able to execute job. The terraform apply takes like 20 minutes to complete the creation of the RDS Mysql
* Creates a RDS Mysql Instance 
* Creates a Parameter Group and a Option Group 
* Creates the RDS Oracle Identifier using the Naming Convention Module

## Read replication

* Able to create replication using identifier output from the source DB instance.
* Skipped the creation of new resources and taken the ones from source instance.
* Names and identifiers of DB instance read replica created according naming conventions.

## CRRR Testing

* Creates an RDS MySql Instance
* call the Main MySql RDS instance in the parameter replicate_sourcedb
* To launch Both Primary and Secondary DB instance it will take 23mins and 33 mins respectively.



