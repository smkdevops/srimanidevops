# Anthem AWS API Gateway Resource Module

This module provides an API Gateway Resource.

## HIPAA eligibility status

1. Amazon API Gateway is eligible

## Security Guardrail reference

https://confluence.anthem.com/pages/viewpageattachments.action?pageId=299009562&sortBy=date&startIndex=60&preview=/299009562/370573552/Anthem%20AWS%20Security%20Patterns%20-%20API%20Gateway.docx

## Pre-Requisites

1. Rest API should be created
2. The ID of the parent API resource should be passed
3. Path segment of this API resource


## Usage
To run this example you need to execute:

```bash

module "api_resource" {
  source = "cps-terraform.anthem.com/<ORG>/terraform-aws-api-gateway-resource/aws"

  #Parameters
  rest_api_id = ""
  parent_id   = ""
  path_part   = ""
}

#Initialize Terraform
terraform init

#Terraform Dry-Run
terraform plan

#Create the resources
terraform apply

#Destroy the resources saved in the tfstate
terraform destroy
```

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| create\_apigateway\_resource | (Optional) A boolean that indicates whether to create API Gateway resource or not. Default is true | `bool` | `true` | no |
| parent\_id | (Required) The ID of the parent API resource | `string` | n/a | yes |
| path\_part | (Required) The last path segment of this API resource. | `string` | n/a | yes |
| rest\_api\_id | (Required) The ID of the associated REST API | `string` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| id | The resource's identifier. |
| path | The complete path for this API resource, including all parent paths. |

## Testing

1. Able to create the API gateway resource.