# Anthem AWS APIGateway integartion Module

This module provides an HTTP Method Integration for an API Gateway Integration.

## HIPAA eligibility status

1. Amazon API Gateway is eligible

## Security Guardrail reference

https://confluence.anthem.com/pages/viewpageattachments.action?pageId=299009562&sortBy=date&startIndex=60&preview=/299009562/370573552/Anthem%20AWS%20Security%20Patterns%20-%20API%20Gateway.docx

## Pre-Requisites

1. Rest API should be created.
2. Resource ID should be created.
3. Method is required.
4. Integration type is required. Eg(GET, POST, PUT, DELETE, HEAD, OPTIONs, ANY, PATCH).


## Usage
To run this example you need to execute:

```bash

module "api_integration" {
  source     = "cps-terraform.anthem.com/<ORG>/terraform-aws-api-integration/aws"
  depends_on = [module.lambda]

  #Parameters
  rest_api_id             = module.rest_api.id
  resource_id             = module.api_resource.id
  http_method             = module.api_method.http_method
  integration_http_method = "POST"
  integration_type        = "AWS" #"AWS_PROXY"
  uri                     = module.lambda.invoke_arn
  connection_type                = null
  #credentials                    = ""
  #request_templates              = {}
  #integration_request_parameters = {}
  #passthrough_behavior           = "WHEN_NO_MATCH"
  #cache_key_parameters           = []
  #cache_namespace                = ""
  #content_handling               = "CONVERT_TO_TEXT"
  #timeout_milliseconds           = 29000
}

#Initialize Terraform
terraform init

#Terraform Dry-Run
terraform plan

#Create the resources
terraform apply

#Destroy the resources saved in the tfstate
terraform destroy
```

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| cache\_key\_parameters | (Optional) A list of cache key parameters for the integration. | `list(string)` | `[]` | no |
| cache\_namespace | (Optional) The integration's cache namespace. | `string` | `""` | no |
| connection\_id | (Optional) The id of the VpcLink used for the integration. Required if connection\_type is VPC\_LINK. | `string` | `""` | no |       
| connection\_type | (Optional) The integration input's connectionType. Valid values are INTERNET (default for connections through the public routable internet), and VPC\_LINK (for private connections between API Gateway and a network load balancer in a VPC). | `string` | `null` | no |
| content\_handling | (Optional) Specifies how to handle request payload content type conversions. Supported values are CONVERT\_TO\_BINARY and CONVERT\_TO\_TEXT. If the value is null then the request payload will be passed through from the method request to integration request without modification, provided that the passthroughBehaviors is configured to support payload pass-through. | `string` | `null` | no |
| credentials | (Optional) The credentials required for the integration. For AWS integrations, 2 options are available. To specify an IAM Role for Amazon API Gateway to assume, use the role's ARN. To require that the caller's identity be passed through from the request, specify the string arn:aws:iam::\*:user/\*. | `string` | `""` | no |
| http\_method | (Required) The HTTP method (GET, POST, PUT, DELETE, HEAD, OPTION, ANY) when calling the associated resource. | `string` | n/a | yes |  
| integration\_http\_method | (Optional) The integration HTTP method (GET, POST, PUT, DELETE, HEAD, OPTIONs, ANY, PATCH) specifying how API Gateway will interact with the back end. Required if type is AWS, AWS\_PROXY, HTTP or HTTP\_PROXY. Not all methods are compatible with all AWS integrations. e.g. Lambda function can only be invoked via POST. | `string` | `"POST"` | no |
| integration\_request\_parameters | (Optional) A map of request query string parameters and headers that should be passed to the backend responder. For example: request\_parameters = { "integration.request.header.X-Some-Other-Header" = "method.request.header.X-Some-Header" }. | `map(string)` | `{}` | no |
| integration\_type | (Required) The integration input's type. Valid values are HTTP (for HTTP backends), MOCK (not calling any real backend), AWS (for 
AWS services), AWS\_PROXY (for Lambda proxy integration) and HTTP\_PROXY (for HTTP proxy integration). An HTTP or HTTP\_PROXY integration with a connection\_type of VPC\_LINK is referred to as a private integration and uses a VpcLink to connect API Gateway to a network load balancer of a VPC. | `string` | `"AWS_PROXY"` | no |
| passthrough\_behavior | (Optional) The integration passthrough behavior (WHEN\_NO\_MATCH, WHEN\_NO\_TEMPLATES, NEVER). Required if request\_templates 
is used. | `string` | `"WHEN_NO_MATCH"` | no |
| request\_templates | (Optional) A map of the integration's request templates. | `map(string)` | `{}` | no |
| resource\_id | (Required) The API resource ID. | `string` | n/a | yes |
| rest\_api\_id | (Required) The ID of the associated REST API. | `string` | n/a | yes |
| timeout\_milliseconds | (Optional) Custom timeout between 50 and 29,000 milliseconds. The default value is 29,000 milliseconds. | `string` | `"29000"` | no |
| uri | (Optional) The input's URI. Required if type is AWS, AWS\_PROXY, HTTP or HTTP\_PROXY. For HTTP integrations, the URI must be a fully formed, encoded HTTP(S) URL according to the RFC-3986 specification . For AWS integrations, the URI should be of the form arn:aws:apigateway:{region}:{subdomain.service\|service}:{path\|action}/{service\_api}. region, subdomain and service are used to determine the right endpoint. e.g. arn:aws:apigateway:eu-west-1:lambda:path/2015-03-31/functions/arn:aws:lambda:eu-west-1:012345678901:function:my-func/invocations. | `string` | `""` | no |

## Outputs

No output.

## Testing

1. Able to create the API gateway Integration with the Pre-requisties.
