# Anthem AWS API Gateway REST API Policy Module

This module provides an API Gateway REST API Policy.

## HIPAA eligibility status

1. Amazon API Gateway is eligible

## Security Guardrail reference

https://confluence.anthem.com/pages/viewpageattachments.action?pageId=299009562&sortBy=date&startIndex=60&preview=/299009562/370573552/Anthem%20AWS%20Security%20Patterns%20-%20API%20Gateway.docx

## Pre-Requisites

1. REST API should be created.


## Usage
To run this example you need to execute:

```bash

module "api_policy" {
  source = "cps-terraform.anthem.com/<ORG>/terraform-aws-api-gateway-rest-api-policy/aws"

  rest_api_id = module.rest_api.id
  policy      = <<EOF
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Principal": {
        "AWS": "*"
      },
      "Action": "execute-api:Invoke",
      "Resource": "${module.rest_api.execution_arn}",
      "Condition": {
        "IpAddress": {
          "aws:SourceIp": "10.188.212.0/22"
        }
      }
    }
  ]
}
EOF
}

#Initialize Terraform
terraform init

#Terraform Dry-Run
terraform plan

#Create the resources
terraform apply

#Destroy the resources saved in the tfstate
terraform destroy
```


## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| policy | (Required) The policy of the API | `string` | n/a | yes |
| rest\_api\_id | (Required) The ID of the associated Rest API | `string` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| id | The ID of the REST API |

## Testing

1. Able to create the REST API policy.