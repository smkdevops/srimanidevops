# Anthem AWS Lambda Layer Version Module

This module provides a Lambda Layer Version resource. Lambda Layers allow you to reuse shared bits of code across multiple lambda functions.

For information about Lambda Layers and how to use them, see AWS Lambda Layers.

## HIPAA eligibility status

NA. This is supporting module for lambda.

## Security Guardrail reference

NA. This is supporting module for lambda.

## Pre-Requisite

1. Source code dependencies.zip should exist in local.

## Usage
To run this example you need to execute:

```bash
#Example Script
module "lambda_layer_version" {
  source = "cps-terraform.anthem.com/<ORGANIZATION NAME>/terraform-aws-lambda-layer-version/aws"

  #Required Parameters
  layer_name          = "test-layer"

  #Optional Parameters
  filename            = "./Dependencies.zip"
  s3_bucket           = ""
  s3_key              = ""
  s3_object_version   = ""
  compatible_runtimes = []
  description         = "The dependencies for the lambda function"
  license_info        = ""
  source_code_hash    = "filebase64sha256(\"Dependencies.zip\")"
  source_code_location = "local"
}

#Initialize Terraform
terraform init

#Terraform Dry-Run
terraform plan

#Create the resources
terraform apply

#Destroy the resources saved in the tfstate
terraform destroy
```


## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| compatible\_runtimes | A list of runtimes this layer is compatible with | `list(string)` | `[]` | no |
| description | Description of what your Lambda layer does | `string` | `""` | no |
| filename | The path to the function's deployment package within the local filesystem. If defined, The s3\_-prefixed options cannot be used | `string` | `""` | no |
| layer\_name | Name of the Lambda layer | `string` | n/a | yes |
| license\_info | License info for your Lambda layer | `string` | `""` | no |
| s3\_bucket | The S3 bucket location containing the function's deployment package | `string` | `""` | no |
| s3\_key | The S3 key of an object containing the function's deployment package | `string` | `""` | no |
| s3\_object\_version | The object version containing the function's deployment package | `string` | `""` | no |
| source\_code\_hash | Used to trigger updates | `string` | `""` | no |
| source\_code\_location | The Location of the source code. It can either s3 or local | `string` | `""` | no |

## Outputs

| Name | Description |
|------|-------------|
| arn | The Amazon Resource Name (ARN) of the Lambda Layer with version. |
| created\_date | The date this resource was created. |
| layer\_arn | The Amazon Resource Name (ARN) of the Lambda Layer without version. |
| signing\_job\_arn | The Amazon Resource Name (ARN) of a signing job. |
| signing\_profile\_version\_arn | The Amazon Resource Name (ARN) for a signing profile version. |
| source\_code\_size | The size in bytes of the function .zip file. |
| version | This Lamba Layer version. |

## Testing

1. Able to create lambda layer version and see it on console.