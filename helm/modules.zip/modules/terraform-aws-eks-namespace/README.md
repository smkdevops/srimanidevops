## Terraform module to create Namespace in EKS Cluster

This module with create kubernetes Namespace in the configured EKS cluster along with Resouce Quota, Limit Range, Default Network Policies and kubernetes Roles for role based access controle (RBAC). 

## Pre-Requisites

1. Should have EKS cluster up and running.
2. Include Kuberenetes provier for your EKS cluster as shown below:

```bash
data "aws_eks_cluster" "cluster" {
  name = module.eks_cluster.cluster_id
}

data "aws_eks_cluster_auth" "cluster" {
  name = module.eks_cluster.cluster_id
}

provider "kubernetes" {
  #  load_config_file       = false
  host                   = data.aws_eks_cluster.cluster.endpoint
  cluster_ca_certificate = base64decode(data.aws_eks_cluster.cluster.certificate_authority.0.data)
  token                  = data.aws_eks_cluster_auth.cluster.token
}
```

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| namespace_name | Name of the K8s Namespace | String | - | yes |
| namespace_group | Name of Active Directory group created for application | String | gid:default-group | yes |
| tshirt_size | T-Shirt size of namespace | String | km.large | no |
| max_pods | Max number of Pods allowed in a namespace | String | 8 | no |
| namespace_labels | Labels application team wants to apply for namespace | String | default = { Description = "Default_Namespace_description" } | yes |
| vault_ca_bundle | Vault Server CA certificate (Base64 encoded string) | String | - | yes |

## Usage

Include below module code to create K8s Namespace into EKS cluster:

```bash

module "app1-namespace" {
  depends_on = [ module.eks_cluster, module.eks-managed-node-group ]
  source = "cps-terraform.anthem.com/CORP/terraform-aws-eks-namespace/aws"
  version = "0.1.3"

  namespace_name   = "app1"
  namespace_group  = "gid:ad-grp-app1"
  tshirt_size      = "km.large"
  max_pods         = "8"
  namespace_labels = { 
    AppName = "MyFirstApp" 
    AppDesc = "My_First_App_In_EKS"
  }
  
  environment      = "production"
  company          = "antm"
  costcenter       = "12345678"
  owner-department = "corpdemo1"
  it-department    = "service_catalog"
  barometer-it-num = "100corp"
  application      = "test1"
  resource-type    = "eks"
  layer            = "DBx"
  compliance       = "None"
  application_dl   = "app1ower-at-anthem.com"

  vault_ca_bundle = data.vault_generic_secret.vault-agent.data["vault_ca_bundle"]

} 

#Initialize Terraform
terraform init

#Terraform Dry-Run
terraform plan

#Create the resources
terraform apply

#Destroy the resources saved in the tfstate
terraform destroy
```

## Verify Installation


1. Create EKS Cluster.
2. Create Namespace using reference module code provided above in earlier section.
3. Run below commands to verify namespace resouces deployed without any errors:
```bash
kubectl get ns

NAME               STATUS   AGE
app1               Active   12m
```
- Describe the Namespace for detailed information

```bash

kubectl describe namespace app1

Name:         app1
Labels:       AppDesc=My_First_App_In_EKS
              AppName=MyFirstApp
              app-support-dl=app1ower-at-anthem.com
              application-name=test1
              barometer-it=100corp
              business-division=service_catalog
              company=antm
              compliance=None
              costcenter=12345678
              environment=production
              kubernetes.io/metadata.name=app1
              owner-department=corpdemo1
              resource-type=eks
              schedule-window=DBx
Annotations:  <none>
Status:       Active

Resource Quotas
  Name:            app1-namespace-res-quota
  Resource         Used  Hard
  --------         ---   ---
  limits.cpu       0     2
  limits.memory    0     8Gi
  requests.cpu     0     1
  requests.memory  0     2Gi
  Name:            app1-namespace-res-quota-pods
  Resource         Used  Hard
  --------         ---   ---
  pods             0     8

Resource Limits
 Type       Resource  Min    Max  Default Request  Default Limit  Max Limit/Request Ratio
 ----       --------  ---    ---  ---------------  -------------  -----------------------
 Pod        cpu       20m    1    -                -              -
 Pod        memory    100Mi  1Gi  -                -              -
 Container  cpu       -      1    20m              20m            -
 Container  memory    -      1Gi  100Mi            100Mi          -

```