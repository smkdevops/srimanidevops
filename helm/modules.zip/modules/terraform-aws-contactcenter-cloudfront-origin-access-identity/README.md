# Anthem AWS Cloudfront Cache Resource

This module create aws  Cloudfront Cache Resource.

<span style="color: red">**This module should only be used by Contact Center Project.**</span>

## HIPAA eligibility status

* N/A


## Security Guardrail reference

[security Guardrails Link](https://confluence.anthem.com/download/attachments/717965086/Anthem%20AWS%20Security%20Patterns%20-%20AWS_CloudFront%20-%20Deliotte%20Digital%20CCaaS%20use%20case.docx?version=1&modificationDate=1628274246000&api=v2)

## Pre-requisite

- No dependent resource required.

## Usage

To run this example you need to execute:

```bash
#Initialize Terraform
terraform init

#Terraform Dry-Run
terraform plan

#Create the resources
terraform apply

#Destroy the resources saved in the tfstate
terraform destroy
```

## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | ">=3.35.0" |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [aws_cloudfront_origin_access_identity.this](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/cloudfront_origin_access_identity) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_comment"></a> [comment](#input\_comment) | (Optional) - An optional comment for the origin access identity. | `string` | `null` | no |
| <a name="input_create_origin_access_identity"></a> [create\_origin\_access\_identity](#input\_create\_origin\_access\_identity) | Controls if CloudFront create origin access identity should be created | `bool` | `true` | no |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_caller_reference"></a> [caller\_reference](#output\_caller\_reference) | returns a string |
| <a name="output_cloudfront_access_identity_path"></a> [cloudfront\_access\_identity\_path](#output\_cloudfront\_access\_identity\_path) | returns a string |
| <a name="output_etag"></a> [etag](#output\_etag) | returns a string |
| <a name="output_iam_arn"></a> [iam\_arn](#output\_iam\_arn) | returns a string |
| <a name="output_id"></a> [id](#output\_id) | returns a string |
| <a name="output_s3_canonical_user_id"></a> [s3\_canonical\_user\_id](#output\_s3\_canonical\_user\_id) | returns a string |
| <a name="output_this"></a> [this](#output\_this) | n/a |
