# AWS Auto scaling group notification Terraform Module

This module is to create the auto scaling group notification.

## HIPAA eligibility status

1. Amazon Elastic Compute Cloud (Amazon EC2) 
2. Amazon Auto Scaling

## Security Guardrail reference

https://confluence.anthem.com/pages/viewpageattachments.action?pageId=299009562&sortBy=date&startIndex=80&preview=/299009562/357900867/Anthem%20AWS%20Security%20Patterns%20-%20EC2%20AutoScalingGroup_v1.docx

## Pre-Requisite

1. Auto scaling group name is required.
2. SNS topic is required.
3. Acceptable values for notification type is documented in the AWS documentation https://docs.aws.amazon.com/autoscaling/ec2/APIReference/API_NotificationConfiguration.html


## Usage
To run this example you need to execute:

```bash
#Initialize Terraform
terraform init

#Terraform Dry-Run
terraform plan

#Create the resources
terraform apply

#Destroy the resources saved in the tfstate
terraform destroy
```

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| autoscaling\_group\_name | A list of AutoScaling Group Names. | `list` | n/a | yes |
| notifications | A list of Notification Types that trigger notifications. Default is set for autoscaling:EC2\_INSTANCE\_LAUNCH, autoscaling:EC2\_INSTANCE\_TERMINATE, autoscaling:EC2\_INSTANCE\_LAUNCH\_ERROR, autoscaling:EC2\_INSTANCE\_TERMINATE\_ERROR | `list` | <pre>[<br>  "autoscaling:EC2_INSTANCE_LAUNCH",<br>  "autoscaling:EC2_INSTANCE_TERMINATE",<br>  "autoscaling:EC2_INSTANCE_LAUNCH_ERROR",<br>  "autoscaling:EC2_INSTANCE_TERMINATE_ERROR"<br>]</pre> | no |
| topic\_arn | The Topic ARN for notifications to be sent through. | `string` | n/a | yes |

## Outputs

No output.

## Testing

1. Created ASG with launch template.
2. Created Scaling policy.
3. Attached the scaling policy to the SNS topic for notification.