# Anthem AWS APIGateway Custom Domain Name Module

Registers a custom domain name for use with AWS API Gateway. Additional information about this functionality can be found in the API Gateway Developer Guide.

This resource just establishes ownership of and the TLS settings for a particular domain name. An API can be attached to a particular path under the registered domain name using the aws_api_gateway_base_path_mapping resource.

API Gateway domains can be defined as either 'edge-optimized' or 'regional'. In an edge-optimized configuration, API Gateway internally creates and manages a CloudFront distribution to route requests on the given hostname. In addition to this resource it's necessary to create a DNS record corresponding to the given domain name which is an alias (either Route53 alias or traditional CNAME) to the Cloudfront domain name exported in the cloudfront_domain_name attribute.

In a regional configuration, API Gateway does not create a CloudFront distribution to route requests to the API, though a distribution can be created if needed. In either case, it is necessary to create a DNS record corresponding to the given domain name which is an alias (either Route53 alias or traditional CNAME) to the regional domain name exported in the regional_domain_name attribute.

## HIPAA eligibility status

1. Amazon API Gateway is eligible

## Security Guardrail reference

https://confluence.anthem.com/pages/viewpageattachments.action?pageId=299009562&sortBy=date&startIndex=60&preview=/299009562/370573552/Anthem%20AWS%20Security%20Patterns%20-%20API%20Gateway.docx

## Pre-Requisites

1. To create a Domain name it should have a valid pattern. Ex(domainname.awsdns.internal.das).
2. Without passing the valid domain name we cant create it. 

## Mandatory Tags Note:
*	As per redesigned new mandatory tags, mandatory tags along with any additional tags have to be added through template configuration within the modules as below
*	Have a reference of mandatory tags module within the template configuration as shown in example script below.
```bash
# Mandatory Tag Workspace Variables
  variable "apm-id" {}
  variable "application-name" {}
  variable "app-support-dl" {}
  variable "app-servicenow-group" {}
  variable "business-division" {}
  variable "company" {}
  variable "compliance" {}
  variable "costcenter" {}
  variable "environment" {}
  variable "PatchGroup" {}
  variable "PatchWindow" {}
  variable "ATLAS_WORKSPACE_NAME" {}

# Mandatory Tags Module 
module "mandatory_tags" {
  source               = "cps-terraform.anthem.com/<ORG_NAME>/terraform-aws-mandatory-tags-v2/aws"
  tags                 = {}
  apm-id               = var.apm-id
  application-name     = var.application-name
  app-support-dl       = var.app-support-dl
  app-servicenow-group = var.app-servicenow-group
  business-division    = var.business-division
  compliance           = var.compliance
  company              = var.company
  costcenter           = var.costcenter
  environment          = var.environment
  PatchGroup           = var.PatchGroup
  PatchWindow          = var.PatchWindow
  workspace            = var.ATLAS_WORKSPACE_NAME
}
```
*	Mandatory tags module should be referred in tags attribute as below:
  tags = module.mandatory_tags.tags
*	Any additional tags can be merged to tags attribute as below:
  tags = merge(module.mandatory_tags.tags, {"sample" = "abc"})


## Usage
To run this example you need to execute:

```bash

module "custom-domain" {
  source  = "cps-terraform.anthem.com/<ORG_NAME>/terraform-aws-api-domain-name/aws"
  
  #Mandatory tags
  tags = module.mandatory_tags.tags

  domain_name = ""
  regional_certificate_arn = ""
  types = ["REGIONAL"]
}

#Initialize Terraform
terraform init

#Terraform Dry-Run
terraform plan

#Create the resources
terraform apply

#Destroy the resources saved in the tfstate
terraform destroy
```

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| certificate\_arn | (Optional) ARN for an AWS-managed certificate. AWS Certificate Manager is the only supported source. Used when an edge-optimized domain name is desired. Conflicts with certificate\_name, certificate\_body, certificate\_chain, certificate\_private\_key, regional\_certificate\_arn, and regional\_certificate\_name. | `string` | `""` | no |
| domain\_name | (Required) Fully-qualified domain name to register. | `string` | n/a | yes |
| mutual\_tls\_authentication | (Optional) Configuration block defining API endpoint information including type.A list of endpoint types. This resource currently only supports managing a single value. Valid values: EDGE or REGIONAL. If unspecified, defaults to EDGE. Must be declared as REGIONAL in non-Commercial partitions. Refer to the documentation for more information on the difference between edge-optimized and regional APIs. | `map` | `{}` | no |
| regional\_certificate\_arn | (Optional) ARN for an AWS-managed certificate. AWS Certificate Manager is the only supported source. Used when a regional domain name is desired. Conflicts with certificate\_arn, certificate\_name, certificate\_body, certificate\_chain, and certificate\_private\_key. | `string` | `""` | no |
| security\_policy | (Optional) Transport Layer Security (TLS) version + cipher suite for this DomainName. Valid values are TLS\_1\_0 and TLS\_1\_2. Must be configured to perform drift detection. | `string` | `"TLS_1_2"` | no |
| tags | (Required) Map of tags assigned to the resource, including those inherited from the provider default\_tags | `map(string)` | n/a | yes |
| truststore\_uri | (Required) Amazon S3 URL that specifies the truststore for mutual TLS authentication, for example, s3://bucket-name/key-name. The truststore can contain certificates from public or private certificate authorities. To update the truststore, upload a new version to S3, and then update your custom domain name to use the new version. | `map` | `{}` | no |
| truststore\_version | (Optional) Version of the S3 object that contains the truststore. To specify a version, you must have versioning enabled for the S3 bucket. | `map` | `{}` | no |
| types | (Required) List of endpoint types. This resource currently only supports managing a single value. Valid values: EDGE or REGIONAL. If unspecified, defaults to EDGE. Must be declared as REGIONAL in non-Commercial partitions. | `list(string)` | <pre>[<br>  "EDGE"<br>]</pre> | no |

## Outputs

| Name | Description |
|------|-------------|
| domain\_name\_arn | Amazon Resource Name (ARN) |
| domain\_name\_id | The internal id assigned to this domain name by API Gateway. |

## Testing

1. Able to create Custom Domain name.
