# Anthem AWS Lambda Provisioned Concurrency Configuration Module

This module manages a Lambda Provisioned Concurrency Configuration.

## HIPAA eligibility status

NA. This is supporting module for lambda.

## Security Guardrail reference

NA. This is supporting module for lambda.

## Pre-Requisite

1. The Lambda function should exist.
2. Name or ARN should be provided.

## Usage
To run this example you need to execute:

```bash
#Example Script
module "lambda_provisioned_config" {
  source = "cps-terraform.anthem.com/<ORGANIZATION NAME>/terraform-aws-lambda-provisioned-concurrency-config/aws"  

  #Required Parameters
  function_name                     = "test-function"
  provisioned_concurrent_executions = 1
  qualifier                         = "1"
}

#Initialize Terraform
terraform init

#Terraform Dry-Run
terraform plan

#Create the resources
terraform apply

#Destroy the resources saved in the tfstate
terraform destroy
```

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| function\_name | Name of the Lambda function | `string` | n/a | yes |
| provisioned\_concurrent\_executions | Amount of capacity to allocate | `number` | n/a | yes |
| qualifier | Lambda Function version or Lambda Alias name | `string` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| id | Lambda Function name and qualifier separated by a colon (:). |

## Testing

1. Able to create lambda provisioned concurrency config and see it on console.