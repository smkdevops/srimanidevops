# Anthem AWS Lambda Alias Module

This module creates a Lambda function alias. Creates an alias that points to the specified Lambda function version.

For information about Lambda and how to use it, see What is AWS Lambda? For information about function aliases, see CreateAlias and AliasRoutingConfiguration in the API docs.

## HIPAA eligibility status

NA. This is supporting module for lambda.

## Security Guardrail reference

NA. This is supporting module for lambda.

## Pre-Requisite

1. The Lambda function should exist.
2. Name or ARN should be provided.

## Usage
To run this example you need to execute:

```bash
#Example Script
module "lambda_alias" {
  source = "cps-terraform.anthem.com/<ORGANIZATION NAME>/terraform-aws-lambda-alias/aws"  

  #Required Parameters
  name                       = "test-lambda-alias"  
  function_name              = "test-function"
  function_version           = "1"
  
  #Optional Parameters
  description                = "This is test lambda alias"
  additional_version_weights = null

}

#Initialize Terraform
terraform init

#Terraform Dry-Run
terraform plan

#Create the resources
terraform apply

#Destroy the resources saved in the tfstate
terraform destroy
```

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| additional\_version\_weights | Additional Version Weights | `map(string)` | `null` | no |
| description | Description of the Alias for the Lambda function | `string` | `""` | no |
| function\_name | Name or ARN of the the Lambda function | `string` | n/a | yes |
| function\_version | Version to which the alias is being applied | `string` | n/a | yes |
| name | Name of the Alias for the Lambda function | `string` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| arn | The Amazon Resource Name (ARN) identifying your Lambda function alias. |
| invoke\_arn | The ARN to be used for invoking Lambda Function from API Gateway - to be used in aws\_api\_gateway\_integration's uri. |

## Testing

1. Able to create lambda alias and see it on console.