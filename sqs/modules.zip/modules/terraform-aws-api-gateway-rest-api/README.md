# Anthem AWS APIGateway Rest API Module

A REST API in API Gateway is a collection of resources and methods that are integrated with backend HTTP endpoints, Lambda functions, or other AWS services. You can use API Gateway features to help you with all aspects of the API lifecycle, from creation through monitoring your production APIs.

API Gateway REST APIs use a request/response model where a client sends a request to a service and the service responds back synchronously. This kind of model is suitable for many different kinds of applications that depend on synchronous communication.

## HIPAA eligibility status

1. Amazon API Gateway is eligible

## Security Guardrail reference

https://confluence.anthem.com/pages/viewpageattachments.action?pageId=299009562&sortBy=date&startIndex=60&preview=/299009562/370573552/Anthem%20AWS%20Security%20Patterns%20-%20API%20Gateway.docx

## Pre-Requisites

1. Name of the REST API is required.


## Important Note

1. If the Endpoint_configuration type is "PRIVATE" then a VPC endpoint identifier is required.
2. Body argument can be used to define the set of routes and integrations to create as part of the REST API.Information about REST API OpenAPI support can be found in the [API Gateway Developer Guide](https://docs.aws.amazon.com/apigateway/latest/developerguide/api-gateway-import-api.html).
Body argument can be provided like the below code snippet 

```bash
body = jsonencode({
    openapi = "3.0.1"
    info = {
      title   = "example"
      version = "1.0"
    }
    paths = {
      "/path1" = {
        get = {
          x-amazon-apigateway-integration = {
            httpMethod           = "GET"
            payloadFormatVersion = "1.0"
            type                 = "HTTP_PROXY"
            uri                  = "https://ip-ranges.amazonaws.com/ip-ranges.json"
          }
        }
      }
    }
  })     
```
3. put_rest_api_mode can be used to specify mode of the PutRestApi operation when importing an OpenAPI specification via the body argument. Default value is set to merge, can be changed to overwrite by setting  put_rest_api_mode  = overwrite.
overwrite will replace the resources created using terraform-aws-api-gateway-method ,terraform-aws-api-gateway-integration

## Mandatory Tags Note:
*	As per redesigned new mandatory tags, mandatory tags along with any additional tags have to be added through template configuration within the modules as below
*	Have a reference of mandatory tags module within the template configuration as shown in example script below.
```bash
# Mandatory Tag Workspace Variables
variable "apm-id" {}
variable "application-name" {}
variable "app-support-dl" {}
variable "app-servicenow-group" {}
variable "business-division" {}
variable "company" {}
variable "compliance" {}
variable "costcenter" {}
variable "environment" {}
variable "PatchGroup" {}
variable "PatchWindow" {}
variable "ATLAS_WORKSPACE_NAME" {}

# Mandatory Tags Module 
module "mandatory_tags" {
  source               = "cps-terraform.anthem.com/<ORG_NAME>/terraform-aws-mandatory-tags-v2/aws"
  tags                 = {}
  apm-id               = var.apm-id
  application-name     = var.application-name
  app-support-dl       = var.app-support-dl
  app-servicenow-group = var.app-servicenow-group
  business-division    = var.business-division
  compliance           = var.compliance
  company              = var.company
  costcenter           = var.costcenter
  environment          = var.environment
  PatchGroup           = var.PatchGroup
  PatchWindow          = var.PatchWindow
  workspace            = var.ATLAS_WORKSPACE_NAME
}
```
*	Mandatory tags module should be referred in tags attribute as below:
  tags = module.mandatory_tags.tags
*	Any additional tags can be merged to tags attribute as below:
  tags = merge(module.mandatory_tags.tags, {"sample" = "abc"})

## Usage
To run this example you need to execute:

```bash

module "rest_api" {
  source = "cps-terraform.anthem.com/<ORG>/terraform-aws-rest-api/aws"

  #Mandatory tags
 tags = module.mandatory_tags.tags

  #Parameters
  api_name = ""
  endpoint_configuration = [{
    types            = ["PRIVATE"]
    vpc_endpoint_ids = [""]
  }]
  api_description              = ""
  api_binary_media_types       = ["UTF-8-encoded"]
  api_minimum_compression_size = "-1"

  # body = jsonencode({
  #   openapi = "3.0.1"
  #   info = {
  #     title   = "example"
  #     version = "1.0"
  #   }
  #   paths = {
  #     "/path1" = {
  #       get = {
  #         x-amazon-apigateway-integration = {
  #           httpMethod           = "GET"
  #           payloadFormatVersion = "1.0"
  #           type                 = "HTTP_PROXY"
  #           uri                  = "https://ip-ranges.amazonaws.com/ip-ranges.json"
  #         }
  #       }
  #     }
  #   }
  # })
  
}

#Initialize Terraform
terraform init

#Terraform Dry-Run
terraform plan

#Create the resources
terraform apply

#Destroy the resources saved in the tfstate
terraform destroy
```

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| api\_binary\_media\_types | (Optional) List of binary media types supported by the REST API. By default, the REST API supports only UTF-8-encoded text payloads. If importing an OpenAPI specification via the body argument, this corresponds to the x-amazon-apigateway-binary-media-types extension. If the argument value is provided and is different than the OpenAPI value, the argument value will override the OpenAPI value. | `list(string)` | <pre>[<br>  "UTF-8-encoded"<br>]</pre> | no |
| api\_description | (Optional) Description of the REST API. If importing an OpenAPI specification via the body argument, this corresponds to the info.description field. If the argument value is provided and is different than the OpenAPI value, the argument value will override the OpenAPI value. | `string` | `""` | no |
| api\_key\_source | (Optional) Source of the API key for requests. Valid values are HEADER (default) and AUTHORIZER. If importing an OpenAPI specification via the body argument, this corresponds to the x-amazon-apigateway-api-key-source extension. If the argument value is provided and is different than the OpenAPI value, the argument value will override the OpenAPI value. | `string` | `"HEADER"` | no |
| api\_minimum\_compression\_size | (Optional) Minimum response size to compress for the REST API. Integer between -1 and 10485760 (10MB). Setting a value greater than -1 will enable compression, -1 disables compression (default). | `number` | `-1` | no |
| api\_name | (Required) Name of the REST API. If importing an OpenAPI specification via the body argument, this corresponds to the info.title field. If the argument value is different than the OpenAPI value, the argument value will override the OpenAPI value. | `string` | n/a | yes |
| body | (Optional) OpenAPI specification that defines the set of routes and integrations to create as part of the REST API. This configuration, and any updates to it, will replace all REST API configuration except values overridden in this resource configuration and other resource updates applied after this resource but before any aws\_api\_gateway\_deployment creation. More information about REST API OpenAPI support can be found in the API Gateway Developer Guide. | `string` | `""` | no |
| enabled | (Optional) Whether to create rest api. default = true | `bool` | `true` | no |
| endpoint\_configuration | (Optional) Configuration block defining API endpoint configuration including endpoint type. | `any` | `[]` | no |
| policy | (Optional) JSON formatted policy document that controls access to the API Gateway. | `string` | `null` | no |
| put\_rest\_api\_mode | (Optional) Mode of the PutRestApi operation when importing an OpenAPI specification via the body argument (create or update operation). Valid values are merge and overwrite. If unspecificed, defaults to overwrite (for backwards compatibility). This corresponds to the x-amazon-apigateway-put-integration-method extension. If the argument value is provided and is different than the OpenAPI value, the argument value will override the OpenAPI value. | `string` | `"merge"` | no |
| tags | (Required) Map of tags assigned to the resource, including those inherited from the provider default\_tags | `map(string)` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| arn | The ARN of the REST API |
| created\_date | The creation date of the REST API |
| execution\_arn | The execution ARN part to be used in lambda\_permission's source\_arn when allowing API Gateway to invoke a Lambda function, e.g. arn:aws:execute-api:eu-west-2:123456789012:z4675bid1j, which can be concatenated with allowed stage, method and resource path. |
| id | The ID of the REST API |
| root\_resource\_id | The resource ID of the REST API's root |

## Testing

1. Able to create the Rest API.
2. Created API gateway resources methods and integrations using the body argument.