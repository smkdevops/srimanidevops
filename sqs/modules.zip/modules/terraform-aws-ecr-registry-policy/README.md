## Anthem ECR Registry Policy Terraform Module

This module creates an ECR Registry Policy  using Terraform

## HIPAA eligibility status

1. Amazon Elastic Container Registry (ECR)


## Security Guardrail reference

[AWS Security Pattern](https://confluence.anthem.com/download/attachments/299009562/Anthem%20AWS%20Security%20Patterns%20-%20ECR%20-%20v1.docx?api=v2)

## Pre-Requisite

1. Policy should be in the form of Json.
2. user can pass policy in the form of
``` bash
    policy = file("./policy.json")
```

        or
        
``` bash
policy = jsonencode({
    Version = "2012-10-17",
    Statement = [
      {
        Sid    = "testpolicy",
        Effect = "Allow",
        Principal = {
          
           "AWS" : "arn:aws:iam::<Account-id>:root"
        },
        Action = [
          "ecr:ReplicateImage"
        ],
        Resource = [
          "arn:aws:ecr:<region-name>:<Account-id>:repository/*"
        ]
      }
    ]
  })
```
## Usage
To run this example you need to execute:

```bash

# Example Script

module "terraform-aws-ecr-registry-policy" {
  source  = "cps-terraform.anthem.com/<ORGANIZATION NAME>/terraform-aws-ecr-registry-policy/aws"
  
    
  policy = jsonencode({
    Version = "2012-10-17",
    Statement = [
      {
        Sid    = "testpolicy",
        Effect = "Allow",
        Principal = {
          
           "AWS" : "arn:aws:iam::<Account-id>:root"
        },
        Action = [
          "ecr:ReplicateImage"
        ],
        Resource = [
          "arn:aws:ecr:<region-name>:<Account-id>:repository/*"
        ]
      }
    ]
  })
}


#Initialize Terraform
terraform init

#Terraform Dry-Run
terraform plan

#Create the resources
terraform apply

#Destroy the resources saved in the tfstate
terraform destroy
```

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| policy | The policy document. This is a JSON formatted string | `string` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| registry\_id | The registry ID where the registry was created. |

## Testing 

1. Able to create registroy policy successfully.
2. Able to see  that polcy in console.