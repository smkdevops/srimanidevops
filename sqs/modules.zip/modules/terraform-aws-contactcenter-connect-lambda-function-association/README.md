# Anthem AWS Connect Lambda Function Association Resource

This module create aws Connect Lambda Function Association Resource.

## HIPAA eligibility status

* N/A


## Security Guardrail reference

[security Guardrails Link](https://confluence.anthem.com/download/attachments/717965086/Anthem%20AWS%20Security%20Patterns%20-%20Amazon%20Connect%20-%20Deloitte%20Digital.docx?version=1&modificationDate=1628274395000&api=v2)
## Pre-requisite

```bash
N/A
```

## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | n/a |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [aws_connect_lambda_function_association.this](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/connect_lambda_function_association) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_create_aws_connect_lambda_function_association"></a> [create\_aws\_connect\_lambda\_function\_association](#input\_create\_aws\_connect\_lambda\_function\_association) | Controls if AWS Connect lambda function association should be created | `bool` | `true` | no |
| <a name="input_function_arn"></a> [function\_arn](#input\_function\_arn) | (Required) Amazon Resource Name (ARN) of the Lambda Function, omitting any version or alias qualifier. | `string` | n/a | yes |
| <a name="input_instance_id"></a> [instance\_id](#input\_instance\_id) | (Required) The identifier of the Amazon Connect instance. You can find the instanceId in the ARN of the instance. | `string` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_id_aws_connect_lambda_function_association"></a> [id\_aws\_connect\_lambda\_function\_association](#output\_id\_aws\_connect\_lambda\_function\_association) | The Amazon Connect instance ID and Lambda Function ARN separated by a comma (,). |
| <a name="output_this_aws_connect_lambda_function_association"></a> [this\_aws\_connect\_lambda\_function\_association](#output\_this\_aws\_connect\_lambda\_function\_association) | n/a |
