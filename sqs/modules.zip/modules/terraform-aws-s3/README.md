
# Anthem AWS S3 Module

This module creates an S3 bucket.

## Pre-requisite
* At-rest encryption is implemented and enforced in the code. A valid Customer managed(CMK) is required.
* Bucket name is mandatory.
* Server access logging is enabled.
* Lifecycle rules has enabled. 
* Expired delete marker is enabled.
* Versioning on s3 bucket is enabled.
* Conditional resource creation is enabled with "create_s3_bucket" variable, setting this variable to "true" will create the resource and setting this to "false" will skip the resource creation
* Conditional resource creation is enabled with "create_s3_replication_configuration" variable, setting this variable to "true" will create the resource and setting this to "false" will skip the resource creation
* Conditional resource creation is enabled with "create_aws_s3_bucket_logging" variable, setting this variable to "true" will create the resource and setting this to "false" will skip the resource creation
* Conditional resource creation is enabled with "create_s3_bucket_versioning" variable, setting this variable to "true" will create the resource and setting this to "false" will skip the resource creation
* Conditional resource creation is enabled with "create_aws_s3_lifecycle_configuration" variable, setting this variable to "true" will create the resource and setting this to "false" will skip the resource creation
* If user want to set replication configuration in S3 then rule configuration should be passed as below.
## Note
* If your upgrading to this module then get the replication rule name from console and pass that to id. Else this will rename the existing the replication rule.
* Use filter prefix parameters for object level replication.

 e.g:
```bash
  create_aws_s3_lifecycle_configuration = true
  create_s3_replication_configuration = true
  role      = module.iam-role-instance-profile.iamrole_arn
  rule = [{
      id       = "sc-replica-rule"
      status   = "Enabled"
      existing_object_replication_status = "Enabled"
      priority  = 1
      source_selection_criteria = {
      sse_kms_encrypted_objects = {
        status = "Enabled"
        }
      }
      metrics = {
        status = "Enabled"
        event_threshold = {
          minutes = 1
          }
      }
      destination = {
        bucket             = module.bucket-secondary.arn
        storage_class      = "STANDARD_IA"
        encryption_configuration = {
        replica_kms_key_id = module.s3-kms-key-secondary.kms_arn["s3"]
        }       
      access_control_translation = {
        owner = "Destination"
      }
      replication_time = {
        status = "Enabled"
        time = {
          minutes = 1
        }
      }
      }
      delete_marker_replication = {
        status = "Disabled"
      }
      filter = {
        prefix = "test1/test11"
      }
    },
    {
      id       = "filter_rule"
      status   = "Enabled"    
     # priority  = 2
      source_selection_criteria = {
        sse_kms_encrypted_objects = {
          status = "Enabled"
        }
      }
      destination = {
        bucket             = module.bucket-secondary.arn
        storage_class      = "STANDARD_IA"
        encryption_configuration = {
        replica_kms_key_id = module.s3-kms-key-secondary.kms_arn["s3"]
        }}       
      delete_marker_replication = {
        status = "Disabled"
      }
      filter = {
        prefix = "test2"       
      }
    }
  ]   
```
* All S3 Actions are being routed through S3 Interface Endpoint with a default bucket policy that gets added to the bucket, i.e., This policy will be added by default within the module, no user input required.
```bash
statement {
    sid = "Access-to-specific-VPCE-only"
    effect = "Deny"
    principals {
      type        = "*"
      identifiers = ["arn:aws:iam::${data.aws_caller_identity.current.account_id}:root"]     
    }

    actions = [
      "s3:*"
    ]

    resources = [
      "arn:aws:s3:::${var.bucket}",
        "arn:aws:s3:::${var.bucket}/*"
    ]
    condition {
      test     = "StringNotEquals"
      variable = "aws:SourceVpce"
      values   = [local.endpoint]
    }
    condition {
      test     = "StringNotLike"
      variable = "aws:PrincipalARN"
      values   = ["arn:aws:iam::*:role/OlympusVaultServiceRole","arn:aws:iam::*:role/antm-sec","arn:aws:iam::*:role/antm-InfoSecIAMTeam"]
    }
  }

```
* Before creating any S3 resources using terraform, users need to update their provider configuration adding endpoint configuration as below.
```bash
For us-east-2:
provider "aws" {
  endpoints {   
    s3       = "https://bucket.vpce-0157fc5f0d4d2b003-zy0yy31z.s3.us-east-2.vpce.amazonaws.com"
  }
  region     = "us-east-2"
  access_key = data.vault_aws_access_credentials.creds.access_key
  secret_key = data.vault_aws_access_credentials.creds.secret_key
  token      = data.vault_aws_access_credentials.creds.security_token
}
For us-east-1:
provider "aws" {
  endpoints {   
    s3       = "https://bucket.vpce-0c65760352332dd5a-qahda5nv.s3.us-east-1.vpce.amazonaws.com"
  }
  region     = "us-east-1"
  access_key = data.vault_aws_access_credentials.creds.access_key
  secret_key = data.vault_aws_access_credentials.creds.secret_key
  token      = data.vault_aws_access_credentials.creds.security_token
}
```
* Any S3 actions that are being performed outside of terraform should also be pointed through the endpoint url as below, otherwise, users will get Access Denied error.
* A default bucket policy is added to route all S3 actions through S3 Privatelink, any modifications or updates to the bucket policy have to go through cloud security.
* Amazon S3 will change the default settings for S3 Block Public Access and Object Ownership (ACLs disabled) for all new S3 buckets. For new buckets created after this update, all S3 Block Public Access settings will be enabled, and S3 access control lists (ACLs) will be disabled.so we added aws_s3_bucket_ownership_controls resource. for more details refer this [document] (https://docs.aws.amazon.com/AmazonS3/latest/userguide/about-object-ownership.html)

## Mandatory Tags Note:
*	As per redesigned new mandatory tags, mandatory tags along with any additional tags have to be added through template configuration within the modules as below
*	Have a reference of mandatory tags module within the template configuration as shown in example script below.
```bash
# Mandatory Tag Workspace Variables
variable "apm-id" {}
variable "application-name" {}
variable "app-support-dl" {}
variable "app-servicenow-group" {}
variable "business-division" {}
variable "company" {}
variable "compliance" {}
variable "costcenter" {}
variable "environment" {}
variable "PatchGroup" {}
variable "PatchWindow" {}
variable "ATLAS_WORKSPACE_NAME" {}

# Mandatory Tags Module 
module "mandatory_tags" {
  source               = "cps-terraform.anthem.com/<ORG_NAME>/terraform-aws-mandatory-tags-v2/aws"
  tags                 = {}
  apm-id               = var.apm-id
  application-name     = var.application-name
  app-support-dl       = var.app-support-dl
  app-servicenow-group = var.app-servicenow-group
  business-division    = var.business-division
  compliance           = var.compliance
  company              = var.company
  costcenter           = var.costcenter
  environment          = var.environment
  PatchGroup           = var.PatchGroup
  PatchWindow          = var.PatchWindow
  workspace            = var.ATLAS_WORKSPACE_NAME
}
# Mandatory Data Tag Workspace Variables
variable "financial-internal-data" {}
variable "financial-regulatory-data" {}
variable "legal-data" {}
variable "privacy-data" {}

module "mandatory_data_tags" {
  source                    = "cps-terraform.anthem.com/<ORG_NAME>/terraform-aws-mandatory-data-tags-v2/aws"
  tags                      = {}
  financial-internal-data   = var.financial-internal-data
  financial-regulatory-data = var.financial-regulatory-data
  legal-data                = var.legal-data
  privacy-data              = var.privacy-data
}
```
* Mandatory and mandatory data tags modules should be merged in tags attribute as below: tags = merge(module.mandatory_tags.tags, module.mandatory_data_tags.tags)
* Any additional tags can be merged to tags attribute as below: tags = merge(module.mandatory_tags.tags, module.mandatory_data_tags.tags, {"sample" = "abc"})

## Usage
To run this example you need to execute:

Usecase 1:
1. This module is used to create s3 bucket without any repliaction

```bash
# Example Script
variable "create_s3_bucket" {
  default = true
}
module "s3_bucket" {

  /******** Source location of the module **************/
  source  = "cps-terraform.anthem.com/<ORGANIZATION NAME>/terraform-aws-s3/aws"

  /******** Mandatory tags *****************************/
  
  tags            = merge(module.mandatory_tags.tags, module.mandatory_data_tags.tags)

  create_s3_bucket = var.create_s3_bucket
  aws_kms_key_arn  = var.create_s3_bucket == false ? "" : module.kms-key.kms_arn["s3"]
  bucket           = ""
}

module "kms-key" {
  source  = "cps-terraform.anthem.com/<ORGANIZATION NAME>/terraform-aws-kms-service/aws"

  /******** Mandatory tags *****************************/
  tags = module.mandatory_tags.tags 

  /******** Parameter required for resource creation ****/
  service_name            = ["s3"]
  description             = ""
  kms_alias_name          = "${module.mandatory_tags.tags["application-name"]}-${module.mandatory_tags.tags["environment"]}"
}
```
Usecase2:

1. This module is used to create s3 bucket with cross region replication.
2. For cross region replication,user has to create iam role with below policy(crossregion.json).

```bash
module "s3_bucket_crossregionreplication" {

  /******** Source location of the module **************/
  source  = "cps-terraform.anthem.com/<ORGANIZATION NAME>/terraform-aws-s3/aws"

  /******** Mandatory tags *****************************/
  
  tags            = merge(module.mandatory_tags.tags, module.mandatory_data_tags.tags)

 
  aws_kms_key_arn  = module.kms-key.kms_arn["s3"]
  bucket           = ""
  create_s3_replication_configuration = true
  role                                =  module.iam-role-s3crossregion.iamrole_arn
  rule = [{
    id     = "s3-bucket-replica-rule"
    status = "Enabled"

    existing_object_replication_status = "Enabled"
    priority                           = 1
    source_selection_criteria = {
      sse_kms_encrypted_objects = {
        status = "Enabled"
      }
    }
    destination = {
      bucket        = ""                    ## Destination region bucket arn
      storage_class = "STANDARD"

      encryption_configuration = {
        replica_kms_key_id = ""             ## Destination region kms key arn 

      }
    }

  }]
}


module "iam-role-s3crossregion" {
  source = "cps-terraform.anthem.com/<ORGANIZATION NAME>/terraform-aws-iam-role/aws"

  tags = module.mandatory_tags.tags

  iam_role_name             = "sc-cross-region-replica-crossregion"
  role_description          = "to create ec2 instances using ssm"
  assume_role_service_names = ["s3.amazonaws.com"]
  inline_policy = [
    {
      name   = "crossregion"
      policy = file("./crossregion.json")
  }]
}

    crossregion.json :
{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Effect": "Allow",
            "Action": [
                "s3:GetReplicationConfiguration",
                "s3:ListBucket"
            ],
            "Resource": [
                "arn:aws:s3:::<source region bucket name>"
            ]
        },
        {
            "Effect": "Allow",
            "Action": [
                "s3:GetObjectVersionForReplication",
                "s3:GetObjectVersionAcl",
                "s3:GetObjectVersionTagging"
            ],
            "Resource": [
                "arn:aws:s3:::<source region bucket name>/*"
            ]
        },
        {
            "Effect": "Allow",
            "Action": [
                "s3:ReplicateObject",
                "s3:ReplicateDelete",
                "s3:ReplicateTags"
            ],
            "Resource": "arn:aws:s3:::<destination region bucket name>/*"
        },
        {
            "Effect": "Allow",
            "Action": [
                "kms:Encrypt",
                "kms:Decrypt"
            ],
            "Resource": [
                "<destination region kms key arn>",
                "<source region kms key arn>"
            ]
        }
    ]
}
```

UseCase 3:

1. This module is used to create s3 bucket with cross account replication.
2. To enable cross account replication, user has to follow below steps.
     * Destination account bucket should have below policy. 
         For S3 Bucket Policy modifications/additions, Submit a SNOW ticket to Cloud Security.  Assignment Group:  Cloud Security  - Cloud Security Delivery & Support Services Platform. DL:  <DL-CloudSecurity_StrategyEngineering@elevancehealth.com>
         
```bash      
  statement {
    effect      = "Allow"
    principals {
    type        = "AWS"
    identifiers = ["<iam role arn created for replication in source account>"]
    }
    actions = [
        "s3:ReplicateDelete",
        "s3:ReplicateObject"
    ]
    resources = ["arn:aws:s3:::<destination account bucket name>/*"]
  }
  statement {
    effect = "Allow"
    principals {
    type        = "AWS"
    identifiers = ["<iam role arn created for replication in source account>"]
    }
  actions = [
        "s3:List*",
        "s3:GetBucketVersioning",
        "s3:PutBucketVersioning"
  ]
  resources = ["arn:aws:s3:::<destination account bucket name>"]
  }
statement {
  effect = "Allow"
  principals {
  type        = "AWS"
  identifiers = ["arn:aws:iam::<source account number>:root"]
  }
  actions   = [
        "s3:ObjectOwnerOverrideToBucketOwner"
  ]
resources = ["arn:aws:s3:::<destination account bucket name>/*"]
}
  
```
  *  For destination account kms key, User has to add policy.
      * For Key Policy Modifications, Ref: [AWS Key Policy Modification](https://confluence.elevancehealth.com/display/ENTCLOUD/AWS+Key+Policy+Modification+Process) Process and reach out to Enterprise Encryption team for any questions/concerns.DL: <dl-CloudEncryption@elevancehealth.com>
     
```bash     
       
    statement {
     effect = "Allow"
      principals {
      type        = "AWS"
      identifiers = ["<iam role arn created for replication in source account"]
      }
      actions = [
        "kms:Encrypt",
        "kms:ReEncrypt*",
        "kms:GenerateDataKey*",
        "kms:DescribeKey"
      ]
       resources = ["*"]
    }

```
example:

```bash 
module "s3-bucket-sourceaccount" {
  source = "cps-terraform.anthem.com/<ORGANIZATION NAME>/terraform-aws-s3/aws"

  tags            = merge(module.mandatory_tags.tags, module.mandatory_data_tags.tags)
  aws_kms_key_arn = module.kms-key.kms_arn["s3"]
  bucket          = "test-s3-sourceaccount"

  create_s3_replication_configuration = true
  role                                = module.iam-role-s3crossaccountreplication.iamrole_arn
  rule = [{
    id     = "s3-bucket-replica-rule"
    status = "Enabled"

    existing_object_replication_status = "Enabled"
    priority                           = 1
    source_selection_criteria = {
      sse_kms_encrypted_objects = {
        status = "Enabled"
      }
    }
    destination = {
      bucket        = "" ### Destination account bucket arn
      storage_class = "STANDARD"
      account       = "" ### Destination account number
      encryption_configuration = {
        replica_kms_key_id = ""  ### Destination account kms key arn

      }
    }

  }]
}

module "iam-role-s3crossaccountreplication" {
  source = "cps-terraform.anthem.com/<ORGANIZATION NAME>/terraform-aws-iam-role/aws"

  tags = module.mandatory_tags.tags

  iam_role_name             = ""
  role_description          = ""
  assume_role_service_names = ["s3.amazonaws.com"]

  inline_policy = [
    {
      name   = "crossaccounttest"
      policy = file("./crossaccounttest.json")
    }
  ]
}

crossaccounttest.json:
{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Action": [
                "s3:ListBucket",
                "s3:GetReplicationConfiguration",
                "s3:GetObjectVersionForReplication",
                "s3:GetObjectVersionAcl",
                "s3:GetObjectVersionTagging",
                "s3:GetObjectRetention",
                "s3:GetObjectLegalHold"
            ],
            "Effect": "Allow",
            "Resource": [
                "arn:aws:s3:::<source account bucket name>",
                "arn:aws:s3:::<source account bucket name>/*",
                "arn:aws:s3:::<destination account bucket name>",
                "arn:aws:s3:::<destination account bucket name>/*"
            ]
        },
        {
            "Action": [
                "s3:ReplicateObject",
                "s3:ReplicateDelete",
                "s3:ReplicateTags",
                "s3:ObjectOwnerOverrideToBucketOwner"
            ],
            "Effect": "Allow",
            "Resource": [
                "arn:aws:s3:::<source account bucket name>/*",
                "arn:aws:s3:::<destination account bucket name>/*"
            ]
        },
        {
           
            "Effect": "Allow",
            "Action": [
                "kms:Encrypt",
                "kms:Decrypt",
                "kms:ReEncrypt*",
                "kms:GenerateDataKey*",
                "kms:DescribeKey"
            ],
            "Resource": [
                "<source account kms key arn>",
                "<destination account kms key arn>"
            ]
        }
    ]
}
```

## Note on existing objects replication
* Objects which pushed to bucket after replication setup only will be replicated.
* To replicate existing objects use below commands.
```bash
aws s3 cp s3://bucket-648103712037123 s3://bucket-destination-648103712037123/ --recursive --include "*.txt" 
```
* Reference links - https://aws.amazon.com/premiumsupport/knowledge-center/s3-large-transfer-between-buckets/ 
* https://bobbyhadz.com/blog/aws-cli-list-all-files-in-bucket 

## If S3 is not required in any other env then configure the arguments as below accordingly.
```bash  
  variable "create_s3_bucket" {
    default = false
  }
  create_s3_bucket =  var.create_s3_bucket

  aws_kms_key_arn  = var.create_s3_bucket == false ? "" : module.s3-kms-key-primary.kms_arn["s3"]
```
## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| aws\_kms\_key\_arn | (Required) The Customer managed(CMK) to encrypt the bucket | `string` | n/a | yes |
| bucket | (Required) The name of the bucket. | `string` | n/a | yes |
| bucket\_key\_enabled | (Optional) "Default : null". Whether or not to use Amazon S3 Bucket Keys for SSE-KMS. | `string` | `null` | no |
| create\_aws\_s3\_bucket\_logging | (Optional) "Default : true". A boolean that indicates whether to create aws\_s3\_bucket\_logging or not. Default is true | `bool` | `true` | no |
| create\_aws\_s3\_lifecycle\_configuration | (Optional) "Default : true". A boolean that indicates whether to create s3\_bucket\_versioning or not. Default is true | `bool` | `true` | no |
| create\_s3\_bucket | (Optional) "Default : true". A boolean that indicates whether to create s3 bucket or not. Default is true | `bool` | `true` | no |
| create\_s3\_bucket\_versioning | (Optional) "Default : true". A boolean that indicates whether to create s3\_bucket\_versioning or not. Default is true | `bool` | `true` | no |
| create\_s3\_replication\_configuration | (Optional) "Default : false". A boolean that indicates whether to create create\_s3\_replication\_configuration or not. Default is true | `bool` | `false` | no |
| days\_after\_initiation | (Optional) "Default : 7". The number of days after which Amazon S3 aborts an incomplete multipart upload | `number` | `7` | no |
| existing\_object\_replication\_status | (Optional) "Default : null". Whether the existing objects should be replicated. Either Enabled or Disabled. | `string` | `null` | no |
| expiration\_date | (Optional) "Default : null". The date the object is to be moved or deleted. Should be in GMT ISO 8601 Format. | `string` | `null` | no |
| expiration\_days | (Optional) "Default : 365". The lifetime, in days, of the objects that are subject to the rule. The value must be a non-zero positive integer | `string` | `365` | no |
| expired\_object\_delete\_marker | (Optional) "Default : true".(Conflicts with date and days) Indicates whether Amazon S3 will remove a delete marker with no noncurrent versions. If set to true, the delete marker will be expired; if set to false the policy takes no action. | `bool` | `"true"` | no |
| filter\_lifecycle\_configuration | (Optional) "Default : {}". Configuration block used to identify objects that a Lifecycle Rule | `map(any)` | `{}` | no |
| force\_destroy | (Optional) "Default : false". A boolean that indicates all objects (including any locked objects) should be deleted from the bucket so that the bucket can be destroyed without error. These objects are not recoverable. Default is false. | `bool` | `false` | no |
| mfa | (Optional) "Default : "" ". Required if versioning\_configuration mfa\_delete is enabled.The concatenation of the authentication device's serial number, a space, and the value that is displayed on your authentication device. | `string` | `""` | no |
| mfa\_delete | (Optional) "Default : null". Specifies whether MFA delete is enabled in the bucket versioning configuration. Valid values: Enabled or Disabled. | `string` | `null` | no |
| noncurrent\_version\_expiration | (Optional) "Default : {}". Configuration block that specifies when noncurrent object versions expire | `any` | `{}` | no |
| noncurrent\_version\_transition | (Optional) "Default : ["noncurrent\_days = 30","storage\_class = "STANDARD\_IA""]". Specifies when noncurrent object versions transitions. Days: Specifies the number of days noncurrent object versions transition. Storage\_class: Specifies the Amazon S3 storage class to which you want the noncurrent object versions to transition. Can be ONEZONE\_IA, STANDARD\_IA, INTELLIGENT\_TIERING, GLACIER, or DEEP\_ARCHIVE. | `list(any)` | <pre>[<br>  {<br>    "noncurrent_days": 30,<br>    "storage_class": "STANDARD_IA"<br>  }<br>]</pre> | no |
| object\_lock\_configuration | (Optional) "Default : {}". A configuration of S3 object locking Indicates whether this bucket has an Object Lock configuration enabled. | `any` | `{}` | no |
| object\_ownership | (Optional) "Default : ObjectWriter".Valid values: BucketOwnerPreferred, ObjectWriter or BucketOwnerEnforced | `string` | `"ObjectWriter"` | no |
| role | (Optional) "Default : "" ". The ARN of the IAM role for Amazon S3 to assume when replicating the objects. | `string` | `""` | no |
| rule | (Optional) "Default : {}". Set of configuration blocks describing the rules managing the replication | `any` | `{}` | no |
| source\_selection\_criteria | (Optional) "Default : {}". A configuration block for filter information for the selection of Amazon S3 objects encrypted with AWS KMS. If specified, replica\_kms\_key\_id in destination encryption\_configuration must be specified as well | `map(any)` | `{}` | no |
| status | (Optional) "Default : null". The status of the rule. Either Enabled or Disabled. The rule is ignored if status is not Enabled. | `string` | `null` | no |
| tags | (Required) A mapping of tags to assign to the bucket. | `map(string)` | n/a | yes |
| target\_grant | (Optional) "Default : {}". Set of configuration blocks with information for granting permissions | `map(any)` | `{}` | no |
| transition | (Optional) "Default : ["days = 30","storage\_class = "STANDARD\_IA""]". Specifies a period in the object's transitions. Days: Specifies the number of days after object creation when the specific rule action takes effect. Storage\_class: Specifies the Amazon S3 storage class to which you want the object to transition. Can be ONEZONE\_IA, STANDARD\_IA, INTELLIGENT\_TIERING, GLACIER, or DEEP\_ARCHIVE. | `list(any)` | <pre>[<br>  {<br>    "days": 30,<br>    "storage_class": "STANDARD_IA"<br>  }<br>]</pre> | no |

## Outputs

| Name | Description |
|------|-------------|
| arn | The ARN of the bucket. Will be of format arn:aws:s3:::bucketname. |
| id | The name of the bucket. |

## Unit Testing 

* Submit & able to execute job. 
* The terraform apply takes like 2 minutes to complete the s3 bucket creation
* Creates a non public S3 bucket 
* Configures the access logs into a pre created repository
* Use lifecycle rules
* Able to create bucket object cross region replication in disaster recovery region
* Tested both cross region and cross account replication.


