# Anthem DMS Replication Subnet Group Base Code

This module creates subnet group for Replication instance of AWS DMS (Database Migration Services)

## HIPAA eligibility status

1. AWS DMS (Database Migration Service) is eligible.

## Security Guardrail reference

[AWS Security Pattern](https://confluence.anthem.com/download/attachments/299009562/Anthem%20AWS%20Security%20Patterns%20-%20Database%20Migration%20Service.docx?api=v2)

## Pre-requisite
1. As per Anthem Cloud Security Guidelines, non-public subnets are not allowed to create DMS subnet group.

2. Valid subnets are required to cover at least 2 availability zones to ensure fault tolerance

# Release Notes:
## New Version - 0.0.3
1. With Mandatory Tags Redesign that happened early part of this year, we had to refactor all our templates to include central Mandatory Tag Module and remove variable references from the code.
2. All the new templates has been pushed in and you should be able to see the changes. Below are the highlights. 

### Adoption of the New Version - 0.0.3

1.	There is a new file tags.tf that is now included and integral part of our code base.
2.	We now have only Application Specific Tags in DMS modules of each templates. The entire code is now bit sleek. 
3.	Each module refers to mandatory tags module.

## Usage

To run this example you need to execute:

```bash
#Initialize Terraform
terraform init

#Terraform Dry-Run
terraform plan

#Create the resources
terraform apply

#Destroy the resources saved in the tfstate
terraform destroy
```

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| application | Based upon application nomenclature in server naming convention policy.Use up to six (6) characters to name your application. | `string` | n/a | yes |
| application\_dl | Application DL | `string` | n/a | yes |
| barometer-it-num | The barometer it number. | `string` | n/a | yes |
| company | Company that owns resource | `string` | n/a | yes |
| compliance | PHI, PCI, PII, SOX, None | `string` | n/a | yes |
| costcenter | The project cost center. | `string` | n/a | yes |
| environment | DBx,SIT,PERF,PRODX,UAT,UTILx | `string` | n/a | yes |
| it-department | The name of IT department | `string` | n/a | yes |
| layer | WEBx, MWx, DBx, UTILx | `string` | n/a | yes |
| owner-department | The name of department owner. | `string` | n/a | yes |
| replication\_subnet\_group\_description | The description for the subnet group. | `string` | n/a | yes |
| replication\_subnet\_group\_id | The name for the replication subnet group. This value is stored as a lowercase string. <br> Must contain no more than 255 alphanumeric characters, periods, spaces, underscores, or hyphens. <br> Must not be "default". | `string` | n/a | yes |
| resource-type | Type of resource. | `string` | n/a | yes |
| subnet\_ids | A list of the EC2 subnet IDs for the subnet group. | `list(string)` | n/a | yes |
| tags | A mapping of tags to assign to the resource. | `map(any)` | `{}` | no |

## Outputs

| Name | Description |
|------|-------------|
| replication\_subnet\_group\_id | The ID of the replication subnet group |
| vpc\_id | The ID of the VPC the subnet group is in. |



## Unit Testing
1. Created Subnet group with subnets with minimum two availaibility zone.
2. Manadatory tags are attached to subnet group.
3. Utilized same subnet group while creating Replication Instance.
