# Anthem AWS Cloudfront Origin Request Policy Resource

This module create aws Cloudfront Origin Request Policy Resource

<span style="color: red">**This module should only be used by Contact Center Project.**</span>

## HIPAA eligibility status

* N/A


## Security Guardrail reference

[security Guardrails Link](https://confluence.anthem.com/download/attachments/717965086/Anthem%20AWS%20Security%20Patterns%20-%20AWS_CloudFront%20-%20Deliotte%20Digital%20CCaaS%20use%20case.docx?version=1&modificationDate=1628274246000&api=v2)

## Pre-requisite

- Dependent resources will be needed if any & Usage for Complex Parameter/s given below.
```
cookies_config = [{
    cookie_behavior = <VALUE>
    cookies = [{
      items = [ value1,value2,...]
    }]
  }]
```
```
  headers_config = [{
    header_behavior = <VALUE>
    headers = [{
      items = [ value1,value2,...]
    }]
  }]
```
```
  query_strings_config = [{
    query_string_behavior = <VALUE>
    query_strings = [{
      items = [ value1,value2,...]
    }]
  }]

```
## Usage

To run this example you need to execute:

```bash
#Initialize Terraform
terraform init

#Terraform Dry-Run
terraform plan

#Create the resources
terraform apply

#Destroy the resources saved in the tfstate
terraform destroy
```

## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | ">=3.35.0" |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [aws_cloudfront_origin_request_policy.this](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/cloudfront_origin_request_policy) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_comment"></a> [comment](#input\_comment) | (Optional) Comment to describe the origin request policy. | `string` | `null` | no |
| <a name="input_cookies_config"></a> [cookies\_config](#input\_cookies\_config) | (Required) Object that determines whether any cookies in viewer requests (and if so, which cookies) are included in the origin request key and automatically included in requests that CloudFront sends to the origin. See Cookies Config for more information. | <pre>set(object(<br>    {<br>      cookie_behavior = string<br>      cookies = list(object(<br>        {<br>          items = set(string)<br>        }<br>      ))<br>    }<br>  ))</pre> | n/a | yes |
| <a name="input_create_origin_request_policy"></a> [create\_origin\_request\_policy](#input\_create\_origin\_request\_policy) | Controls if CloudFront origin request policy should be created | `bool` | `true` | no |
| <a name="input_etag"></a> [etag](#input\_etag) | (optional) | `string` | `null` | no |
| <a name="input_headers_config"></a> [headers\_config](#input\_headers\_config) | Required) Object that determines whether any HTTP headers (and if so, which headers) are included in the origin request key and automatically included in requests that CloudFront sends to the origin. See Headers Config for more information. | <pre>set(object(<br>    {<br>      header_behavior = string<br>      headers = list(object(<br>        {<br>          items = set(string)<br>        }<br>      ))<br>    }<br>  ))</pre> | n/a | yes |
| <a name="input_name"></a> [name](#input\_name) | (Required) Unique name to identify the origin request policy. | `string` | n/a | yes |
| <a name="input_query_strings_config"></a> [query\_strings\_config](#input\_query\_strings\_config) | (Required) Object that determines whether any URL query strings in viewer requests (and if so, which query strings) are included in the origin request key and automatically included in requests that CloudFront sends to the origin. See Query Strings Config for more information. | <pre>set(object(<br>    {<br>      query_string_behavior = string<br>      query_strings = list(object(<br>        {<br>          items = set(string)<br>        }<br>      ))<br>    }<br>  ))</pre> | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_etag"></a> [etag](#output\_etag) | returns a string |
| <a name="output_id"></a> [id](#output\_id) | returns a string |
| <a name="output_this"></a> [this](#output\_this) | n/a |
