# Anthem AWS APIGateway Deployment Module

Provides a settings of an API Gateway Account. Settings is applied region-wide per provider block.

## HIPAA eligibility status

1. Amazon API Gateway is eligible

## Security Guardrail reference

https://confluence.anthem.com/pages/viewpageattachments.action?pageId=299009562&sortBy=date&startIndex=60&preview=/299009562/370573552/Anthem%20AWS%20Security%20Patterns%20-%20API%20Gateway.docx

## Pre-Requisites

1. cloudwatch_role_arn parameter is mandatory.

## Usage
To run this example you need to execute:

```bash

module "api_gateway_account" {
  source = "cps-terraform.anthem.com/<ORGNAME>/terraform-aws-api-gateway-account/aws"

  cloudwatch_role_arn = ""
}

#Initialize Terraform
terraform init

#Terraform Dry-Run
terraform plan

#Create the resources
terraform apply

#Destroy the resources saved in the tfstate
terraform destroy
```

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| cloudwatch\_role\_arn | (Required) The ARN of an IAM role for CloudWatch (to allow logging & monitoring). See more in AWS Docs. Logging & monitoring can be enabled/disabled and otherwise tuned on the API Gateway Stage level. | `string` | n/a | yes |
| create\_apigateway\_account | (Optional) A boolean that indicates whether to create API Gateway Account or not. Default is true | `bool` | `true` | no |

## Outputs

| Name | Description |
|------|-------------|
| throttle\_settings | throttle\_settings, block exports burst\_limit and rate\_limit |

## Testing

1. Able to create a API Gateway account.