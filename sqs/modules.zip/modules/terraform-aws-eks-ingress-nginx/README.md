## Terraform module to deploy Nginx Ingress in EKS Cluster

 This module will help to deploy Nginx Ingress Controller into existing Kubernetes cluster.

 
## Pre-Requisites

1. Should have EKS cluster up and running.
2. Get qualified DNS of application.
3. Include Kuberenetes provider for your EKS cluster as shown below:

```bash
data "aws_eks_cluster" "cluster" {
  name = module.eks_cluster.cluster_id
}

data "aws_eks_cluster_auth" "cluster" {
  name = module.eks_cluster.cluster_id
}

provider "kubernetes" {
  #  load_config_file       = false
  host                   = data.aws_eks_cluster.cluster.endpoint
  cluster_ca_certificate = base64decode(data.aws_eks_cluster.cluster.certificate_authority.0.data)
  token                  = data.aws_eks_cluster_auth.cluster.token
}
```
## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| nginx_ingress_namespace | The namespace to install nginx-ingress| String | - | yes |
| nginx_ingress_repository | Repository URL where to locate the requested chart|String|-|yes|
| nginx_ingress_chartname | Helm chart name | String | - |yes|
| nginx_ingress_domain_name | Record to create in ROUTE53. The format is - "*.nginx-ingress.<Default HostedZone created in AWS Account>" | String | - | yes |
| nginx_ingress_timeout | Time in seconds to wait for any individual kubernetes operation | String | 400 | yes |
| nginx_ingress_helm_version | Specify the exact chart version to install. If this is not specified, the latest version is installed | String | 400 | yes |
| nginx_ingress_name | Release name | String | - | yes |

## Usage

Include below module code to deploy Istio into EKS cluster:
1. Configure Ingress gateway for application. Use this module to create ingress gateway for each application (specific to application). It also configure IAM policy for ExternalDns.

```bash
module "terraform_aws_nginx_ingress" {
  source                     = "cps-terraform.anthem.com/ACSCD/terraform-aws-eks-ingress-nginx/aws"
  version                    = "0.0.1" # use latest module version
  nginx_ingress_namespace    = "ingress-nginx"
  nginx_ingress_repository   = "https://kubernetes.github.io/ingress-nginx"
  nginx_ingress_chartname    = "ingress-nginx"
  nginx_ingress_domain_name  = "*.nginx.<HOSTED_ZONE>"
  nginx_ingress_timeout      = "500"
  nginx_ingress_helm_version = ""
  nginx_ingress_name         = "ingress-nginx"
}

terraform init
terraform plan # Evaluate the resources creation
terraform apply --auto-approve

```
## Validation

Run below command to verify the installation. Make sure all resources got deployed successfully without any error.

```bash
kubectl get all -n <nginx_ingress_namespace>

```
