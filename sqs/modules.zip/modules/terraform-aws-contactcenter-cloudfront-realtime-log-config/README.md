# Anthem AWS Cloudfront Real time log config Resource

This module create aws Cloudfront Cache Resource.

<span style="color: red">**This module should only be used by Contact Center Project.**</span>

## HIPAA eligibility status

* N/A


## Security Guardrail reference

[security Guardrails Link](https://confluence.anthem.com/download/attachments/717965086/Anthem%20AWS%20Security%20Patterns%20-%20AWS_CloudFront%20-%20Deliotte%20Digital%20CCaaS%20use%20case.docx?version=1&modificationDate=1628274246000&api=v2)

## Pre-requisite

- Dependent resources will be needed if any & Usage for Complex Parameter/s given below.
```
 endpoint = [{
    kinesis_stream_config = [{
      role_arn   = <VALUE>
      stream_arn = <VALUE>
    }]
    stream_type = <VALUE>
  }]
}

```
## Usage

To run this example you need to execute:

```bash
#Initialize Terraform
terraform init

#Terraform Dry-Run
terraform plan

#Create the resources
terraform apply

#Destroy the resources saved in the tfstate
terraform destroy
```
## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | ">=3.35.0" |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [aws_cloudfront_realtime_log_config.this](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/cloudfront_realtime_log_config) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_create_realtime_log_config"></a> [create\_realtime\_log\_config](#input\_create\_realtime\_log\_config) | Controls if CloudFront realtime log config should be created | `bool` | `true` | no |
| <a name="input_endpoint"></a> [endpoint](#input\_endpoint) | (Required) The Amazon Kinesis data streams where real-time log data is sent. | <pre>set(object(<br>    {<br>      kinesis_stream_config = list(object(<br>        {<br>          role_arn   = string<br>          stream_arn = string<br>        }<br>      ))<br>      stream_type = string<br>    }<br>  ))</pre> | n/a | yes |
| <a name="input_fields"></a> [fields](#input\_fields) | (Required) The fields that are included in each real-time log record. See the AWS documentation for supported values. | `set(string)` | n/a | yes |
| <a name="input_name"></a> [name](#input\_name) | (Required) The unique name to identify this real-time log configuration. | `string` | n/a | yes |
| <a name="input_sampling_rate"></a> [sampling\_rate](#input\_sampling\_rate) | (Required) The sampling rate for this real-time log configuration. The sampling rate determines the percentage of viewer requests that are represented in the real-time log data. An integer between 1 and 100, inclusive. | `number` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_arn"></a> [arn](#output\_arn) | returns a string |
| <a name="output_id"></a> [id](#output\_id) | returns a string |
| <a name="output_this"></a> [this](#output\_this) | n/a |

