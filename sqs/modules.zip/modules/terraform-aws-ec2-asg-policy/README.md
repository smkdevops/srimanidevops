# AWS Auto scaling group policy Terraform Module

This module is to create the auto scaling group policy.

## HIPAA eligibility status

1. Amazon Elastic Compute Cloud (Amazon EC2) 
2. Amazon Auto Scaling

## Security Guardrail reference

https://confluence.anthem.com/pages/viewpageattachments.action?pageId=299009562&sortBy=date&startIndex=80&preview=/299009562/357900867/Anthem%20AWS%20Security%20Patterns%20-%20EC2%20AutoScalingGroup_v1.docx

## Pre-Requisite

1. This module is to create the SimpleScaling, StepScaling and TargetTrackingScaling policy.
2. TargetTrackingScaling policy can be created either with predefined metrics or customized metrics.
3. CloudWatch alarm trigger should be configured seperately for SimpleScaling and StepScaling.
4. StepScaling policy can be set like below.

step_adjustment = [ {
    scaling_adjustment          = -1
    metric_interval_lower_bound = null
    metric_interval_upper_bound = 2.0
},
{
    scaling_adjustment          = 1
  metric_interval_lower_bound = 2.0
  metric_interval_upper_bound = null
}
]

5. If one step adjustment has a negative lower bound, then there must be a step adjustment with a null lower bound.
6. If one step adjustment has a positive upper bound, then there must be a step adjustment with a null upper bound.
7. Target Tracking scaling policy with predefined metric type can be provided like below.

target_tracking_configuration = [{
    predefined_metric_type = "ASGAverageCPUUtilization"
    disable_scale_in       = false
    target_value           = "50.0"
}]

8. Target Tracking scaling policy with customized metric type can be provided like below.

target_tracking_configuration = [{
    customized_metric_name = "hoge"
    customized_namespace = "hoge"
    customized_statistic = "Maximum"
    disable_scale_in       = false
    target_value           = "50.0"
}]

## Usage
To run this example you need to execute:

```bash
#Initialize Terraform
terraform init

#Terraform Dry-Run
terraform plan

#Create the resources
terraform apply

#Destroy the resources saved in the tfstate
terraform destroy
```

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| adjustment\_type | Specifies whether the adjustment is an absolute number or a percentage of the current capacity. Valid values are ChangeInCapacity, ExactCapacity, and PercentChangeInCapacity. Default is ChangeInCapacity. | `string` | `"ChangeInCapacity"` | no |
| autoscaling\_group\_name | The name of the autoscaling group. | `string` | n/a | yes |
| autoscaling\_policy\_name | The name of the auto scaling policy. | `string` | n/a | yes |
| cooldown | The amount of time, in seconds, after a scaling activity completes and before the next scaling activity can start. This arguments is only available to SimpleScaling type policy. Default is 300.| `string` | `"300"` | no |
| disable\_scale\_in | Indicates whether scale in by the target tracking policy is disabled. Default is false. | `bool` | `false` | no |
| estimated\_instance\_warmup | The estimated time, in seconds, until a newly launched instance will contribute CloudWatch metrics. Without a value, AWS will default to the group's specified cooldown period. default is null. | `string` | `null` | no |
| metric\_aggregation\_type | The aggregation type for the policy's metrics. Valid values are Minimum, Maximum, and Average. The argument is only available to StepScaling type policy. Default is Average. | `string` | `"Average"` | no |
| policy\_type | The policy type, either SimpleScaling, StepScaling or TargetTrackingScaling. Default is SimpleScaling | `string` | `"SimpleScaling"` | no |
| scaling\_adjustment | The number of instances by which to scale. adjustment\_type determines the interpretation of this number (e.g., as an absolute number or as a percentage of the existing Auto Scaling group size). A positive increment adds to the current capacity and a negative value removes from the current capacity. Default is 1. | `string` | `"1"` | no |
| step\_adjustment | A set of adjustments that manage group scaling. This is mandatory if the policy type is StepScaling. Default is null. | `list` | `null` | no |
| target\_tracking\_configuration | A target tracking policy. This is mandatory if the policy type is TargetTrackingScaling. Default is []. | `list` | `[]` | no |

## Outputs

| Name | Description |
|------|-------------|
| adjustment\_type | The scaling policy's adjustment type. |
| arn | The ARN assigned by AWS to the scaling policy. |
| autoscaling\_group\_name | The scaling policy's assigned autoscaling group. |
| name | The scaling policy's name. |
| policy\_type | The scaling policy's type. |


## Testing

1. Target tracking Policy is created with Average CPU utilization of 50%.
2. Tested the policy by putting stess on EC2 instances.
3. Observed that the scale out event happened when the CPU utilization goes above 50% on the existing EC2 instances.
4. Observed that the scale in event happened when the CPU utilization goes below 50% on the existing EC2 instances.