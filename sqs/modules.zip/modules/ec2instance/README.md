# Anthem AWS EC2

This module creates one or more EC2 instances

## Pre-Requisite

* If user wants to pass <INSTANCE_NAME> Kindly pass the parameter <Instance_name> in your template, Otherwise it will take by default.
* User can attach additional <EBS> volumes in the script.
* A valid Customer Managed Key CMK is required
* AMI is to use for the instance. If the AMI has the EBS encrypted you must use a CMK for the encryption
* Instance_type is the type of instance to start. Updates to this field will trigger a stop/start of the EC2 instance.
* The required Security group with the rules should be exist for the instance.
* The required subnet should be exist for the instance.
* Keyword 'file' added to the user data variable.
* If user wants to provide http_token variable then they can pass otherwise it will take by default.Default value is "required"

## IMPORTANT NOTE:

* User have option to create multiple EC2 instances with multiple network interfaces.
* User have option to create multiple EC2 instances with subnets and security groups.
* Mandatory tags should be passed to the module either in single variables or inside the tags map variable
* In capacity_reservation_specification you can specify either capacity_reservation_preference or capacity_reservation_target..If you specify both it will fail.

## Observation

* Instances are getting created with the subnet selecting sequentially from the subnet list. like if 5 instances [ 0,1,2,3,4] and 3 subnets [0,1,2] then instances will be created with mapping [0-0,1-1,2-2,3-0,4-1]
* If subnets are more than number of EC2 then the EC2 will be created in the required subnets and extra subnets will be unused.
* While creating multiple instances , Creation of Number of instances should be equals to number of ENI's.
  No_of_EC2's = No_of_ENI's
* If number of EC2 is more than number of ENI then the extras EC2 will be terminated automatically. (No_of_EC2's > No_of_ENI's)
* If number of ENI is greater than number of EC2 then the number of ENI equals to number of EC2 will be allocated and rest of the ENI will be unused which can be used in future. (No_of_EC2's < No_of_ENI's)
* If you want to create EC2 with network interface then create the network interface using network interface module and provide the id to network_interface_id parameter.
* EC2 can be created with network interface or without network interface. Subnet ID should be provided if EC2 need to be created without network interface otherwise it should be null.
* If EC2 need to be created with network interface then network interface id becomes primary address.
* If EC2 need to be created with the network interface as a secondary address then use network interface attachment module once EC2 is created.

## Mandatory Tags Note:
*	As per redesigned new mandatory tags, mandatory tags along with any additional tags have to be added through template configuration within the modules as below
*	Have a reference of mandatory tags module within the template configuration as shown in example script below.
```bash
# Mandatory Tag Workspace Variables
variable "apm-id" {}
variable "application-name" {}
variable "app-support-dl" {}
variable "app-servicenow-group" {}
variable "business-division" {}
variable "company" {}
variable "compliance" {}
variable "costcenter" {}
variable "environment" {}
variable "PatchGroup" {}
variable "PatchWindow" {}
variable "ATLAS_WORKSPACE_NAME" {}

# Mandatory Tags Module 
module "mandatory_tags" {
  source               = "cps-terraform.anthem.com/<ORG_NAME>/terraform-aws-mandatory-tags-v2/aws"
  tags                 = {}
  apm-id               = var.apm-id
  application-name     = var.application-name
  app-support-dl       = var.app-support-dl
  app-servicenow-group = var.app-servicenow-group
  business-division    = var.business-division
  compliance           = var.compliance
  company              = var.company
  costcenter           = var.costcenter
  environment          = var.environment
  PatchGroup           = var.PatchGroup
  PatchWindow          = var.PatchWindow
  workspace            = var.ATLAS_WORKSPACE_NAME
}
```
*	Mandatory tags module should be referred in tags attribute as below:
tags = module.mandatory_tags.tags
*	Any additional tags can be merged to tags attribute as below:
tags = merge(module.mandatory_tags.tags, {"sample" = "abc"})

## Usage

To run this example you need to execute:

```bash
# Example Script

module "ec2instance" {

  source = "cps-terraform.anthem.com/<ORG_NAME>/terraform-aws-ec2/aws"

  tags = merge(module.mandatory_tags.tags)
  instance_name = "" #"awsa-DBx-s3" ##"${module.mandatorytags.tags["application-name"]}-${module.mandatorytags.tags["environment"]}-${module.mandatorytags.tags["costcenter"]}" #User has to pass name of the instances from aws console if it is created already.
  
  #Required Parameters
  number_of_instances                  = ""
  instance_ami                         = ""       
  vpc_security_group_ids               = [""]
  kms_key_id                          = module.kms.kms_arn["ec2"]
 
  #Optional Parameters
  delete_on_termination_eni            = ""
  host_id                              = ""
  tenancy                              = ""
  root_volume_size                     = ""
  subnet_ids                           = [""]
  iam_instance_profile                 = module.instance-profile.name
  instance_initiated_shutdown_behavior = ""
  delete_on_termination                = ""
  instance_type                        = ""
  source_dest_check                    = ""
   #user_data = ""
  #private_ips = [""]
  network_interface_id = [module.network.id]
  #http_tokens = "optional" 
  ebs_optimized = false
  hibernation   = false
  user_data_base64 = ""
  ephemeral_block_device =[{
    device_name = ""
    virtual_name = ""
  }]
  enclave_enabled = false
  auto_recovery   ="disabled"
  capacity_reservation_specification = [{
     capacity_reservation_preference = ""
  }]
  capacity_reservation_target = [{
    capacity_reservation_resource_group_arn    = ""
    capacity_reservation_id         = ""
   }]
  cpu_credits = ""
   disable_api_termination =false
  ebs_block_device = [{
    device_name       = ""
    kms_key_id        = ""
    volume_size       = ""
    volume_type       = ""

  }]
}

module "network" {

  source = "cps-terraform.anthem.com/<ORG_NAME>/terraform-aws-network-interface/aws"
  number_of_networkinterfaces = 2
  subnet_ids                  = [""] 
  vpc_security_group_ids      = [""]
  #private_ips = []

  tags = merge(module.mandatory_tags.tags)
}

module "kms" {

  source  = "cps-terraform.anthem.com/<ORG_NAME>/terraform-aws-kms-service/aws"
  
  tags = merge(module.mandatory_tags.tags)
  service_name = ["ec2"]
}


module "iam-role" {

source  = "cps-terraform.anthem.com/<ORG_NAME>/terraform-aws-iam-role/aws"
 
  tags = merge(module.mandatory_tags.tags)

################## IAM Role #####################
aws_create_iam_role =  true
iam_role_name                   = ""
role_description                = ""
# assume_role_policy              = jsonencode({
#     Version = "2012-10-17",
#     Statement = [
#       {
#         Action = "sts:AssumeRole"
#         Effect = "Allow"
#         Sid    = ""
#         Principal = {
#           Service = [
#             "application-autoscaling.amazonaws.com",
#             "lambda.amazonaws.com",
#             "elasticmapreduce.amazonaws.com",
#             "glue.amazonaws.com",
#             "ec2.amazonaws.com", 
#             "s3.amazonaws.com",
#             "es.amazonaws.com",
#             "ssm.amazonaws.com",
#             "states.amazonaws.com",
#             "events.amazonaws.com"
#             ]
#         }
#       }     
#     ]
#   })

assume_role_service_names       = ["ec2.amazonaws.com"]
managed_policy_arns =["arn:aws:iam::aws:policy/AmazonSSMFullAccess"]
# inline_policy = [{
#     name = "test-inlinepolicy"
#     policy = file("./role_policy.json")
#    }]
}

module "instance-profile" {

source = "cps-terraform.anthem.com/<ORG_NAME>/terraform-aws-iam-instance-profile/aws"

  tags = merge(module.mandatory_tags.tags)
  instance_profile_name = ""
  role_name = ""

}

#Initialize Terraform
terraform init

#Terraform Dry-Run
terraform plan

#Create the resources
terraform apply

#Destroy the resources saved in the tfstate
terraform destroy
```
## Providers

| Name | Version |
|------|---------|
| aws | n/a |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| auto\_recovery | (Optional) "Default : "disabled" ". The automatic recovery behavior of the Instance. Can be default or disabled | `string` | `"disabled"` | no |
| capacity\_reservation\_specification | (Optional) "Default : []". Indicates the target Capacity Reservation. | `any` | `[]` | no |
| capacity\_reservation\_target | (Optional) "Default : []". Indicates the target Capacity Reservation. | `any` | `[]` | no |
| cpu\_credits | (Optional) "Default : null". Credit option for CPU usage. Valid values include standard or unlimited.T3 instances are launched as unlimited by default.T2 instances are launched as standard by default. | `string` | `null` | no |
| delete\_on\_termination | (Optional) "Default : true". Whether the volume should be destroyed on instance termination. | `bool` | `true` | no | 
| delete\_on\_termination\_eni | (Optional) "Default : false". Whether or not to delete the network interface on instance termination. Defaults to false. Currently, the only valid value is false, as this is only supported when creating new network interfaces when launching an instance. | `bool` | `false` | no |
| disable\_api\_termination | (Optional) "Default : true". If true, enables EC2 Instance Termination Protection. | `bool` | `true` | no |
| ebs\_block\_device | (Optional) "Default : null". To add EBS Volume to EC2 instances | `any` | `null` | no |
| ebs\_optimized | (Optional) "Default : false". If true, the launched EC2 instance will be EBS-optimized. Note that if this is not set on an instance type that is optimized by default then this will show as disabled but if the instance type is optimized by default then there is no need to set this and there is no effect to disabling it. | `bool` | `false` | no |
| enclave\_enabled | (Optional) "Default : false". Enable Nitro Enclaves on launched instances. | `bool` | `false` | no |
| ephemeral\_block\_device | (Optional) "Default : []". To customize Ephemeral (also known as Instance Store) volumes on the instance. | `any` | `[]` | no |
| hibernation | (Optional) "Default : false". If true, the launched EC2 instance will support hibernation. | `bool` | `false` | no |
| host\_id | (Optional) "Default : null". ID of a dedicated host that the instance will be assigned to. Use when an instance is to be launched on 
a specific dedicated host. | `string` | `null` | no |
| http\_tokens | (Optional) "Default : required". Whether or not the metadata service requires session tokens, also referred to as Instance Metadata Service Version 2 (IMDSv2). Valid values include optional or required. Defaults to required. | `string` | `"required"` | no |
| iam\_instance\_profile | (Optional) "Default : "" ". The IAM role to assign to the instance | `string` | `""` | no |
| instance\_ami | (Required) The AMI (Amazon Machine Image) that identifies the instance | `string` | n/a | yes |
| instance\_initiated\_shutdown\_behavior | (Optional) "Default : "stop" .Shutdown behavior for the instance | `string` | `"stop"` | no |
| instance\_name | (Required) The key name to use for the instance | `string` | n/a | yes |
| instance\_type | (Optional) "Default : "t2.medium" ". The AWS EC2 tier to use for the DB instances | `string` | `"t2.medium"` | no |
| kms\_key\_id | (Required) Amazon Resource Name (ARN) of the KMS Key to use when encrypting the volume. | `string` | n/a | yes |
| monitoring | (Optional) "Default : true". If true, the launched EC2 instance will have detailed monitoring enabled | `bool` | `true` | no |     
| network\_card\_index | (Optional) "Default : 0". Integer index of the network card.The default index is 0 | `number` | `0` | no |
| network\_interface\_id | (Optional) "Default : []". Required when User need to create multiple EC2 instances with Netowkr Interface.list of ID's of the network interface to attach. | `list(string)` | `[]` | no |
| number\_of\_instances | (Required) number of instances | `number` | n/a | yes |
| root\_volume\_iops | (Optional) "Default : null". Amount of provisioned IOPS. Only valid for volume\_type of io1, io2 or gp3. | `string` | `null` | no |
| root\_volume\_size | (Optional) "Default : "30" . AWS EC2 root volume size | `string` | `"30"` | no |
| root\_volume\_type | (Optional) "Default : null". Type of volume. Valid values include standard, gp2, gp3, io1, io2, sc1, or st1. Defaults to gp2. | `string` | `null` | no |
| source\_dest\_check | (Optional) "Default : true". Controls if traffic is routed to the instance when the destination address does not match the instance | `string` | `true` | no |
| subnet\_ids | (Optional) "Default : null". VPC Subnet IDs to launch in | `list(string)` | `null` | no |
| tags | (Required) A mapping of tags to assign to all resources. | `map(string)` | n/a | yes |
| tenancy | (Optional) "Default : "default" .The tenancy of the instance (if the instance is running in a VPC). Available values: default, dedicated, host. | `string` | `"default"` | no |
| throughput | (Optional) "Default : null". Throughput to provision for a volume in mebibytes per second (MiB/s).This is only valid for volume\_type of gp3. | `string` | `null` | no |
| user\_data | (Optional) "Default : "" .User data content to attach to the instance | `string` | `""` | no |
| vpc\_security\_group\_ids | (Required) List of security group names. | `list(string)` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| arn | The ARN of the instance. |
| availability\_zone | The availability zone of the instance. |
| capacity\_reservation\_specification | Tags attatched to the instance |
| credit\_specification | Credit specification of instance. |
| id | The instance ID. |
| instance\_state | The state of the instance. One of: pending, running, shutting-down, terminated, stopping, stopped. See Instance Lifecycle for 
more information. |
| ipv6\_addresses | A list of assigned IPv6 addresses, if any |
| placement\_group | The placement group of the instance. |
| primary\_network\_interface\_id | The ID of the instance's primary network interface. |
| private\_dns | The private DNS name assigned to the instance. Can only be used inside the Amazon EC2, and only available if you've enabled DNS hostnames for your VPC |
| private\_ip | The private IP address assigned to the instance |
| public\_dns | The public DNS name assigned to the instance. For EC2-VPC, this is only available if you've enabled DNS hostnames for your VPC |  
| security\_groups | The associated security groups. |
| subnet\_id | The VPC subnet ID. |
| tags | Tags attatched to the instance |
| user\_data | User data executed by the instance |
| vpc\_security\_group\_ids | The associated security groups in non-default VPC |

## Unit Testing 

1) Submit & able to execute job. The terraform apply takes like 3 minutes to complete the creation of the EC2 Instance

* Creates a EC2 Instance
* Creates the Block Store and attaches it to the Instance
* Modifies the Life Cycle rules to not be refreshed when some attributes are modified
* The EC2 Instance name is been generated using some mandatory tags

2) Test use case of Ec2 instance with network interface

* Created One Network interface service. It generates Primay Private ID
* Created EC2 instance with Network interface block.
* Deleted the EC2 instance.
* Again created EC2 instance with same ENI ID and private ID should not change. Verified wheather the Primary Private ID of network interface is same or not. 
* EC2 instance created with same ENI ID and primary private ID also same. 

3) Tested ephemeral block device and the its added to the instance
4) Tested the http_token parameter

Note: Make sure to have your aws credentials refreshed when executing in TFE.
