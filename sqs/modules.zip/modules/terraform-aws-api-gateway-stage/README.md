# Anthem AWS API Gateway Stage Module

This module manages an API Gateway Stage. A stage is a named reference to a deployment, which can be done via the aws_api_gateway_deployment resource. Stages can be optionally managed further with the aws_api_gateway_base_path_mapping resource, aws_api_gateway_domain_name resource, and aws_api_method_settings resource. For more information, see the API Gateway Developer Guide.

## HIPAA eligibility status

1. Amazon API Gateway is eligible

## Security Guardrail reference

https://confluence.anthem.com/pages/viewpageattachments.action?pageId=299009562&sortBy=date&startIndex=60&preview=/299009562/370573552/Anthem%20AWS%20Security%20Patterns%20-%20API%20Gateway.docx

## Pre-Requisites

1. REST API should be created.
2. Stage name is required.
3. The ID of the deployment is required.
4. Variabilized additional tag "scheme" in the module and added "internal" as default value.

## Mandatory Tags Note:
*	As per redesigned new mandatory tags, mandatory tags along with any additional tags have to be added through template configuration within the modules as below
*	Have a reference of mandatory tags module within the template configuration as shown in example script below.
```bash
# Mandatory Tag Workspace Variables
  variable "apm-id" {}
  variable "application-name" {}
  variable "app-support-dl" {}
  variable "app-servicenow-group" {}
  variable "business-division" {}
  variable "company" {}
  variable "compliance" {}
  variable "costcenter" {}
  variable "environment" {}
  variable "PatchGroup" {}
  variable "PatchWindow" {}
  variable "ATLAS_WORKSPACE_NAME" {}

# Mandatory Tags Module 
module "mandatory_tags" {
  source               = "cps-terraform.anthem.com/<ORG_NAME>/terraform-aws-mandatory-tags-v2/aws"
  tags                 = {}
  apm-id               = var.apm-id
  application-name     = var.application-name
  app-support-dl       = var.app-support-dl
  app-servicenow-group = var.app-servicenow-group
  business-division    = var.business-division
  compliance           = var.compliance
  company              = var.company
  costcenter           = var.costcenter
  environment          = var.environment
  PatchGroup           = var.PatchGroup
  PatchWindow          = var.PatchWindow
  workspace            = var.ATLAS_WORKSPACE_NAME
}
```
*	Mandatory tags module should be referred in tags attribute as below:
  tags = module.mandatory_tags.tags
*	Any additional tags can be merged to tags attribute as below:
  tags = merge(module.mandatory_tags.tags, {"sample" = "abc"})

## Usage
  To run this example you need to execute:

```bash

module "api_stage" {
  source = "cps-terraform.anthem.com/<ORG>/terraform-aws-api-gateway-stage/aws"

  #Mandatory Tags
  tags = module.mandatory_tags.tags

  #Parameters
  rest_api_id           = module.rest_api.id
  stage_name            = "TEST-STAGE"
  deployment_id         = module.api_deployment.id
  stage_description     = "Test stage"
  cache_cluster_enabled = false
  cache_cluster_size    = "0.5"
  xray_tracing_enabled  = false
  client_certificate_id = ""
  documentation_version = ""
  stage_variables       = {}
  #access_log_settings = {}
  #scheme = "internal" # "external"
}

#Initialize Terraform
terraform init

#Terraform Dry-Run
terraform plan

#Create the resources
terraform apply

#Destroy the resources saved in the tfstate
terraform destroy
```

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| access\_log\_settings | (Optional) Enables access logs for the API stage. destination\_arn - (Required) The Amazon Resource Name (ARN) of the CloudWatch Logs log group or Kinesis Data Firehose delivery stream to receive access logs. If you specify a Kinesis Data Firehose delivery stream, the stream name must begin with amazon-apigateway-. Automatically removes trailing :\* if present. format - (Required) The formatting and values recorded in the logs. For more information on configuring the log format rules visit the AWS documentation. | <pre>object({<br>    destination_arn = string<br>    format          = string<br>  })</pre> | `null` | no |
| cache\_cluster\_enabled | (Optional) Specifies whether a cache cluster is enabled for the stage. | `bool` | `false` | no |
| cache\_cluster\_size | (Optional) The size of the cache cluster for the stage, if enabled. Allowed values include 0.5, 1.6, 6.1, 13.5, 28.4, 58.2, 118 and 237. | `string` | `"0.5"` | no |
| client\_certificate\_id | (Optional) The identifier of a client certificate for the stage. | `string` | `null` | no |
| deployment\_id | (Required) The ID of the deployment that the stage points to. | `string` | n/a | yes |
| documentation\_version | (Optional) The version of the associated API documentation. | `string` | `null` | no |
| rest\_api\_id | (Required) REST API identifier | `string` | n/a | yes |
| scheme | (Optional) "Default : internal". Tag Scheme should be either external or internal. | `string` | `"internal"` | no |
| stage\_description | (Optional) Description of the stage. | `string` | `null` | no |
| stage\_name | (Required) The name of the stage | `string` | n/a | yes |
| stage\_variables | (Optional) A map that defines the stage variables | `map` | `null` | no |
| tags | (Required) Map of tags assigned to the resource, including those inherited from the provider default\_tags | `map(string)` | n/a | yes |
| xray\_tracing\_enabled | (Optional) Whether active tracing with X-ray is enabled. Defaults to false. | `bool` | `false` | no |

## Outputs

| Name | Description |
|------|-------------|
| arn | The ARN of the stage |
| execution\_arn | The execution ARN to be used in lambda\_permission's source\_arn when allowing API Gateway to invoke a Lambda function, e.g. arn:aws:execute-api:eu-west-2:123456789012:z4675bid1j/prod |
| id | The ID of the stage |
| invoke\_url | The URL to invoke the API pointing to the stage, e.g. https://z4675bid1j.execute-api.eu-west-2.amazonaws.com/prod |

## Testing

1. Able to create the stage.