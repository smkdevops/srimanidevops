# Anthem AWS API Gateway Usage Plan Module

This module provides an API Gateway Usage Plan.

## HIPAA eligibility status

1. Amazon API Gateway is eligible

## Security Guardrail reference

https://confluence.anthem.com/pages/viewpageattachments.action?pageId=299009562&sortBy=date&startIndex=60&preview=/299009562/370573552/Anthem%20AWS%20Security%20Patterns%20-%20API%20Gateway.docx

## Pre-Requisites

1. Rest API should be created.
2. Name of the Usage Plan need to provided.

## Important Note

1. Usage plan should be created once api-gateway-stage is created.


## Mandatory Tags Note:
*	As per redesigned new mandatory tags, mandatory tags along with any additional tags have to be added through template configuration within the modules as below
*	Have a reference of mandatory tags module within the template configuration as shown in example script below.
```bash
# Mandatory Tag Workspace Variables
  variable "apm-id" {}
  variable "application-name" {}
  variable "app-support-dl" {}
  variable "app-servicenow-group" {}
  variable "business-division" {}
  variable "company" {}
  variable "compliance" {}
  variable "costcenter" {}
  variable "environment" {}
  variable "PatchGroup" {}
  variable "PatchWindow" {}
  variable "ATLAS_WORKSPACE_NAME" {}

# Mandatory Tags Module 
module "mandatory_tags" {
  source               = "cps-terraform.anthem.com/<ORG_NAME>/terraform-aws-mandatory-tags-v2/aws"
  tags                 = {}
  apm-id               = var.apm-id
  application-name     = var.application-name
  app-support-dl       = var.app-support-dl
  app-servicenow-group = var.app-servicenow-group
  business-division    = var.business-division
  compliance           = var.compliance
  company              = var.company
  costcenter           = var.costcenter
  environment          = var.environment
  PatchGroup           = var.PatchGroup
  PatchWindow          = var.PatchWindow
  workspace            = var.ATLAS_WORKSPACE_NAME
}
```
*	Mandatory tags module should be referred in tags attribute as below:
  tags = module.mandatory_tags.tags
*	Any additional tags can be merged to tags attribute as below:
  tags = merge(module.mandatory_tags.tags, {"sample" = "abc"})

## Usage
  To run this example you need to execute:

```bash
module "api-usageplan" {
  source     = "cps-terraform.anthem.com/<ORG>/terraform-aws-api-gateway-usage-plan/aws"
  depends_on = [module.api_stage]

  name                  = "FirstUsagePlan"
  product_code          = ""
  api_stage_api_id      = module.rest_api.id
  api_stage_stage       = "TEST-STAGE"
  description           = "Usage Plan for the api"
  api_stage_limit       = "20"
  api_stage_offset      = ""
  api_stage_period      = "WEEK"
  api_stage_burst_limit = ""
  api_stage_rate_limit  = ""
  
  tags = module.mandatory_tags.tags

}

#Initialize Terraform
terraform init

#Terraform Dry-Run
terraform plan

#Create the resources
terraform apply

#Destroy the resources saved in the tfstate
terraform destroy
```

## Resources

| Name | Type |
|------|------|
| [aws_api_gateway_usage_plan.api_gateway_usage_plan](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/api_gateway_usage_plan) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| api\_stage\_api\_id | (Required) - API Id of the associated API stage in a usage plan. | `string` | n/a | yes |
| api\_stage\_burst\_limit | (Optional) - The API request burst limit, the maximum rate limit over a time ranging from one to a few seconds, depending upon whether the underlying token bucket is at its full capacity. | `string` | `""` | no |
| api\_stage\_limit | (Optional) - Maximum number of requests that can be made in a given time period. | `string` | `"20"` | no |
| api\_stage\_offset | (Optional) - Number of requests subtracted from the given limit in the initial time period. | `string` | `""` | no |
| api\_stage\_period | (Optional) - Time period in which the limit applies. Valid values are DAY, WEEK or MONTH. | `string` | `"WEEK"` | no |
| api\_stage\_rate\_limit | (Optional) - The API request steady-state rate limit. | `string` | `""` | no |
| api\_stages | (Required) - API stage name of the associated API stage in a usage plan. | `list(any)` | n/a | yes |
| description | (Optional) Description of a usage plan. | `string` | `""` | no |
| name | (Required) Name of the usage plan. | `string` | n/a | yes |
| product\_code | (Optional) AWS Marketplace product identifier to associate with the usage plan as a SaaS product on AWS Marketplace. | `string` | `""` | no |
| tags | (Required) Map of tags assigned to the resource, including those inherited from the provider default\_tags | `map(string)` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| api\_stages | The associated API stages of the usage plan. |
| arn | Amazon Resource Name (ARN) |
| description | The description of a usage plan. |
| id | The ID of the API resource |
| name | The name of the usage plan. |
| product\_code | The AWS Marketplace product identifier to associate with the usage plan as a SaaS product on AWS Marketplace. |
| quota\_settings | The quota of the usage plan. |
| throttle\_settings | The throttling limits of the usage plan. |
