# Anthem AWS Cloudfront KeyGroup Resource

This module create aws Cloudfront KeyGroup Resource.


<span style="color: red">**This module should only be used by Contact Center Project.**</span>

## HIPAA eligibility status

* N/A


## Security Guardrail reference

[security Guardrails Link](https://confluence.anthem.com/download/attachments/717965086/Anthem%20AWS%20Security%20Patterns%20-%20AWS_CloudFront%20-%20Deliotte%20Digital%20CCaaS%20use%20case.docx?version=1&modificationDate=1628274246000&api=v2)

## Pre-requisite

- Dependent resources will be needed , here reference to key will be needed.

## Usage

To run this example you need to execute:

```bash
#Initialize Terraform
terraform init

#Terraform Dry-Run
terraform plan

#Create the resources
terraform apply

#Destroy the resources saved in the tfstate
terraform destroy
```

## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | ">=3.35.0" |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [aws_cloudfront_key_group.this](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/cloudfront_key_group) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_comment"></a> [comment](#input\_comment) | (Optional) A comment to describe the key group. | `string` | `null` | no |
| <a name="input_create_key_group"></a> [create\_key\_group](#input\_create\_key\_group) | Controls if CloudFront key\_group  should be created | `bool` | `true` | no |
| <a name="input_items"></a> [items](#input\_items) | (Required) A list of the identifiers of the public keys in the key group. | `list` | n/a | yes |
| <a name="input_name"></a> [name](#input\_name) | (Required) A name to identify the key group. | `string` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_etag"></a> [etag](#output\_etag) | returns a string |
| <a name="output_id"></a> [id](#output\_id) | returns a string |
| <a name="output_this"></a> [this](#output\_this) | n/a |
