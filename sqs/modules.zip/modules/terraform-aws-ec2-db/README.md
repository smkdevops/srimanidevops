# ElevanceHealth AWS EC2

This module creates one or more EC2 instances

## Release Notes:
# New Version - 0.0.2
1. We now have tags.tf file which is the integral part our code base.
2. Only Database Technical Tags and Application specific Tags are now available in the templates, which makes our code very sleek/tidy.
3. Each Database Module will be referring to mandatory tags module.

## Pre-Requisite

* If user wants to pass <INSTANCE_NAME> Kindly pass the parameter <Instance_name> in your template, Otherwise it will take by default.
* User can attach additional <EBS> volumes in the script.
* A valid Customer Managed Key CMK is required
* AMI is to use for the instance. If the AMI has the EBS encrypted you must use a CMK for the encryption
* Instance_type is the type of instance to start. Updates to this field will trigger a stop/start of the EC2 instance.
* The required Security group with the rules should be exist for the instance.
* The required subnet should be exist for the instance.
* patch window and patch group tags are added with default value as "Default".
* Keyword 'file' added to the user data variable.

## IMPORTANT NOTE:

* User have option to create multiple EC2 instances with multiple network interfaces.
* User have option to create multiple EC2 instances with subnets and security groups.
* Mandatory tags should be passed to the module either in single variables or inside the tags map variable

## Observation

* Instances are getting created with the subnet selecting sequentially from the subnet list. like if 5 instances [ 0,1,2,3,4] and 3 subnets [0,1,2] then instances will be created with mapping [0-0,1-1,2-2,3-0,4-1]
* If subnets are more than number of EC2 then the EC2 will be created in the required subnets and extra subnets will be unused.
* While creating multiple instances , Creation of Number of instances should be equals to number of ENI's.
  No_of_EC2's = No_of_ENI's
* If number of EC2 is more than number of ENI then the extras EC2 will be terminated automatically. (No_of_EC2's > No_of_ENI's)
* If number of ENI is greater than number of EC2 then the number of ENI equals to number of EC2 will be allocated and rest of the ENI will be unused which can be used in future. (No_of_EC2's < No_of_ENI's)
* If you want to create EC2 with network interface then create the network interface using network interface module and provide the id to network_interface_id parameter.
* EC2 can be created with network interface or without network interface. Subnet ID should be provided if EC2 need to be created without network interface otherwise it should be null.
* If EC2 need to be created with network interface then network interface id becomes primary address.
* If EC2 need to be created with the network interface as a secondary address then use network interface attachment module once EC2 is created.

## Usage

To run this example you need to execute:

```bash
#Initialize Terraform
terraform init

#Terraform Dry-Run
terraform plan

#Create the resources
terraform apply

#Destroy the resources saved in the tfstate
terraform destroy
```
## Providers

| Name | Version |
|------|---------|
| aws | n/a |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| application-name | application is now application-name.  Based upon application nomenclature in server naming convention policy.Use up to six (6) characters to name your application. | `string` | n/a | yes |
| application\_tag1 | Manged by APP teams | `string` | n/a | yes |
| application\_tag2 | Manged by APP teams | `string` | n/a | yes |
| application\_tag3 | Manged by APP teams | `string` | n/a | yes |
| application\_tag4 | Manged by APP teams | `string` | n/a | yes |
| application\_tag5 | Manged by APP teams | `string` | n/a | yes |
| bcp-tier | Application BCP tier | `string` | n/a | yes |
| created-by | who created the instance | `string` | n/a | yes |
| database-platform | Names of the Database | `string` | n/a | yes |
| database-state | State providing direction for InfoHub to manage Metadata elements. | `string` | n/a | yes |
| db-patch-schedule | Schedules coordinated with Application Team. As general guidelines, we don't want to patch Databases during Q4 due to Annual Enrollment and Holiday season.  We also don't want to AWS Auto Patch Schedule used for Data Platforms as there are application dependency in play. | `string` | n/a | yes |
| db-patch-time-window | 2-Hour slots Weekend Window for Patching starting late Friday night till Sunday evening 6pm US EST. | `string` | n/a | yes |
| delete\_on\_termination | Default : true . Whether the volume should be destroyed on instance termination. | `bool` | `true` | no |
| delete\_on\_termination\_eni | Default : false .Whether or not to delete the network interface on instance termination. Defaults to false. Currently, the only valid value is false, as this is only supported when creating new network interfaces when launching an instance. | `bool` | `false` | no |
| disable\_api\_termination | If true, enables EC2 Instance Termination Protection. | `bool` | `true` | no |
| ebs\_block\_device | To add EBS Volume to EC2 instances | `any` | `null` | no |
| environment | Allowed values are 'proof\_of\_concept', 'development', 'integration', 'user\_acceptance', 'testing', 'performance', 'production'. | `string` | n/a | yes |
| iam\_instance\_profile | Default : "" .The IAM role to assign to the instance | `string` | `""` | no |
| instance\_ami | The AMI (Amazon Machine Image) that identifies the instance | `string` | n/a | yes |
| instance\_initiated\_shutdown\_behavior | Default : "stop" .Shutdown behavior for the instance | `string` | `"stop"` | no |
| instance\_name | The key name to use for the instance | `string` | `""` | no |
| instance\_type | Default : "t2.medium" .The AWS EC2 tier to use for the DB instances | `string` | `"t2.medium"` | no |
| kms\_key\_id | Amazon Resource Name (ARN) of the KMS Key to use when encrypting the volume. | `string` | n/a | yes |
| monitoring | Default : true .If true, the launched EC2 instance will have detailed monitoring enabled | `bool` | `true` | no |
| network\_interface\_id | Default : [] .Required when User need to create multiple EC2 instances with Netowkr Interface.list of ID's of the network interface to attach. | `list(string)` | `[]` | no |
| number\_of\_instances | number of instances | `number` | n/a | yes |
| prepatch-snapshot-flag | Tag for patching | `string` | n/a | yes |
| resource-type | Based upon the type of resource. | `string` | `"ec2"` | no |
| root\_volume\_size | Default:AWS EC2 root volume size | `string` | `"50"` | no |
| source\_dest\_check | Default : true . Controls if traffic is routed to the instance when the destination address does not match the instance | `string` | `true` | no |
| subnet\_ids | VPC Subnet IDs to launch in | `list(string)` | `null` | no |
| tags | Default : {} .Additional tags (e.g. `map(`BusinessUnit`,`XYZ`)` | `map(string)` | `{}` | no |
| tenancy | Default : "default" .The tenancy of the instance (if the instance is running in a VPC). Available values: default, dedicated, host. | `string` | `"default"` | no |
| user\_data | Default : "" .User data content to attach to the instance | `string` | `""` | no |
| vpc\_security\_group\_ids | List of security group names. | `list(string)` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| arn | The ARN of the instance. |
| availability\_zone | The availability zone of the instance. |
| credit\_specification | Credit specification of instance. |
| id | The instance ID. |
| instance\_state | The state of the instance. One of: pending, running, shutting-down, terminated, stopping, stopped. See Instance Lifecycle for more information. |
| ipv6\_addresses | A list of assigned IPv6 addresses, if any |
| placement\_group | The placement group of the instance. |
| primary\_network\_interface\_id | The ID of the instance's primary network interface. |
| private\_dns | The private DNS name assigned to the instance. Can only be used inside the Amazon EC2, and only available if you've enabled DNS hostnames for your VPC |
| private\_ip | The private IP address assigned to the instance |
| public\_dns | The public DNS name assigned to the instance. For EC2-VPC, this is only available if you've enabled DNS hostnames for your VPC |
| security\_groups | The associated security groups. |
| subnet\_id | The VPC subnet ID. |
| tags | Tags attatched to the instance |
| user\_data | User data executed by the instance |
| vpc\_security\_group\_ids | The associated security groups in non-default VPC |

## Unit Testing 

1) Submit & able to execute job. The terraform apply takes like 3 minutes to complete the creation of the EC2 Instance

* Creates a EC2 Instance
* Creates the Block Store and attaches it to the Instance
* Modifies the Life Cycle rules to not be refreshed when some attributes are modified
* The EC2 Instance name is been generated using some mandatory tags

2) Test use case of Ec2 instance with network interface

* Created One Network interface service. It generates Primay Private ID
* Created EC2 instance with Network interface block.
* Deleted the EC2 instance.
* Again created EC2 instance with same ENI ID and private ID should not change. Verified wheather the Primary Private ID of network interface is same or not. 
* EC2 instance created with same ENI ID and primary private ID also same. 

Note: Make sure to have your aws credentials refreshed when executing in TFE.
