## Terraform module to deploy Vault sidecar injector in EKS Cluster.

Vault can manage secrets for Kubernetes application pods from outside the cluster. This could be HashiCorp Cloud Platform (HCP) Vault or another Vault service. This terraform module with help to deploy Vault sidecar injector using helm chart.

## Security Guardrail reference

N/A

## Pre-Requisites

1. Should have EKS cluster up and running.
2. Include Kuberenetes provier for your EKS cluster as shown below:

```bash
data "aws_eks_cluster" "cluster" {
  name = module.eks_cluster.cluster_id
}

data "aws_eks_cluster_auth" "cluster" {
  name = module.eks_cluster.cluster_id
}

provider "kubernetes" {
  #  load_config_file       = false
  host                   = data.aws_eks_cluster.cluster.endpoint
  cluster_ca_certificate = base64decode(data.aws_eks_cluster.cluster.certificate_authority.0.data)
  token                  = data.aws_eks_cluster_auth.cluster.token
}
```
3. Include helm provide for your EKS cluster as shown below:
```bash
provider "helm" { 
 kubernetes {  
  host                   = data.aws_eks_cluster.cluster.endpoint
  cluster_ca_certificate = base64decode(data.aws_eks_cluster.cluster.certificate_authority.0.data)
  token                  = data.aws_eks_cluster_auth.cluster.token
}
}
```

## Input

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| vault\_name | Release name | `string` | vault | no |
| vault\_chart |Chart name to be installed | `string` | vault | no |
| vault\_repository | Repository URL where to locate the requested chart | `string` | https://helm.releases.hashicorp.com | no |
| vault\_namespace | The namespace to install the release into | `string` | vault | no |
| vault\_helm\_version | Specify the exact chart version to install. If this is not specified, the latest version is installed | `string` | null | no |
| vault\_timeout | Time in seconds to wait for any individual kubernetes operation | `number` | 400 | no |
| vault\_auth\_path | This value is different for every Kubernetes cluster, provided when it is onboarded to Vault | `string` | "" | no |
| vault\_cluster\_role\_binding\_name| Name to Vault Cluster RoleBinding | `string` | vault-auth-delegator-crb | no |


## Usage

Include below module code to deploy Vault Add On into EKS cluster:

```bash
module "shared_eks_vault_injector" {
  source     = "cps-terraform.anthem.com/<ORG>/terraform-aws-eks-hashicorp-vault/aws"
  
}


#Initialize Terraform
terraform init

#Terraform Dry-Run
terraform plan

#Create the resources
terraform apply

#Destroy the resources saved in the tfstate
terraform destroy
```

## Verify Installation


1. Create EKS Cluster.
2. Deploy Vault sidecar injector using the reference module code provided above in earlier section.
3. Run below commands to verify vault resouces deployed without any errors:
```bash

kubectl get pods -n vault

NAME                                             READY   STATUS    RESTARTS   AGE
hashicorp-vault-agent-injector-66474cb7f-xr6nt   1/1     Running   0          17m

```

```bash

kubectl get secrets -n vault

NAME                               TYPE                                  DATA   AGE
default-token-95bxc                kubernetes.io/service-account-token   3      48s
sh.helm.release.v1.vault.v1        helm.sh/release.v1                    1      48s
vault-agent-injector-token-mck29   kubernetes.io/service-account-token   3      48s
vault-auth                         kubernetes.io/service-account-token   3      39s
vault-auth-token-6d8b4             kubernetes.io/service-account-token   3      40s

```

```bash

kubectl get sa -n vault

NAME                   SECRETS   AGE
default                1         57s
vault-agent-injector   1         56s
vault-auth             2         48s

```

```bash

kubectl get clusterrole

NAME                                                                   CREATED AT
hashicorp-vault-agent-injector-clusterrole                             2022-03-24T17:13:28Z
```

```bash

kubectl get clusterrolebinding 

NAME                                                   ROLE                                                               AGE
vault-agent-injector-binding                           ClusterRole/vault-agent-injector-clusterrole                       2m19s
vault-auth-delegartor-crb                              ClusterRole/system:auth-delegator                                  2m10s
```


## Configure Kubernetes Authentication

Need to provide below details to vault team

Retrive JWT Token from Vault Secret using below command

```bash

kubectl -n vault get secret vault-auth --output='go-template={{ .data.token }}' | base64 --decode

eyJhbGciOiJSUzI1NiIsImtpZCI6IlRncW9RempKTHlQOWUySTgxS080a05VUWVNbUNGRnQ4MUtOaDRLS2tQb3cifQ.eyJpc3MiOiJrdWJlcm5ldGVzL3NlcnZpY2VhY2NvdW50Iiwia3ViZXJuZXRlcy5pby9zZXJ2aWNlYWNjb3VudC9uYW1lc3BhY2UiOiJ2YXVsdCIsImt1YmVybmV0ZXMuaW8vc2VydmljZWFjY291bnQvc2VjcmV0Lm5hbWUiOiJ2YXVsdC1hdXRoIiwia3ViZXJuZXRlcy5pby9zZXJ2aWNlYWNjb3VudC9zZXJ2aWNlLWFjY291bnQubmFtZSI6InZhdWx0LWF1dGgiLCJrdWJlcm5ldGVzLmlvL3NlcnZpY2VhY2NvdW50L3NlcnZpY2UtYWNjb3VudC51aWQiOiJmMDRkMWZkMi02ZmM4LTQ0YjctODVhNC1iNzkxZjdlY2RjZDYiLCJzdWIiOiJzeXN0ZW06c2VydmljZWFjY291bnQ6dmF1bHQ6dmF1bHQtYXV0aCJ9.OmikETm5sseXYCYOYlAk4RUrlRu99yg_syrPdg-_YIp-Ub5VhrBG-dVBFND-Sh43PTjipwdgcN0v9Q8odd9zLLEvcw77fVMWStQB1mz-kSgU5_IzGsiIZTr18Z7_RyrWkPfKW7vgpThfdEFwgElgtLxSfKjW2VbNmk4mvXAvstV60ummDoyQyNxAjYW_nwa0qcpYI55OgNW07VPGu-abGCoew0OLMVKpTi1WBvBK24re5WLWWcjpTpgClUlKCHKI3jfxVAYkmAl37mobwUCQB3ZbV4UJ8pwgOyDmPXilWbruc8QhMqMlaqwtGViQaOGjMBap8cselN2eONNNgolydQ

```

Retrive Kubernetes CA certificate

```bash

kubectl config view --raw --minify --flatten --output='jsonpath={.clusters[].cluster.certificate-authority-data}' | base64 --decode

-----BEGIN CERTIFICATE-----
MIIC5zCCAc+gAwIBAgIBADANBgkqhkiG9w0BAQsFADAVMRMwEQYDVQQDEwprdWJl
cm5ldGVzMB4XDTIyMDMyMjIwMDU1NVoXDTMyMDMxOTIwMDU1NVowFTETMBEGA1UE
AxMKa3ViZXJuZXRlczCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBALmM
t4/Pgo47w3bu0gnjcAeIFTv5RZfp0neoAMoXLamAwwROwCHrwxj03weH2Ks5dZxD
XqBssoLn1fCr3NrsSlSeucY9Ok8fmFHPHquNvlBZj6zbAdQAIJGy11D/dDBYP22+
KSx2GxT2vuG2z8mRVDKfr42Qh8pCslGhFy1sDCQapWjbHrDXUdclKa7DN7zrsvdS
ziduRCtDK/m3hEgyOOzOAeeWleWSE1EG1pEC60o1NK00eleptmaVx/4gQkoGYyEl
bmiZFQyBp83eQCs5mg84YphQ8jbHl228LAAlHSHMXWl9P69X/EeIkaGIMJtOE0p3
Ob8FwDNGcbp8E71RAWUCAwEAAaNCMEAwDgYDVR0PAQH/BAQDAgKkMA8GA1UdEwEB
/wQFMAMBAf8wHQYDVR0OBBYEFPybH0+YnKrUbUBeZlPti9mufkgRMA0GCSqGSIb3
QlkeU03GO0+zjTGT60E8iYqGyMRMxu/hkzAxE7uUhxgoDHG9gNf+4Zy08dXQIGxg
AL0nJZLOIYK+PST5I3yvXcMnVKSVF/LxhUYzj0pJRQtOT90T4TvK9jtLiJeDMNHF
5K+YZPxXGoPG/2qjlo7Vy/wntaqWNrntXQnLAPSlTAl7U//J6qIz9pVN1GGLLf3B
F+Db20F0KOmAK+C76jwB1Q7drl+swWxhx7tp
-----END CERTIFICATE-----

```

Retrive Kubernetes Host URL

```bash

kubectl config view --raw --minify --flatten --output='jsonpath={.clusters[].cluster.server}'
https://D07F1C2BB71A5D4E295B2C217E422BD2.gr7.us-east-2.eks.amazonaws.com


```

## Note

- Currently this module only supports Vault Injector deployment.
- Vault Server deployment is not supported.

