# Anthem AWS SSM Document

This module Provides an SSM Document resource

## HIPAA eligibility status

AWS Systems Manager Service Document is eligible.

## Security Guardrail reference

[Security Guardrail Link](https://confluence.anthem.com/pages/viewpageattachments.action?pageId=299009562&preview=/299009562/516937786/Anthem%20AWS%20Security%20Patterns%20-%20Systems%20Manager.docx)

## Pre-requisites

1. attachments_source supports the following: Key, values and Name as arguments. Valid key types include: SourceUrl and S3FileUrl. The value describing the location of an attachment to a document.
```
Eg: attachments_source = [{
        key    = "SourceUrl"
        values = ["s3://${aws_s3_bucket.object_bucket.bucket}/test.zip"]
        name   = "optional_name"
  }]
  ```

2. The permissions attribute specifies how you want to share the document. If you share a document privately, you must specify the AWS user account IDs for those people who can use the document. If you share a document publicly, you must specify All as the account ID. The permissions mapping supports type and account_ids
```
Eg: permissions = {
        "type" : "Share",
        "account_ids" : "All"
  }
```

 
## Important Note

1. Only documents with a schema version of 2.0 or greater can update their content once created. To update a document with an older schema version you must recreate the resource. Not all document types support a schema version of 2.0 or greater. Refer to [SSM document schema features and examples](https://docs.aws.amazon.com/systems-manager/latest/userguide/document-schemas-features.html) for information about which schema versions are supported for the respective document_type.

## Mandatory Tags Note:
*	As per redesigned new mandatory tags, mandatory tags along with any additional tags have to be added through template configuration within the modules as below
*	Have a reference of mandatory tags module within the template configuration as shown in example script below.
```bash
# Mandatory Tag Workspace Variables
variable "apm-id" {}
variable "application-name" {}
variable "app-support-dl" {}
variable "app-servicenow-group" {}
variable "business-division" {}
variable "company" {}
variable "compliance" {}
variable "costcenter" {}
variable "environment" {}
variable "PatchGroup" {}
variable "PatchWindow" {}
variable "ATLAS_WORKSPACE_NAME" {}

# Mandatory Tags Module 
module "mandatory_tags" {
  source               = "cps-terraform.anthem.com/<ORG_NAME>/terraform-aws-mandatory-tags-v2/aws"
  tags                 = {}
  apm-id               = var.apm-id
  application-name     = var.application-name
  app-support-dl       = var.app-support-dl
  app-servicenow-group = var.app-servicenow-group
  business-division    = var.business-division
  compliance           = var.compliance
  company              = var.company
  costcenter           = var.costcenter
  environment          = var.environment
  PatchGroup           = var.PatchGroup
  PatchWindow          = var.PatchWindow
  workspace            = var.ATLAS_WORKSPACE_NAME
}
```
*	Mandatory tags module should be referred in tags attribute as below:
tags = module.mandatory_tags.tags
*	Any additional tags can be merged to tags attribute as below:
tags = merge(module.mandatory_tags.tags, {"sample" = "abc"})


## Usage 

```bash

Sample Script

# For document_type = automation

module "terraform-aws-ssm-document-automation" {
  source = "cps-terraform.anthem.com/<ORG_NAME>/terraform-aws-ssm-document/aws"

  # mandatory tags
  environment      = ""
  company          = ""
  costcenter       = ""
  owner-department = ""
  it-department    = ""
  barometer-it-num = ""
  resource-type    = ""
  layer            = ""
  compliance       = ""
  application      = ""
  application_dl   = ""
  tags             = {}

  # insert required variables here

  name = ""

  attachments_source = [{
    key    = ""
    values = [""]
    name   = ""
  }]

  permissions = {
    "type" : "",
    "account_ids" : ""
  }

  target_type   = "" # eg: "/AWS::EC2::Instance"
  document_type = "Automation"
  content       = <<DOC
  {
  "assumeRole": "{{AutomationAssumeRole}}",
  "schemaVersion": "0.3",
  "parameters": {
    "AutomationAssumeRole": {
      "type": "String"
    },
    "InstanceId": {
      "type": "StringList"
    },
    "ConfigRuleName": {
      "type": "String"
    }
  },
  "mainSteps": [
    {
      "inputs": {
        "Script": "import boto3\nfrom datetime import datetime, timedelta\n\ndef script_handler(events, context):\n  ec2 = boto3.resource('ec2')\n  ec2_control = boto3.client('ec2')\n  config = boto3.client('config')\n  \n  config_rule_name = events[\"ConfigRuleName\"]\n  for instance_id in events[\"InstanceId\"]:\n    instance = ec2.Instance(instance_id)\n    remediate = \"yes\"\n    for tags in instance.tags:\n      if tags['Key'] == 'antmEC2PubIPException': \n        if tags['Value'] == 'temp':\n          today = datetime.now()\n          exp_date = today + timedelta(days=3)\n          config.put_remediation_exceptions(\n            ConfigRuleName=config_rule_name,\n            ResourceKeys=[\n              {\n                'ResourceType': 'AWS::EC2::Instance',\n                'ResourceId': instance_id\n              }\n            ],\n            Message='Instance has temp whitelisted tag. Putting exception for 3 days.',\n            ExpirationTime=datetime.date.today()\n          )\n          remediate = \"no\"\n          print('%s has temp whitelisted tag. Putting exception for 3 days.' % instance_id)\n        elif tags['Value'] == 'yes':\n          config.put_remediation_exceptions(\n            ConfigRuleName=config_rule_name,\n            ResourceKeys=[\n              {\n                'ResourceType': 'AWS::EC2::Instance',\n                'ResourceId': instance_id\n              }\n            ],\n            Message='Instance has whitelisted tag. Putting exception in.'\n          )\n          remediate = \"no\"\n          print('%s has whitelisted tag. Putting exception in.' % instance_id)\n    if remediate == \"yes\":\n      print(\"stopping instance %s\" % instance_id)\n      stop_status = ec2_control.stop_instances(\n        InstanceIds=[\n          instance_id\n        ]\n      )\n      print(stop_status)\n  \n  return {'message': 'Done'}",
        "Runtime": "python3.6",
        "InputPayload": {
          "InstanceId": "{{InstanceId}}",
          "ConfigRuleName": "{{ConfigRuleName}}"
        },
        "Handler": "script_handler"
      },
      "name": "StopInstance",
      "action": "aws:executeScript"
    }
  ]
}
DOC
  document_format = "JSON"
}

# SSM document for document_type command
module "terraform-aws-ssm-document" {
  source = "cps-terraform.anthem.com/ORGNAME/terraform-aws-ssm-document/aws"

  # mandatory tags
  environment      = ""
  company          = ""
  costcenter       = ""
  owner-department = ""
  it-department    = ""
  barometer-it-num = ""
  resource-type    = ""
  layer            = ""
  compliance       = ""
  application      = ""
  application_dl   = ""
  tags             = {}

  # insert required variables here

  name = ""

  attachments_source = [{
    key    = ""
    values = [""]
    name   = ""
  }]

  permissions = {
    "type" : "",
    "account_ids" : ""
  }

  target_type   = ""  # example - "/AWS::EC2::Instance"
  document_type = "Command"
  content       = <<DOC
  {
    "schemaVersion": "1.2",
    "description": "Check ip configuration of a Linux instance.",
    "parameters": {

    },
    "runtimeConfig": {  

      "aws:runShellScript": {
        "properties": [
          {
            "id": "0.aws:runShellScript",
            "runCommand": ["ifconfig"]
          }
        ]
      }
    }
  }
DOC

  document_format = "JSON"
}


#Initialize Terraform
terraform init

#Terraform Dry-Run
terraform plan

#Create the resources
terraform apply

#Destroy the resources saved in the tfstate
terraform destroy

```

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| attachments\_source | (Optional) "Default : null".One or more configuration blocks describing attachments sources to a version of a document. It suports key, values and name(optional) | `any` | `null` | no |
| content | (Required) The JSON or YAML content of the document | `string` | n/a | yes |
| document\_format | (Optional) "Default : JSON".The format of the document. Valid document types include: JSON and YAML | `string` | `"JSON"` | no |
| document\_type | (Required) The type of the document. Valid document types include: Automation, Command, Package, Policy, and Session | `string` | n/a | yes |
| name | (Required) The name of the document. | `string` | n/a | yes |
| permissions | (Optional) "Default : {}".Additional Permissions to attach to the document. Supports type and document id as the parameters | `map(any)` | `{}` | no |
| tags | (Required) A mapping of tags to assign to all resources. | `map(string)` | n/a | yes |
| target\_type | (Optional) "Default : null".The target type which defines the kinds of resources the document can run on. For example, /AWS::EC2::Instance | `string` | `null` | no |
| version\_name | (Optional) "Default : null".A field specifying the version of the artifact you are creating with the document. For example, Release 12, Update 6. This value is unique across all versions of a document and cannot be changed for an existing document version. | `string` | `null` | no |

## Outputs

| Name | Description |
|------|-------------|
| created\_date | The date the document was created. |
| default\_version | The default version of the document. |
| description | The description of the document. |
| document\_version | The document version. |
| hash | The sha1 or sha256 of the document content |
| hash\_type | Sha1 Sha256. The hashing algorithm used when hashing the content. |
| latest\_version | The latest version of the document. |
| owner | The AWS user account of the person who created the document. |
| parameter | The parameters that are available to this document. |
| platform\_types | A list of OS platforms compatible with this SSM document, either Windows or Linux. |
| schema\_version | The schema version of the document. |
| status | Creating, Active or Deleting. The current status of the document. |
| tags\_all | A map of tags assigned to the resource, including those inherited from the provider default\_tags configuration block. |

## Testing

Created and tetsted SSM documents of document types Command, Automation and Session.  
