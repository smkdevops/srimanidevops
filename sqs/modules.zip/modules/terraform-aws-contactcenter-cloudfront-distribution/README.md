# Anthem AWS Cloudfront Distribution Resource

This module create aws Cloudfront Distribution Resource.

<span style="color: red">**This module should only be used by Contact Center Project.**</span>

## HIPAA eligibility status

* N/A


## Security Guardrail reference

[security Guardrails Link](https://confluence.anthem.com/download/attachments/717965086/Anthem%20AWS%20Security%20Patterns%20-%20AWS_CloudFront%20-%20Deliotte%20Digital%20CCaaS%20use%20case.docx?version=1&modificationDate=1628274246000&api=v2)

## Pre-requisite

- Dependent resources will be needed if any & Usage for Complex Parameter/s given below.
- Only whitelsited geo_restriction is US. No other geo locations are allowed.
```
  custom_error_response = [{
    error_caching_min_ttl = <VALUE>
    error_code            = <VALUE>
    response_code         = <VALUE>
    response_page_path    = <VALUE>
  }]
```
```
  default_cache_behavior = [{
    allowed_methods           == [value1,value2,...]
    cache_policy_id           = <VALUE>
    cached_methods            == [value1,value2,...]
    compress                  = <VALUE>
    default_ttl               = <VALUE>
    field_level_encryption_id = <VALUE>
    forwarded_values = [{
      cookies = [{
        forward           = <VALUE>
        whitelisted_names == [value1,value2,...]
      }]
      headers                 == [value1,value2,...]
      query_string            = <VALUE>
      query_string_cache_keys == [value1,value2,...]
    }]
    lambda_function_association = [{
      event_type   = <VALUE>
      include_body = <VALUE>
      lambda_arn   = <VALUE>
    }]
    max_ttl                  = <VALUE>
    min_ttl                  = <VALUE>
    origin_request_policy_id = <VALUE>
    realtime_log_config_arn  = <VALUE>
    smooth_streaming         = <VALUE>
    target_origin_id         = <VALUE>
    trusted_signers          == [value1,value2,...]
    viewer_protocol_policy   = <VALUE>
  }]
```
```
  logging_config = [{
    bucket          = <VALUE>
    include_cookies = <VALUE>
    prefix          = <VALUE>
  }]
```
```
  ordered_cache_behavior = [{
    allowed_methods           == [value1,value2,...]
    cache_policy_id           = <VALUE>
    cached_methods            == [value1,value2,...]
    compress                  = <VALUE>
    default_ttl               = <VALUE>
    field_level_encryption_id = <VALUE>
    forwarded_values = [{
      cookies = [{
        forward           = <VALUE>
        whitelisted_names == [value1,value2,...]
      }]
      headers                 == [value1,value2,...]
      query_string            = <VALUE>
      query_string_cache_keys == [value1,value2,...]
    }]
    lambda_function_association = [{
      event_type   = <VALUE>
      include_body = <VALUE>
      lambda_arn   = <VALUE>
    }]
    max_ttl                  = <VALUE>
    min_ttl                  = <VALUE>
    origin_request_policy_id = <VALUE>
    path_pattern             = <VALUE>
    realtime_log_config_arn  = <VALUE>
    smooth_streaming         = <VALUE>
    target_origin_id         = <VALUE>
    trusted_signers          == [value1,value2,...]
    viewer_protocol_policy   = <VALUE>
  }]
```
```
  origin = [{
    custom_header = [{
      name  = <VALUE>
      value = <VALUE>
    }]
    custom_origin_config = [{
      http_port                = <VALUE>
      https_port               = <VALUE>
      origin_keepalive_timeout = <VALUE>
      origin_protocol_policy   = <VALUE>
      origin_read_timeout      = <VALUE>
      origin_ssl_protocols     == [value1,value2,...]
    }]
    domain_name = <VALUE>
    origin_id   = <VALUE>
    origin_path = <VALUE>
    s3_origin_config = [{
      origin_access_identity = <VALUE>
    }]
  }]
```
```
  origin_group = [{
    failover_criteria = [{
      status_codes == [value1,value2,...]
    }]
    member = [{
      origin_id = <VALUE>
    }]
    origin_id = <VALUE>
  }]


```
```
  viewer_certificate = [{
    acm_certificate_arn            = <VALUE>
    cloudfront_default_certificate = <VALUE>
    iam_certificate_id             = <VALUE>
    minimum_protocol_version       = <VALUE>
    ssl_support_method             = <VALUE>
  }]
}
```
## Mandatory Tags Note:

*	As per redesigned new mandatory tags, mandatory tags along with any additional tags have to be added through template configuration within the modules as below
*	Have a reference of mandatory tags module within the template configuration as shown in example script below.
```bash
# Mandatory Tag Workspace Variables
variable "apm-id" {}
variable "application-name" {}
variable "app-support-dl" {}
variable "app-servicenow-group" {}
variable "business-division" {}
variable "company" {}
variable "compliance" {}
variable "costcenter" {}
variable "environment" {}
variable "PatchGroup" {}
variable "PatchWindow" {}
variable "ATLAS_WORKSPACE_NAME" {}

# Mandatory Tags Module 
module "mandatory_tags" {
  source               = "cps-terraform.anthem.com/<ORG_NAME>/terraform-aws-mandatory-tags-v2/aws"
  tags                 = {}
  apm-id               = var.apm-id
  application-name     = var.application-name
  app-support-dl       = var.app-support-dl
  app-servicenow-group = var.app-servicenow-group
  business-division    = var.business-division
  compliance           = var.compliance
  company              = var.company
  costcenter           = var.costcenter
  environment          = var.environment
  PatchGroup           = var.PatchGroup
  PatchWindow          = var.PatchWindow
  workspace            = var.ATLAS_WORKSPACE_NAME
}
```
*	Mandatory tags module should be referred in tags attribute as below:
tags = module.mandatory_tags.tags
*	Any additional tags can be merged to tags attribute as below:
tags = merge(module.mandatory_tags.tags, {"sample" = "abc"})

## Usage

To run this example you need to execute:

```bash
#Example script
module "terraform-aws-cloudfront-distribution" {

  source  = "cps-terraform.anthem.com/<ORG_NAME>/terraform-aws-cloudfront-distribution/aws"

  origin =  [{
    domain_name = "mybucket.s3.us-east-1.amazonaws.com"
    origin_id   = local.s3_origin_id
     custom_header= []
    #custom_origin_config =   []
    custom_origin_config =[{
      http_port                = 80
      https_port               = 443
      origin_keepalive_timeout = null
      origin_protocol_policy   = "https-only"
      origin_read_timeout      = null
      origin_ssl_protocols     =   ["TLSv1.3"]

      }
     ]
     origin_path= null
    }]
   tags = module.mandatory_tags.tags
  enabled             = true
  is_ipv6_enabled     = true
  comment             = "Some comment"
  default_root_object = "index.html"
  default_cache_behavior = [{
    allowed_methods  = ["DELETE", "GET", "HEAD", "OPTIONS", "PATCH", "POST", "PUT"]
    cached_methods   = ["GET", "HEAD"]
    target_origin_id = local.s3_origin_id

    forwarded_values = [{
      query_string = false
       headers                 = null
       query_string_cache_keys = null
      cookies =[{
        forward = "none"
        whitelisted_names = null
      }]
    }]
   viewer_protocol_policy = "allow-all"
    min_ttl                = 0
    default_ttl            = 3600
    max_ttl                = 86400
    compress               = true
    viewer_protocol_policy = "redirect-to-https"
  }]
 price_class = "PriceClass_200"
 viewer_certificate = [{
    cloudfront_default_certificate = true

  }]
}
#Initialize Terraform
terraform init

#Terraform Dry-Run
terraform plan

#Create the resources
terraform apply

#Destroy the resources saved in the tfstate
terraform destroy
```

## Requirements

No requirements.
## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | ">=3.35.0" |

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_mandatorytags"></a> [mandatorytags](#module\_mandatorytags) | cps-terraform.anthem.com/ASCSD/terraform-aws-mandatory-tags/aws | n/a |

## Resources

| Name | Type |
|------|------|
| [aws_cloudfront_distribution.this](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/cloudfront_distribution) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| aliases | (Optional)Default:null - Extra CNAMEs (alternate domain names), if any, for this distribution. | `set(string)` | `null` | no |       
| comment | (Optional)Default:null - Any comments you want to include about the distribution. | `string` | `null` | no |
| create\_cloudfront\_distribution | (Optional)Default:true Controls if CloudFront distribution  should be created | `bool` | `true` | no |      
| custom\_error\_response | (Optional)Default:[] - One or more custom error response elements (multiples allowed). | <pre>set(object(<br>    {<br>      error_caching_min_ttl = number<br>      error_code            = number<br>      response_code         = number<br>      response_page_path    = string<br>    }<br>  ))</pre> | `[]` | no |
| default\_cache\_behavior | (Required) - The default cache behavior for this distribution (maximum one). | `list(any)` | n/a | yes |
| default\_root\_object | (Optional)Default:null - The object that you want CloudFront to return (for example, index.html) when an end user requests the root URL. | `string` | `null` | no |
| enabled | (Required) - Whether the distribution is enabled to accept end user requests for content. | `bool` | n/a | yes |
| http\_version | (Optional)Default:null - The maximum HTTP version to support on the distribution. Allowed values are http1.1 and http2. The default is http2 | `string` | `null` | no |
| is\_ipv6\_enabled | (Optional)Default:null - Whether the IPv6 is enabled for the distribution. | `bool` | `null` | no |
| logging\_config | (Optional)Default:[] - The logging configuration that controls how logs are written to your distribution (maximum one). | <pre>set(object(<br>    {<br>      bucket          = string<br>      include_cookies = bool<br>      prefix          = string<br>    }<br>  ))</pre> | `[]` | no |
| ordered\_cache\_behavior | (Optional)Default:[] - An ordered list of cache behaviors resource for this distribution. List from top to bottom in order of precedence. The topmost cache behavior will have precedence 0. | `list(any)` | `[]` | no |
| origin | (Required) - One or more origins for this distribution (multiples allowed). | `list(any)` | n/a | yes |
| origin\_group | (Optional)Default:[] - One or more origin\_group for this distribution (multiples allowed). | <pre>set(object(<br>    {<br>    
  failover_criteria = list(object(<br>        {<br>          status_codes = set(number)<br>        }<br>      ))<br>      member = list(object(<br>        {<br>          origin_id = string<br>        }<br>      ))<br>      origin_id = string<br>    }<br>  ))</pre> | `[]` | no |
| price\_class | (Optional)Default:null - The price class for this distribution. One of PriceClass\_All, PriceClass\_200, PriceClass\_100 | `string` | `null` | no |
| retain\_on\_delete | (Optional)Default:null - Disables the distribution instead of deleting it when destroying the resource through Terraform. 
If this is set, the distribution needs to be deleted manually afterwards. Default: false. | `bool` | `null` | no |
| tags | (Required) A mapping of tags to assign to all resources. | `map(string)` | n/a | yes |
| viewer\_certificate | (Required) - The SSL configuration for this distribution (maximum one). | `list(any)` | n/a | yes |
| wait\_for\_deployment | (Optional)Default:null - If enabled, the resource will wait for the distribution status to change from InProgress to Deployed. Setting this tofalse will skip the process. Default: true. | `bool` | `null` | no |
| web\_acl\_id | (Optional)Default:null - A unique identifier that specifies the AWS WAF web ACL, if any, to associate with this distribution. To specify a web ACL created using the latest version of AWS WAF (WAFv2), use the ACL ARN, for example aws\_wafv2\_web\_acl.example.arn. To specify a web ACL created using AWS WAF Classic, use the ACL ID, for example aws\_waf\_web\_acl.example.id. The WAF Web ACL must exist in the WAF Global (CloudFront) region and the credentials configuring this argument must have waf:GetWebACL permissions assigned. | `string` | `null` | no |      

## Outputs

| Name | Description |
|------|-------------|
| arn | returns a string |
| caller\_reference | returns a string |
| domain\_name | returns a string |
| etag | returns a string |
| hosted\_zone\_id | returns a string |
| id | returns a string |
| in\_progress\_validation\_batches | returns a number |
| last\_modified\_time | returns a string |
| status | returns a string |
| this | n/a |
| trusted\_signers | returns a list of object |