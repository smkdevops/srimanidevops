# Anthem AWS Cloudfront Monitoring Subscription Resource

This module create aws Monitoring Subscription Resource.

<span style="color: red">**This module should only be used by Contact Center Project.**</span>


## HIPAA eligibility status

* N/A


## Security Guardrail reference

[security Guardrails Link](https://confluence.anthem.com/download/attachments/717965086/Anthem%20AWS%20Security%20Patterns%20-%20AWS_CloudFront%20-%20Deliotte%20Digital%20CCaaS%20use%20case.docx?version=1&modificationDate=1628274246000&api=v2)

## Pre-requisite

- No dependent resource required.

## Usage

To run this example you need to execute:

```bash
#Initialize Terraform
terraform init

#Terraform Dry-Run
terraform plan

#Create the resources
terraform apply

#Destroy the resources saved in the tfstate
terraform destroy
```


## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | ">=3.35.0" |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [aws_cloudfront_monitoring_subscription.this](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/cloudfront_monitoring_subscription) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_create_monitoring_subscription"></a> [create\_monitoring\_subscription](#input\_create\_monitoring\_subscription) | Controls if CloudFront create monitoring subscription should be created | `bool` | `true` | no |
| <a name="input_distribution_id"></a> [distribution\_id](#input\_distribution\_id) | (Required) The ID of the distribution that you are enabling metrics for. | `string` | n/a | yes |
| <a name="input_metrics_subscription_status"></a> [metrics\_subscription\_status](#input\_metrics\_subscription\_status) | realtime\_metrics\_subscription\_status - (Required) A flag that indicates whether additional CloudWatch metrics are enabled for a given CloudFront distribution. Valid values are Enabled and Disabled. See below. | `set(any)` | `null` | no |
| <a name="input_realtime_metrics_subscription_status"></a> [realtime\_metrics\_subscription\_status](#input\_realtime\_metrics\_subscription\_status) | realtime\_metrics\_subscription\_status - (Required) A flag that indicates whether additional CloudWatch metrics are enabled for a given CloudFront distribution. Valid values are Enabled and Disabled. See below. | `string` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_id"></a> [id](#output\_id) | returns a string |
| <a name="output_this"></a> [this](#output\_this) | n/a |
