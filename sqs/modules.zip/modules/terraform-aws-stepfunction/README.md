# Anthem AWS StepFunction

This resource creates StepFunction on AWS cloud


## HIPAA eligibility status

* AWS Step Functions is eligible


## Security Guardrail reference

[security guardrails link](https://confluence.anthem.com/pages/viewpageattachments.action?pageId=299009562&sortBy=date&startIndex=60&preview=/299009562/370574349/Anthem%20AWS%20Security%20Patterns%20-%20Step%20Functions.docx)

## Pre-Requisite
1. Conditional resource creation is enabled with "create_sfn_activity" variable, setting this variable to "true" will create the resource and setting this to "false" will skip the resource creation.
2. Conditional resource creation is enabled with "create_sfn_state_machine" variable, setting this variable to "true" will create the resource and setting this to "false" will skip the resource creation.
3. Creates a Step Function State Machine resource. This requires role ARN, wwhich has permission to execute the lambda function mentoned in the defination of the state function. Also, requires a json file with the state machine definition.
4. definition can now be passed in various ways, i.e.,:
```bash
definition                      = data.template_file.variable-definition.rendered
<<-EOF
{
    "Comment": "A Hello World example of the Amazon States Language using an AWS Lambda Function",
    "StartAt": "HelloWorld",
    "States": {
      "HelloWorld": {
        "Type": "Task",
        "Resource": "",
        "End": true
      }
    }
}
EOF
"./lambda.json"
jsonencode({
    "Comment": "A Hello World example of the Amazon States Language using an AWS Lambda Function",
    "StartAt": "HelloWorld",
    "States": {
      "HelloWorld": {
        "Type": "Task",
        "Resource": "",
        "End": true
      }
    }
})
```
## Mandatory Tags Note:
*	As per redesigned new mandatory tags, mandatory tags along with any additional tags have to be added through template configuration within the modules as below
*	Have a reference of mandatory tags module within the template configuration as shown in example script below.
```bash
# Mandatory Tag Workspace Variables
variable "apm-id" {}
variable "application-name" {}
variable "app-support-dl" {}
variable "app-servicenow-group" {}
variable "business-division" {}
variable "company" {}
variable "compliance" {}
variable "costcenter" {}
variable "environment" {}
variable "PatchGroup" {}
variable "PatchWindow" {}
variable "ATLAS_WORKSPACE_NAME" {}

# Mandatory Tags Module 
module "mandatory_tags" {
  source               = "cps-terraform.anthem.com/<ORG_NAME>/terraform-aws-mandatory-tags-v2/aws"
  tags                 = {}
  apm-id               = var.apm-id
  application-name     = var.application-name
  app-support-dl       = var.app-support-dl
  app-servicenow-group = var.app-servicenow-group
  business-division    = var.business-division
  compliance           = var.compliance
  company              = var.company
  costcenter           = var.costcenter
  environment          = var.environment
  PatchGroup           = var.PatchGroup
  PatchWindow          = var.PatchWindow
  workspace            = var.ATLAS_WORKSPACE_NAME
}
```
*	Mandatory tags module should be referred in tags attribute as below:
tags = module.mandatory_tags.tags
*	Any additional tags can be merged to tags attribute as below:
tags = merge(module.mandatory_tags.tags, {"sample" = "abc"})



## Usage

```bash
#Example script
module "sfn_state" {

/******** Source location of the module **************/

source  = "cps-terraform.anthem.com/<ORGANIZATION_NAME>/terraform-aws-stepfunction/aws"

tags = merge(module.mandatory_tags.tags)

/******** Parameter required for resource creation ****/

stepfunction_name               = ""
definition                      = ""
log_destination                 =""
stepfunction_role               = ""
activity_name                   = ""
cloudwatch_kms_key_arn          =""

}

To run this example you need to execute:

#Initialize Terraform
terraform init

#Terraform Dry-Run
terraform plan

#Create the resources
terraform apply

#Destroy the resources saved in the tfstate
terraform destroy
`````

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| activity\_name | (Required) The name of the activity to create. | `string` | n/a | yes |
| cloud\_watch\_log\_retention | (Optional) "Default : 0".Specifies the number of days you want to retain log events in the specified log group. Possible values are: 1, 3, 5, 7, 14, 30, 60, 90, 120, 150, 180, 365, 400, 545, 731, 1827, 3653, and 0. If you select 0, the events in the log group are always retained and never expire. | `number` | `0` | no |
| cloudwatch\_kms\_key\_arn | (Required) Amazon Resource Name (ARN) of the Cloudwatch KMS key to be used to encrypt the data. | `string` | n/a | yes |
| create\_cloudwatch\_log\_group | (Optional) "Default : false".Need to create a New cloudwatch log group True or False | `bool` | `false` | no |
| create\_sfn\_activity | (Optional) "Default : true".It controls the step function activity should be create. | `bool` | `true` | no |
| create\_sfn\_state\_machine | (Optional) "Default : true".It controls the step function state machine should be create. | `bool` | `true` | no |
| definition | (Required) The Amazon States Language definition of the state machine. | `string` | n/a | yes |
| include\_execution\_data | (Optional) "Default : true".It includes execution data into the logging configuration. | `bool` | `true` | no |
| log\_destination | (Optional) "Default : null".The Cloud Watch Log group Amazon Resource Name (ARN) for this state machine. | `string` | `""` | no |
| log\_level | (Optional) "Default : ALL".It controls the step function Log levels. | `string` | `"ALL"` | no |
| stepfunction\_name | (Required) The name of the state machine. | `string` | n/a | yes |
| stepfunction\_role | (Required) The Amazon Resource Name (ARN) of the IAM role to use for this state machine. | `string` | n/a | yes |
| tags | (Required) A mapping of tags to assign to all resources. | `map(any)` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| creation\_date\_activity | The date the activity was created. |
| creation\_date\_machine | The date the state machine was created. |
| id\_activity | The Amazon Resource Name (ARN) that identifies the created activity. |
| id\_machine | The ARN of the state machine. |
| name | The name of the activity. |
| status | The current status of the state machine. Either ACTIVE or DELETING. |

## Testing

1.created State machine with tags and verified in console.
2.we have  step by step diagramatic represntation for definition,that was given in json format(e.g:helloworld using lambda function), this is verified by state machine definition in console.
3.Created State activity with tags and verified in console.