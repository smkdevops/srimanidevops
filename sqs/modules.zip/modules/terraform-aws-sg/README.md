# AWS Security Group Terraform Module

This module creates a security group using terraform

## Reference

[AWS Security Groups](https://docs.aws.amazon.com/vpc/latest/userguide/VPC_SecurityGroups.html)

## Terraform Resources

* [aws_iam_policy](https://www.terraform.io/docs/providers/aws/r/iam_policy.html)
* [aws_security_group](https://www.terraform.io/docs/providers/aws/r/security_group.html)
* [aws_security_group_rule](https://www.terraform.io/docs/providers/aws/r/security_group_rule.html)

## HIPAA eligibility status

1. Security group is a part of VPC and Amazon Virtual Private Cloud (VPC) is eligible.

## Security Guardrail reference

https://confluence.anthem.com/pages/viewpageattachments.action?pageId=299009562&sortBy=date&startIndex=80&preview=/299009562/357900868/Anthem%20AWS%20Security%20Patterns%20-%20Security%20Groups%20-%20v1.docx

## Pre-requisite

1. Security group can be created with multiple ingress, egress rules or without any rule. If ingress or egress parameters don't have any value then the Security group can be created without any rule as well. 
2. It is mandatory to have all the parameters mentioned in the block of rule while creating the rule. It can be blank but it should exist,otherwise the security group will fail. This block is same for egress and ingress both.
   {
                                        cidr_blocks       = ["192.168.1.11/32"]
                                        ipv6_cidr_blocks  = []
                                        prefix_list_ids   = []
                                        from_port         = 80
                                        protocol          = "TCP"
                                        security_groups   = []
                                        self              = "false"
                                        to_port           = 80
                                        description       = "Test1"
                                    }

3. Cidr block 0.0.0.0/0 is not allowed in ingress rule.
4. Protocol http is not allowed in ingress rule.
5. Port 445 and 80 is not allowed in ingress rule.
6. If cidr_blocks, security_groups and self is true in one block then 3 rule will be created but then there should not be any other overlapping rule mentioned with the same details while creating the SG. otherwise it will fail.
7. To skip create security group please pass variable aws_create_security_group = false by default it will be true.


## Usage
To run this example you need to execute:

```bash
module "sg" {

/******** Source location of the module **************/



source  = "cps-terraform.anthem.com/<ORG_NAME>/terraform-aws-sg/aws"


/******** Mandatory tags *****************************/

environment                     = ""
company                         = ""
costcenter                      = ""
owner-department                = ""
it-department                   = ""
barometer-it-num                = ""
resource-type                   = ""
layer                           = ""
compliance                      = ""
application                     = ""
application_dl                     = ""

/******** Parameter required for resource creation ****/

name                            = ""
security_group_description      = ""
vpc_id                          = "vpc-XXXXXX"
revoke_rules_on_delete          = ""

ingress                         = [ {
                                        cidr_blocks       = []
                                        ipv6_cidr_blocks  = []
                                        prefix_list_ids   = []
                                        from_port         = 
                                        protocol          = "TCP"
                                        security_groups   = []
                                        self              = ""
                                        to_port           = 
                                        description       = ""
                                    }
                                ]

egress                         = [{
                                        cidr_blocks       = []
                                        ipv6_cidr_blocks  = []
                                        prefix_list_ids   = []
                                        from_port         = 
                                        protocol          = "TCP"
                                        security_groups   = []
                                        self              = ""
                                        to_port           = 
                                        description       = ""
                                    }
                                ]

}
#Initialize Terraform
terraform init

#Terraform Dry-Run
terraform plan

#Create the resources
terraform apply

#Destroy the resources saved in the tfstate
terraform destroy
```

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| application | Based upon application nomenclature in server naming convention policy.Use up to six (6) characters to name your application. | `string` | n/a | yes |
| application\_dl | Application DL | `string` | n/a | yes |
| aws\_create\_security\_group | It takes care of create security group and to skip create pass as false | `bool` | `true` | no |
| barometer-it-num | The barometer it number. | `string` | n/a | yes |
| company | Company that owns resource | `string` | n/a | yes |
| compliance | PHI, PCI, PII, SOX, None | `string` | n/a | yes |
| costcenter | The project cost center. | `string` | n/a | yes |
| egress | Default : []. List of maps with  rules to apply to the security group | `list` | `[]` | no |
| environment | DBx,SIT,PERF,PRODX,UAT,UTILx | `string` | n/a | yes |
| ingress | Default : []. List of maps with ingress rules to apply to the security group | `list` | `[]` | no |
| it-department | The name of IT department | `string` | n/a | yes |
| layer | WEBx, MWx, DBx, UTILx | `string` | n/a | yes |
| name | The name of the security group. | `string` | n/a | yes |
| owner-department | The name of department owner. | `string` | n/a | yes |
| resource-type | Type of resource. | `string` | n/a | yes |
| revoke\_rules\_on\_delete | Default : false .Instruct Terraform to revoke all of the Security Groups attached ingress and egress rules before deleting the rule itself. This is normally not needed, however certain AWS services such as Elastic Map Reduce may automatically add required rules to security groups used with the service, 
and those rules may contain a cyclic dependency that prevent the security groups from being destroyed without removing the dependency first. Default false | `bool` | `false` | no |
| security\_group\_description | Default : "Security group created with Terraform Module." Security Group description | `string` | `"Security group created with Terraform Module"` | no |
| tags | Default : {} .A mapping of tags to assign to the resource | `map` | `{}` | no |
| vpc\_id | VPC ID to attached the security group | `string` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| arn | The ARN of the security group |
| description | The description of the security group |
| egress | The egress rules. See above for more. |
| id | The ID of the security group |
| ingress | The ingress rules. See above for more. |
| name | The name of the security group |
| owner\_id | The owner ID. |
| vpc\_id | The VPC ID. |

## Testing

1. This module has been tested by creating a security group.
2. The same security group is used for EC2 instance creation.
3. Ping to EC2 instance from local is working after adding a seurity group to EC2 instance.
