# Anthem DMS Database Endpoint

This module creates DMS endpoint for source or target database.

## HIPAA eligibility status

1. AWS DMS (Database MIgration Service) is eligible.

## Security Guardrail reference

[AWS Security Pattern](https://confluence.elevancehealth.com/download/attachments/299009562/Anthem%20AWS%20Security%20Patterns%20-%20Database%20Migration%20Service.docx?api=v2)

# Release Notes:
## New Version - 0.1.1
1. With Mandatory Tags Redesign that happened early part of this year, we had to refactor all our templates to include central Mandatory Tag Module and remove variable references from the code.
2. All the new templates has been pushed in and you should be able to see the changes. Below are the highlights. 

### Adoption of the New Version - 0.1.1

1.	There is a new file tags.tf that is now included and integral part of our code base.
2.	We now have only Application Specific Tags in DMS modules of each templates. The entire code is now bit sleek. 
3.	Each module refers to mandatory tags module.

## Prerequisite
1. Connection for source and target endpoints are encrypted by Secure Socket Layer. Thus value for ssl_mode should not be none. Otherwise it would not create endpoints.
2. Service Access Role is required for DynamoDB endpoints
3. In-Transit encryption(https://) is implemented and enforced in the code. The non ssl(http:// and port 80) is not allowed.
4. At-rest encryption is implemented and enforced in the code. Valid KMS Key is required.
5. For Kinesis, S3, Kafka, mongoDB or elasticsearch engine types the configuration block of settings must be passed in the form of a map with the required parameters(refer to the documentation in the description of the variables), e.g:

```bash
s3_settings = {
    bucket_name       = "bucketexample1234"
    compression_type  = "NONE"
    csv_delimiter     = ","
    csv_row_delimiter = "\n"
    server_side_encryption_kms_key_id = ""
}
```

## Usage

To run this example you need to execute:

```bash
#Initialize Terraform
terraform init

#Terraform Dry-Run
terraform plan

#Create the resources
terraform apply

#Destroy the resources saved in the tfstate
terraform destroy
```

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| application | Based upon application nomenclature in server naming convention policy.Use up to six (6) characters to name your application. | `string` | n/a | yes |
| application\_dl | Application DL | `string` | n/a | yes |
| barometer-it-num | The barometer it number. | `string` | n/a | yes |
| certificate\_arn | Required when "engine\_name" related to database services.If given condition doesn't meet condition, It means variable is not applicable for given engine\_name. In this case user is required to provide blank("") value. The Amazon Resource Name (ARN) for the certificate. | `string` | n/a | yes |
| company | Company that owns resource | `string` | n/a | yes |
| compliance | PHI, PCI, PII, SOX, None | `string` | n/a | yes |
| costcenter | The project cost center. | `string` | n/a | yes |
| database\_name | Required when "engine\_name" related to database services.If given condition doesn't meet condition, It means variable is not applicable for given engine\_name. In this case user is required to provide blank("") value..The name of the endpoint database. | `string` | n/a | yes |
| elasticsearch\_settings | The elasticsearch settings in the form of a map. To see more information about the parameters inside this block please refer [Elasticsearch settings](https://docs.aws.amazon.com/dms/latest/APIReference/API_ElasticsearchSettings.html) | `map` | `{}` | no |
| endpoint\_id | The database endpoint identifier. <br> Must contain from 1 to 255 alphanumeric characters or hyphens. <br> Must begin with a letter <br> Must contain only ASCII letters, digits, and hyphens <br> Must not end with a hyphen <br> Must not contain two consecutive hyphens. | `string` | n/a | yes |
| endpoint\_type | Default : "target" . The type of endpoint. Can be one of source \| target. | `string` | `"target"` | no |
| engine\_name | The type of engine for the endpoint. Can be one of aurora \| azuredb \| db2 \| docdb \| dynamodb \| mariadb \| mongodb \| mysql \| oracle \| postgres \| redshift \| s3 \| sqlserver \| sybase \| elasticsearch \| kinesis. | `string` | n/a | yes |
| environment | DBx,SIT,PERF,PRODX,UAT,UTILx | `string` | n/a | yes |
| extra\_connection\_attributes\_path | Default : "" . File path to additional attributes associated with the connection. For available attributes see Using Extra Connection Attributes with [AWS Database Migration Service](http://docs.aws.amazon.com/dms/latest/userguide/CHAP_Introduction.ConnectionAttributes.html). | `string` | `""` | no |
| it-department | The name of IT department | `string` | n/a | yes |
| kafka\_settings | The Kafka settings in the form of a map. To see more information about the parameters of this block please refer [Kafka settings](https://docs.aws.amazon.com/dms/latest/APIReference/API_KafkaSettings.html) | `map` | `{}` | no |
| kinesis\_settings | The Kinesis settings described in the form of a map. To see more information about the parameters of this block please refer [Kinesis settings](https://docs.aws.amazon.com/dms/latest/APIReference/API_KinesisSettings.html) | `map` | `{}` | no |
| kms\_key\_arn | The Amazon Resource Name (ARN) for the customer managed CMK that will be used to encrypt the connection parameters. | `string` | n/a | yes |
| layer | WEBx, MWx, DBx, UTILx | `string` | n/a | yes |
| mongodb\_settings | The mongodb settings described in the form of a map. To see more information abut the parameters of this block, please refer [MongoDB settings](https://docs.aws.amazon.com/dms/latest/APIReference/API_MongoDbSettings.html) | `map` | `{}` | no |
| owner-department | The name of department owner. | `string` | n/a | yes |
| password | Required when "engine\_name" related to database services. If given condition doesn't meet condition, It means variable is not applicable for given engine\_name. In this case user is required to provide blank("") value.The password to be used to login to the endpoint database. | `string` | n/a | yes |
| port | Required when "engine\_name" related to database services.If given condition doesn't meet condition, It means variable is not applicable for given engine\_name. In this case user is required to provide blank("") value. Port number will change depends on database which is used. The port used by the endpoint database. | `number` | n/a | yes |
| resource-type | Type of resource. | `string` | n/a | yes |
| s3\_settings | The S3 settings described in the form of a map, to see more information about the parameters required for this block please refer [S3 Settings](https://docs.aws.amazon.com/dms/latest/APIReference/API_S3Settings.html) | `map` | `{}` | no |
| server\_name | Required when "engine\_name" related to database services.If given condition doesn't meet condition, It means variable is not applicable for given engine\_name. In this case user is required to provide blank("") value. The host name of the server. | `string` | n/a | yes |
| service\_access\_role | Required when "engine\_name" is "dynamodb" , need to provide valid value for attribute.If given condition doesn't meet condition, It means variable is not applicable for given engine\_name. In this case user is required to provide blank("") value. The Amazon Resource Name (ARN) used by the service access IAM role for dynamodb endpoints. | `string` | `null` | no |
| ssl\_mode | Required when "engine\_name" related to database services.If given condition doesn't meet condition, It means variable is not applicable for given engine\_name. In this case user is required to provide blank("") value.The SSL mode to use for the connection. Can be one of  require \| verify-ca \| verify-full. | `string` | n/a | yes |
| tags | Default : {} . A mapping of tags to assign to the resource. | `map(string)` | `{}` | no |
| username | Required when "engine\_name" related to database services.If given condition doesn't meet condition, It means variable is not applicable for given engine\_name. In this case user is required to provide blank("") value. The user name to be used to login to the endpoint database. | `string` | n/a | yes |
| secrets\_manager\_arn | Full ARN, partial ARN, or friendly name of the SecretsManagerSecret that contains the endpoint connection details. Supported only when engine_name is aurora, aurora-postgresql, mariadb, mongodb, mysql, oracle, postgres, redshift, or sqlserver.| `string` | n/a | no |
| secrets\_manager\_access\_role\_arn | ARN of the IAM role that specifies AWS DMS as the trusted entity and has the required permissions to access the value in SecretsManagerSecret.| `string` | n/a | no |
| s3\_server\_side\_encryption\_kms\_key\_id | Required when encryption_mode is SSE_KMS, must not be set otherwise. ARN or Id of KMS Key to use when encryption_mode is SSE_KMS.| `string` | n/a | no |

## Outputs

| Name | Description |
|------|-------------|
| dms\_endpoint\_arn | The Amazon Resource Name (ARN) for the endpoint. |
| dms\_endpoint\_message | Message for end-user for SSL Mode |


## Unit Testing
1. Created DMS endpoints using terraform script for oracle database
2. On AWS Console, we have tested connection with available replication instance successfully to create endpoint on Replication Instance. 
3. Same DMS endpoints have been associated with DMS migration task.
4. KMS Key validation (its existance in account) is done successfully.