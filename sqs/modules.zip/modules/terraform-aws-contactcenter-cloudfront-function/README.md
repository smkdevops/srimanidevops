# Anthem AWS Cloudfront function Resource

This module create aws Cloudfront function Resource.


<span style="color: red">**This module should only be used by Contact Center Project.**</span>

## HIPAA eligibility status

* N/A


## Security Guardrail reference

[security Guardrails Link](https://confluence.anthem.com/download/attachments/717965086/Anthem%20AWS%20Security%20Patterns%20-%20AWS_CloudFront%20-%20Deliotte%20Digital%20CCaaS%20use%20case.docx?version=1&modificationDate=1628274246000&api=v2)

## Pre-requisite

- Dependent resources will be needed if any.

## Usage

To run this example you need to execute:

```bash
#Initialize Terraform
terraform init

#Terraform Dry-Run
terraform plan

#Create the resources
terraform apply

#Destroy the resources saved in the tfstate
terraform destroy
```

## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | ">=3.35.0" |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [aws_cloudfront_function.this](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/cloudfront_function) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_code"></a> [code](#input\_code) | (Required) Source code of the function | `string` | n/a | yes |
| <a name="input_comment"></a> [comment](#input\_comment) | (Optional) Comment. | `string` | `null` | no |
| <a name="input_create_function"></a> [create\_function](#input\_create\_function) | Controls if CloudFront function should be created | `bool` | `true` | no |
| <a name="input_name"></a> [name](#input\_name) | (Required) Unique name for your CloudFront Function. | `string` | n/a | yes |
| <a name="input_publish"></a> [publish](#input\_publish) | (Optional) Whether to publish creation/change as Live CloudFront Function Version. Defaults to true. | `bool` | `true` | no |
| <a name="input_runtime"></a> [runtime](#input\_runtime) | (Required) Identifier of the function's runtime. Currently only cloudfront-js-1.0 is valid. | `string` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_arn"></a> [arn](#output\_arn) | returns a string |
| <a name="output_etag"></a> [etag](#output\_etag) | returns a string |
| <a name="output_status"></a> [status](#output\_status) | returns a string |
| <a name="output_this"></a> [this](#output\_this) | n/a |
