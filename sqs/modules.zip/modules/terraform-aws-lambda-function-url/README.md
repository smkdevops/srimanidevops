## Anthem AWS Lambda  Function URLModule

This module will create a Lambda Function URL.

## HIPPA eligibility status

1. AWS Lambda is eligible.

## Security Guardrail reference
[AWS Security Pattern](https://confluence.anthem.com/pages/viewpageattachments.action?pageId=299009562&sortBy=date&startIndex=80&preview=/299009562/331420438/Anthem%20AWS%20Security%20Patterns%20-Lambda-Final-v1.docx)

## Pre-Requisite

1. The module is to create a lambda function url.
2. Before creating this we need to create lambda function.
3. If user doesnt specify any qualifier it will create  url to lambda function. If user specifies qualifier as alias name it will create url to qualifier.

## Usage
```bash

module "terraform-aws-lambda-function-url" {
  source  = "cps-terraform-dev.anthem.com/CORP/terraform-aws-lambda-function-url/aws"
  authorization_type = "AWS_IAM"
  function_name = "tirumal-scteam-lambda-test"
  #qualifier = "my_alias"
   /* cors = [{
    allow_credentials = true
    allow_origins     = ["*"]
    allow_methods     = ["*"]
    allow_headers     = ["date", "keep-alive"]
    expose_headers    = ["keep-alive", "date"]
    max_age           = 86400
  }]
  */

}

#Initialize Terraform
terraform init

#Terraform Dry-Run
terraform plan

#Create the resources
terraform apply

#Destroy the resources saved in the tfstate
terraform destroy
```

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| authorization\_type | The type of authentication that the function URL uses. Set to AWS\_IAM to restrict access to authenticated IAM users only. Set to NONE to bypass IAM authentication and create a public endpoint. | `string` | n/a | yes |
| cors | The cross-origin resource sharing (CORS) settings for the function URL. | `any` | `null` | no |
| create\_lambda\_function\_url | A boolean that indicates whether to create lambda\_function\_url or not. Default is true | `bool` | `true` | no |
| function\_name | The name (or ARN) of the Lambda function. | `string` | n/a | yes |
| qualifier | The alias name. | `string` | `null` | no |

## Outputs

| Name | Description |
|------|-------------|
| function\_arn | The Amazon Resource Name (ARN) of the function. |
| function\_url | The HTTP URL endpoint for the function in the format https://<url\_id>.lambda-url.<region>.on.aws |
| url\_id | A generated ID for the endpoint. |


## Testing

1. Created lambda function url with auth_type "None". Able to see that in console.
2. Created lambda function url with auth_type "AWS-IAM". Able to see that in console.