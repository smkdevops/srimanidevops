# Anthem AWS APIGateway Integration Response Module

Provides an HTTP Method Integration Response for an API Gateway Resource.

## HIPAA eligibility status

1. Amazon API Gateway is eligible

## Security Guardrail reference

https://confluence.anthem.com/pages/viewpageattachments.action?pageId=299009562&sortBy=date&startIndex=60&preview=/299009562/370573552/Anthem%20AWS%20Security%20Patterns%20-%20API%20Gateway.docx

## Pre-Requisites

1. REST API is required.
2. Method is required.
3. Resource id is required.
4. Status_code is required.


## Important Note

1. REST API, Method and Resource need to be created before creating Integration response.

## Usage
To run this example you need to execute:

```bash

module "integration_response" {
  source = "cps-terraform.anthem.com/<ORG_NAME>/terraform-aws-api-integration-response/aws"

  depends_on = [module.rest_api, module.api_resource, module.api_method]

  rest_api_id             = module.rest_api.id
  resource_id             = module.api_resource.id
  http_method             = module.api_method.http_method
  status_code             = "200"
  response_parameters     = {
    "method.response.header.Access-Control-Allow-Origin"  = "'*'"
    "method.response.header.Access-Control-Allow-Headers" = "'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token,X-Amz-User-Agent'"
    "method.response.header.Access-Control-Allow-Methods" = "'OPTIONS,DELETE,GET,HEAD,PATCH,POST,PUT'"
  }

}

#Initialize Terraform
terraform init

#Terraform Dry-Run
terraform plan

#Create the resources
terraform apply

#Destroy the resources saved in the tfstate
terraform destroy
```

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| content\_handling | (Optional) Specifies how to handle request payload content type conversions. Supported values are CONVERT\_TO\_BINARY and CONVERT\_TO\_TEXT. If value is null then the response payload will be passthrough from the integration response to the method response without modification. | `string` | `null` | no |
| http\_method | (Required) The HTTP Method (GET, POST, PUT, DELETE, HEAD, OPTIONS, ANY) | `string` | n/a | yes |
| resource\_id | (Required) ID of an aws\_api\_gateway\_resource resource | `string` | n/a | yes |
| response\_parameters | (Optional) A map of response parameters that can be sent to the caller. For example: response\_parameters = { method.response.header.X-Some-Header = true } would define that the header X-Some-Header can be provided on the response. | `map(string)` | `{}` | no |      
| response\_templates | (Optional) A map specifying the templates used to transform the integration response body | `map(string)` | `{}` | no |   
| rest\_api\_id | (Required) The ID of the associated REST API | `string` | n/a | yes |
| selection\_pattern | (Optional) Specifies the regular expression pattern used to choose an integration response based on the response from the backend. Omit configuring this to make the integration the default one. If the backend is an AWS Lambda function, the AWS Lambda function error header is matched. For all other HTTP and AWS backends, the HTTP status code is matched. | `string` | `""` | no |
| status\_code | (Required) The HTTP status code | `string` | n/a | yes |

## Outputs

No output.

## Testing

1. Able to create API Integration response.