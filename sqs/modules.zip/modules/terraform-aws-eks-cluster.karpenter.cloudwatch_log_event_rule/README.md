# Anthem Cloudwatch Log Event Rule Module

This module creates a CloudWatch Logs Event Rule resource.

A rule matches incoming events and routes them to targets for processing. A single rule can route to multiple targets, all of which are processed in parallel. Rules aren't processed in a particular order. This enables different parts of an organization to look for and process the events that are of interest to them. A rule can customize the JSON sent to the target, by passing only certain parts or by overwriting it with a constant.

## HIPAA eligibility status

AWS Cloudwatch Logs Event Rule is eligible

## Security Guardrail reference


## Pre-Requisite
### Limitations
* Conditional resource creation is enabled with "create_cloudwatch_event_rule" variable, setting this variable to "true" will create the resource and setting this to "false" will skip the resource creation.
* The targets you associate with a rule must be in the same Region as the rule.
* Creating rules with built-in targets is supported only in the AWS Management Console.
***NOTE:** At least one of `schedule_expression` or `event_pattern` is required. By default, both are marked as optional to allow one o the other to be used.

## Mandatory Tags Note:
*	As per redesigned new mandatory tags, mandatory tags along with any additional tags have to be added through template configuration within the modules as below
*	Have a reference of mandatory tags module within the template configuration as shown in example script below.
```bash
# Mandatory Tag Workspace Variables
variable "apm-id" {}
variable "application-name" {}
variable "app-support-dl" {}
variable "app-servicenow-group" {}
variable "business-division" {}
variable "company" {}
variable "compliance" {}
variable "costcenter" {}
variable "environment" {}
variable "PatchGroup" {}
variable "PatchWindow" {}
variable "ATLAS_WORKSPACE_NAME" {}

# Mandatory Tags Module 
module "mandatory_tags" {
  source               = "cps-terraform.anthem.com/<ORG_NAME>/terraform-aws-mandatory-tags-v2/aws"
  tags                 = {}
  apm-id               = var.apm-id
  application-name     = var.application-name
  app-support-dl       = var.app-support-dl
  app-servicenow-group = var.app-servicenow-group
  business-division    = var.business-division
  compliance           = var.compliance
  company              = var.company
  costcenter           = var.costcenter
  environment          = var.environment
  PatchGroup           = var.PatchGroup
  PatchWindow          = var.PatchWindow
  workspace            = var.ATLAS_WORKSPACE_NAME
}
```
*	Mandatory tags module should be referred in tags attribute as below:
tags = module.mandatory_tags.tags
*	Any additional tags can be merged to tags attribute as below:
tags = merge(module.mandatory_tags.tags, {"sample" = "abc"})


## Usage
To run this example you need to execute:

```bash
#Example script
module "cloudwatch_log_event_rule" {

  source = "cps-terraform.anthem.com/<ORGANIZATION NAME>/terraform-aws-eventbridge-rule/aws"
  
  tags = merge(module.mandatory_tags.tags)

  /******** Parameter required for resource creation ****/

  name              = ""
  description         = ""  
  schedule_expression = ""
  event_pattern       = ""
  role_arn = ""
    
}

#Initialize Terraform
terraform init

#Terraform Dry-Run
terraform plan

#Create the resources
terraform apply

#Destroy the resources saved in the tfstate
terraform destroy
```

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| create\_cloudwatch\_event\_rule | (Optional) "Default : true". Need to create a new cloudwatch event rule True or False | `bool` | `true` | no |
| description | (Optional) "Default : """. The description of the rule. | `string` | `""` | no |
| event\_bus\_name | (Optional) "Default : """. The event bus to associate with this rule. If you omit this, the default event bus is used. | `string` | `""` | no |
| event\_pattern | (Optional) "Default : """. The event pattern described a JSON object. At least one of schedule\_expression or event\_pattern is required. See full documentation of Events and Event Patterns in EventBridge for details. | `string` | `""` | no |
| is\_enabled | (Optional) "Default : true". Whether the rule should be enabled (defaults to true). | `bool` | `true` | no |
| name | (Required) The name of the rule. If omitted, Terraform will assign a random, unique name. Conflicts with name\_prefix. | `string` | n/a | yes |
| name\_prefix | (Optional) "Default : null". Creates a unique name beginning with the specified prefix. Conflicts with name. | `string` | `null` | no |
| role\_arn | (Optional) "Default : """. The Amazon Resource Name (ARN) associated with the role that is used for target invocation | `string` | `""` | no |
| schedule\_expression | (Optional) "Default : """. The scheduling expression. For example, cron(0 20 \* \* ? \*) or rate(5 minutes). At least one of schedule\_expression or event\_pattern is required. Can only be used on the default event bus. | `string` | `""` | no |
| tags | (Required) A mapping of tags to assign to all resources. | `map(string)` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| arn | The Amazon Resource Name (ARN) of the rule. |
| id | The name of the rule. |

## Testing
1. Created a event rule and was able to see in console.