# Anthem AWS APIGateway Deployment Module

This module manages an API Gateway REST Deployment. A deployment is a snapshot of the REST API configuration. The deployment can then be published to callable endpoints via the aws_api_gateway_stage resource and optionally managed further with the aws_api_gateway_base_path_mapping resource, aws_api_gateway_domain_name resource, and aws_api_method_settings resource. For more information, see the API Gateway Developer Guide.

## HIPAA eligibility status

1. Amazon API Gateway is eligible

## Security Guardrail reference

https://confluence.anthem.com/pages/viewpageattachments.action?pageId=299009562&sortBy=date&startIndex=60&preview=/299009562/370573552/Anthem%20AWS%20Security%20Patterns%20-%20API%20Gateway.docx

## Pre-Requisites

1. Rest API should be created

## Important Note


## Usage
To run this example you need to execute:

```bash

module "api_deployment" {
  source     = "cps-terraform.anthem.com/<ORG>/terraform-aws-api-gateway-deployment/aws"
  depends_on = [module.api_method, module.api_integration]

  #Parameters
  rest_api_id            = module.rest_api.id
  deployment_description = "Test deployment"
  triggers               = {}
}

#Initialize Terraform
terraform init

#Terraform Dry-Run
terraform plan

#Create the resources
terraform apply

#Destroy the resources saved in the tfstate
terraform destroy
```

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| deployment\_description | (Optional) Description of the deployment. | `string` | `""` | no |
| rest\_api\_id | (Required) REST API identifier | `string` | n/a | yes |
| stage\_description | (Optional) Description of the stage. | `string` | `null` | no |
| stage\_name | (Optional) The name of the stage | `string` | `null` | no |
| triggers | (Optional) Map of arbitrary keys and values that, when changed, will trigger a redeployment. To force a redeployment without changing these keys/values, use the terraform taint command. | `map` | `null` | no |
| variables | (Optional) A map that defines the stage variables | `map` | `null` | no |

## Outputs

| Name | Description |
|------|-------------|
| created\_date | The creation date of the deployment |
| execution\_arn | The execution ARN to be used in lambda\_permission's source\_arn when allowing API Gateway to invoke a Lambda function, e.g. arn:aws:execute-api:eu-west-2:123456789012:z4675bid1j/prod |
| id | The ID of the deployment |
| invoke\_url | The URL to invoke the API pointing to the stage, e.g. https://z4675bid1j.execute-api.eu-west-2.amazonaws.com/prod |

## Testing

1. Able to create a Deployement.