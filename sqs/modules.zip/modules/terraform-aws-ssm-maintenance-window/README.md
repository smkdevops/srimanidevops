# Anthem AWS SSM Maintenance Window, Target and Task

This module creates SSm Maintenance Window, Target and Task services

## HIPPA eligibility status

1. AWS Systems Manager service is eligible.

## Security Guardrail reference

https://confluence.anthem.com/pages/viewpageattachments.action?pageId=299009562&preview=/299009562/516937786/Anthem%20AWS%20Security%20Patterns%20-%20Systems%20Manager.docx

## Pre-requisite

* Name of maintenance window, target and task are mandatory.
* Depends on resource_type the maintenance target will be created.
* Depends on task_type the maintenance task will be created.
* maintenance_window_task_targets_values variable required when maintenance_window_task_targets_key is "InstanceIds".

## Important Note

* This module is tested with only task_type "AUTOMATION" to terminate EC2 instance.

## Mandatory Tags Note:
*	As per redesigned new mandatory tags, mandatory tags along with any additional tags have to be added through template configuration within the modules as below
*	Have a reference of mandatory tags module within the template configuration as shown in example script below.
```bash
# Mandatory Tag Workspace Variables
variable "apm-id" {}
variable "application-name" {}
variable "app-support-dl" {}
variable "app-servicenow-group" {}
variable "business-division" {}
variable "company" {}
variable "compliance" {}
variable "costcenter" {}
variable "environment" {}
variable "PatchGroup" {}
variable "PatchWindow" {}
variable "ATLAS_WORKSPACE_NAME" {}

# Mandatory Tags Module 
module "mandatory_tags" {
  source               = "cps-terraform.anthem.com/<ORG_NAME>/terraform-aws-mandatory-tags-v2/aws"
  tags                 = {}
  apm-id               = var.apm-id
  application-name     = var.application-name
  app-support-dl       = var.app-support-dl
  app-servicenow-group = var.app-servicenow-group
  business-division    = var.business-division
  compliance           = var.compliance
  company              = var.company
  costcenter           = var.costcenter
  environment          = var.environment
  PatchGroup           = var.PatchGroup
  PatchWindow          = var.PatchWindow
  workspace            = var.ATLAS_WORKSPACE_NAME
}
```
*	Mandatory tags module should be referred in tags attribute as below:
tags = module.mandatory_tags.tags
*	Any additional tags can be merged to tags attribute as below:
tags = merge(module.mandatory_tags.tags, {"sample" = "abc"})

## Usage

To run this example you need to execute:

```bash
module "ssmmw" {
  source = "cps-terraform.anthem.com/<ORG_NAME>/terraform-aws-ssm-maintenance-window/aws"
  version = ""
  
  tags = merge(module.mandatory_tags.tags)
  ssm_maintenance_window_name        = ""
  schedule                           = ""
  schedule_offset                    = ""
  ssm_maintenance_window_target_name = ""
  maintenance_window_target_values = [""]
  task_arn                                = ""
  task_type                               = ""
  maintenance_window_task_targets_key     = ""
  automation_parameters_name              = ""
  automation_parameters_values            = []
  maintenance_window_task_name            = ""
  maintenance_window_task_description     = ""
  service_role_arn                        = ""
  
  
}
#Initialize Terraform
terraform init

#Terraform Dry-Run
terraform plan

#Create the resources
terraform apply

#Destroy the resources saved in the tfstate
terraform destroy
```

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| allow\_unassociated\_targets | (Optional) "Default : false .Whether targets must be registered with the Maintenance Window before tasks can be defined for those targets. | `bool` | `false` | no |
| automation\_parameters\_name | (Optional) "Default : "InstanceId" .Required when task\_type is "AUTOMATION" .The parameter name. | `string` | `"InstanceId"` | no |
| automation\_parameters\_values | (Required) Required when task\_type is "AUTOMATION" .The array of strings. | `list(any)` | n/a | yes |
| cloudwatch\_log\_group\_name | (Optional) "Default : "" .Required when task\_type is "RUN\_COMMAND" .The name of the CloudWatch log group where you want to send command output. If you don't specify a group name, Systems Manager automatically creates a log group for you. The log group uses the following naming format: aws/ssm/SystemsManagerDocumentName | `string` | `""` | no |
| cloudwatch\_output\_enabled | (Optional) "Default : "true" .Required when task\_type is "RUN\_COMMAND" Enables Systems Manager to send command output to CloudWatch Logs. | `bool` | `true` | no |
| comment | (Optional) "Default : "" .Required when task\_type is "RUN\_COMMAND" .Information about the command(s) to execute. | `string` | `""` | no |
| create\_maintenance\_window | (Optional) "Default : "yes" .Create ssm maintenance window yes or no | `string` | `"yes"` | no |
| create\_maintenance\_window\_target | (Optional) "Default : "yes" .Create ssm maintenance window target yes or no | `string` | `"yes"` | no |
| create\_maintenance\_window\_task | (Optional) "Default : "yes" .Create ssm maintenance window task yes or no | `string` | `"yes"` | no |
| cutoff | (Optional) "Default : 1 .The number of hours before the end of the Maintenance Window that Systems Manager stops scheduling new tasks for execution. | `number` | `1` | no |
| document\_hash | (Optional) "Default : "" .Required when task\_type is "RUN\_COMMAND" .The SHA-256 or SHA-1 hash created by the system when the document was created. SHA-1 hashes have been deprecated. | `string` | `""` | no |
| document\_hash\_type | (Optional) "Default : "" .Required when task\_type is "RUN\_COMMAND" .SHA-256 or SHA-1. SHA-1 hashes have been deprecated. Valid values: Sha256 and Sha1 | `string` | `""` | no |
| document\_version | (Optional) "Default : "$LATEST" .The version of an Automation document to use during task execution. | `string` | `"$LATEST"` | no |
| duration | (Optional) "Default : 3 .The duration of the Maintenance Window in hours. | `number` | `3` | no |
| enabled | (Optional) "Default : true .Whether the maintenance window is enabled. | `bool` | `true` | no |
| end\_date | (Optional) "Default : "" .Timestamp in ISO-8601 extended format when to no longer run the maintenance window. | `string` | `""` | no |
| lambda\_parameters\_client\_context | (Optional) "Default : "" .Required when task\_type is "LAMBDA" .Pass client-specific information to the Lambda function that you are invoking. | `string` | `""` | no |
| lambda\_parameters\_payload | (Optional) "Default : "" . Required when task\_type is "LAMBDA" .JSON to provide to your Lambda function as input. | `string` | `""` | no |
| lambda\_parameters\_qualifier | (Optional) "Default : "" .Required when task\_type is "LAMBDA" .Specify a Lambda function version or alias name. | `string` | `""` | no |
| maintenance\_window\_target\_key | (Optional) "Default : "tag:Name" .Required when create\_maintenance\_window\_target and create\_maintenance\_window are "yes".targets using instance IDs, resource group names, or tags(e.g; tag:Name or resource-groups:ResourceTypeFilters) | `string` | `"tag:Name"` | no |
| maintenance\_window\_target\_values | (Required) Required when create\_maintenance\_window\_target and create\_maintenance\_window are "yes" .targets using instance IDs, resource group names, or tags(e.g; ["acceptance\_test"] or ["AWS::EC2::Instance"]) | `list(any)` | n/a | yes |
| maintenance\_window\_task\_description | (Optional) "Default : "test" .The description of the maintenance window task. | `string` | `"test"` | no |
| maintenance\_window\_task\_name | (Optional) "The name of the maintenance window task. | `string` | n/a | yes |
| maintenance\_window\_task\_targets\_key | (Optional) "Default : "WindowTargetIds" .Instances are specified using Key=InstanceIds or Window target ids are specified using Key=WindowTargetIds | `string` | `"WindowTargetIds"` | no |
| maintenance\_window\_task\_targets\_values | (Optional) "Default : [] .Required when maintenance\_window\_task\_targets\_key is "InstanceIds" and create\_maintenance\_window\_target is "no" .Instances are specified using Values=instanceid1,instanceid2 or Window target ids are specified using Values=window target id1, window target id2. | `list(any)` | `[]` | no |
| max\_concurrency | (Optional) "Default : "2" .The maximum number of targets this task can be run for in parallel. | `string` | `"2"` | no |
| max\_errors | (Optional) "Default : "2" .The maximum number of errors allowed before this task stops being scheduled. | `string` | `"2"` | no |
| notification\_arn | (Optional) "Default : "" .Required when task\_type is "RUN\_COMMAND". An Amazon Resource Name (ARN) for a Simple Notification Service (SNS) topic. Run Command pushes notifications about command status changes to this topic. | `string` | `""` | no |
| notification\_events | (Optional) "Default : "[]" .Required when task\_type is "RUN\_COMMAND". The different events for which you can receive notifications. Valid values: All, InProgress, Success, TimedOut, Cancelled, and Failed | `list(any)` | `[]` | no |
| notification\_type | (Optional) "Default : "" .Required when task\_type is "RUN\_COMMAND" .When specified with Command, receive notification when the status of a command changes. When specified with Invocation, for commands sent to multiple instances, receive notification on a per-instance basis when the status of a command changes. Valid values: Command and Invocation | `string` | `""` | no |
| number\_of\_maintenance\_window\_targets | (Optional) "Default : 1 .Required when create\_maintenance\_window\_target and create\_maintenance\_window are "yes".count for creating number of SSM maintenance windows targets | `number` | `1` | no |
| output\_s3\_bucket | (Optional) "Default : "" .Required when task\_type is "RUN\_COMMAND" .The name of the Amazon S3 bucket. | `string` | `""` | no |
| output\_s3\_key\_prefix | (Optional) "Default : "" .Required when task\_type is "RUN\_COMMAND" .The Amazon S3 bucket subfolder. | `string` | `""` | no |
| owner\_information | (Optional) "Default : "2" .Required when create\_maintenance\_window\_target and create\_maintenance\_window are "yes".User-provided value that will be included in any CloudWatch events raised while running tasks for these targets in this Maintenance Window. | `string` | `"2"` | no |
| priority | (Optional) "Default : 1 .The priority of the task in the Maintenance Window, the lower the number the higher the priority. Tasks in a Maintenance Window are scheduled in priority order with tasks that have the same priority scheduled in parallel. | `number` | `1` | no |
| resource\_type | (Optional) "Default : "INSTANCE" .Required when create\_maintenance\_window\_target and create\_maintenance\_window are "yes" .The type of target being registered with the Maintenance Window. Possible values are INSTANCE and RESOURCE\_GROUP. | `string` | `"INSTANCE"` | no |
| run\_command\_parameters\_name | (Optional) "Default : "" .Required when task\_type is "RUN\_COMMAND" .The parameter name. | `string` | `""` | no |
| run\_command\_parameters\_service\_role\_arn | (Optional) "Default : "" .Required when task\_type is "RUN\_COMMAND" .The IAM service role to assume during task execution. | `string` | `""` | no |
| run\_command\_parameters\_values | (Optional) "Default : "[]" .Required when task\_type is "RUN\_COMMAND" .The array of strings. | `list(any)` | `[]` | no |
| schedule | (Required) The schedule of the Maintenance Window in the form of a cron or rate expression. | `string` | n/a | yes |
| schedule\_offset | (Optional) "Default : 1 .Requried when schedule is "" .The number of days to wait after the date and time specified by a CRON expression before running the maintenance window. | `number` | `1` | no |
| schedule\_timezone | (Optional) "Default : "" .Timezone for schedule in Internet Assigned Numbers Authority (IANA) Time Zone Database format. For example: America/Los\_Angeles, etc/UTC, or Asia/Seoul. | `string` | `""` | no |
| service\_role\_arn | (Required) The role that should be assumed when executing the task. If a role is not provided, Systems Manager uses your account's service-linked role. If no service-linked role for Systems Manager exists in your account, it is created for you. | `string` | n/a | yes |
| ssm\_maintenance\_window\_description | (Optional) "Default : "test" .A description for the maintenance window. | `string` | `"test"` | no |
| ssm\_maintenance\_window\_name | (Required) The name of the maintenance window. | `string` | n/a | yes |
| ssm\_maintenance\_window\_target\_description | (Optional) "Default : "test" .Required when create\_maintenance\_window\_target and create\_maintenance\_window are "yes".The description of the maintenance window target. | `string` | `"test"` | no |
| ssm\_maintenance\_window\_target\_name | (Required) Required when create\_maintenance\_window\_target and create\_maintenance\_window are "yes" .The name of the maintenance window target. | `string` | n/a | yes |
| start\_date | (Optional) "Default : "" .Timestamp in ISO-8601 extended format when to begin the maintenance window. | `string` | `""` | no |
| step\_functions\_parameters\_input | (Optional) "Default : "" .Required when task\_type is "STEP\_FUNCTIONS" .The inputs for the STEP\_FUNCTION task. | `string` | `""` | no |
| step\_functions\_parameters\_name | (Optional) "Default : "" .Required when task\_type is "STEP\_FUNCTIONS" .The name of the STEP\_FUNCTION task. | `string` | `""` | no |
| tags | (Required) A mapping of tags to assign to all resources. | `map(string)` | n/a | yes |
| task\_arn | (Required) The ARN of the task to execute. | `string` | n/a | yes |
| task\_type | (Optional) "Default : "AUTOMATION" .The type of task being registered. Valid values: AUTOMATION, LAMBDA, RUN\_COMMAND or STEP\_FUNCTIONS. | `string` | `"AUTOMATION"` | no |
| timeout\_seconds | (Optional) "Default : "360" .Required when task\_type is "RUN\_COMMAND" .If this time is reached and the command has not already started executing, it doesn't run. | `number` | `360` | no |

## Outputs

| Name | Description |
|------|-------------|
| ssm\_maintenance\_window\_id | The ID of the maintenance window. |
| ssm\_maintenance\_window\_target\_id | The ID of the maintenance window target. |
| ssm\_maintenance\_window\_task\_id | The ID of the maintenance window task. |

## Testing

* Created SSM Maintenance window with schedule time using corn expression
* Created SSM Maintenance target with resource_type "INSTANCE" using same module.
* Created SSM Maintenance task with task_type "AUTOMATION" and task_arn "AWS-TerminateEC2Instance".
* Attached EC2 instance to automation task parameters.
* Given schedule time the maintenance window is triggered and Terminated the attached EC2 Instance.
* Able to see the Histroy logs in Maintenance Window AWS console

## Note

* Attached Instance in Maintenance target and Maintenance task should not be same.