# Anthem AWS APIGateway Rest API Module

This module provides an API Gateway VPC Link.

## HIPAA eligibility status

1. Amazon API Gateway is eligible

## Security Guardrail reference

https://confluence.anthem.com/pages/viewpageattachments.action?pageId=299009562&sortBy=date&startIndex=60&preview=/299009562/370573552/Anthem%20AWS%20Security%20Patterns%20-%20API%20Gateway.docx

## Pre-Requisites

1. The name to identify the VPC link.
2. Network load balancer target arn is required.

## Important Note

1. To create a VPCLink Network loadbalancer target arn is required.
2. Need to enable VPC Links to create private integrations that connect your HTTP API routes to private resources in a VPC.


## Mandatory Tags Note:
*	As per redesigned new mandatory tags, mandatory tags along with any additional tags have to be added through template configuration within the modules as below
*	Have a reference of mandatory tags module within the template configuration as shown in example script below.
```bash
# Mandatory Tag Workspace Variables
  variable "apm-id" {}
  variable "application-name" {}
  variable "app-support-dl" {}
  variable "app-servicenow-group" {}
  variable "business-division" {}
  variable "company" {}
  variable "compliance" {}
  variable "costcenter" {}
  variable "environment" {}
  variable "PatchGroup" {}
  variable "PatchWindow" {}
  variable "ATLAS_WORKSPACE_NAME" {}

# Mandatory Tags Module 
module "mandatory_tags" {
  source               = "cps-terraform.anthem.com/<ORG_NAME>/terraform-aws-mandatory-tags-v2/aws"
  tags                 = {}
  apm-id               = var.apm-id
  application-name     = var.application-name
  app-support-dl       = var.app-support-dl
  app-servicenow-group = var.app-servicenow-group
  business-division    = var.business-division
  compliance           = var.compliance
  company              = var.company
  costcenter           = var.costcenter
  environment          = var.environment
  PatchGroup           = var.PatchGroup
  PatchWindow          = var.PatchWindow
  workspace            = var.ATLAS_WORKSPACE_NAME
}
```
*	Mandatory tags module should be referred in tags attribute as below:
  tags = module.mandatory_tags.tags
*	Any additional tags can be merged to tags attribute as below:
  tags = merge(module.mandatory_tags.tags, {"sample" = "abc"})

## Usage
To run this example you need to execute:

```bash

Sample Script to create VPCLink

module "api_vpc_link" {
  source = "cps-terraform.anthem.com/CORP/terraform-aws-api-vpclink/aws"

  #Mandatory Tags
  tags = module.mandatory_tags.tags
  
  #Parameters
  vpc_link_name        = ""
  vpc_link_description = ""
  target_arns          = [module.lb.arn]

}

#Initialize Terraform
terraform init

#Terraform Dry-Run
terraform plan

#Create the resources
terraform apply

#Destroy the resources saved in the tfstate
terraform destroy
```
## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| create\_apigateway\_vpclink | (Optional) A boolean that indicates whether to create API Gateway vpclink or not. Default is true | `bool` | `true` | no |
| tags | (Required) Map of tags assigned to the resource, including those inherited from the provider default\_tags | `map(string)` | `{}` | yes |
| target\_arns | (Required, ForceNew) List of network load balancer arns in the VPC targeted by the VPC link. Currently AWS only supports 1 target. | `list(any)` | n/a | yes |
| vpc\_link\_description | (Optional) Description of the VPC link. | `string` | n/a | yes |
| vpc\_link\_name | (Required) Name used to label and identify the VPC link. | `string` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| id | The identifier of the VpcLink. |

## Testing

1. Able to create a VPC link.