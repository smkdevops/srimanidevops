## AWS Calico Add On Module

Project Calico is a network policy engine for Kubernetes. With Calico network policy enforcement, you can implement network segmentation and tenant isolation. This is useful in multi-tenant environments where you must isolate tenants from each other or when you want to create separate environments for development, staging, and production. Network policies are similar to AWS security groups in that you can create network ingress and egress rules. Instead of assigning instances to a security group, you assign network policies to pods using pod selectors and labels.
 

## Security Guardrail reference

N/A

## Pre-Requisites

1. Should have EKS cluster up and running.
2. Include Kuberenetes provier for your EKS cluster as shown below:

```bash
data "aws_eks_cluster" "cluster" {
  name = module.eks_cluster.cluster_id
}

data "aws_eks_cluster_auth" "cluster" {
  name = module.eks_cluster.cluster_id
}

provider "kubernetes" {
  #  load_config_file       = false
  host                   = data.aws_eks_cluster.cluster.endpoint
  cluster_ca_certificate = base64decode(data.aws_eks_cluster.cluster.certificate_authority.0.data)
  token                  = data.aws_eks_cluster_auth.cluster.token
}
```
3. Include helm provide for your EKS cluster as shown below:
```bash
provider "helm" { 
 kubernetes {  
  host                   = data.aws_eks_cluster.cluster.endpoint
  cluster_ca_certificate = base64decode(data.aws_eks_cluster.cluster.certificate_authority.0.data)
  token                  = data.aws_eks_cluster_auth.cluster.token
}
}
```

## Usage

Include below module code to deploy Calico Add On into EKS cluster:

```bash
module "terraform_eks_calico_addon" {
  source  = "cps-terraform.anthem.com/<ORGANIZATION NAME>/terraform-aws-eks-calico-addon/aws"
  version = "0.0.5"
}


#Initialize Terraform
terraform init

#Terraform Dry-Run
terraform plan

#Create the resources
terraform apply

#Destroy the resources saved in the tfstate
terraform destroy
```

## Verify Installation


1. Create EKS Cluster.
2. Deploy Calico Add On plugin using reference module code provided above in earlier section.
3. Run below commands to verify Calico resouces deployed without any errors:
```bash
kubectl get ns

NAME               STATUS   AGE
calico-apiserver   Active   127m
calico-system      Active   127m
tigera-operator    Active   127m
```
- Verify resouces deployed on namespace calico-apiserver are successful without any errors:

```bash
kubectl get all -n calico-apiserver

NAME                                    READY   STATUS    RESTARTS   AGE
pod/calico-apiserver-6db5bcc6bf-8xwvc   1/1     Running   0          129m
pod/calico-apiserver-6db5bcc6bf-9mbww   1/1     Running   0          129m

NAME                 TYPE        CLUSTER-IP      EXTERNAL-IP   PORT(S)   AGE
service/calico-api   ClusterIP   172.20.66.119   <none>        443/TCP   129m

NAME                               READY   UP-TO-DATE   AVAILABLE   AGE
deployment.apps/calico-apiserver   2/2     2            2           129m

NAME                                          DESIRED   CURRENT   READY   AGE
replicaset.apps/calico-apiserver-6db5bcc6bf   2         2         2       129m
```
- Verify resouces deployed on namespace calico-system are successful without any errors:

```bash
kubectl get all -n calico-system

NAME                                           READY   STATUS    RESTARTS   AGE
pod/calico-kube-controllers-55b67d5544-qsf2w   1/1     Running   0          15h
pod/calico-node-7mz6x                          1/1     Running   0          15h
pod/calico-node-ggmwm                          1/1     Running   0          15h
pod/calico-typha-78ff498ff-9m24h               1/1     Running   0          15h

NAME                                      TYPE        CLUSTER-IP       EXTERNAL-IP   PORT(S)    AGE
service/calico-kube-controllers-metrics   ClusterIP   172.20.212.126   <none>        9094/TCP   15h
service/calico-typha                      ClusterIP   172.20.119.64    <none>        5473/TCP   15h

NAME                                    DESIRED   CURRENT   READY   UP-TO-DATE   AVAILABLE   NODE SELECTOR              AGE
daemonset.apps/calico-node              2         2         2       2            2           kubernetes.io/os=linux     15h
daemonset.apps/calico-windows-upgrade   0         0         0       0            0           kubernetes.io/os=windows   15h

NAME                                      READY   UP-TO-DATE   AVAILABLE   AGE
deployment.apps/calico-kube-controllers   1/1     1            1           15h
deployment.apps/calico-typha              1/1     1            1           15h

NAME                                                 DESIRED   CURRENT   READY   AGE
replicaset.apps/calico-kube-controllers-55b67d5544   1         1         1       15h
replicaset.apps/calico-typha-78ff498ff               1         1         1       15h

```

- Verify resouces deployed on namespace tigera-operator are successful without any errors:

```bash

kubectl get all -n tigera-operator

NAME                                   READY   STATUS    RESTARTS   AGE
pod/tigera-operator-7988989b89-glb9n   1/1     Running   0          15h

NAME                              READY   UP-TO-DATE   AVAILABLE   AGE
deployment.apps/tigera-operator   1/1     1            1           15h

NAME                                         DESIRED   CURRENT   READY   AGE
replicaset.apps/tigera-operator-7988989b89   1         1         1       15h

```