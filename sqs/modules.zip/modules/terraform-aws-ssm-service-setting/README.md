# Anthem AWS SSM service setting

This setting defines how a user interacts with or uses a service or a feature of a service.

## HIPPA eligibility status

1. AWS Systems Manager service is eligible.

## Security Guardrail reference

https://confluence.anthem.com/pages/viewpageattachments.action?pageId=299009562&preview=/299009562/516937786/Anthem%20AWS%20Security%20Patterns%20-%20Systems%20Manager.docx

## Pre-requisite

* Reference - https://docs.aws.amazon.com/systems-manager/latest/userguide/parameter-store-throughput.html#parameter-store-throughput-permissions
https://docs.aws.amazon.com/systems-manager/latest/APIReference/API_ResetServiceSetting.html

* SettingId
The Amazon Resource Name (ARN) of the service setting to reset. The setting ID can be one of the following.
  /ssm/automation/customer-script-log-destination
  /ssm/automation/customer-script-log-group-name
  /ssm/documents/console/public-sharing-permission
  /ssm/managed-instance/activation-tier
  /ssm/opsinsights/opscenter
  /ssm/parameter-store/default-parameter-tier
  /ssm/parameter-store/high-throughput-enabled

## Usage

To run this example you need to execute:

```bash
#Example script
module "terraform-aws-ssm-service-setting" {
  source  = "cps-terraform-dev.anthem.com/CORP/terraform-aws-ssm-service-setting/aws"
 
  setting_id    = "arn:aws:ssm:<region>:<accountid>:servicesetting/ssm/automation/customer-script-log-group-name"
  setting_value = true
}

#Initialize Terraform
terraform init

#Terraform Dry-Run
terraform plan

#Create the resources
terraform apply

#Destroy the resources saved in the tfstate
terraform destroy
```
## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| setting\_id | (Required) ID of the service setting. | `string` | n/a | yes |
| setting\_value | (Required) Value of the service setting. | `bool` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| arn | ARN of the service setting. |
| status | Status of the service setting. Value can be Default, Customized or PendingUpdate. |

## Testing

* This setting defines how a user interacts with or uses a service or a feature of a service. we can just see the setup value in terraform output.