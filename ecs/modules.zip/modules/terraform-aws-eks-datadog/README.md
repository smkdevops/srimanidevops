## Terraform module to deploy Datadog Monitoring in EKS Cluster

 This module will help to deploy Datadog agent into existing Kubernetes cluster. This will allow DevOps engineers to get insight view of Kuberenetes cluster, nodes, containers and other resouces into Datadog console. 
 
 Reference: https://confluence.anthem.com/display/ENTCLOUD/How+to+setup+Datadog+Monitoring+for+EKS

 
## Pre-Requisites

1. Should have EKS cluster up and running.
2. Include Kuberenetes provier for your EKS cluster as shown below:

```bash
data "aws_eks_cluster" "cluster" {
  name = module.eks_cluster.cluster_id
}

data "aws_eks_cluster_auth" "cluster" {
  name = module.eks_cluster.cluster_id
}

provider "kubernetes" {
  #  load_config_file       = false
  host                   = data.aws_eks_cluster.cluster.endpoint
  cluster_ca_certificate = base64decode(data.aws_eks_cluster.cluster.certificate_authority.0.data)
  token                  = data.aws_eks_cluster_auth.cluster.token
}
```

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| cluster_name | Name of existing EKS Cluster | String | - | yes |
| datadog_apikey | Datadog API Key | String | - | yes |
| datadog_apikey | Datadog App Key | String | - | yes |


## Usage

Include below module code to deploy Datadog agent into EKS cluster:

```bash

module "shared_eks_datadog" {
  depends_on = [module.eks_cluster, module.shared-eks-managed-node-group]
  source     = "cps-terraform-dev.anthem.com/CORP/terraform-aws-eks-datadog/aws"

  cluster_name   = var.cluster_name
  datadog_appkey = var.datadog_appkey
  datadog_apikey = var.datadog_apikey

}

terraform init
terraform plan
terraform apply --auto-approve

```

## Validation

Run below command to verify the installation. Make sure all resources got deployed successfully without any error.

```bash
kubectl get all -n datadog

```

## Datadog Web Console

Console URL: https://app.datadoghq.com/containers?query=kube_cluster_name%3A--YOUR-CLUSTER-NAME

(Enter Anthem Username & Password for Sign-In)