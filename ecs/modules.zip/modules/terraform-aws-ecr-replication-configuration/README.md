## Anthem ECR Replication Configuration Terraform Module

This module creates an ECR Replication Configuration using Terraform

## HIPAA eligibility status

1. Amazon Elastic Container Registry (ECR)


## Security Guardrail reference

[AWS Security Pattern](https://confluence.anthem.com/download/attachments/299009562/Anthem%20AWS%20Security%20Patterns%20-%20ECR%20-%20v1.docx?api=v2)

## Pre-Requisite
1. A maximum of 25 destinations are allowed per rule.
2. Existing images cannot be replicated automatically.they need re-push again.
3. New iamges can be pushed automatically to destination regions or accounts.
4. For replication,the destination regions and accounts also should have the same repository name that source repository have.for example., if we have ABC repository in source account then the destination region or account should have ABC repository name.
5. If user wants to create replication configuration with repository_filter option then destination repository should also have repository filter.
6. For cross account replication, user needs to have registry policy  in destination account as below: 
Use terraform-aws-registry-policy module for this.
```bash
  {
    "Version": "2012-10-17",
    "Id": "",
    "Statement": [
        {
            "Effect": "Allow",
            "Principal": {
                "AWS": "arn:aws:iam::<source_account_id>:root"
            },
            "Resource": "arn:aws:ecr:<region-name>:<destination_account_id>:repository/*",
            "Action": [
                "ecr:ReplicateImage",
                "ecr:CreateRepository"
            ]
        }
    ]
}
```
## Usage
To run this example you need to execute:

```bash

# Example Script

module "ecrexample" {


source = "cps-terraform.anthem.com/<ORGANIZATION NAME>/terraform-aws-ecr-replication-configuration/aws"

  destination = [{
      region      = <region-name>
      registry_id = <account-id>
  }]

#repository_filter = [{
#       filter      = "prod-microservice"
#      filter_type = "PREFIX_MATCH"
#   }]
  
}


#Initialize Terraform
terraform init

#Terraform Dry-Run
terraform plan

#Create the resources
terraform apply

#Destroy the resources saved in the tfstate
terraform destroy
```
## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| destination | the details of a replication destination. A maximum of 25 are allowed per rule. | `any` | n/a | yes |
| repository\_filter | filters for a replication rule. | `any` | `[]` | no |

## Outputs

| Name | Description |
|------|-------------|
| registry\_id | The registry ID where the replication configuration was created. |

## Testing 

1. Able to create replication configiration successfully.
2. Need to create repository with same name in destination region.
3. Created a sample image for repository using push commands(user can  view this commands in repository,view push commands session)
  * aws ecr get-login-password --region region-name | docker login --username AWS --password-stdin account-id.dkr.ecr.region-name.amazonaws.com
  * For testing purpose pulled nginx image   [docker pull nginx:latest]
  * Tag the image [docker tag <name of image.i.e; nginx>:latest account-id.dkr.ecr.region-name.amazonaws.com/ecr-reponame:latest]
  * Push the image [docker push account-id.dkr.ecr.region-name.amazonaws.com/ecr-reponame:latest]
4. Once we push the image we will be able to see the image in destination regions and destination accounts.
