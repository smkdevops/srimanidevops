# Anthem AWS EC2

This module creates one or more EC2 instances capacity reservation

## Pre-Requisite

* Conditional resource creation is enabled with "create_ec2_capacity_reservation" variable, setting this variable to "true" will create the resource and setting this to "false" will skip the resource creation.
* Availability zone ,instance type ,instance platform ,enddate and enddate type parameters are mandatory.
* End date should be in the valid RFC3339 time string format i.e(YYYY-MM-DDTHH:MM:SSZ).

## Mandatory Tags Note:

*	As per redesigned new mandatory tags, mandatory tags along with any application specific additional tags have to be added through template configuration within the modules as below.
*	Have a reference of mandatory tags modules within the template configuration as shown in example script below.
```bash
# Mandatory Tag Workspace Variables
variable "apm-id" {}
variable "application-name" {}
variable "app-support-dl" {}
variable "app-servicenow-group" {}
variable "business-division" {}
variable "company" {}
variable "compliance" {}
variable "costcenter" {}
variable "environment" {}
variable "PatchGroup" {}
variable "PatchWindow" {}
variable "ATLAS_WORKSPACE_NAME" {}

# Mandatory Tags Module 
module "mandatory_tags" {
  source               = "cps-terraform.anthem.com/<ORG_NAME>/terraform-aws-mandatory-tags-v2/aws"
  tags                 = {}
  apm-id               = var.apm-id
  application-name     = var.application-name
  app-support-dl       = var.app-support-dl
  app-servicenow-group = var.app-servicenow-group
  business-division    = var.business-division
  compliance           = var.compliance
  company              = var.company
  costcenter           = var.costcenter
  environment          = var.environment
  PatchGroup           = var.PatchGroup
  PatchWindow          = var.PatchWindow
  workspace            = var.ATLAS_WORKSPACE_NAME
}
```
*	Mandatory and mandatory data tags modules should be merged in tags attribute as below:
tags = merge(module.mandatory_tags.tags)
*	Any additional tags can be merged to tags attribute as below:
tags = merge(module.mandatory_tags.tags, {"sample" = "abc"})

## Usage

To run this example you need to execute:

```bash
#Example script

module "ec2instance" {
  source = "cps-terraform.anthem.com/<ORGANIZATION NAME>/terraform-aws-capacity-reservation/aws"
  
  /******** Parameter required for resource creation ******/
 
  instance_type                        = ""
  instance_platform                    = ""
  end_date_type                        = ""
  availability_zone                    = ""
  tags                                 = merge(module.mandatory_tags.tags)

  /******** Optional Parameters *******/

  end_date                             = "" 
  instance_count                       = ""
  ebs_optimized                        = ""
  tenancy                              = ""
  instance_match_criteria              = ""                          
  ephemeral_storage                    = ""
  outpost_arn                          = ""
}

#Initialize Terraform
terraform init

#Terraform Dry-Run
terraform plan

#Create the resources
terraform apply

#Destroy the resources saved in the tfstate
terraform destroy
```
## Providers

| Name | Version |
|------|---------|
| aws | n/a |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| availability\_zone | (Required) The Availability Zone in which you want to create the Capacity Reservation. | `string` | n/a | yes |
| create\_ec2\_capacity\_reservation | (Optional) "Default : true". Need to create a new capacity reservation Ec2 instance True or False | `bool` | `true` | no |
| ebs\_optimized | (Optional) "Default : false". Supports Ebs Optimized instance for  the Capacity Reservation. | `bool` | `false` | no |
| end\_date | (Required) The date and time at which the Capacity Reservation expires.Valid values:RFC3339 time string (YYYY-MM-DDTHH:MM:SSZ) | `any` | n/a | yes |
| end\_date\_type | (Optional) "Default : "limited" ". Indicates the way in which the Capacity Reservation ends | `string` | `"limited"` | no |
| ephemeral\_storage | (Optional) "Default : false". Indicates whether the Capacity Reservation supports instances with temporary, block-level storage. | `bool` | `false` | no |
| instance\_count | (Optional) "Default : 1". Number of instance count Needs to be created | `number` | `1` | no |
| instance\_match\_criteria | (Optional) "Default : "open" ". Indicates the type of instance launches that the Capacity Reservation accepts | `string` | `"open"` | no |
| instance\_platform | (Optional) "Default : "" ". The type of operating system for which to reserve capacity. Valid options(Linux/UNIX, Red Hat Enterprise Linux, SUSE Linux, Windows, Windows with SQL Server, Windows with SQL Server Enterprise, Windows with SQL Server Standard or Windows with SQL Server Web) | `string` | `""` | no |
| instance\_type | (Optional) "Default : "t2.medium" ". The Instance type that Needs to be created for capacity reservation. | `string` | `"t2.medium"` | no |
| outpost\_arn | (Optional) "Default : "" ". The Amazon Resource Name (ARN) of the Outpost on which to create the Capacity Reservation. | `any` | `""` | no |
| tags | (Required) A mapping of tags to assign to all resources. | `map(string)` | n/a | yes |
| tenancy | (Optional) "Default : "default" ". The tenancy of the Capacity Reservation | `string` | `"default"` | no |

## Outputs

| Name | Description |
|------|-------------|
| arn | The ARN of the Capacity Reservation. |
| id | The Capacity Reservation ID. |
| owner\_id | The ID of the AWS account that owns the Capacity Reservation. |
| tags\_all | Tags attatched to the Capacity reservation |

## Unit Testing 

* Created EC2 capacity reservation service.
* Able to see the capacity reservation in AWS console
