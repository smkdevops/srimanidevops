## Terraform module to deploy Splunk connector in EKS Cluster
  This module will help to deploy Splunk connector agent into existing Kubernetes cluster.
 
  Reference: https://confluence.anthem.com/pages/viewpage.action?spaceKey=ENTCLOUD&title=How+to+Setup+Splunk+Connect+for+Kuberentes
 
## Pre-Requisites

1. Should have EKS cluster up and running.
2. Include Kuberenetes provier for your EKS cluster as shown below:

```bash
  data "aws_eks_cluster" "cluster" {
    name = module.eks_cluster.cluster_id
  }

  data "aws_eks_cluster_auth" "cluster" {
    name = module.eks_cluster.cluster_id
  }

  provider "kubernetes" {
    #  load_config_file       = false
    host                   = data.aws_eks_cluster.cluster.endpoint
    cluster_ca_certificate = base64decode(data.aws_eks_cluster.cluster.certificate_authority.0.data)
    token                  = data.aws_eks_cluster_auth.cluster.token
}
```
## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| splunk\_release\_name | Release name | `string` | - | yes |
| splunk\_repository | Repository URL where to locate the requested chart | `string` | - | yes |
| splunk\_chart\_name | Helm chart name | `string` | - | yes |
| splunk\_helm\_version | Specify the exact chart version to install. If this is not specified, the latest version is installed | `string` | - | yes |
| splunk\_namespace | The namespace to install nginx-ingress | `string` | - | yes |
| cluster\_name | Kuberenetes Cluster Name | `string` | - | yes |
| splunk\_host | Hostname of the Splunk | `string` | - | yes |
| splunk\_logs\_index | Index name for logs | `string` | - | yes |
| splunk\_metrics\_index | Index name for metrics | `string` | - | yes |
| splunk\_objects\_index | Index name for objects | `string` | - | yes |
| splunk\_index\_token | HEC token of the indexes | `string` | - | yes |
| splunk\_timeout | Index name for metrics | number | - | yes |
| fluentd\_hec\_image\_tag | splunk HEC image with tag | `string` | - | yes |
| k8s\_metrics\_image\_tag | splunk K8s metrics image tag | `string` | - | yes |
| k8s\_metrics\_aggr\_image\_tag | splunk k8s metrics aggr image with tag | `string` | - | yes |
| kube\_objects\_image\_tag | splunk kube objects image tag | `string` | - | yes |
| quay\_registry | Quay repository url to pull images | `string` | - | yes |

## Usage
  Include below module to deploy Splunk connector into EKS cluster:

```bash

  module "terraform_helm_splunk_connect" {
    source                  = "cps-terraform.anthem.com/ACSCD/terraform-aws-eks-splunk/aws"
    splunk_release_name     = ""
    splunk_repository       = ""
    splunk_chart_name       = ""
    splunk_helm_version     = "1.5.2"
    splunk_namespace        = ""
    cluster_name            = ""
    splunk_logs_index       = ""
    splunk_metrics_index    = ""
    splunk_index_token      = ""
    splunk_host             = ""
    splunk_objects_index    = ""
    fluentd_hec_image_tag      = "1.3.1"
    k8s_metrics_image_tag      = "1.2.1"
    k8s_metrics_aggr_image_tag = "1.2.1"
    kube_objects_image_tag     = "1.2.1"
    quay_registry              = "quay.apps.lz-np2.ent-ocp4-useast1.aws.internal.das/eks-blueprints"
  }

  terraform init
  terraform plan
  terraform apply

```

## Validation

Run below command to verify the installation. Make sure all resources got deployed successfully without any error.

```bash
kubectl get all -n splunk

```

## Splunk Console

Web Console URL: https://splunk.internal.das/en-US/app/search/search

Click on Search input box and enter index="Your-Index-Name". Wait for couple of minutes and verify system is displaying the data ingested so far.