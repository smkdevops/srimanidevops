# Anthem DMS Replication Certificate Base Code

This provides a DMS (Data Migration Service) certificate resource.

## HIPAA eligibility status

1. AWS DMS (Database Migration Service) is eligible.

## Security Guardrail reference

[AWS Security Pattern](https://confluence.elevancehealth.com/download/attachments/299009562/Anthem%20AWS%20Security%20Patterns%20-%20Database%20Migration%20Service.docx?api=v2)


## Prerequisite
1. .pem file with contents of the .pem X.509 certificate.
2. wallet file with contents of the Oracle Wallet certificate for use with SSL.

# Release Notes:
## New Version - 0.0.5
1. With Mandatory Tags Redesign that happened early part of this year, we had to refactor all our templates to include central Mandatory Tag Module and remove variable references from the code.
2. All the new templates has been pushed in and you should be able to see the changes. Below are the highlights. 

### Adoption of the New Version - 0.0.5

1.	There is a new file tags.tf that is now included and integral part of our code base.
2.	We now have only Application Specific Tags in DMS modules of each templates. The entire code is now bit sleek. 
3.	Each module refers to mandatory tags module.

## Usage

To run this example you need to execute:

```bash
#Initialize Terraform
terraform init

#Terraform Dry-Run
terraform plan

#Create the resources
terraform apply

#Destroy the resources saved in the tfstate
terraform destroy
```

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|:----:|:-----:|:-----:|
| certificate\_id | The certificate identifier. | string | n/a | yes |
| certificate\_type | Type of Certificate to create. Valid values are "pem" or "wallet". | string | n/a | yes |
| pem\_certificate\_path | Path to the contents of the .pem X.509 certificate file for the certificate. Either certificate\_pem or certificate\_wallet must be set. | string | n/a | yes |
| wallet\_certificate\_path | Path to the contents of the Oracle Wallet certificate for use with SSL. Either certificate\_pem or certificate\_wallet must be set. | string | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| certificate\_arn | The Amazon Resource Name \(ARN\) for the certificate. |

## Unit Testing
1. Created DMS certificate using .pem certificate as external file.