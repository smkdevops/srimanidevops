# AWS Auto scaling with launch template Terraform Module

This module is to create the auto scaling group with launch template.

## HIPAA eligibility status

1. Amazon Elastic Compute Cloud (Amazon EC2) 
2. Amazon Auto Scaling

## Security Guardrail reference

https://confluence.anthem.com/pages/viewpageattachments.action?pageId=299009562&sortBy=date&startIndex=80&preview=/299009562/357900867/Anthem%20AWS%20Security%20Patterns%20-%20EC2%20AutoScalingGroup_v1.docx


## Pre-Requisite

1. This module will create the Auto scaling group using launch template.
2. Block device mapping is optional. Block volume details need to be provided in the below format if required.

```bash
block_device_mappings  = [{
      device_name  = "/dev/sda1"
      no_device    = ""
      virtual_name = "ephemeral0"
      ebs = {
          delete_on_termination = true
          iops                  = null
          kms_key_id            = ""
          volume_size           = ""
          volume_type           = "gp2"
          snapshot_id           = null
      }
}]
```

3. At-rest encryption is implemented and enforced in the code.
4. KMS key should be valid for service ec2 for EBS encryption.
5. If the snapshot id is provided then kms key arn is not required. Ensure that the snapshot is encrypted with the valid KMS key.
6. CPU Credit specification is optional.
7. Elastic GPU specification is optional.
8. Anthem Approved AMI should be use.
9. Instance market option is optiona. The values need to be provided in the below format.

```bash
instance_market_options = [{
      market_type = null
      spot_options = [{
          block_duration_minutes         = null
          instance_interruption_behavior = null
          max_price                      = null
          spot_instance_type             = null
          valid_until                    = null
        }
      ]
      }
]

```
10. Placement is option. It can be provided in below format.

```bash
placement = [{
      affinity          = null
      availability_zone = null
      group_name        = null
      host_id           = null
      tenancy           = null
    }
]
```

11. User data need to provided in the file.
12. Instance profile is optional. Instance profile name should be provided is required.
13. Monitoring is mandatory so it is enabled by default. No option to disable it.
14. Tags will be propogated to volume and ec2 instance both.
15. life cycle create before destroy is set to true by default.
16. the existing Subnet and security group id should be provided.
17. Min capacity and max capacity is required.
18. If target group arn is provided then the ASG will be attached to ALB target group and the health check type will set to ELB by default.
19. Ensure that the target group should be created for the type Instance.
20. force delete is set to false.
21. metrics granularity is set to 1 minute by default.
22. ASG can be created with mixed instance policy. It should be provided like below.

```bash
mixed_instances_policy = [{
  instances_distribution = null
  override = [{
    instance_type     = "t3.small"
    weighted_capacity = 3
    },
    {
    instance_type     = "t3a.small"
    weighted_capacity = 2
  }]
}]
```

23. To use the Auto scaling group (ASG) with launch template, ASG service link role must have create grant and Encrypt, Decrypt, Describe permissions on KMS key. 
24. Below metrics are by default enabled.

```bash
[
    "GroupMinSize",
    "GroupMaxSize",
    "GroupDesiredCapacity",
    "GroupInServiceInstances",
    "GroupPendingInstances",
    "GroupStandbyInstances",
    "GroupTerminatingInstances",
    "GroupTotalInstances",
  ]
```

25. The only method for us to connect EC2 Windows instance is through SSM.
26. Conditional resource creation is enabled with "create_aws_launch_template" variable, setting this variable to "true" will create the resource and setting this to "false" will skip the resource creation.
27. Conditional resource creation is enabled with "create_aws_autoscaling_group" variable, setting this variable to "true" will create the resource and setting this to "false" will skip the resource creation.
28. In capacity_reservation_specification you can specify either capacity_reservation_preference or capacity_reservation_target.If you specify both it will fail.
29. If user wants to provide vpc_security_group_ids variable then they can pass otherwise it will take by default. vpc_security_group_ids will conflict with security_groups in network interfaces block.so only one of them should decalre.
30. For user_data variable,user can pass value either in file format or jsonencode format.

## Mandatory Tags Note:

*	As per redesigned new mandatory tags,mandatory tags along with any additional tags have to be added through template configuration within the modules as below
*	Have a reference of mandatory tags module within the template configuration as shown in example script below.
```bash
# Mandatory Tag Workspace Variables
variable "apm-id" {}
variable "application-name" {}
variable "app-support-dl" {}
variable "app-servicenow-group" {}
variable "business-division" {}
variable "company" {}
variable "compliance" {}
variable "costcenter" {}
variable "environment" {}
variable "PatchGroup" {}
variable "PatchWindow" {}
variable "ATLAS_WORKSPACE_NAME" {}

# Mandatory Tags Module 
module "mandatory_tags" {
  source               = "cps-terraform.anthem.com/<ORG_NAME>/terraform-aws-mandatory-tags-v2/aws"
  tags                 = {}
  apm-id               = var.apm-id
  application-name     = var.application-name
  app-support-dl       = var.app-support-dl
  app-servicenow-group = var.app-servicenow-group
  business-division    = var.business-division
  compliance           = var.compliance
  company              = var.company
  costcenter           = var.costcenter
  environment          = var.environment
  PatchGroup           = var.PatchGroup
  PatchWindow          = var.PatchWindow
  workspace            = var.ATLAS_WORKSPACE_NAME
}
```
*	Mandatory tags module should be referred in tags attribute as below:
tags = module.mandatory_tags.tags
*	Any additional tags can be merged to tags attribute as below:
tags = merge(module.mandatory_tags.tags, {"sample" = "abc"})


## Usage
To run this example you need to execute:

```bash
#Example Script

module "ec2-asg" {

source  = "cps-terraform.anthem.com/<ORG_NAME>/terraform-aws-ec2-asg/aws"

tags = merge(module.mandatory_tags.tags)

/******** Parameter required for resource creation ******/
image_id   = ""
asg_name = ""
target_group_arns = ""
subnet_ids = [""]
launch_template_name = ""
service_linked_role_arn = ""

/******** Optional Parameters *******/

vpc_security_group_ids =[""]
cooldown_time = ""
health_check_grace_period = ""
enable_loadbalancer = ""
termination_policies = [""]
suspended_processes = []
placement_group = ""
enabled_metrics
wait_for_capacity_timeout = ""
min_elb_capacity = ""
wait_for_elb_capacity = ""
protect_from_scale_in = ""
#user_data   = file("./launch_template_user_data.sh")
# user_data   = jsonencode(
#   {"echo" = "Hello World",
#   "sudo"= "amazon-linux-extras install epel -y"}
# )
launch_template_version = ""
max_size = ""
min_size = ""
ebs_optimized = ""
iam_instance_profile_name = ""
instance_initiated_shutdown_behavior = ""
capacity_reservation_specification = [{
     capacity_reservation_preference = ""
     
  }]
  # capacity_reservation_target = [{
  #     #  capacity_reservation_resource_group_arn  = "" 
  #      capacity_reservation_id = ""
  #    }]
}

module "target-group" {
  source = "cps-terraform.anthem.com/<ORG_NAME>/terraform-aws-target-group/aws"
  
  tags = merge(module.mandatory_tags.tags)

  /******** Parameter required for resource creation ******/
  target_group_name  = ""
  target_type        = "instance"
  port               =  
  vpc_id             = ""
  load_balancer_type = "ALB"
  stickiness_type    = ""

}


#Initialize Terraform
terraform init

#Terraform Dry-Run
terraform plan

#Create the resources
terraform apply

#Destroy the resources saved in the tfstate
terraform destroy
```

## Providers

| Name | Version |
|------|---------|
| aws | n/a |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| asg\_name | (Required) Auto scaling group name | `string` | n/a | yes |
| auto\_recovery | (Optional) "Default : "disabled" ". The automatic recovery behavior of the Instance. | `string` | `"disabled"` | no |
| block\_device\_mappings | (Optional) "Default : []". Specify volumes to attach to the instance besides the volumes specified by the AMI | <pre>list(object({<br>    device_name = string<br>    no_device   = string<br>    virtual_name = string<br>    ebs = object({<br>      delete_on_termination = bool<br>      iops                  = any<br>      kms_key_id            = string<br>      snapshot_id           = string<br>      volume_size           = number<br>      volume_type           = string<br>    })<br>  }))</pre> | `[]` | no |
| capacity\_reservation\_specification | (Optional) "Default : []". Indicates the target Capacity Reservation. | `any` | `[]` | no |
| capacity\_reservation\_target | (Optional) "Default : []". Indicates the target Capacity Reservation. | `any` | `[]` | no |
| cooldown\_time | (Optional) "Default : 180". The amount of time, in seconds, after a scaling activity completes before another scaling activity can start | `number` | `180` | no |
| create\_aws\_autoscaling\_group | (Optional) "Default : true". Need to create a new aws autoscaling group True or False. | `bool` | `true` | no |
| create\_aws\_launch\_template | (Optional) "Default : true". Need to create a new aws launch template True or False. | `bool` | `true` | no |
| credit\_specification | (Optional) "Default : null". Customize the credit specification of the instances | <pre>object({<br>    cpu_credits = string<br>  })</pre> | `null` | no |
| disable\_api\_termination | (Optional) "Default : false". If true, enables EC2 Instance Termination Protection | `bool` | `false` | no |
| ebs\_optimized | (Optional) "Default : true". If true, the launched EC2 instance will be EBS-optimized. | `bool` | `true` | no |
| elastic\_gpu\_specifications | (Optional) "Default : null". Specifications of Elastic GPU to attach to the instances | <pre>object({<br>    type = string<br>  })</pre> | `null` | no |
| enable\_loadbalancer | (Optional) "Default : "yes" ". Whether to enable load balancer or not. Valid values are yes or no. | `string` | `"yes"` | no |
| enabled\_metrics | (Optional) "Default : ["GroupMinSize","GroupMaxSize","GroupDesiredCapacity","GroupInServiceInstances","GroupPendingInstances","GroupStandbyInstances","GroupTerminatingInstances","GroupTotalInstances"]". A list of metrics to collect. The allowed values are GroupMinSize, GroupMaxSize, GroupDesiredCapacity, GroupInServiceInstances, GroupPendingInstances, GroupStandbyInstances, GroupTerminatingInstances, GroupTotalInstances | `list(string)` | <pre>[<br>  "GroupMinSize",<br>  "GroupMaxSize",<br>  "GroupDesiredCapacity",<br>  "GroupInServiceInstances",<br>  "GroupPendingInstances",<br>  "GroupStandbyInstances",<br>  "GroupTerminatingInstances",<br>  "GroupTotalInstances"<br>]</pre> | no |
| enclave\_enabled | (Optional) "Default : false". Enable Nitro Enclaves on launched instances. | `bool` | `false` | no |
| health\_check\_grace\_period | (Optional) "Default : 300". Time (in seconds) after instance comes into service before checking health | `number` | `300` | no |
| iam\_instance\_profile\_name | (Optional) "Default : null". The IAM instance profile name to associate with launched instances. | `string` | `null` | no |
| image\_id | (Required) The EC2 image ID to launch | `string` | n/a | yes |
| instance\_initiated\_shutdown\_behavior | (Optional) "Default : null". Shutdown behavior for the instances. Can be stop or terminate. | `string` | `null` | no |
| instance\_market\_options | (Optional) "Default : null". The market (purchasing) option for the instances | <pre>object({<br>    market_type = string<br>    spot_options = object({<br>      block_duration_minutes         = number<br>      instance_interruption_behavior = string<br>      max_price                      = number<br>      spot_instance_type             = string<br>      valid_until                    = string<br>    })<br>  })</pre> | `null` | no |
| instance\_type | (Optional) "Default : "t3.micro" ". Instance type to launch | `string` | `"t3.micro"` | no |
| key\_name | (Optional) "Default : null". The SSH key name that should be used for the instance. | `string` | `null` | no |
| launch\_template\_name | (Optional) "Default : null". Launch template name. | `string` | `null` | no |
| launch\_template\_version | (Optional) "Default : "$Latest" ". Launch template version. Can be version number, $Latest or $Default. | `string` | `"$Latest"` | no |
| max\_size | (Optional) "Default : "1" ". The maximum size of the autoscale group | `number` | `"1"` | no |
| min\_elb\_capacity | (Optional) "Default : 0". Setting this causes Terraform to wait for this number of instances to show up healthy in the ELB only on creation. Updates will not wait on ELB instance number changes. | `number` | `0` | no |
| min\_size | (Optional) "Default : "1" ". The minimum size of the autoscale group | `number` | `"1"` | no |
| mixed\_instances\_policy | (Optional) "Default : null". policy to used mixed group of on demand/spot of differing types. Launch template is automatically generated. | `list` | `null` | no |
| network\_interfaces | (Optional) "Default : []". Customize network interfaces to be attached at instance boot time. | `any` | `[]` | no |
| placement | (Optional) "Default : null". The placement specifications of the instances | <pre>object({<br>    affinity          = string<br>    availability_zone = string<br>    group_name        = string<br>    host_id           = string<br>    tenancy           = string<br>  })</pre> | `null` | no |
| placement\_group | (Optional) "Default : "" ". The name of the placement group into which you will launch your instances, if any | `string` | `""` | no |
| protect\_from\_scale\_in | (Optional) "Default : false". Allows setting instance protection. The autoscaling group will not select instances with this setting for terminination during scale in events. | `bool` | `false` | no |
| service\_linked\_role\_arn | (Optional) "Default : null". The ARN of the service-linked role that the ASG will use to call other AWS services. If do not provide then internally it will take the default autoscaling service link role AWSServiceRoleForAutoScaling. | `string` | `null` | no |
| subnet\_ids | (Required) A list of subnet IDs to launch resources in | `list(string)` | n/a | yes |
| suspended\_processes | (Optional) "Default : []". A list of processes to suspend for the AutoScaling Group. The allowed values are Launch, Terminate, HealthCheck, ReplaceUnhealthy, AZRebalance, AlarmNotification, ScheduledActions, AddToLoadBalancer. Note that if you suspend either the Launch or Terminate process types, it can prevent your autoscaling group from functioning properly. | `list(string)` | `[]` | no |
| tags | (Required) A mapping of tags to assign to all resources. | `map(string)` | n/a | yes |
| target\_group\_arns | (Required) A list of aws\_alb\_target\_group ARNs, for use with Application Load Balancing | `list(string)` | n/a | yes |
| termination\_policies | (Optional) "Default : ["Default"] ". A list of policies to decide how the instances in the auto scale group should be terminated. The allowed values are OldestInstance, NewestInstance, OldestLaunchConfiguration, ClosestToNextInstanceHour, Default. | `list(string)` | <pre>[<br>  "Default"<br>]</pre> | no |
| user\_data | (Optional) "Default : "" ". The Base64-encoded user data to provide when launching the instances | `string` | `""` | no |
| vpc\_security\_group\_ids | (Optional) "Default : null". A list of associated security group IDs | `list(string)` | `null` | no |
| wait\_for\_capacity\_timeout | (Optional) "Default : "10m" ". A maximum duration that Terraform should wait for ASG instances to be healthy before timing out. Setting this to 0 causes Terraform to skip all Capacity Waiting behavior. | `string` | `"10m"` | no |
| wait\_for\_elb\_capacity | (Optional) "Default : 0". Setting this will cause Terraform to wait for exactly this number of healthy instances in all attached load balancers on both create and update operations. Takes precedence over min\_elb\_capacity behavior. | `number` | `0` | no |

## Outputs

| Name | Description |
|------|-------------|
| arn | The ARN for this AutoScaling Group |
| availability\_zones | The availability zones of the autoscale group. |
| default\_cooldown | Time between a scaling activity and the succeeding scaling activity. |
| desired\_capacity | The number of Amazon EC2 instances that should be running in the group. |
| health\_check\_grace\_period | Time after instance comes into service before checking health. |
| health\_check\_type | EC2 or ELB. Controls how health checking is done. |
| id | n/a |
| latest\_version | The latest version of the launch template. |
| launch\_configuration | The launch configuration of the autoscale group |
| launch\_template\_arn | Amazon Resource Name (ARN) of the launch template. |
| launch\_template\_id | The ID of the launch template. |
| load\_balancers | The load balancer names associated with the autoscaling group. |
| max\_size | The maximum size of the autoscale group |
| min\_size | The minimum size of the autoscale group |
| name | The name of the autoscale group |
| target\_group\_arns | list of Target Group ARNs that apply to this AutoScaling Group. |
| vpc\_zone\_identifier | The VPC zone identifier |

## Testing

1. Created ASG with launch template.
2. Observed that the required number of EC2 instances are getting launched.
3. EBS volume attached to EC2 instance is encrypted.
4. Also observed that if mixed instance policy is used then the instances with different instance type is getitng created.

Note :- This module is tested in LZ DEV account by creating the AMI from Anthem approved AMI using the CMK as Auto scaling service link role do not have required permission on the KMS key used in the Anthem approved AMI. 

Windows AMI
1. Created ASG with Launch Template
2. created security groups
3. created Anthem approved IAM role instance profile.
4. Able to launch EC2 instance in ASG and able to access that instance through SSM.