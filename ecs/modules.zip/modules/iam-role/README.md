## Anthem AWS IAM Role & IAM Role Inline policy Module

This module creates AWS IAM Role and can also provide IAM inline policy to this role.

### HIPPA eligibility status

IAM is not storing or proccessing any PHI data. IAM is used to provide the control to other services which stores or process PHI information so IAM is not relavent to be evaluated as per HIPPA guidelines.

### Security Guardrail reference

[Security Guardrail Link](https://confluence.anthem.com/pages/viewpageattachments.action?pageId=299009562&sortBy=date&startIndex=0&preview=/299009562/516559035/Anthem%20AWS%20Security%20Patterns%20-%20Identity%20and%20Access%20Management.docx)


### Pre-requisite


1. The value of the max_session_duration variable in a range of 3600 - 43200 seconds.
2. Assume role policy document for assume_role_policy can be provided as a json file format or this can be automatically created by passing the principals in the assume_role_service_names parameter.
3. Please do note that the permission boundary is mandatory to create roles, attach managed policies and create/update inline policies. otherwise these actions will fail. 
4. Permission boundary antm-IAMPermissionsBoundaryForExecutionRole is hardcoded in the code.
5. Role trust relationship can not be modified once the role is created. If required then request should be sent to Security team.
6. sts:AssumeRole with principal "service" and sts:AssumeRoleWithWebIdentity with principal "Federated" are only allowed in assume role policy.
7. To create customized Assume role policy user must have json file as assume role policy like below:

Assume Role Policy 
```bash
{
    "Version": "2012-10-17",
    "Statement": {
      "Effect": "Allow",
      "Action": "sts:AssumeRole",
      "Principal": { "Service": "ec2.amazonaws.com" }
    }
}
```
For client build script user need to provide the input as:
```bash
assume_role_policy    = file("assume_role_policy.json)
```

8. For creating the IAM role with assume role policy which has the variable then user need to have data block to replace the variable in the client build script and provide the input as below. 

Assume role policy
```bash
{
    "Version": "2012-10-17",
    "Statement": [
      {
        "Effect": "Allow",
        "Principal": {
          "Federated": "arn:aws:iam::544086441256:oidc-provider/${openID_URL}"
        },
        "Action": "sts:AssumeRoleWithWebIdentity",
        "Condition": {
          "StringEquals": {
            "${openID_URL}:sub": "system:serviceaccount:kube-system:cluster-autoscaler"
          }
        }
      }
    ]
  }
```
Data block in the client build script:
```bash
data "template_file" "update-variable" {
  template = file("cluster_assume_role_policy.json")
  vars = {
    openID_URL = module.eks_cluster.openID_URL
  }
}
```
Pass the input like below:
```bash
assume_role_policy = data.template_file.update-variable.rendered
```
9. inline_policy is optional variable. If user wants to add inline_policies at the time of role creation then inlline_policy should be provided in below format.
```bash
  inline_policy = [{
    name = "test-inlinepolicy"
    policy = file("./inlinepolicy.json")
},
{
    name = "test-inlinepolicy1"
    policy = file("./inlinepolicy1.json")
}]
```
or 
```bash
 inline_policy = [{
    name = "test-inlinepolicy"
    policy = jsonencode({
      Version = "2012-10-17"
      Statement = [
        {
          Action   = ["ec2:Describe*"]
          Effect   = "Allow"
          Resource = "*"
        },
      ]
    })
}]
```
10. There is no limit for adding inline_policies in role.
11. managed_policy_arns is optional varaible. If user wants to add managed_policy_arns at the time of role creation then  managed_policy_arns should be provided in below format:
```bash
 managed_policy_arns = [
   "arn:aws:iam::aws:policy/AmazonS3FullAccess","arn:aws:iam::aws:policy/service-role/AWSGlueServiceRole"
]
```
12. There is  a limit of adding 10 managed_policies to role.
13. If user want to remove inline-policies without deleting role then we need to give inline_policy as below:
```bash
 inline_policy = [{
    name = null
    policy = null
}]
```
14. If user wants to remove managed policies without deleting role then we need to give managed_policy-arns as  managed_policy_arns = []
15. If you want to skip the create role , use variable aws_create_iam_role as "false" and by default it will be true.

## Mandatory Tags Note:

*	As per redesigned new mandatory tags, mandatory tags along with any additional tags have to be added through template configuration within the modules as below
*	Have a reference of mandatory tags module within the template configuration as shown in example script below.

```bash

# Mandatory Tag Workspace Variables
variable "apm-id" {}
variable "application-name" {}
variable "app-support-dl" {}
variable "app-servicenow-group" {}
variable "business-division" {}
variable "company" {}
variable "compliance" {}
variable "costcenter" {}
variable "environment" {}
variable "PatchGroup" {}
variable "PatchWindow" {}
variable "ATLAS_WORKSPACE_NAME" {}

# Mandatory Tags Module 
module "mandatory_tags" {
  source               = "cps-terraform.anthem.com/<ORG_NAME>/terraform-aws-mandatory-tags-v2/aws"
  tags                 = {}
  apm-id               = var.apm-id
  application-name     = var.application-name
  app-support-dl       = var.app-support-dl
  app-servicenow-group = var.app-servicenow-group
  business-division    = var.business-division
  compliance           = var.compliance
  company              = var.company
  costcenter           = var.costcenter
  environment          = var.environment
  PatchGroup           = var.PatchGroup
  PatchWindow          = var.PatchWindow
  workspace            = var.ATLAS_WORKSPACE_NAME
}
```
*	Mandatory tags module should be referred in tags attribute as below:
tags = module.mandatory_tags.tags
*	Any additional tags can be merged to tags attribute as below:
tags = merge(module.mandatory_tags.tags, {"sample" = "abc"})


## Usage
To run this example you need to execute:

```bash

#Example Script
module "iam-role" {

  source = "cps-terraform.anthem.com/<ORG_NAME>/terraform-aws-iam-role/aws"

  tags  = module.mandatory_tags.tags
  ################## IAM Role #####################
  iam_role_name             = ""
  role_description          = ""
  assume_role_service_names = ["ec2.amazonaws.com", "s3.amazonaws.com"]
  inline_policy = [{
    name   = "test-inlinepolicy"
    policy = "./policy.json"
  }]
}

#Initialize Terraform
terraform init

#Terraform Dry-Run
terraform plan

#Create the resources
terraform apply

#Destroy the resources saved in the tfstate
terraform destroy
```
## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| assume\_role\_policy | (Optional) "Default : null"The policy that grants an entity permission to assume the role. User need to provide the assume role policy in json file format. | `string` | `null` | no |
| assume\_role\_service\_names | (Optional) "Default : []"Required list of services to create the assume role trust relationship. | `list(any)` | `[]` | no | 
| aws\_create\_iam\_role | (Optional) "Default : true" It will take care to create or skip the IAM Role | `bool` | `true` | no |
| force\_detach\_policies | (Optional) "Default : false". Specifies to force detaching any policies the role has before destroying it. Defaults to false. Allowed values: true/false | `bool` | `false` | no |
| iam\_role\_name | (Required) The name of the role. | `string` | n/a | yes |
| inline\_policy | (Optional) "Default : []" . Configuration block defining an exclusive set of IAM inline policies associated with the IAM role. Defined below. If no blocks are configured, Terraform will ignore any managing any inline policies in this resource. Configuring one empty block (i.e., inline\_policy {}) will cause Terraform to remove all inline policies. | `list(any)` | `[]` | no |
| managed\_policy\_arns | (Optional) "Default : []". Set of exclusive IAM managed policy ARNs to attach to the IAM role. If this attribute is not configured, Terraform will ignore policy attachments to this resource. When configured, Terraform will align the role's managed policy attachments with this set by attaching or detaching managed policies. Configuring an empty set (i.e., managed\_policy\_arns = []) will cause Terraform to remove all managed policy attachments. | `list(any)` | `[]` | no |
| max\_session\_duration | (Optional) " Default : 3600". The maximum session duration (in seconds) that you want to set for the specified role. If you do not specify a value for this setting, the default maximum of one hour (3600 sec) is applied. This setting can have a value from 3600 to 43200 seconds. | `number` | `3600` | no |
| path | (Optional) "Default : "/"".Path to the role. | `string` | `"/"` | no |
| role\_description | (Required) The description of the role. | `string` | n/a | yes |
| tags | (Required) A mapping of tags to assign to the resource. | `map(any)` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| iamrole\_arn | The Amazon Resource Name (ARN) specifying the role. |
| iamrole\_create\_date | The creation date of the IAM role. |
| iamrole\_description | The description of the role. |
| iamrole\_id | The name of the role. |
| iamrole\_name | The name of the role. |
| iamrole\_unique\_id | The stable and unique string identifying the role. |

## Testing

1. Created a role successfully without inline_policy and managed_policy.
2. Created a role by attaching multiple inline-policies successfully.
3. Created a role by attaching 10 managed policy arn as there is a limit of adding 10 manged policies.
4. Tested role by giving blank for managed policy arn so that all attached managed policies are removed by terraform.
5. Tested role by giving blank (null) for inline_policy so that all attached inline policies are removed by terraform.
