# Anthem DMS Migration Task

This creates  s3 endpoint task from source to target database of AWS DMS (Database Migration Services)

## HIPAA eligibility status

1. AWS DMS (Database MIgration Service) is eligible.

## Security Guardrail reference

[AWS Security Pattern](https://confluence.elevancehealth.com/download/attachments/299009562/Anthem%20AWS%20Security%20Patterns%20-%20Database%20Migration%20Service.docx?api=v2)

# Release Notes:
## New Version  ##

1. Included a module of S3 endpoint.

### Adoption of the New Version ###

### Testing for s3 endpoint :

1. Testing for s3 source endpoint :
	- Create an s3 endpoint
	- If the endpoint_type is source you have to uncomment the parameter <external_table_definition>. 
  - Update <external_table_definition_policy.json> file to meet your metadata definition needs. Once source endpoint(s3 integration) is created, add security group to the source instance and do another apply.
	- Re-run the connectivity test.
2. Testing for s3 Target endpoint :
	- Create an s3 endpoint
	- Once target endpoint(s3 integration) is created, add security group to the target instance and do another apply..
	- Re-run the connectivity test.
3. Kindly pass the s3 bucket name in the parameter <bucket_name>

## Usage

To run this example you need to execute:

```bash
#Initialize Terraform
terraform init

#Terraform Dry-Run
terraform plan

#Create the resources
terraform apply

#Destroy the resources saved in the tfstate
terraform destroy
## Providers

| Name | Version |
|------|---------|
| aws | n/a |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| add\_column\_name | (Optional) Whether to add column name information to the .csv output file. Default is false. | `bool` | `false` | no |
| add\_trailing\_padding\_character | (Optional) Whether to add padding. Default is false. (Ignored for source endpoints.) | `bool` | `false` | no |
| bucket\_folder | (Optional) S3 object prefix. | `string` | `""` | no |
| bucket\_name | (Required) S3 bucket name. | `string` | n/a | yes |
| canned\_acl\_for\_objects | (Optional) Predefined (canned) access control list for objects created in an S3 bucket. Valid values include none, private, public-read, public-read-write, authenticated-read, aws-exec-read, bucket-owner-read, and bucket-owner-full-control. Default is none. | `string` | `null` | no |
| cdc\_inserts\_and\_updates | (Optional) Whether to write insert and update operations to .csv or .parquet output files. Default is false. | `bool` | `false` | no |
| cdc\_inserts\_only | (Optional) Whether to write insert operations to .csv or .parquet output files. Default is false. | `bool` | `false` | no |
| cdc\_max\_batch\_interval | (Optional) Maximum length of the interval, defined in seconds, after which to output a file to Amazon S3. (AWS default is 60.) | `number` | `60` | no |
| cdc\_min\_file\_size | (Optional) Minimum file size condition as defined in kilobytes to output a file to Amazon S3. (AWS default is 32000 KB.) | `number` | `32000` | no |
| cdc\_path | (Required for CDC; otherwise, Optional) Folder path of CDC files. If cdc\_path is set, AWS DMS reads CDC files from this path and replicates the data changes to the target endpoint. Supported in AWS DMS versions 3.4.2 and later. | `string` | `""` | no |
| certificate\_arn | (Optional, Default: empty string) ARN for the certificate. | `string` | `""` | no |
| compression\_type | (Optional) Set to compress target files. Valid values are GZIP and NONE. Default is NONE. (Ignored for source endpoints.) | `string` | `"NONE"` | no |
| csv\_delimiter | (Optional) Delimiter used to separate columns in the source files. Default is ,. | `string` | `","` | no |
| csv\_no\_sup\_value | (Optional) Only applies if output files for a CDC load are written in .csv format. If use\_csv\_no\_sup\_value is set to true, string to use for all columns not included in the supplemental log. If you do not specify a string value, DMS uses the null value for these columns regardless of use\_csv\_no\_sup\_value. (Ignored for source endpoints.) | `string` | `null` | no |
| csv\_null\_value | (Optional) String to as null when writing to the target. (AWS default is NULL.) | `string` | `null` | no |
| csv\_row\_delimiter | (Optional) Delimiter used to separate rows in the source files. Default is newline (i.e., <br>). | `string` | `"\n"` | no |
| data\_format | (Optional) Output format for the files that AWS DMS uses to create S3 objects. Valid values are csv and parquet. (Ignored for source endpoints -- only csv is valid.) | `string` | `"parquet"` | no |
| data\_page\_size | (Optional) Size of one data page in bytes. (AWS default is 1 MiB, i.e., 1048576.) | `number` | `1048576` | no |
| date\_partition\_delimiter | (Optional) Date separating delimiter to use during folder partitioning. Valid values are SLASH, UNDERSCORE, DASH, and NONE. (AWS default is SLASH.) (Ignored for source endpoints.) | `string` | `"SLASH"` | no |
| date\_partition\_enabled | (Optional) Partition S3 bucket folders based on transaction commit dates. Default is false. (Ignored for source endpoints.) | `bool` | `false` | no |
| date\_partition\_sequence | (Optional) Date format to use during folder partitioning. Use this parameter when date\_partition\_enabled is set to true. Valid values are YYYYMMDD, YYYYMMDDHH, YYYYMM, MMYYYYDD, and DDMMYYYY. (AWS default is YYYYMMDD.) (Ignored for source endpoints.) | `string` | `"YYYYMMDD"` | no |
| date\_partition\_timezone | (Optional) Convert the current UTC time to a timezone. The conversion occurs when a date partition folder is created and a CDC filename is generated. The timezone format is Area/Location (e.g., Europe/Paris). Use this when date\_partition\_enabled is true. (Ignored for source endpoints.) | `string` | `"Asia/Seoul"` | no |
| dict\_page\_size\_limit | (Optional) Maximum size in bytes of an encoded dictionary page of a column. (AWS default is 1 MiB, i.e., 1048576.) | `number` | `1048576` | no |
| enable\_statistics | (Optional) Whether to enable statistics for Parquet pages and row groups. Default is true. | `bool` | `true` | no |
| encoding\_type | (Optional) Type of encoding to use. Value values are rle\_dictionary, plain, and plain\_dictionary. (AWS default is rle\_dictionary.) | `string` | `"rle-dictionary"` | no |
| encryption\_mode | (Optional) Server-side encryption mode that you want to encrypt your .csv or .parquet object files copied to S3. Valid values are SSE\_S3 and SSE\_KMS. (AWS default is SSE\_S3.) (Ignored for source endpoints -- only SSE\_S3 is valid.) | `string` | `"SSE_S3"` | no |
| endpoint\_id | (Required) Database endpoint identifier. Identifiers must contain from 1 to 255 alphanumeric characters or hyphens, begin with a letter, contain only ASCII letters, digits, and hyphens, not end with a hyphen, and not contain two consecutive hyphens. | `string` | n/a | yes |
| endpoint\_type | (Required) Type of endpoint. Valid values are source, target.. | `string` | n/a | yes |
| expected\_bucket\_owner | (Optional) Bucket owner to prevent sniping. Value is an AWS account ID. | `string` | `""` | no |
| external\_table\_definition | (Required for source endpoints; otherwise, Optional) JSON document that describes how AWS DMS should interpret the data. | `string` | `""` | no |
| ignore\_header\_rows | (Optional, Force New) When this value is set to 1, DMS ignores the first row header in a .csv file. (AWS default is 0.) | `number` | `0` | no |
| include\_op\_for\_full\_load | (Optional) Whether to enable a full load to write INSERT operations to the .csv output files only to indicate how the rows were added to the source database. Default is false. | `bool` | `false` | no |
| kms\_key\_arn | (Optional) ARN for the KMS key that will be used to encrypt the connection parameters. If you do not specify a value for kms\_key\_arn, then AWS DMS will use your default encryption key. AWS KMS creates the default encryption key for your AWS account. Your AWS account has a different default encryption key for each AWS region. | `string` | `null` | no |
| max\_file\_size | (Optional) Maximum size (in KB) of any .csv file to be created while migrating to an S3 target during full load. Valid values are from 1 to 1048576. (AWS default is 1 GB, i.e., 1048576.) | `number` | `1048576` | no |
| parquet\_timestamp\_in\_millisecond | (Optional) - Specifies the precision of any TIMESTAMP column values written to an S3 object file in .parquet format. Default is false. (Ignored for source endpoints.) | `bool` | `false` | no |
| parquet\_version | (Optional) Version of the .parquet file format. Valid values are parquet-1-0 and parquet-2-0. (AWS default is parquet-1-0.) (Ignored for source endpoints.) | `string` | `"parquet-1-0"` | no |
| preserve\_transactions | (Optional) Whether DMS saves the transaction order for a CDC load on the S3 target specified by cdc\_path. Default is false. (Ignored for source endpoints.) | `bool` | `false` | no |
| rfc\_4180 | (Optional) For an S3 source, whether each leading double quotation mark has to be followed by an ending double quotation mark. Default is true. | `bool` | `true` | no |
| row\_group\_length | (Optional) Number of rows in a row group. (AWS default is 10000.) | `number` | `10000` | no |
| server\_side\_encryption\_kms\_key\_id | (Optional) When encryption\_mode is SSE\_KMS, ARN for the AWS KMS key. (Ignored for source endpoints -- only SSE\_S3 encryption\_mode is valid.) | `string` | n/a | yes |
| service\_access\_role\_arn | (Required) ARN of the IAM role with permissions to the S3 Bucket. | `string` | n/a | yes |
| ssl\_mode | (Optional) SSL mode to use for the connection. Valid values are none, require, verify-ca, verify-full. (AWS default is none.) | `string` | `"none"` | no |
| tags | A map of tags to assign to the resource. | `map(string)` | `{}` | no |
| timestamp\_column\_name | (Optional) Column to add with timestamp information to the endpoint data for an Amazon S3 target. | `string` | `""` | no |
| use\_csv\_no\_sup\_value | (Optional) Whether to use csv\_no\_sup\_value for columns not included in the supplemental log. (Ignored for source endpoints.) | `bool` | `false` | no |
| use\_task\_start\_time\_for\_full\_load\_timestamp | (Optional) When set to true, uses the task start time as the timestamp column value instead of the time data is written to target. For full load, when set to true, each row of the timestamp column contains the task start time. For CDC loads, each row of the timestamp column contains the transaction commit time.When set to false, the full load timestamp in the timestamp column increments with the time data arrives at the target. Default is false. | `bool` | `false` | no |

## Outputs

| Name | Description |
|------|-------------|
| endpoint\_arn | The Amazon Resource Name (ARN) for the endpoint. |
| engine\_display\_name | Expanded name for the engine name. |
| status | Expanded name for the engine name. |
| tags\_all | Expanded name for the engine name. |