# Anthem DMS Replication Instance Base Code

This creates Replication instance of AWS DMS (Database Migration Services)

## HIPPA eligibility status

1. AWS DMS (Database Migration Service) is eligible.

## Security Guardrail reference

[AWS Security Pattern](https://confluence.elevancehealth.com/download/attachments/299009562/Anthem%20AWS%20Security%20Patterns%20-%20Database%20Migration%20Service.docx?api=v2)

# Release Notes:
## New Version - 0.0.5
1. With Mandatory Tags Redesign that happened early part of this year, we had to refactor all our templates to include central Mandatory Tag Module and remove variable references from the code.
2. All the new templates has been pushed in and you should be able to see the changes. Below are the highlights. 

### Adoption of the New Version - 0.0.5

1.	There is a new file tags.tf that is now included and integral part of our code base.
2.	We now have only Application Specific Tags in DMS modules of each templates. The entire code is now bit sleek. 
3.	Each module refers to mandatory tags module.

## Prerequisite
1. IAM Role name "dms-vpc-role" with action "sts:AssumeRole" , identifiers "dms.amazonaws.com" and type "Service".
2. KMS Key is required for encryption.
3. DMS Subnet group is required.
4. Requesting a specific availability zone is not valid for Multi-AZ instances.

## Usage

To run this example you need to execute:

```bash
#Initialize Terraform
terraform init

#Terraform Dry-Run
terraform plan

#Create the resources
terraform apply

#Destroy the resources saved in the tfstate
terraform destroy
```

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|:----:|:-----:|:-----:|
| allocated\_storage | The amount of storage \(in gigabytes\) to be initially allocated for the replication instance. Default : 50 , Min : 5, Max : 6144 | string | n/a | yes |
| apply\_immediately | Indicates whether the changes should be applied immediately or during the next maintenance window. Only used when updating an existing resource.Default is false. | string | n/a | yes |
| auto\_minor\_version\_upgrade | Indicates that minor engine upgrades will be applied automatically to the replication instance during the maintenance window. | string | n/a | yes |
| availability\_zone | The EC2 Availability Zone that the replication instance will be created in | string | n/a | yes |
| engine\_version | The engine version number of the replication instance. | string | n/a | yes |
| kms\_key\_arn | The Amazon Resource Name \(ARN\) for the KMS key that will be used to encrypt the connection parameters. If you do not specify a value for kms\_key\_arn, then AWS DMS will use your default encryption key. AWS KMS creates the default encryption key for your AWS account. Your AWS account has a different default encryption key for each AWS region. | string | n/a | yes |
| multi\_az | Specifies if the replication instance is a multi-az deployment. You cannot set the availability\_zone parameter if the multi\_az parameter is set to true. | string | n/a | yes |
| preferred\_maintenance\_window | The weekly time range during which system maintenance can occur, in Universal Coordinated Time \(UTC\).  Default: A 30-minute window selected at random from an 8-hour block of time per region, occurring on a random day of the week.  Format: ddd:hh24:mi-ddd:hh24:mi   Valid Days: mon, tue, wed, thu, fri, sat, sun   Constraints: Minimum 30-minute window. | string | n/a | yes |
| replication\_instance\_class | The compute and memory capacity of the replication instance as specified by the replication instance class. Can be one of dms.t2.micro \| dms.t2.small \| dms.t2.medium \| dms.t2.large \| dms.c4.large \| dms.c4.xlarge \| dms.c4.2xlarge \| dms.c4.4xlarge | string | n/a | yes |
| replication\_instance\_id | The replication instance identifier. This parameter is stored as a lowercase string.   Must contain from 1 to 63 alphanumeric characters or hyphens.   First character must be a letter.   Cannot end with a hyphen   Cannot contain two consecutive hyphens. | string | n/a | yes |
| replication\_subnet\_group\_id | A subnet group to associate with the replication instance. | string | n/a | yes |
| tags | A mapping of tags to assign to the resource. | map | `<map>` | yes |
| vpc\_security\_group\_ids | A list of VPC security group IDs to be used with the replication instance. The VPC security groups must work with the VPC containing the replication instance. | list | n/a | yes |
| application | Based upon application nomenclature in server naming convention policy.Use up to six \(6\) characters to name your application. | string | n/a | yes |
| application\_dl | Application DL | string | n/a | yes |
| barometer-it-num | The barometer it number. | string | n/a | yes |
| company | Company that owns resource | string | n/a | yes |
| compliance | PHI, PCI, PII, SOX, None | string | n/a | yes |
| costcenter | The project cost center. | string | n/a | yes |
| description | The description of the key as viewed in AWS console. | string | n/a | yes |
| environment | DBx,SIT,PERF,PRODX,UAT,UTILx | string | n/a | yes |
| it-department | The name of IT department | string | n/a | yes |
| layer | WEBx, MWx, DBx, UTILx | string | n/a | yes |
| owner-department | The name of department owner. | string | n/a | yes |
| resource-type | Type of resource. | string | n/a | yes |


## Outputs

| Name | Description |
|------|-------------|
| replication\_instance\_arn | The Amazon Resource Name \(ARN\) of the replication instance. |
| replication\_instance\_private\_ips | A list of the private IP addresses of the replication instance. |
| replication\_instance\_public\_ips | A list of the public IP addresses of the replication instance. |


## Unit Testing
1. Replication instance created with KMS Key , preferred_maintenance_window, Instance Class, VPC Security Group Id using terrform script.
2. Same replication Instance used for creating endpoint for source and target.
3. KMS Key validation (its existance in account) is done successfully.