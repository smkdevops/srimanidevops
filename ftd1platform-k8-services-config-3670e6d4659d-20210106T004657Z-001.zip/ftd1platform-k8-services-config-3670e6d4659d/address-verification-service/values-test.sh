BASE_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
. ${BASE_DIR}/values.sh
envName="test"
groupName="test"
cpu="0.5"
memory="0.5Gi"
imageTag="latest"
staticIPAddress="10.82.216.193"
maxReplicas=2
gcpProjectId="gcp-ftd-nonprod-gke"
gcpDBProjectId="gcp-ftd-nonprod-db"
gcpPubSubProjectId="gcp-ftd-nonprod-pubsub"
clusterName="nonprod-gke-primary-1"
