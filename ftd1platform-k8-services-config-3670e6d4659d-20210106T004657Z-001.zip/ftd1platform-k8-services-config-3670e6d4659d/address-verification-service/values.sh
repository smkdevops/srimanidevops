replicas=1
appName="address-verification"
cpu="0.5"
memory="0.5Gi"
imageTag="latest"
gcpProjectId="quality-assurance-191019"
gcpDBProjectId="quality-assurance-191019"
gcpPubSubProjectId="quality-assurance-191019"
registryProjectId="gcp-ftd-prod-devops"
minReplicas=1
maxReplicas=2
clusterName="nonprod1"
affinityLabel="placeHolder"
JAVA_ARGS="-Dsun.net.inetaddr.ttl=30 -XX:+UseG1GC -XX:MaxGCPauseMillis=200  -Dlogging.level.com.ftd.commons.logging.aspect=ERROR  -Djava.io.tmpdir=\/dev\/shm"
rcpu="0.5"
lcpu="1"
initialHealthCheckDelay="180"
