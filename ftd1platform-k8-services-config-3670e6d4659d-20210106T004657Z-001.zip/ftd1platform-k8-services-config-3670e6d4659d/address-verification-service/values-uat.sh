BASE_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
. ${BASE_DIR}/values.sh
envName="uat"
groupName="uat"
gcpProjectId="gcp-ftd-preprod-gke"
gcpDBProjectId="gcp-ftd-preprod-db"
gcpPubSubProjectId="gcp-ftd-preprod-pubsub"
registryProjectId="gcp-ftd-prod-devops"
cpu="0.5"
memory="0.5Gi"
staticIPAddress="10.93.250.50"
minReplicas=1
maxReplicas=1
imageTag="qa1-24.2018-10-14-17-54"

clusterRegion="us-central1"
clusterName="preprod-gke-primary-1"
