BASE_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
. ${BASE_DIR}/values.sh
envName="prod"
groupName="prod1"
gcpProjectId="gcp-ftd-prod-gke"
gcpDBProjectId="gcp-ftd-prod-db"
gcpPubSubProjectId="gcp-ftd-prod-pubsub"
registryProjectId="gcp-ftd-prod-devops"
cpu="0.5"
memory="3.5Gi"
staticIPAddress="10.89.138.74"
clusterRegion="us-central1"
minReplicas="4"
maxReplicas="20"
initialHealthCheckDelay="120"
clusterName="prod-gke-primary-1"
rcpu="1"
lcpu="3"




imageTag="uat-qa1-156.2019-12-19-11-58"
