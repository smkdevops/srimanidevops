BASE_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
. ${BASE_DIR}/values.sh
envName="dev1"
groupName="dev1"
staticIPAddress="10.82.216.126"
maxReplicas=2
minReplicas=2
gcpProjectId="gcp-ftd-nonprod-gke"
gcpDBProjectId="gcp-ftd-nonprod-db"
gcpPubSubProjectId="gcp-ftd-nonprod-pubsub"
cpu="100m"
memory="0.2Gi"

clusterRegion="us-central1"
clusterName="nonprod-gke-primary-1"
affinityLabel="us-c1-np2"
enableDebugger="false"
enableProfiler="false"
lcpu="3"
initialHealthCheckDelay="80"
rcpu="0.5"
imageTag="dev1-287.2020-01-10-16-54"
imageTag="v1"
