BASE_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
. ${BASE_DIR}/values.sh
envName="stag"
groupName="stag2"
gcpProjectId="gcp-ftd-prod-gke"
gcpDBProjectId="gcp-ftd-prod-db"
gcpPubSubProjectId="gcp-ftd-prod-pubsub"
registryProjectId="gcp-ftd-prod-devops"
maxReplicas=1
memory="3.5Gi"
staticIPAddress="10.89.144.77"
cpu="1000m"
minReplicas="1"

clusterRegion="us-west1"
clusterName="prod-gke-primary-2"
imageTag="uat-qa1-156.2019-12-19-11-58"
