BASE_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
. ${BASE_DIR}/values.sh
envName="prod"
groupName="prod3"
gcpProjectId="gcp-ftd-prod-gke"
gcpDBProjectId="gcp-ftd-prod-db"
gcpPubSubProjectId="gcp-ftd-prod-pubsub"
registryProjectId="gcp-ftd-prod-devops"
cpu="0.5"
memory="0.5Gi"
staticIPAddress="10.93.228.12"
minReplicas=2
maxReplicas=2
clusterName="prod-gke-primary-2"
clusterRegion="us-west1"
lcpu="3"
initialHealthCheckDelay="120"
rcpu="0.5"

MongoServer="prod-mdb-cachewarmer-pt0b4.gcp.mongodb.net"
imageTag="v1-mongo"
