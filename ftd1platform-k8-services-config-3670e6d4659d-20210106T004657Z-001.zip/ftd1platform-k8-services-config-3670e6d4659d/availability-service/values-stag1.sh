BASE_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
. ${BASE_DIR}/values.sh
envName="stag"
groupName="stag1"
gcpProjectId="gcp-ftd-prod-gke"
gcpDBProjectId="gcp-ftd-prod-db"
gcpPubSubProjectId="gcp-ftd-prod-pubsub"
registryProjectId="gcp-ftd-prod-devops"
cpu="0.5"
staticIPAddress="10.89.138.37"
minReplicas=1
maxReplicas=1

clusterRegion="us-central1"
clusterName="prod-gke-primary-1"
memory="3.5Gi"
imageTag="uat-qa1-87.2019-12-10-16-02"
