BASE_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
. ${BASE_DIR}/values.sh
envName="prod"
groupName="prod3A"
gcpProjectId="gcp-ftd-prod-gke"
gcpDBProjectId="gcp-ftd-prod-db"
gcpPubSubProjectId="gcp-ftd-prod-pubsub"
registryProjectId="gcp-ftd-prod-devops"
cpu="0.5"
memory="0.5Gi"
minReplicas=3
maxReplicas=10
clusterName="prod-gke-primary-2"
imageTag="uat-qa1-25.2018-05-01-19-04"
staticIPAddress="10.89.144.115"
