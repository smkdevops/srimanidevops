BASE_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
. ${BASE_DIR}/values.sh
envName="qa2"
groupName="qa2"
staticIPAddress="10.82.216.167"
maxReplicas=2
gcpProjectId="gcp-ftd-nonprod-gke"
gcpDBProjectId="gcp-ftd-nonprod-db"
gcpPubSubProjectId="gcp-ftd-nonprod-pubsub"
cpu="100m"
memory="0.2Gi"

clusterRegion="us-central1"
clusterName="nonprod-gke-primary-1"
affinityLabel="us-c1-np2"
imageTag="qa2-17.2019-05-16-15-03"
lcpu="3"
initialHealthCheckDelay="130"
rcpu="0.5"
