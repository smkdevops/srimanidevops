BASE_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
. ${BASE_DIR}/values.sh
envName="qa3"
groupName="qa3"
staticIPAddress="10.82.216.168"
maxReplicas=2
gcpProjectId="gcp-ftd-nonprod-gke"
gcpDBProjectId="gcp-ftd-nonprod-db"
gcpPubSubProjectId="gcp-ftd-nonprod-pubsub"
cpu="100m"
memory="0.2Gi"
imageTag="qa3-9.2018-12-06-15-41"

clusterRegion="us-central1"
lcpu="0.75"
rcpu="0.75"
clusterName="nonprod-gke-primary-1"
