BASE_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
. ${BASE_DIR}/values.sh
envName="dev1"
groupName="dev1"
staticIPAddress="10.82.216.169"
maxReplicas=2
gcpProjectId="gcp-ftd-nonprod-gke"
gcpDBProjectId="gcp-ftd-nonprod-db"
gcpPubSubProjectId="gcp-ftd-nonprod-pubsub"
cpu="100m"
memory="0.2Gi"

clusterRegion="us-central1"
clusterName="nonprod-gke-primary-1"
affinityLabel="us-c1-np2"
lcpu="3"
initialHealthCheckDelay="130"
rcpu="0.5"
imageTag="dev1-222.2020-01-10-14-45"
