replicas=1
appName="bl-import-service"
cpu="0.5"
memory="0.5Gi"
imageTag="latest"
gcpProjectId="quality-assurance-191019"
gcpDBProjectId="quality-assurance-191019"
gcpPubSubProjectId="quality-assurance-191019"
registryProjectId="gcp-ftd-prod-devops"
minReplicas=1
maxReplicas=2
clusterName="nonprod1"
affinityLabel="placeHolder"
JAVA_ARGS="-Dsun.net.inetaddr.ttl=30 -Xms512m -Xmx4096m"
