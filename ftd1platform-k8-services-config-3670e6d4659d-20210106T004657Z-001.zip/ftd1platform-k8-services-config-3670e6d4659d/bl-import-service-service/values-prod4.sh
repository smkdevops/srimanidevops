BASE_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
. ${BASE_DIR}/values.sh
envName="prod"
groupName="prod4"
gcpProjectId="gcp-ftd-prod-gke"
gcpDBProjectId="gcp-ftd-prod-db"
gcpPubSubProjectId="gcp-ftd-prod-pubsub"
registryProjectId="gcp-ftd-prod-devops"
cpu="0.5"
imageTag="latest"
staticIPAddress="10.93.228.13"
minReplicas=3
maxReplicas=10
clusterName="prod-gke-primary-2"
memory="3.5Gi"
