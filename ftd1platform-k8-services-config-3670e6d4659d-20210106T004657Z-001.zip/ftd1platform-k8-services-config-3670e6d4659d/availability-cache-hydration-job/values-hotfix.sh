imageTag="uat-qa1-13.2018-05-08-20-14"
lcpu="0.75"
rcpu="0.75"
