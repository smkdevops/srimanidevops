BASE_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
. ${BASE_DIR}/values.sh
envName="qa1"
groupName="qa1"
staticIPAddress="10.80.33.40"
gcpProjectId="gcp-ftd-nonprod-gke"
gcpDBProjectId="gcp-ftd-nonprod-db"
gcpPubSubProjectId="gcp-ftd-nonprod-pubsub"
registryProjectId="gcp-ftd-prod-devops"
minReplicas=1
maxReplicas=2
cpu="100m"
memory="0.2Gi"
lcpu="0.75"
rcpu="0.75"
clusterName="nonprod-gke-primary-1"
affinityLabel="nonprod-gke-primary-2"
imageTag="qa1-23.2019-05-16-17-05"
