BASE_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
. ${BASE_DIR}/values.sh
envName="prod"
groupName="prod1"
staticIPAddress="10.180.33.11"

gcpProjectId="gcp-ftd-prod-gke"
gcpDBProjectId="gcp-ftd-prod-db"
gcpPubSubProjectId="gcp-ftd-prod-pubsub"
registryProjectId="gcp-ftd-prod-devops"
maxReplicas=10
minReplicas="1"
memory="0.5Gi"
cpu="1000m"
initialHealthCheckDelay="120"
clusterName="prod-gke-primary-1"
imageTag="uat-qa1-19.2019-05-13-18-14"
