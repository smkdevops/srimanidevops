BASE_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
. ${BASE_DIR}/values.sh
envName="qa3"
groupName="qa3"
imageTag="dev1-124.2018-05-11-09-30"
staticIPAddress="10.82.216.96"
maxReplicas=2
gcpProjectId="gcp-ftd-nonprod-gke"
gcpDBProjectId="gcp-ftd-nonprod-db"
gcpPubSubProjectId="gcp-ftd-nonprod-pubsub"
cpu="100m"
memory="0.2Gi"

clusterRegion="us-central1"
lcpu="0.75"
rcpu="0.75"
clusterName="nonprod-gke-primary-1"
