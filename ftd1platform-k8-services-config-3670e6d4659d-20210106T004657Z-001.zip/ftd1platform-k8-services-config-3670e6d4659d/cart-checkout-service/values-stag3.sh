BASE_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
. ${BASE_DIR}/values.sh
envName="stag"
groupName="stag3"
gcpProjectId="gcp-ftd-prod-gke"
gcpDBProjectId="gcp-ftd-prod-db"
gcpPubSubProjectId="gcp-ftd-prod-pubsub"
registryProjectId="gcp-ftd-prod-devops"
cpu="0.5"
memory="0.5Gi"
imageTag="latest"
staticIPAddress="10.91.168."
minReplicas=1
maxReplicas=1
CartToken="true"
clusterName="prod-gke-primary-3"

clusterRegion="europe-west2"
