BASE_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
. ${BASE_DIR}/values.sh
envName="prod"
groupName="prod4A"
gcpProjectId="gcp-ftd-prod-gke"
gcpDBProjectId="gcp-ftd-prod-db"
gcpPubSubProjectId="gcp-ftd-prod-pubsub"
registryProjectId="gcp-ftd-prod-devops"
cpu="0.5"
memory="0.5Gi"
minReplicas=3
maxReplicas=10
clusterName="prod-gke-primary-2"
MongoServer="prodpci-mdb-cart-ldo8e.gcp.mongodb.net"
imageTag="uat-qa1-29.2018-05-03-09-01"
CartToken="true"
staticIPAddress="10.89.144.100"
