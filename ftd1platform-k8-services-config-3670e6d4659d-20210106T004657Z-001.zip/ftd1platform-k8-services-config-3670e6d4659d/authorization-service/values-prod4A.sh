BASE_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
. ${BASE_DIR}/values.sh
envName="prod"
groupName="prod4A"
gcpProjectId="gcp-ftd-prod-gke"
gcpDBProjectId="gcp-ftd-prod-db"
gcpPubSubProjectId="gcp-ftd-prod-pubsub"
registryProjectId="gcp-ftd-prod-devops"
cpu="0.5"
memory="0.5Gi"
minReplicas=3
maxReplicas=10
clusterName="prod-gke-primary-2"
imageTag="qa1-22.2018-05-03-07-01"
staticIPAddress="10.89.144.98"
