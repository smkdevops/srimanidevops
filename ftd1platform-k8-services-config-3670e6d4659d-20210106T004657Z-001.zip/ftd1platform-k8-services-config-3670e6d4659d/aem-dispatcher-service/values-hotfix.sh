cpu="100m"
memory="0.2Gi"

clusterRegion="us-central1"
imageTag="uat-qa3-11.2018-07-09-08-55"
lcpu="0.75"
rcpu="0.75"
