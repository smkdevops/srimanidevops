BASE_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
. ${BASE_DIR}/values.sh

envName="prod"
groupName="prod2"
gcpProjectId="gcp-ftd-prod-gke"
gcpDBProjectId="gcp-ftd-prod-db"
gcpPubSubProjectId="gcp-ftd-prod-pubsub"
registryProjectId="gcp-ftd-prod-devops"
staticIPAddress="10.89.220.11"
maxReplicas=10
minReplicas="2"
imageTag="uat-qa3-11.2018-07-09-08-55"
cpu="1000m"

clusterRegion="us-central1"
initialHealthCheckDelay="120"
clusterName="prod-gke-primary-1"
rcpu="0.5"
lcpu="3"
memory="3.5Gi"
