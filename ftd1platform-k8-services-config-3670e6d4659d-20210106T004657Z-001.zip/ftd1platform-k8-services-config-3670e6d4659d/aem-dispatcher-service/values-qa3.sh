BASE_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
. ${BASE_DIR}/values.sh
envName="qa3"
groupName="qa3"
cpu="0.5"
memory="0.5Gi"
#staticIPAddress="10.82.216.49"
minReplicas=2
maxReplicas=2
gcpProjectId="gcp-ftd-nonprod-gke"
gcpDBProjectId="gcp-ftd-nonprod-db"
gcpPubSubProjectId="gcp-ftd-nonprod-pubsub"
imageTag="qa3-11.2018-07-09-08-55"

clusterRegion="us-central1"
lcpu="0.75"
rcpu="0.75"
clusterName="nonprod-gke-primary-1"
