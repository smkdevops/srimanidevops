BASE_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
. ${BASE_DIR}/values.sh
envName="stress"
groupName="stress"
cpu="0.5"
memory="0.5Gi"
#staticIPAddress="10.82.216.49"
gcpProjectId="gcp-ftd-preprod-gke"
gcpDBProjectId="gcp-ftd-preprod-db"
gcpPubSubProjectId="gcp-ftd-preprod-pubsub"
imageTag="uat-qa3-11.2018-07-09-08-55"

clusterRegion="us-central1"
minReplicas="2"
replicas=2
lcpu="1.5"
rcpu="0.75"
clusterName="preprod-gke-primary-1"
maxReplicas="20"
