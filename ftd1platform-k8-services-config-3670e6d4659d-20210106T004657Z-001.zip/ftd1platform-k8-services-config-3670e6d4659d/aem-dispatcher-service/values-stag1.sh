minReplicas="1"
cpu="1000m"

clusterRegion="us-central1"
clusterName="prod-gke-primary-1"
memory="3.5Gi"
