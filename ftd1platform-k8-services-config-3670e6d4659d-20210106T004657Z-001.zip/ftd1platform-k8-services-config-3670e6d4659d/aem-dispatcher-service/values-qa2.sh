cpu="100m"
memory="0.2Gi"

clusterRegion="us-central1"
clusterName="nonprod-gke-primary-1"
affinityLabel="us-c1-np2"
lcpu="3"
initialHealthCheckDelay="130"
rcpu="0.5"
