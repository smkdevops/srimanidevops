BASE_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
. ${BASE_DIR}/values.sh

envName="prod"
groupName="prod3A"
gcpProjectId="gcp-ftd-prod-gke"
gcpDBProjectId="gcp-ftd-prod-db"
gcpPubSubProjectId="gcp-ftd-prod-pubsub"
registryProjectId="gcp-ftd-prod-devops"
staticIPAddress="10.89.220.11"
maxReplicas=10
clusterName="prod-gke-primary-2"
cpu="500m"
minReplicas="2"
memory="0.5Gi"
imageTag="uat-qa3-11.2018-07-09-08-55"
