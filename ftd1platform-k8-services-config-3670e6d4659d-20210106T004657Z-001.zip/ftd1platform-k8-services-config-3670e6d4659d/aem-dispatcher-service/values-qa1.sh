BASE_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
. ${BASE_DIR}/values.sh
envName="qa1"
groupName="qa1"
cpu="0.5"
memory="0.5Gi"
#staticIPAddress="10.82.216.49"
minReplicas=2
maxReplicas=2
gcpProjectId="gcp-ftd-nonprod-gke"
gcpDBProjectId="gcp-ftd-nonprod-db"
gcpPubSubProjectId="gcp-ftd-nonprod-pubsub"
imageTag="qa3-11.2018-07-09-08-55"

clusterRegion="us-central1"
clusterName="nonprod-gke-primary-1"
affinityLabel="nonprod-gke-primary-2"
lcpu="3"
initialHealthCheckDelay="130"
rcpu="0.5"
