staticIPAddress="10.89.144.91"
imageTag="uat-qa3-11.2018-07-09-08-55"
cpu="1000m"
minReplicas="1"

clusterRegion="us-west1"
clusterName="prod-gke-primary-2"
memory="3.5Gi"
