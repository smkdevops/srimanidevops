BASE_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
. ${BASE_DIR}/values.sh
envName="uat"
groupName="uat"
imageTag="latest"
staticIPAddress="10.80.33.47"
cpu="100m"
memory="0.2Gi"
