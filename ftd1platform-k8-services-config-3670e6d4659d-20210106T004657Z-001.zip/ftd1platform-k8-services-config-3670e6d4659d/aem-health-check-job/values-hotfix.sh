imageTag="uat-qa1-3.2018-11-09-05-10"
lcpu="0.75"
rcpu="0.75"
