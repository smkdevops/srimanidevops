replicas=1
appName="aem"
cpu="0.5"
memory="0.5Gi"
imageTag="latest"
gcpProjectId="quality-assurance-191019"
registryProjectId="gcp-ftd-prod-devops"
initialHealthCheckDelay="180"
