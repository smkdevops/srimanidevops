BASE_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
. ${BASE_DIR}/values.sh
envName="qa3"
groupName="qa3"
cpu="100m"
memory="0.2Gi"
imageTag="latest"
staticIPAddress="10.82.216.42"
maxReplicas=2
gcpProjectId="gcp-ftd-nonprod-gke"
gcpDBProjectId="gcp-ftd-nonprod-db"
gcpPubSubProjectId="gcp-ftd-nonprod-pubsub"
clusterName="nonprod-gke-primary-1"
