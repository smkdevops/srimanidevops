BASE_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
. ${BASE_DIR}/values.sh
envName="uat"
groupName="uat"
cpu="100m"
memory="0.2Gi"
imageTag="latest"
staticIPAddress="10.82.216.213"
maxReplicas=2
gcpProjectId="gcp-ftd-nonprod-gke"
gcpDBProjectId="gcp-ftd-nonprod-db"
gcpPubSubProjectId="gcp-ftd-nonprod-pubsub"
clusterName="nonprod-gke-primary-1"

clusterRegion="us-central1"
