
clusterRegion="us-central1"
imageTag="latest"
lcpu="0.75"
rcpu="0.75"
