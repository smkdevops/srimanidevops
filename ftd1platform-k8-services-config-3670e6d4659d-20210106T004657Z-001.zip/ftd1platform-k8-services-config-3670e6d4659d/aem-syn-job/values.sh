replicas=1
imageTag="v1"
registryProjectId="gcp-ftd-prod-devops"